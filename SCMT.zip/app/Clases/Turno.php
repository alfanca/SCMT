<?php

namespace App\Clases;

use App\Models\LocomotoraDisponibilidad;
use Illuminate\Http\Request;

class Turno
{
	const TURNOS = array('I', 'II', 'III');

    public static function obtenerTurnoSegunHora($hora_in){
    $hora = date("H:i", time());

    switch ($hora) {
      case ($hora >= '23:00' and $hora <= '24:00' ) :
        return 'I';
        break;
      case ($hora >= '00:00' and $hora < '07:00' ) :
        return 'I';
        break;
      case ($hora >= '07:00' and $hora < '15:00' ) :
        return 'II';
        break;
      default:
        return 'III';
        break;
    }
  }
}
