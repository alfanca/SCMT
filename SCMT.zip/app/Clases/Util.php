<?php
namespace App\Clases;

class Util{

	public static function crearArrayParaWhereIn($coleccion, $indice){
		$valores = $coleccion->pluck($indice);
        $whereIn = '';
        foreach ($valores as $id => $valor) {
            if ($id === 0)
                $whereIn = $valor;
            else
                $whereIn = $whereIn.','.$valor;
        }
        return $whereIn;
	}

    public static function promedioTiempo($suma, $divisor){
        $intervalo = $suma / $divisor;
        $segundos  = $intervalo;
        $dias      = intval($segundos/86400);
        $segundos -= $dias * 86400;
        $horas     = intval($segundos/3600);
        $segundos -= $horas * 3600;
        $minutos   = intval($segundos/60);
        $segundos -= $minutos * 60;
        return $dias * 24 + $horas. "." . $minutos;
    }

    public static function strtotimeAHora($suma){
        $segundos  = $suma;
        $dias      = intval($segundos/86400);
        $segundos -= $dias * 86400;
        $horas     = intval($segundos/3600);
        $segundos -= $horas * 3600;
        $minutos   = intval($segundos/60);
        $segundos -= $minutos * 60;
        return $dias * 24 + $horas. ":" . $minutos;
    }

}

