<?php
namespace App\Clases;
use DateTime;

class Fechas {
  public static function darFechaAnterior($fecha, $rango='-1 day'){
    return date ( 'Y-m-d' , strtotime ( $rango , strtotime ( $fecha ) ) );
  }

  public static function darFechaPosterior($fecha, $rango='+1 day'){
    if ($fecha != date('Y-m-d'))
      return date ( 'Y-m-d' , strtotime ( $rango , strtotime ( $fecha ) ) );
    return null;
  }

  public static function validarFecha($dateStr){
    $formato = 'Y-m-d';
    $date = \DateTime::createFromFormat($formato, $dateStr);
    return $date && ($date->format($formato) === $dateStr);
  }

  public static function obtenerValoresDiasNavegacion($fechaAListar=null){
    if (isset($fechaAListar)){
      $fechas['diaanterior'] = self::darFechaAnterior($fechaAListar);
      $fechas['diaPosterior'] = self::darFechaPosterior($fechaAListar);
      $fechas['fechaAListar'] = $fechaAListar;
    }
    else{
      $fechas['diaanterior'] = self::darFechaAnterior(date('Y-m-d'));
      $fechas['fechaAListar'] = date('Y-m-d');
    }
    return $fechas;
  }

  public static function devolverSemanaAnterior($fecha){
    $fechas[] = self::darFechaAnterior($fecha, '-7 day');
    $fechas[] = $fecha;
    return $fechas;
  } 
}