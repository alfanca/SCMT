<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vagones extends Model
{
    protected $table='vagones';
    protected $guarded = [];

    public function getEstatusAttribute($value){
        $estatus = ['No disponible', 'Disponible'];
        return $estatus[$value] ?? '';
    }

    public function tipoLocomotoras(){
    	return ['VOLTEO', 'L/1 P/V', 'L/2 P/V', 'L/3 P/V', 'L/4 P/V', 'CIUDAD PIAR', 'TREN 02', 'TREN 04', 'TREN 06', 'TREN EXTRA CARGADO', 'TREN 01', 'TREN 03', 'TREN 05', 'TREN EXTRA VACIO', 'TALLER DE VAGONES', 'L/1 LLEGADA', 'L/2 LLEGADA', 'TOCOMA'];
    }

    public function estatusLocomotoras(){
    	return [
    		0 => 'No disponible',
    		1 => 'Disponible'
    	];
    }


    public function scopeVisible($query)
    {
        return $query->where('estatus', 1);
    }

    public static function listadoLocomotorasSelect(){
        return self::select('id', 'numero')->orderBy('numero')->get();
    }

}