<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class programas_senales extends Model
{
    protected $table='programas_senales';
    protected $guarded = [];


    static $rules = [
		'programa' => 'required',
		'fecha' => 'required',
		'planificador' => 'required',
		'superintendente' => 'required',
		'jefeplanificacion' => 'required',
		'nota' => '',
        'fecha_fin' => 'required',
        'estatus' => '',
    ];


    public function estatusPrograma(){
        return ['LIBERADA','CERRADA'];
    }

    public static function Getall(){
        return self::select('id', 'programa','fecha', 'fecha_fin','estatus','planificador', 'superintendente', 'jefeplanificacion', 'nota' ,'usuario_crea', 'usuario_actualiza')
                ->where('estatus', 'LIBERADA')
                ->get();
    }

    public static function anualProgramas(){
        return self::select('id', 'programa','fecha', 'fecha_fin','estatus','planificador', 'superintendente', 'jefeplanificacion', 'nota' ,'usuario_crea', 'usuario_actualiza')
                ->whereYear('fecha', now('Y'))
                ->get();
    }


    public function scopeFecha($query, $fecha)
    {
    return $query->whereDate('programa', $fecha);
    }

    public function scopeRangoDeFechas($query, $fechas){
    return $query->whereBetween('programa', $fechas);
    }  

        public static function getAllXPeriodo($rangoFechas, $ano){
        $sql = self::select('id', 'programa', 'fecha', 'fecha_fin','estatus', 'planificador', 'superintendente', 'jefeplanificacion', 'nota' ,'usuario_crea', 'usuario_actualiza');

        if (!empty($rangoFechas and $ano))
            $sql = $sql->RangoDeFechas($rangoFechas)->whereYear('fecha', $ano);

        elseif (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

    
    public function programas_senales_detalles_union()
    {
        return $this->hasMany('App\Models\programas_senales_detalles', 'programa_id', 'id');
    }

    public function datosplanificador()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'planificador');
    }

    public function datossuperintendente()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'superintendente');
    }

    public function datosjefeplanificacion()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'jefeplanificacion');
    }

}
