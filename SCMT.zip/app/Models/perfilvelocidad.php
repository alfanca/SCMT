<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class perfilvelocidad extends Model
{
    protected $table='perfilvelocidads';
    protected $guarded = [];


    public static function estatusPerfil(){
        return ['ABIERTA','CERRADA'];
    }

    public static function getAll($estatus){
    	return self::select('id', 'fechareal', 'kminicial', 'kmfinal', 'velplan', 'velreal', 'nota', 'fecha_fin', 'estatus')
    	        ->selectRaw('((kmfinal - kminicial)*10)*velreal as kmtotal, (kmfinal - kminicial)*10 as resto, kmfinal - kminicial as kmdiftotal, kmfinal - kminicial as total')
                ->where('estatus', $estatus)
    			->get();
    }

    public static function dashboard(){
        return self::select('id', 'fechareal', 'kminicial', 'kmfinal', 'velplan', 'velreal', 'estatus')
                ->selectRaw('((kmfinal - kminicial)*10)*velreal as kmtotal, (kmfinal - kminicial)*10 as resto, kmfinal - kminicial as kmdiftotal, kmfinal - kminicial as total')
                ->where('estatus', 'ABIERTA')
                ->get();
    }

        public static function ultimoregistro(){
        return self::select('updated_at')
                 ->get();
    }

}
