<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class senales_equipos extends Model
{
    protected $table='señales_equipos';
    protected $guarded = [];

     public function conjunto(){
        return ['A','B','C','D','E','F','G'];
    }

    public function tipo(){
        return ['ZPMI','ZPM2'];
    }

    public function lugares(){
        return ['PRINCIPAL','SIDOR','PALUA','PATIO OESTE','PATIO ESTE'];
    }

     public function estatusdelequipo(){
        return ['Disponible','Parcialmente','Mantenimiento'];
    }

    public static function disponibilidadhome(){
        return self::select('id', 'estatus', 'updated_at')
                 ->orderbY('id')
                 ->get();
    }

     public static function ultimoregistro(){
        return self::select('updated_at')
                 ->get();
                 
    }

    public static function equipos_numero(){
        return self::select('id', 'equipo', 'lugar', 'ubicacion','conjunto', 'descripcion', 'estatus', 'mantenimiento','fecha_programa', 'tipo_mant', 'sap_ipdiez')
                 ->selectRaw('fecha_programa + mantenimiento as programa, fecha_programa - mantenimiento as programar')
                 ->whereNotIn('estatus', ['Mantenimiento'])
                 ->whereNotNull('mantenimiento')
                 ->get();
    }

    public static function equipos(){
        return self::select('id', 'equipo', 'lugar', 'ubicacion','conjunto', 'descripcion', 'estatus', 'mantenimiento','fecha_programa', 'tipo_mant', 'sap_ipdiez')
                 ->selectRaw('fecha_programa + mantenimiento as programa')
                 ->get();
    }

}

