<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Locomotora extends Model
{
    protected $table='locomotoras';
    protected $guarded = [];

    public function getEstatusAttribute($value){
        $estatus = ['NO', 'SI'];
        return $estatus[$value] ?? '';
    }

    public function tipoLocomotoras(){
    	return ['2000 HP','4000 HP','4300 HP','4400 HP','4950 HP','S/N'];
    }

    public function centrocosto(){
        return ['202','221','222','241','267','268','272','276'];
    }

    public function estatusLocomotoras(){
    	return [
    		0 => 'NO',
    		1 => 'SI'
    	];
    }


    public function scopeVisible($query)
    {
        return $query->where('estatus', 1);
    }

    public static function listadoLocomotorasSelect(){
        return self::select('id', 'numero','estatus')->where('estatus', false)->orderBy('numero')->get();
    }

    public static function listadoLocomotorasSelectProgramas(){
        return self::select('id', 'numero','estatus','mant')->where('estatus', false)->orderBy('numero')->get();
    }
}

