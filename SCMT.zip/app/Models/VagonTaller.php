<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;

class VagonTaller extends Model
{
    protected $table='vagones_taller';
    protected $guarded = [];


    const EN_LINEA_4 = 1;
    const EN_TALLER = 2;
    const EN_TALLER_REPARADO = 3;

    const ACTIVO = 1;
    const CERRADA = 2;

    protected $casts = [
        'fecha_ingreso' => 'datetime:Y-m-d H:M',
        'fecha_ingreso_taller' => 'datetime:Y-m-d H:M',
        'fecha_reparado_taller' => 'datetime:Y-m-d H:M',
        'fecha_salida_taller' => 'datetime:Y-m-d H:M',
    ];

    public function getFechaIngresoAttribute($fecha){
        return \Carbon\Carbon::parse($fecha)->format('Y-m-d h:i');
    } 

    public function crear($vagones, $fecha, $proyecto_id){
        foreach($vagones as $vagon)
        {                
            $vagon_taller = new Self();
            $vagon_taller->fecha_ingreso = $fecha;
            $vagon_taller->vagones_id = $vagon;
            $vagon_taller->proyecto_id = $proyecto_id;
            $vagon_taller->usuario_c = Auth::user()->name;
            $vagon_taller->save(); 
            
            Vagones::actualizarDisponibilidad($vagon, $fecha, 'Patio vacio', false);
        }
    }

    public static function getActivos(){
        return self::select('id','vagones_id', 'estatus', 'estatus_proceso', 'fecha_ingreso', 'fecha_ingreso_taller','fecha_reparado_taller', 'fecha_salida_taller', 'proyecto_id', 'catalogo_fallas_id')
        			->where('estatus', 1)
        			->get();
    }


     public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha_ingreso_taller', $fecha);
    }

       public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha_ingreso_taller', $fechas);
    } 

    public static function getVagonesRegistradosTaller($rangoFechas){
        return self::select('id','vagones_id', 'estatus', 'estatus_proceso', 'fecha_ingreso', 'fecha_ingreso_taller'               ,'fecha_reparado_taller', 'fecha_salida_taller','created_at', 'proyecto_id', 'catalogo_fallas_id')
                    ->selectRaw('calcularhoras(fecha_reparado_taller,fecha_ingreso_taller) as total')
                    ->RangoDeFechas($rangoFechas)->orderBy('fecha_ingreso_taller')->get();
    }

    public static function detalleTallerProyecto($programaID){
        return self::select('id','vagones_id','estatus','estatus_proceso','fecha_ingreso', 'fecha_ingreso_taller','fecha_reparado_taller','fecha_salida_taller','created_at','proyecto_id')
                    ->where('proyecto_id', $programaID)
                    ->get();
    }

    public function ubicacionTaller(){
        if($this->estatus_proceso == self::EN_LINEA_4)
            return 'LINEA 4';
        elseif($this->estatus_proceso == self::EN_TALLER)
            return 'TALLER DE VAGONES';
        else
            return 'TALLER DE VAGONES REPARADO';
    }

    public function moverVagonTaller($estatus, $fecha){
        if($estatus == self::EN_TALLER)
            $this->fecha_ingreso_taller = $fecha;
        elseif($estatus == self::EN_TALLER_REPARADO)
            $this->fecha_reparado_taller = $fecha;
        else
            $this->fecha_salida_taller = $fecha;
        $this->estatus_proceso = $estatus;
    }   

    public function retornarEstatus(){
        $this->estatus_proceso = $this->estatus_proceso - 1;     
        $fecha = null;
        if($this->estatus_proceso == self::EN_LINEA_4){
            $fecha = $this->fecha_ingreso;
            $this->fecha_ingreso_taller = null;
        }
        elseif($this->estatus_proceso == self::EN_TALLER){
            $fecha = $this->fecha_ingreso_taller;
            $this->fecha_reparado_taller = null;
        }
        else{
            $fecha = $this->fecha_reparado_taller;
            $this->fecha_salida_taller = null;
        }

        return $fecha;
    }
    
    public function verficarVagonReparado(){
        return $this->estatus_proceso == 4 ? 1 : 0;
    }

    public function vagon_proyecto()
    {
        return $this->hasOne('App\Models\proyectovagones', 'id', 'proyecto_id');
    }

}
