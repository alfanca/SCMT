<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProgramaDetalleVium
 *
 * @property $id
 * @property $programa_via_id
 * @property $programa_anual_id
 * @property $fecha
 * @property $plan
 * @property $real
 * @property $nro_orden
 * @property $nota
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property ProgramaActiviadesVium[] $programaActiviadesVias
 * @property ProgramaAnualVium $programaAnualVium
 * @property ProgramaVium $programaVium
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class ProgramaDetalleVium extends Model
{
    
    static $rules = [
		'programa_via_id' => 'required',
		'programa_anual_id' => 'required',
		'fecha' => 'required',
		'plan' => 'required',
		'usuario_crea' => 'required',
    ];

    static $messages = [
        'programa_via_id.required' => 'Falta programa_via_id',
        'programa_anual_id.required' => 'Falta programa_anual_id',
        'fecha.required' => 'Falta la fecha',
        'plan.required' => 'Falta el plan',
        'usuario_crea.required' => 'Falta el usuario',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['programa_via_id','programa_anual_id','fecha','plan','nro_orden','nota','usuario_crea','usuario_actualiza'];


    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    }  

    public static function getAll($rangoFechas){
        $sql = self::select('id','programa_via_id','programa_anual_id','fecha','plan','nro_orden','nota','usuario_crea','usuario_actualiza');

        if (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);

        return $sql;

    }

    public static function detalleprogramacumplimiento($programaID){
        return self::select('id', 'programa_via_id','programa_anual_id','fecha','plan','nro_orden','nota','usuario_crea','usuario_actualiza')
                    ->where('programa_via_id', $programaID) 
                    ->get();
    }

    public static function borradodedetalle($programaId){
       $dato = self::select('id', 'programa_via_id', 'programa_anual_id', 'fecha')
                    ->orderBy('fecha', 'desc')
                    ->where('programa_anual_id', $programaId)
                    ->limit(1)
                    ->first();

        if (!empty($dato))
            return $dato->fecha;
        return null;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function programaActiviadesVias()
    {
        return $this->hasMany('App\Models\ProgramaActiviadesVium', 'programa_detalle_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function programaAnualVium()
    {
        return $this->hasOne('App\Models\ProgramaAnualVium', 'id', 'programa_anual_id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function programaVium()
    {
        return $this->hasOne('App\Models\ProgramaVium', 'id', 'programa_via_id');
    }
    

}
