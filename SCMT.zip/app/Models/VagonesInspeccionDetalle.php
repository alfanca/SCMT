<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;

class VagonesInspeccionDetalle extends Model
{
    protected $table='vagones_inspecciones_detalle';
    protected $guarded = [];

    public function inspeccion()
    {
        return $this->belongsTo(VagonesInspeccion::class, 'vagones_inspecciones_id');
    }

    public function crear($inspeccion, $vagones){
        foreach($vagones as $orden => $vagon)
        {     
            self::verificarSiSeActualizaFechaUltimaUbicacion($inspeccion->fecha, $vagon) && Vagones::actualizarPorInspeccion($vagon, $inspeccion);//

            $vagon_detalle = new Self();
            $vagon_detalle->vagones_inspecciones_id = $inspeccion->id;
            $vagon_detalle->vagones_id = $vagon;
            $vagon_detalle->usuario_c = Auth::user()->name;
            $vagon_detalle->orden = $orden;
            $vagon_detalle->save();             

        }
    }

    public function actualizar($inspeccion, $vagones){
        $orden = $this->getUltimoOrden($inspeccion->id)->orden;
        foreach($vagones as $vagon)
        {     
            self::verificarSiSeActualizaFechaUltimaUbicacion($inspeccion->fecha, $vagon) && Vagones::actualizarPorInspeccion($vagon, $inspeccion);//

            $vagon_detalle = new Self();
            $vagon_detalle->vagones_inspecciones_id = $inspeccion->id;
            $vagon_detalle->vagones_id = $vagon;
            $vagon_detalle->usuario_c = Auth::user()->name;
            $vagon_detalle->orden = ++$orden;
            $vagon_detalle->save();             

        }
    }    

    private function getUltimoOrden($id){
        return $this->selectRaw("max(orden) as orden")
            ->where('vagones_inspecciones_id', $id)->first();
    }


    public static function verificarSiSeActualizaFechaUltimaUbicacion($fecha, $vagon){
        $ultimoRegistro = self::getInfoUltimaUbicacionVagon($vagon) ?? '';
        if ($ultimoRegistro)
            return $ultimoRegistro->inspeccion->hora_salida < $fecha;
        else
            return true;
    }

    public static function getInfoUltimaUbicacionVagon($vagon){
        return self::with('inspeccion')
        ->where('vagones_id', $vagon)
        ->orderBy('created_at', 'desc')
        ->limit(1)
        ->first();
    }
    
}

