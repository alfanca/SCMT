<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProgramaVium
 *
 * @property $id
 * @property $programa
 * @property $fecha_inicio
 * @property $fecha_fin
 * @property $estatus
 * @property $planificador
 * @property $jefesuperintendencia
 * @property $jefeplanificacion
 * @property $nota
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property ProgramaDetalleVium[] $programaDetalleVias
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class ProgramaVium extends Model
{
    
    static $rules = [
		'programa' => 'required',
		'fecha_inicio' => 'required',
		'fecha_fin' => 'required',
		'estatus' => '',
		'planificador' => 'required',
		'jefesuperintendencia' => 'required',
		'jefeplanificacion' => 'required',
		'usuario_crea' => '',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */

    public function datosplanificador()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'planificador');
    }

    public function datosjefeTurnoarea()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'jefesuperintendencia');
    }

    public function datosjefeplanificacion()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'jefeplanificacion');
    }


    protected $fillable = ['programa','fecha_inicio','fecha_fin','estatus','planificador','jefesuperintendencia','jefeplanificacion','nota','usuario_crea','usuario_actualiza'];


    public static function getAll(){
        return self::select('id', 'programa','fecha_inicio','fecha_fin','estatus','planificador','jefesuperintendencia','jefeplanificacion','nota','usuario_crea','usuario_actualiza')
                     ->where('estatus', 'LIBERADA')
                     ->get();
    }

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha_inicio', $fecha);
    }

    public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha_inicio', $fechas);
    }   

    public static function getAllXPeriodo($rangoFechas){

    $sql = self::select('id', 'programa','fecha_inicio','fecha_fin','estatus','planificador','jefesuperintendencia','jefeplanificacion','nota','usuario_crea','usuario_actualiza');

        if (!empty($rangoFechas))
           
            $sql = $sql->RangoDeFechas($rangoFechas);
        
        return $sql;
    }


    public static function selectorActividades(){
        return self::select('id', 'programa', 'estatus')
                ->where('estatus', 'LIBERADA')
                ->get();
    }

    public static function estatus(){
        return ['LIBERADA','CERRADA'];
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function programaActiviadesVias()
    {
        return $this->hasMany('App\Models\ProgramaActiviadesVium', 'programa_id', 'id');
    }
    
}
