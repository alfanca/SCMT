<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProgramaAnualVium
 *
 * @property $id
 * @property $ip10
 * @property $descripcion
 * @property $fecha_actualizacion
 * @property $frecuencia
 * @property $unidad
 * @property $tramo
 * @property $tramo_km_inicio
 * @property $tramo_km_fin
 * @property $plan
 * @property $estatus
 * @property $nota
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property ProgramaActiviadesVium[] $programaActiviadesVias
 * @property ProgramaDetalleVium[] $programaDetalleVias
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class ProgramaAnualVium extends Model
{
    
    static $rules = [
		'descripcion' => 'required',
		'fecha_actualizacion' => '',
		'frecuencia' => 'required',
		'unidad' => 'required',
		'tramo' => 'required',
		'tramo_km_inicio' => 'required',
		'tramo_km_fin' => 'required',
		'plan' => 'required',
		'estatus' => '',
		'usuario_crea' => '',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['ip10','descripcion','fecha_actualizacion','frecuencia','unidad','tramo','tramo_km_inicio','tramo_km_fin','plan','estatus','nota','usuario_crea','usuario_actualiza'];


    public static function getAll($estatus){
        return self::select('id','ip10','descripcion','fecha_actualizacion','frecuencia','unidad','tramo','tramo_km_inicio','tramo_km_fin','plan','estatus','nota','usuario_crea','usuario_actualiza')
                ->selectRaw('fecha_actualizacion + frecuencia as programa')
                ->where('estatus', $estatus)
                ->get();
    }


    public static function selectorAnual(){
        return self::select('id', 'descripcion', 'fecha_actualizacion', 'frecuencia', 'unidad' ,'tramo', 'tramo_km_inicio', 'tramo_km_fin', 'plan', 'estatus')
                ->selectRaw('fecha_actualizacion + frecuencia as programa')
                ->where('estatus', 'ACTIVO')
                ->get();
    }


    public static function estatus(){
        return ['ACTIVO','INACTIVO'];
    }

    public static function tramos(){
        return ['L/P','PALUA','SIDOR','COMSIGUA','BRIQVEN','ORINOCO IRON','PLANTA PELLA','PATIO'];
    }

    public static function inspecciones(){
        return ['INSPECCION A PIE','INSPECCION ALTO RIEL','INSPECCION LOCOMOTORA','INSPECCION CAMBIAVIAS','INSPECCION PUENTE'];
    }

    public static function unidades(){
        return ['KM','EA'];
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function programaActiviadesVias()
    {
        return $this->hasMany('App\Models\ProgramaActiviadesVium', 'programa_anual_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function programaDetalleVias()
    {
        return $this->hasMany('App\Models\ProgramaDetalleVium', 'programa_anual_id', 'id');
    }
    

}
