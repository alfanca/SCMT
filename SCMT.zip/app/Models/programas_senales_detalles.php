<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class programas_senales_detalles extends Model
{
    protected $table='programas_senales_detalles';
    protected $guarded = [];


    static $rules = [
		'equipo_id' => 'required',
		'programa_id' => 'required',
		'fecha' => 'required',
		'cumplimiento' => 'required',
		'nota' => 'max:500',
        'n_orden' => '',
    ];


    public function equiposenales()
    {
        return $this->hasOne('App\Models\senales_equipos', 'id', 'equipo_id');
    }

    public static function getAll(){
    	return self::select('id', 'equipo_id', 'programa_id', 'fecha', 'cumplimiento', 'nota' ,'usuario_crea', 'usuario_actualiza')
    			->get();
    }

    public static function detalleprogramacumplimiento($id){
        return self::select('programas_senales_detalles.id', 'equipo_id', 'programa_id', 'fecha', 'cumplimiento', 'nota', 'n_orden','usuario_crea', 'usuario_actualiza', 'tipo_mant')
                    ->orderBy('fecha', 'asc')
                    ->where('programa_id', $id)
                    ->join('señales_equipos', 'equipo_id', 'señales_equipos.id')
                    ->get();
    }

    public static function detalleprogramasenales(){
        return self::select('id', 'equipo_id', 'programa_id', 'fecha', 'cumplimiento', 'nota', 'n_orden','usuario_crea', 'usuario_actualiza')
                    ->get();
    }


    public static function detalleprogramaAnual(){
        return self::select('id', 'equipo_id', 'programa_id', 'fecha', 'cumplimiento', 'nota' ,'usuario_crea', 'usuario_actualiza')
                    ->whereYear('fecha', now('Y'))
                    ->get();
    }

    public static function borradodedetalle($equipoId){
       $dato = self::select('id', 'equipo_id', 'programa_id', 'fecha')
                    ->orderBy('fecha', 'desc')
                    ->where('equipo_id', $equipoId)
                    ->limit(1)
                    ->first();

        if (!empty($dato))
            return $dato->fecha;
        return null;
    }

    public function programas_senales()
    {
        return $this->hasOne('App\Models\programas_senales', 'id', 'programa_id');
    }


}
;