<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class LocomotoraActividad extends Model
{
    protected $table='locomotoras_actividades';
    protected $guarded = [];

    use SoftDeletes;    

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

    public function locomotora()
   	{	
    	return $this->hasOne(Locomotora::class, 'id', 'locomotora_id')->select('id', 'numero');
   	}

    public function getEstatusAttribute($value){
        $estatus = ['No disponible', 'Disponible'];
        return $estatus[$value] ?? '';
    }

	public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

       public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    } 

    public static function listarActidades(){
    	return self::select('id', 'locomotora_id', 'turno','fecha', 'responsable', 'actividad', 
                            'fecha_salida', 'tiempo', 'estatus', 'usuario_crea', 'created_at', 'orden')
    				->with(['datos', 'locomotora']);
    }

       public static function getAllXPeriodo($rangoFechas){
        return self::select('id', 'locomotora_id', 'turno','fecha', 'responsable', 'actividad', 
                            'fecha_salida', 'tiempo', 'estatus', 'usuario_crea', 'created_at', 'orden')
                    ->with(['datos', 'locomotora'])
                    ->RangoDeFechas($rangoFechas);
     }

       public static function asistenciaControl($rangoFechas){
        return self::select('id','turno','fecha','usuario_crea')
                    ->with(['datos', 'locomotora'])
                    ->orderBy('turno')
                    ->RangoDeFechas($rangoFechas);

    }
}

