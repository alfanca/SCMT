<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class LocomotoraConsumo extends Model
{
	
    protected $table='locomotoras_consumo';
    protected $guarded = [];

    public function locomotora(){	
    	return $this->hasOne(Locomotora::class, 'id', 'locomotora_id')->select('id', 'numero');
   	}

	  public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    }	

    public function getFechaAttribute($fecha){
        return date ( 'd-m-Y' , strtotime ( $fecha ) );
    }

    public static function listadoConsumibles(){
   		return ['MAXITREN DIESEL', 'ENGRALUB', 'GRASA NEGRA', 'GASOIL', 'ACEITE 15W40', 'GOBERNADOR', 'COMPRESOR', 'ZAPATAS'];
   	}

    public static function getListadoConsumiblePorFechas($fechas){
    	return self::select('id', 'locomotora_id', 'cantidad', 'fecha', 'turno', 'tipo', 'nota')
    			->RangoDeFechas($fechas)
    			->orderByRaw('fecha, locomotora_id, tipo, cantidad')
    			->get();
    }

   	public static function getConsumoPorLocomotoraPorFechas($fechas){
   		return self::select('numero as locomotora', 'locomotoras_consumo.tipo', DB::raw('sum(cantidad) as cantidad'))
   				->join('locomotoras', 'locomotora_id', '=', 'locomotoras.id')
    			->RangoDeFechas($fechas)
    			->groupByRaw('locomotoras_consumo.tipo, numero')
    			->orderBy('cantidad', 'asc')
    			->get();
   }

   public static function getListadoConsumiblePorLocomotora($id){
      return self::select('id', 'locomotora_id', 'cantidad', 'fecha', 'turno', 'tipo')
          ->where('locomotora_id', $id)
          ->orderByRaw('fecha, locomotora_id, tipo, cantidad')
          ->get();
    }

    public static function getConsumoPorLocomotoraPorLocomotora($id){
      return self::select('numero as locomotora', 'locomotoras_consumo.tipo', DB::raw('sum(cantidad) as cantidad'))
            ->join('locomotoras', 'locomotora_id', '=', 'locomotoras.id')
            ->where('locomotora_id', $id)
            ->groupByRaw('locomotoras_consumo.tipo, numero')
            ->orderBy('numero')
            ->get();
   }
   
    public static function getConsumoPorMes(){
      return self::select('tipo', DB::raw('sum(cantidad) as cantidad'))
            ->whereMonth('fecha', '=', date('m'))
            ->whereYear('fecha', '=', date('Y'))
            ->groupByRaw('tipo')
            ->orderBy('tipo')
            ->get();        
    }

      public static function ultimoregistroConsumo(){
        return self::select('fecha', 'turno')
                ->orderBy('fecha')
                ->get();
                 
    }

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

    public static function getAllXPeriodo($rangoFechas, $locomotora){
        $sql = self::select('id', 'locomotora_id', 'cantidad', 'fecha', 'turno', 'tipo', 'nota');

        if (!empty($rangoFechas and $locomotora))
            $sql = $sql->RangoDeFechas($rangoFechas)->where('locomotora_id', $locomotora);

        elseif (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

}
