<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserLastLogin extends Model
{

    protected $table='UserLastLogin';
    
    protected $guarded = [];



    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('last_login', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('last_login', $fechas);
    }  

    public static function asistencia($rangoFechas){
        $sql = self::select('user', 'last_login');

        if(!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

    
}
