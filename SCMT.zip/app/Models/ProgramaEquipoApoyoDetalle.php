<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProgramaEquipoApoyoDetalle extends Model
{
    
    protected $table='programa_equipo_apoyo_detalles';
    protected $guarded = [];


    public static $rules = [
            'equipo_id' => ['required'],
            'programa_id' => 'required',
            'fecha' => ['required'],
            'cumplimiento' => ['required'],
            'responsable' => [''],
            'nota' => [''],
            'tipo_mant' => ['required'],
            'n_orden' => [''],
    ];


    public static function Tipo_mant(){
        return ['ZPMI','ZPM2'];
    }


    public static function detalleprogramacumplimiento($programaID){
        return self::select('id', 'equipo_id', 'programa_id', 'fecha', 'cumplimiento', 'nota' ,'usuario_crea', 'usuario_actualiza', 'responsable', 'n_orden', 'tipo_mant')
        			->where('programa_id', $programaID) 
                    ->get();
    }


    public static function borradodedetalle($equipoId){
       $dato = self::select('id', 'equipo_id', 'programa_id', 'fecha')
                    ->orderBy('fecha', 'desc')
                    ->where('equipo_id', $equipoId)
                    ->limit(1)
                    ->first();

        if (!empty($dato))
            return $dato->fecha;
        return null;
    }

    public static function detalleprogramaDetalleAnual(){
        return self::select('id', 'equipo_id', 'programa_id', 'fecha', 'cumplimiento')
                    ->whereYear('fecha', now('Y'))
                    ->get();
    }

    public static function detalleprogramaEqApoyo(){
        return self::select('id', 'equipo_id', 'programa_id', 'fecha', 'cumplimiento')
                    ->get();
    }


    public function scopeFecha($query, $fecha)
    {
    return $query->whereDate('fecha', $fecha);
    }

    public function scopeRangoDeFechas($query, $fechas){
    return $query->whereBetween('fecha', $fechas);
    }  

        public static function getAllXPeriodo($rangoFechas){
        $sql = self::select('id', 'equipo_id', 'programa_id', 'fecha', 'cumplimiento', 'nota' ,'usuario_crea', 'usuario_actualiza', 'responsable', 'n_orden', 'tipo_mant');

        if (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

    
    public function equiposApoyo()
    {
        return $this->hasOne('App\Models\Equipo_apoyo', 'id', 'equipo_id');
    }
	

	public function programas_EquipoApoyo()
    {
        return $this->hasOne('App\Models\ProgramaEquipoApoyo', 'id', 'programa_id');
    }

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }
}
