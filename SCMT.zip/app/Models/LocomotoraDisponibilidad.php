<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\SoftDeletes;

class LocomotoraDisponibilidad extends Model
{
    protected $table='locomotoras_disponibilidad';
    protected $guarded = [];
    

    public function locomotora()
    {   
        return $this->hasOne(Locomotora::class, 'id', 'locomotora_id')->select('id', 'numero', 'tipo','modelo');
    }

    public function getUbicacionAttribute($value){
        $ubicacion = ['pzo' => 'Puerto Ordaz', 'cp' => 'Ciudad Piar'];
        return $ubicacion[$value] ?? '';
    }

    public function getEstatusAttribute($value){
        $estatus = ['No disponible', 'Disponible'];
        return $estatus[$value];
    }

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

    public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    }


    public function crear($datos){
        try { 
            foreach($datos as $dato)
            {                
                $LocomotoraDisponibilidad = new Self();
                $LocomotoraDisponibilidad->locomotora_id = $dato['locomotora_id'];
                $LocomotoraDisponibilidad->turno = $dato['turno'];
                $LocomotoraDisponibilidad->fecha = $dato['fecha'];
                $LocomotoraDisponibilidad->estatus = $dato['estatus'];
                $LocomotoraDisponibilidad->ubicacion = $dato['ubicacion'];
                $LocomotoraDisponibilidad->usuario_crea = $dato['usuario_crea'];
                $LocomotoraDisponibilidad->save();
            }   
            return true;
        }catch (\Exception $e) {
            return false;
      }
    }
    public static function verUltimoTurnoCargado(){
        return self::select(DB::raw('max(fecha) as fecha'), 'turno')
        ->groupBy('turno')
         ->orderByRaw('fecha desc, turno desc')
        ->first();
    }

    public static function verUltimaDisponibilidadCargada($fecha, $turno){
        return self::whereDate('fecha', '=', $fecha)
        ->where('turno', $turno)->get();
    }

    
   public static function disponibilidadXPeriodo($fechas){
        return self::select(DB::raw('count(numero) * 8 as horasdisponibles'), 'numero', 'locomotoras_disponibilidad.ubicacion')
                ->join('locomotoras', 'locomotora_id', '=', 'locomotoras.id')
                ->groupBy(['numero', 'locomotoras_disponibilidad.ubicacion'])
                ->RangoDeFechas($fechas)
                ->orderBy('horasdisponibles', 'desc')
                ->get();
    }

    public static function conteodelocomotorasoperativastiempo($fechas){
        $horasfueradeservicio = (((strtotime($fechas[1])-strtotime($fechas[0]))/86400)+1)*24;
        return self::select(DB::raw('count(numero) * 8 as horasdisponibles, '.$horasfueradeservicio.' - count(numero) * 8 as fueradeservicio'), 'numero')
                ->join('locomotoras', 'locomotora_id', '=', 'locomotoras.id')
                ->groupBy(['numero'])
                ->RangoDeFechas($fechas)
                ->orderBy('horasdisponibles', 'desc')
                ->get();
    }

    public static function acumuladoHoraXLocomotora($disponibilidad){
        $disponibilidadAgrupada = $disponibilidad->groupBy('numero');
        $acumulado = [];
        foreach ($disponibilidadAgrupada as $locomotora => $datos) {
            $acumulado[$locomotora] = $datos->sum('horasdisponibles');
        }
        return $acumulado;
     }

     public static function listarXSemana($rangoFechas){
        return self::select('locomotora_id','turno','fecha','ubicacion')
                    ->selectRaw("date_part('week', fecha) as semana, date_part('dow', fecha) as day")
                    ->RangoDeFechas($rangoFechas);

    }
}

