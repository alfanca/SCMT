<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class cambiavias extends Model
{
    public static function getall(){
        return self::select('id', 'ubicacion','tipo', 'tramo','estatus')
                ->where('estatus', 'ACTIVO')
                ->get();
    }
  }
