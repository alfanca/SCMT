<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Maestropreventivolocomotora
 *
 * @property $id
 * @property $locomotora_id
 * @property $fecha_inicio
 * @property $fecha_fin
 * @property $responsableplanificador
 * @property $responsablejefeplanifiacion
 * @property $responsablejefetallerloc
 * @property $responsablejefetallervag
 * @property $nota
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property Detallepreventivolocomotora[] $detallepreventivolocomotoras
 * @property Locomotora $locomotora
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Maestropreventivolocomotora extends Model
{
    
    static $rules = [
		'locomotora_id' => 'required',
		'fecha_inicio' => 'required',
		'fecha_fin' => 'required',
		'responsableplanificador' => 'required',
		'responsablejefeplanifiacion' => 'required',
		'responsablejefetallerloc' => 'required',
		'responsablejefetallervag' => 'required',
        'causa_reprogramacion' => 'max:800',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['locomotora_id','fecha_inicio','fecha_fin','responsableplanificador','responsablejefeplanifiacion','responsablejefetallerloc','responsablejefetallervag', 'estatus','nota','usuario_crea','usuario_actualiza', 'fecha_reprogramacion', 'causa_reprogramacion', 'fecha_r_realizada'];

    const ESTATUS = ['LIBERADA','CERRADA'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

    public static function programasindex(){
        return self::select('id', 'locomotora_id','fecha_inicio', 'fecha_fin', 'estatus', 'nota', 'fecha_reprogramacion')
                     ->where('estatus', '!=', '1')
                     ->get();
                   }

    public static function programasindexconteo(){
        return self::select('id','fecha_inicio','fecha_reprogramacion')
                     ->whereYear('fecha_inicio', now('Y'))
                     ->get();
                   }
    
    public static function programatope(){
        return self::select('maestropreventivolocomotoras.id', 'locomotora_id','fecha_inicio', 'fecha_reprogramacion', 'mant')
                 ->selectRaw('fecha_inicio + mant as programa, fecha_inicio + (mant-7) as programar, fecha_reprogramacion - 7 as reprogramar')
                 ->join('locomotoras', 'locomotoras.id', 'maestropreventivolocomotoras.locomotora_id')
                 ->orderBy('fecha_inicio', 'desc')
                 ->get()->groupBy('locomotora_id')->sortBy('fecha_inicio', -1);
    }


    public function detallepreventivolocomotoras()
    {
        return $this->hasMany('App\Models\Detallepreventivolocomotora', 'maestropreventivo_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function locomotora()
    {
        return $this->hasOne('App\Models\Locomotora', 'id', 'locomotora_id');
    }

    
    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

     public function datosPlanificador()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsableplanificador');
    }
    public function datosjefePlanificador()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsablejefeplanifiacion');
    }
    public function datosTallerLoc()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsablejefetallerloc');
    }
    public function datosTallerVag()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsablejefetallervag');
    }
    
    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha_inicio', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha_inicio', $fechas);
    }  

    public static function getAllXPeriodo($rangoFechas, $locomotoras){
        $sql = self::select('id','locomotora_id','fecha_inicio','fecha_fin','responsableplanificador','responsablejefeplanifiacion','responsablejefetallerloc','responsablejefetallervag', 'estatus','nota','usuario_crea','usuario_actualiza', 'fecha_reprogramacion')
            ->with(['datos', 'detallepreventivolocomotoras']);

        if (!empty($rangoFechas and $locomotoras))
            $sql = $sql->RangoDeFechas($rangoFechas)->where('locomotora_id', $locomotoras);

        elseif(!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }


}
