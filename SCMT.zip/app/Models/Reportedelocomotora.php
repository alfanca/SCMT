<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Reportedelocomotora
 *
 * @property $id
 * @property $locomotora_id
 * @property $fecha_entrada
 * @property $fecha_salida
 * @property $estatus
 * @property $ceco
 * @property $planeado
 * @property $escoger_planeado
 * @property $no_planeado
 * @property $escoger_noplaneado
 * @property $descripcion_falla
 * @property $razon_falla
 * @property $razon_demora
 * @property $otro_motivo
 * @property $responsable
 * @property $n_orden
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property Locomotora $locomotora
 * @property Reporteconsumiblelocomotora[] $reporteconsumiblelocomotoras
 * @property Reportetiempolocomotora[] $reportetiempolocomotoras
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Reportedelocomotora extends Model
{
    
    static $rules = [
		'locomotora_id' => 'required',
		'fecha_entrada' => 'required',
		'estatus' => '',
		'ceco' => 'required',
        'planeado' => 'required',
        'escoger_planeado' => 'required',
		'descripcion_falla' => 'required|max:200',
		'razon_falla' => 'required',
		'razon_demora' => 'required',
		'responsable' => 'required',
    ];


    protected $perPage = 20;

    const ESTATUS = ['ABIERTA','LIBERADA','CERRADA'];

    const CECO = ['202','221','222','241','267','268','272','276'];

    const PLANEADO = ['SI','NO'];

    const ESCOGERPLANEADO = ['REPARACIÓN','INSPECCIÓN','CHEQUEO', 'CAMBIO', 'AJUSTE'];

    const ESCOGERNOPLANEADO = ['REPARACIÓN','AJUSTE', 'CAMBIO', 'CHEQUEO'];

    const RAZONFALLA = ['MALA OPERACIÓN','MAL DISEÑO', 'MAL ARMADO', 'MAL INSTALADO', 'DESGASTE PREMATURO', 'SOBRECARGA', 'RUTINA DE TRABAJO', 'SERVICIO DEFICIENTE', 'OTRA'];

    const RAZONDEMORA = ['ESPERANDO POR MANO DE OBRA','DIAGNOSTICANDO FALLA', 'ESPERANDO REPUESTO', 'ESPERANDO POR HERRAMIENTAS', 'ESPERANDO POR EQUIPOS AUXILIARES', 'MODIFICANDO O ADAPTANDO REPUESTOS', 'HORAS NO PROGRAMADAS', 'OTROS MOTIVOS'];

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['locomotora_id','fecha_entrada','fecha_salida','estatus','ceco','planeado','escoger_planeado','descripcion_falla','razon_falla','razon_demora','otro_motivo','responsable','n_orden','usuario_crea','usuario_actualiza','notificado'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */

    public static function getAllCorrectivo(){
        return self::select('id', 'locomotora_id','fecha_entrada','fecha_salida','estatus','planeado', 'escoger_planeado','descripcion_falla','responsable','n_orden', 'notificado')
                ->where('fecha_salida', '=', null)
                ->where('estatus', '!=', 'CERRADA')
                ->where('planeado', '1')
                ->where('locomotora_id', '!=','25')
                ->orderBy('fecha_entrada', 'desc')
                ->get();
    }

    public static function getAllCorrectivoNotificado(){
        return self::select('id', 'locomotora_id','fecha_entrada','fecha_salida','estatus','planeado', 'escoger_planeado','descripcion_falla','responsable','n_orden', 'notificado')
                ->where('fecha_salida', '!=', null)
                ->where('estatus', '!=', 'CERRADA')
                ->where('planeado', '1')
                ->where('locomotora_id', '!=','25')
                ->orderBy('fecha_entrada', 'desc')
                ->get();
    }

     public static function getAllLineaservicio(){
        return self::select('id', 'locomotora_id','fecha_entrada','fecha_salida','estatus','planeado', 'escoger_planeado','descripcion_falla','responsable','n_orden')
                ->where('estatus', '!=', 'CERRADA')
                ->where('planeado', '1')
                ->where('locomotora_id', '25')
                ->orderBy('fecha_entrada', 'desc')
                ->get();
    }

    public static function getAllPreventivo(){
        return self::select('id', 'locomotora_id','fecha_entrada','fecha_salida','estatus','planeado', 'escoger_planeado','descripcion_falla','responsable','n_orden','notificado')
                ->where('estatus', '!=', 'CERRADA')
                ->where('planeado', '0')
                ->orderBy('fecha_entrada', 'desc')
                ->get();
    }

    public static function getAllCorrectivoHome(){
        return self::select('id', 'locomotora_id','fecha_entrada','fecha_salida','estatus','planeado', 'escoger_planeado','descripcion_falla','responsable','n_orden')
                ->where('estatus', '!=', 'CERRADA')
                ->where('fecha_salida', '=', null)
                ->where('planeado', '1')
                ->where('locomotora_id', '!=','25')
                ->orderBy('fecha_entrada', 'desc')
                ->get();
    }


    public function locomotora()
    {
        return $this->hasOne('App\Models\Locomotora', 'id', 'locomotora_id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function reporteconsumiblelocomotoras()
    {
        return $this->hasMany('App\Models\Reporteconsumiblelocomotora', 'reportelocomotora_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function reportetiempolocomotoras()
    {
        return $this->hasMany('App\Models\Reportetiempolocomotora', 'reportelocomotora_id', 'id');
    }

    public function reporteactividadlocomotora()
    {
        return $this->hasMany('App\Models\Reporteactividadlocomotora', 'reportelocomotora_id', 'id');
    }

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha_entrada', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha_entrada', $fechas);
    }  

    public static function getAllXPeriodo($rangoFechas, $locomotoras){
        $sql = self::select('reportedelocomotoras.id', 'numero as locomotora_id','fecha_entrada','fecha_salida','reportedelocomotoras.estatus','reportedelocomotoras.ceco','planeado','escoger_planeado','descripcion_falla','razon_falla','razon_demora','otro_motivo','responsable','n_orden','usuario_crea','usuario_actualiza','notificado')
            ->join('locomotoras', 'locomotora_id', '=', 'locomotoras.id');;

        if (!empty($rangoFechas and $locomotoras))
            $sql = $sql->RangoDeFechas($rangoFechas)->where('locomotora_id', $locomotoras);

        elseif(!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }
    

}
