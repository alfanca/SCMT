<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Actividad extends Model
{
    protected $table='actividades';
    protected $guarded = [];
    use SoftDeletes;

    const VIA = 'Via';
    const VAGONES = 'Vagones';
    const SEÑALES = 'Señales';

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

	public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    }  

	public function scopeVia($query)
    {
        return $query->where('origen', self::VIA);
    }

    public function scopeSeñales($query)
    {
        return $query->where('origen', self::SEÑALES);
    }    

    public function scopeVagones($query)
    {
        return $query->where('origen', self::VAGONES);
    }    

    public static function listarActidades(){
    	return self::select('id', 'turno','fecha', 'responsable', 'actividad', 'usuario_crea', 'created_at', 'orden', 'tramo')
    				->with(['datos']);
    }    

    public static function getAllXPeriodo($rangoFechas, $tramosselec){
        $sql = self::select('id', 'turno','fecha', 'responsable', 'actividad', 'usuario_crea', 'created_at', 'orden','tramo')
            ->with(['datos']);

        if (!empty($rangoFechas and $tramosselec))
            $sql = $sql->RangoDeFechas($rangoFechas)->where('tramo', $tramosselec);

        elseif (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

    public static function getAllXPeriodoSenales($rangoFechas){
        $sql = self::select('id', 'turno','fecha', 'responsable', 'actividad', 'usuario_crea', 'created_at', 'orden','tramo')
            ->with(['datos']);

        if (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);

        elseif (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

    public static function tramovia(){
        return ['NOTA','L/P-PUENTE','EQ FERROVIARIO','L/P','SIDOR','PALUA','PATIO','P.PELLA','O.IRON','COMSIGUA','BRIQVEN', 'OFICINA','INSPECCION', 'LOGISTICA', 'A/DESCARRILAMIENTO'];
    }
}

