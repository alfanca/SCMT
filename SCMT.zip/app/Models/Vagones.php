<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Clases\Util;

class Vagones extends Model
{
    //protected $table='vagones';
    protected $guarded = [];
    public $incrementing = false;
    protected $keyType = 'string';

    protected $casts = [
        'fecha_ultima_ubicacion' => 'datetime:Y-m-d H:M',
    ];

    public function inventario()
    {
        return $this->hasOne(VagonesInventario::class, 'vagones_id', 'id');
    }

    public function viajes()
    {
        return $this->hasMany(VagonesInspeccionDetalle::class, 'vagones_id', 'id');
    }

    public function getDisponibleAttribute($value){
        $estatus = ['Mantenimiento', 'Disponible'];
        return $estatus[$value] ?? '';
    }

    public function estatusVagones(){
        return [
            true => 'Activo',
            false => 'No Activo'
        ];
    }

    public function disponibleVagones(){
        return [
            false => 'No disponible',
            true => 'Disponible'
        ];
    }    

    public function tipoVagones(){
        return ['Gondola', 'Tolva', 'Volteo', 'Tanque', 'Plataforma'];
    }    

    public static function buscar($id){
      return self::select("id")
                  ->whereRaw("lower(id) like lower('%$id%')")
                  ->where('disponible', true)
                  ->orderbY('id')
                  ->limit(50)->get();
    }

    public static function buscarTodos($id){
      return self::select("vagones.id")
                    ->leftJoin('vagones_taller', 'vagones.id', '=', 'vagones_id')
                    ->whereRaw("lower(vagones.id) like lower('%$id%') and vagones_taller.estatus is null")
                    ->orderbY('id')
                    ->limit(50)->get();
    }

    public static function buscarTodosSinFiltro($id){
      return self::select("vagones.id")
                    ->whereRaw("lower(vagones.id) like lower('%$id%')")
                    ->orderbY('id')
                    ->limit(50)->get();
    }    

    public function scopeVisible($query)
    {
        return $query->where('estatus', true);
    }

    public static function getAll(){
        return self::select('id', 'zona_geografica', 'ultima_ubicacion','tipo', 
                'fecha_ultima_ubicacion', 'estatus', 'disponible', 'proyecto_recuperacion')
            ->selectRaw("date_part('day', (now() - fecha_ultima_ubicacion)) || ' dias' as ultima_vez,
                case when (date_part('day', (now() - fecha_ultima_ubicacion)) <= 2) then 'NORMAL'
                     when (date_part('day', (now() - fecha_ultima_ubicacion)) >= 3 
                           and date_part('day', (now() - fecha_ultima_ubicacion)) <= 5) then 'ALERTA'
                     else 'ALARMA' end as bandera_alarma")
            ->where('proyecto_recuperacion', null)
            ->with('inventario')->orderbY('id')->get();
    }


    public static function proyectoVagones(){
        return self::select('id', 'ultima_ubicacion','estatus', 'disponible')
                    ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4','DESINCORPORADO', 'DESCARRILADO'])
                    ->where('estatus', true)
                    ->where('disponible', true)
                    ->get();
    }


    public function getVagonInspecciones($vagon){
        return self::select('vagones_inspecciones.hora_salida', 'vagones_inspecciones.fecha', 'vagones_inspecciones.tren')
            ->leftJoin('vagones_inspecciones_detalle', 'vagones.id', '=', 'vagones_id')
            ->join('vagones_inspecciones', 'vagones_inspecciones_detalle.vagones_inspecciones_id', '=', 'vagones_inspecciones.id')
            ->where('vagones.id', $vagon)
            ->orderBy('vagones_inspecciones.hora_salida', 'desc')->get();
    }


    public static function getTrenUbicacionGeografica($tren){
        if (in_array($tren, ['TREN 01', 'TREN 03', 'TREN 05', 'TREN 07', 'TREN 09','TREN EXTRA VACIO']))
            return 'Ciudad Piar';
        else
            return 'Puerto Ordaz';
    }

    public static function actualizarPorInspeccion($vagon, $inspeccion){
        $zona_geografica = self::getTrenUbicacionGeografica($inspeccion->tren);
        $fecha_ultima_ubicacion = $inspeccion->hora_salida;
        return $vagon = DB::table('vagones')
              ->where('id', $vagon)
              ->update([
                    'zona_geografica' => $zona_geografica,
                    'ultima_ubicacion' => $inspeccion->tren,
                    'fecha_ultima_ubicacion' =>  $fecha_ultima_ubicacion
                    ]);
    } 


    public static function actualizarDisponibilidad($vagon, $fecha, $ubicacion, $estatus){
      return  $vagon = DB::table('vagones')
              ->where('id', $vagon)
              ->update([
                    'zona_geografica' => 'Puerto Ordaz',
                    'ultima_ubicacion' => $ubicacion,
                    'fecha_ultima_ubicacion' =>  $fecha,
                    'disponible' => $estatus
                    ]);
    } 

    public static function actualizarTrenPorInspeccion($inspeccion){
        $zona_geografica = self::getTrenUbicacionGeografica($inspeccion->tren);
        $fecha_ultima_ubicacion = $inspeccion->hora_salida;

        $whereIn = $inspeccion->vagones->pluck('vagones_id');
        
        return $vagon = DB::table('vagones')
              ->whereIn('id', $whereIn)
              ->update([
                    'zona_geografica' => $zona_geografica,
                    'ultima_ubicacion' => $inspeccion->tren,
                    'fecha_ultima_ubicacion' =>  $fecha_ultima_ubicacion
                    ]);
    } 

    public static function dashboardvagonesconteo(){
      return self::select('id', 'tipo', 'ultima_ubicacion')
                    ->get();
    }  

}