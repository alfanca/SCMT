<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProgramaEquipoApoyo extends Model
{
    protected $table='programa_equipo_apoyos';
    protected $guarded = [];


    static $rules = [
		'programa' => 'required',
		'fecha' => 'required',
        'fecha_fin' => 'required',
        'estatus' => '',
        'cant_persona' => '',
        'tiempo' => '',
		'planificador' => 'required',
		'jefeturnoarea' => 'required',
		'jefeplanificacion' => 'required',
		'nota' => '',
    ];


    public function programaEstatus(){
        return ['LIBERADA','CERRADA'];
    }


    public static function Getall(){
        return self::select('id', 'programa','fecha', 'fecha_fin', 'estatus','planificador', 'jefeturnoarea', 'jefeplanificacion', 'nota' ,'usuario_crea', 'usuario_actualiza')
                ->where('estatus', 'LIBERADA')
                ->get();
    }

    public static function anualProgramas(){
        return self::select('id', 'programa','fecha', 'fecha_fin', 'estatus','planificador', 'jefeturnoarea', 'jefeplanificacion', 'nota' ,'usuario_crea', 'usuario_actualiza')
                ->whereYear('fecha', now('Y'))
                ->get();
    }


    public function scopeFecha($query, $fecha)
    {
    return $query->whereDate('programa', $fecha);
    }

    public function scopeRangoDeFechas($query, $fechas){
    return $query->whereBetween('programa', $fechas);
    }  

        public static function getAllXPeriodo($rangoFechas, $ano){
        $sql = self::select('id', 'programa', 'fecha', 'fecha_fin', 'estatus', 'planificador', 'jefeturnoarea', 'jefeplanificacion', 'nota' ,'usuario_crea', 'usuario_actualiza');

        if (!empty($rangoFechas and $ano))
            $sql = $sql->RangoDeFechas($rangoFechas)->whereYear('fecha', $ano);

        elseif (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }


    public function programas_equipoApoyo_detalles_union()
    {
        return $this->hasMany('App\Models\ProgramaEquipoApoyoDetalle', 'programa_id', 'id');
    }

    public function datosplanificador()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'planificador');
    }

    public function datosjefeTurnoarea()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'jefeturnoarea');
    }

    public function datosjefeplanificacion()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'jefeplanificacion');
    }


}
