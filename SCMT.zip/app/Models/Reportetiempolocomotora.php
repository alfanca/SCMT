<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Reportetiempolocomotora
 *
 * @property $id
 * @property $reportelocomotora_id
 * @property $fecha
 * @property $responsable
 * @property $horas
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property Reportedelocomotora $reportedelocomotora
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Reportetiempolocomotora extends Model
{
    
    static $rules = [
		'fecha' => 'required',
		'responsable' => 'required',
		'horas' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['reportelocomotora_id','fecha','responsable','horas','usuario_crea','usuario_actualiza'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */

    public static function detalletiemporeporte(){
        return self::select('id', 'reportelocomotora_id','fecha','responsable','horas','usuario_crea','usuario_actualiza')
                ->get();
    }


    public function reportedelocomotora()
    {
        return $this->hasOne('App\Models\Reportedelocomotora', 'id', 'reportelocomotora_id');
    }

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }
    

}
