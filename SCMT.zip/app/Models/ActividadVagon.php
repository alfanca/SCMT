<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ActividadVagon extends Model
{
    protected $table='actividades_taller';
    protected $guarded = [];
    use SoftDeletes;
    
    public static function listadoAreas(){
        return ['Línea de servicios de Vagones', 'Mantenimiento Industrial', 
                'Maquina y herramientas', 'Taller de soldadura', 'Taller de vagones'];
    }

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

	public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

    public static function listarActidades(){
    	return self::select('id', 'turno','fecha', 'responsable', 'actividad', 'area', 'usuario_crea', 'created_at')
    				->with(['datos']);
    }    
}
