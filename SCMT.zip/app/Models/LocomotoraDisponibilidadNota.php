<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class LocomotoraDisponibilidadNota extends Model
{
	
 	protected $table='locomotoras_disponibilidad_notas';
	protected $guarded = [];

	use SoftDeletes;

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }
}
