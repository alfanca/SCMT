<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class materialeslocomotora extends Model
{
    protected $table='materialeslocomotoras';
    protected $guarded = [];
  
    public static $rules = [
        'parte'    => 'required|max:40|',
        'sap'    => 'nullable',
        'modelo'    => 'required|max:20',
        'descripcion'    => 'required|max:200',
        'ubicacion'    => 'required|max:1000',
        'unidad'    => 'required|max:10',
        'cantidad'    => 'required',
        'area'    => 'required|max:20',
        'preciounitario' => '',
    ];

    public static $error_message = 
    [
    'parte.required' => 'Escriba el nombre de la fase',
    'parte.max' => 'El maximo de caracteres alcanzado',
    'nombre.unique' => 'Esta fase ya ha sido registrado',

    ];

    public static function modelos(){
    	return ['SD38','SD70M','SD70Ace','DMU','GENERAL'];
    }

    public static function unidades(){
    	return ['EA','GLN','KG','LB','ROL','TR'];
    }

    public static function areas(){
    	return ['MECANICA','ELECTRICA','NEUMATICA','VIDRIOS Y GOMAS', 'ESTRUCTURAL'];
    }

    


}
