<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class materialesvagones extends Model
{
    protected $table='materialesvagones';
    protected $guarded = [];
  
    public static $rules = [
        'parte'    => 'max:30',
        'sap'    => 'nullable',
        'tipo'    => 'required|max:20',
        'descripcion'    => 'required|max:200',
        'ubicacion'    => 'required|max:500',
        'unidad'    => 'required|max:10',
        'catergoria'    => 'required|max:20',
        'preciounitario' => '',
        'sistema' => 'max:50',
    ];

    public static $error_message = 
    [
    'parte.required' => 'Escriba el nombre de la fase',
    'parte.max' => 'El maximo de caracteres alcanzado',
    'nombre.unique' => 'Esta fase ya ha sido registrado',

    ];

    public static function tipos(){
    	return ['GONDOLA','TOLVA','VOLTEO','BALASTERO','PLATAFORMA', 'TANQUERO', 'CABOOSE','EQ. APOYO'];
    }

    public static function unidades(){
    	return ['EA','GLN','KG','LB','ROL','TR'];
    }

    public static function catergorias(){
    	return ['REPUESTO','INSUMO'];
    }

    public static function sistemas(){
        return ['SISTEMA DE FRENO','SISTEMA DE CHOQUE Y TRACCION', 'SISTEMA RODANTE', 'SISTEMA ESTRUCTURAL', 'SISTEMA DE COMPUERTAS', 'SISTEMA DE VOLTEO',' SISTEMA ELECTRO NEUMATICO DE COMPUERTAS'];
    }

    public static function materialesConsumo(){
        return self::select('id', 'parte','sap', 'tipo', 'descripcion', 'ubicacion', 'unidad', 'catergoria', 'preciounitario')
                     ->get();
    }
}
