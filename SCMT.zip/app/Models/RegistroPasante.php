<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class RegistroPasante
 *
 * @property $id
 * @property $fecha_ingreso
 * @property $fecha_salida
 * @property $tutor
 * @property $tutor_cedula
 * @property $cargo_tutor
 * @property $pasante
 * @property $pasante_cedula
 * @property $pasante_ficha
 * @property $especialidad
 * @property $gerencia
 * @property $unidad
 * @property $division
 * @property $universidad
 * @property $semestre
 * @property $pasantia_regular
 * @property $pasantia_tesista
 * @property $evaluacion
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class RegistroPasante extends Model
{
    
    static $rules = [
		'fecha_ingreso' => 'required',
		'fecha_salida' => 'required',
		'tutor' => 'required',
		'tutor_cedula' => 'required',
		'tutor_ficha' => 'required',
		'cargo_tutor' => 'required',
		'pasante' => 'required',
		'pasante_cedula' => 'required',
		'pasante_ficha' => 'required',
		'especialidad' => 'required',
		'gerencia' => 'required',
		'unidad' => 'required',
		'division' => 'required',
		'universidad' => 'required',
		'semestre' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['fecha_ingreso','fecha_salida','tutor','tutor_cedula', 'tutor_ficha', 'cargo_tutor','pasante','pasante_cedula','pasante_ficha','especialidad','gerencia','unidad','division','universidad','semestre','pasantia_regular','pasantia_tesista', 'tema_regular', 'tema_tesis', 'evaluacion','usuario_crea','usuario_actualiza', 'created_at'];


    const GERENCIA = ['FERROCARRIL'];
    const UNIDAD = ['GERENCIA DE FERROCARRIL, JEFATURA DE PLANIFICACIÓN DE MANTENIMIENTO'];
    const DIVISION = ['PUERTO ORDAZ', 'CIUDAD PIAR', 'PALÚA'];
    const CARGO = ['JEFE DE AREA DE PLANIFICACION DE MANTENIMIENTO', 'PLANIFICADOR DE MANTENIMIENTO'];
    const UNIVERSIDAD = ['UGMA', 'UNEG', 'UNEXPO', 'UDO','SANTIAGO MARIÑO', 'ANTONIO JOSE DE SUCRE', 'IUTIRLA', 'PEDRO EMILIO COLL'];
    const ESPECIALIDAD = ['ING INDUSTRIAL', 'ING MANTENIMIENTO INDUSTRIAL', 'ING ELECTRICA', 'ING MECANICA', 'ING METALURGICA', 'DISEÑADOR GRAFICO', 'ADMISTRADOR DE EMPRESAS', 'TECNOLOGO EN SISTEMAS INDUSTRIALES'];
    const EVALUACION = ['DEFICIENTE', 'REGULAR', 'BUENO', 'MUY BUENO', 'EXCELENTE'];


    public static function dataindex($anho){
        return self::select('id','fecha_ingreso','fecha_salida', 'pasante', 'pasante_cedula', 'especialidad', 'universidad','pasantia_regular','pasantia_tesista', 'created_at')
            ->whereYear('fecha_salida', $anho)
            ->orderBy('created_at', 'desc')->get();
        
    }



}
