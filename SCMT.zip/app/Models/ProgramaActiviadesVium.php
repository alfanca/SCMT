<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProgramaActiviadesVium
 *
 * @property $id
 * @property $programa_anual_id
 * @property $programa_detalle_id
 * @property $fecha
 * @property $tramo_km_inicio
 * @property $tramo_km_fin
 * @property $tramo_km_total
 * @property $cant_persona
 * @property $tiempo
 * @property $responsable
 * @property $tomar
 * @property $nota
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property ProgramaAnualVium $programaAnualVium
 * @property ProgramaDetalleVium $programaDetalleVium
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class ProgramaActiviadesVium extends Model
{
    protected $table='programa_activiades_via';
    protected $guarded = [];
    
    static $rules = [
		'programa_anual_id' => 'required',
		'fecha' => 'required',
		'tramo_km_inicio' => 'required',
		'tramo_km_fin' => 'required',
		'tramo_km_total' => 'required',
		'cant_persona' => 'required',
		'tiempo' => 'required',
		'responsable' => 'required',
		'tomar' => 'required',
		'usuario_crea' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['programa_anual_id','programa_id','fecha','tramo_km_inicio','tramo_km_fin','tramo_km_total','cant_persona','tiempo','responsable','tomar','nota','usuario_crea','usuario_actualiza', 'cambiavias_id'];




    public static function detalleprogramacumplimiento($programaID){
        return self::select('id','programa_anual_id','programa_id','fecha','tramo_km_total','cant_persona','tiempo')
                    ->where('programa_id', $programaID) 
                    ->whereYear('fecha', now())
                    ->get();
    }


    public static function estatusReporteVia(){
        return [
            0 => 'Correctivo',
            1 => 'Preventivo'
        ];
    }


    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

    public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    }   

    public static function getAllXPeriodo($rangoFechas){

    $sql = self::select('programa_activiades_via.id','programa_anual_id','programa_id','programa_activiades_via.fecha','programa_activiades_via.tramo_km_inicio','programa_activiades_via.tramo_km_fin','programa_activiades_via.tramo_km_total','programa_activiades_via.cant_persona','programa_activiades_via.tiempo','programa_activiades_via.responsable','programa_activiades_via.tomar','programa_activiades_via.nota','programa_activiades_via.usuario_crea','programa_activiades_via.usuario_actualiza','programa_activiades_via.cambiavias_id','descripcion')

            ->Join('programa_anual_via', 'programa_anual_via.id', 'programa_activiades_via.programa_anual_id');

        if (!empty($rangoFechas))
           
            $sql = $sql->RangoDeFechas($rangoFechas);
        
        return $sql;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function programaAnualVium()
    {
        return $this->hasOne('App\Models\ProgramaAnualVium', 'id', 'programa_anual_id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function programaVium()
    {
        return $this->hasOne('App\Models\ProgramaVium', 'id', 'programa_id');
    }

    public function cambiavias()
    {
        return $this->hasOne(cambiavias::class, 'id', 'cambiavias_id');
    }

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }
    

}
