<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VagonDescarrilamiento extends Model
{
    protected $table='vagon_descarrilamiento';
    protected $guarded = [];


    static $rules = [
		'vagon_id' => 'required',
		'fecha_inicio' => 'required',
		'observacion' => 'required',
    ];


    const ESTATUS = ['DESCARRILADO', 'ENCARRILADO', 'DESINCORPORADO'];
    

    public static function getAll(){
    	return self::select('id', 'vagon_id', 'fecha_inicio', 'observacion', 'fecha_fin', 'estatus' ,'usuario_crea', 'usuario_actualiza')
    			->get();
    }
}
