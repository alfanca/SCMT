<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class Nota extends Model
{
	
 	protected $table='notas';
	protected $guarded = [];

	use SoftDeletes;

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

    public function scopeLocomotoras($query)
    {
        return $query->where('area', 'locomotoras');
    }    

    public function scopeVagones($query)
    {
        return $query->where('area', 'vagones');
    }
      
}
