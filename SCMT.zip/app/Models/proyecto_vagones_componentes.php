<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class proyecto_vagones_componentes extends Model
{
    protected $table='vagones_componentes_proyecto';
    protected $guarded = [];


    public static function detalleProyectoVagonConsumo($proyecto_id){
        return self::select('id', 'vagones_id', 'proyecto_vagones_id', 'materiales_vagones_id','cantidad', 'precio_unit', 'taller_id')
                    ->selectRaw('cantidad * precio_unit as total')
                    ->where('proyecto_vagones_id', $proyecto_id) 
                    ->get();
    }

    public function materialesvagones()
    {
        return $this->belongsTo('App\Models\materialesvagones', 'materiales_vagones_id', 'id');
    }
}
