<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Detallepreventivolocomotora
 *
 * @property $id
 * @property $reportelocomotora_id
 * @property $maestropreventivo_id
 * @property $locomotora
 * @property $fecha_inicio
 * @property $fecha_fin
 * @property $cumplimiento
 * @property $nota
 * @property $responsable
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property Maestropreventivolocomotora $maestropreventivolocomotora
 * @property Reportedelocomotora $reportedelocomotora
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Detallepreventivolocomotora extends Model
{
    
    static $rules = [
		'reportelocomotora_id' => 'required',
		'maestropreventivo_id' => 'required',
		'locomotora' => 'required',
		'fecha_inicio' => 'required',
		'fecha_fin' => 'required',
		'cumplimiento' => 'required',
		'responsable' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['reportelocomotora_id','maestropreventivo_id','locomotora','fecha_inicio','fecha_fin','cumplimiento','nota','responsable','usuario_crea','usuario_actualiza'];


    public static function detallecumplimiento(){
        return self::select('id', 'reportelocomotora_id','maestropreventivo_id','locomotora','fecha_inicio','fecha_fin','cumplimiento','nota','responsable','usuario_crea','usuario_actualiza')
                    ->get();
    }


    public static function getcumplimientoportada(){
        return self::select('maestropreventivo_id', 'fecha_inicio','cumplimiento')
                    ->whereYear('fecha_inicio', now('Y'))
                    ->get();
    }

    public static function getcumplimiento(){
        return self::select('maestropreventivo_id', 'cumplimiento')->get();
    }



    public static function getcumplimientofecha($rangoFechas){
        $sql = self::select('maestropreventivo_id', 'cumplimiento');

        if (!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function maestropreventivolocomotora()
    {
        return $this->hasOne('App\Models\Maestropreventivolocomotora', 'id', 'maestropreventivo_id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function reportedelocomotora()
    {
        return $this->hasOne('App\Models\Reportedelocomotora', 'id', 'reportelocomotora_id');
    }

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha_inicio', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha_inicio', $fechas);
    }  

    public static function getAllXPeriodo($rangoFechas, $locomotoras){
        $sql = self::select('id', 'locomotora','fecha_inicio','fecha_fin','cumplimiento','nota','responsable','usuario_crea','usuario_actualiza');

        if (!empty($rangoFechas and $locomotoras))
            $sql = $sql->RangoDeFechas($rangoFechas)->where('locomotora', $locomotoras);

        elseif(!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }
    

}
