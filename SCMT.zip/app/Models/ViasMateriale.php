<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ViasMateriale
 *
 * @property $id
 * @property $parte
 * @property $sap
 * @property $descripcion
 * @property $unidad
 * @property $preciounitario
 * @property $created_at
 * @property $updated_at
 *
 * @property ViasConsumo[] $viasConsumos
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class ViasMateriale extends Model
{
    
    static $rules = [
		'descripcion' => 'required',
		'unidad' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['parte','sap','descripcion','unidad','preciounitario'];

    const UNIDAD = ['EA','TR','KM'];


    public static function getall(){
        return self::select('id','parte', 'sap', 'descripcion', 'unidad', 'preciounitario',
                            'created_at', 'updated_at')
                    ->get();
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function viasConsumos()
    {
        return $this->hasMany('App\Models\ViasConsumo', 'material_vias_id', 'id');
    }
    

}
