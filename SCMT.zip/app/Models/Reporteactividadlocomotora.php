<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Reporteactividadlocomotora
 *
 * @property $id
 * @property $reportelocomotora_id
 * @property $locomotora
 * @property $fecha
 * @property $turno
 * @property $area
 * @property $falla
 * @property $fallamotivo
 * @property $descripcion
 * @property $estatus
 * @property $responsable
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property Reportedelocomotora $reportedelocomotora
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Reporteactividadlocomotora extends Model
{
    
    static $rules = [
		'reportelocomotora_id' => 'required',
		'locomotora' => 'required',
		'fecha' => 'required',
		'turno' => 'required',
		'area' => 'required',
		'falla' => 'required',
		'fallamotivo' => 'required',
		'descripcion' => 'required',
		'estatus' => 'required',
		'responsable' => 'required',
        'horas' => 'required',
    ];



    const ESTATUS = ['SI','NO'];

    const TURNO = ['1','2','3'];

    const AREA = ['MECANICO','ELECTRICO', 'NEUMATICO', 'LINEA DE SERVICIO', 'BOBINADO', 'TALLER DE COMPONENTES', 'ESTRUCTURAL', 'MECANICA INDUSTRIAL'];

    const FALLA = ['MOTOR DIESEL', 'GENERADOR PRINCIPAL', 'MOTORES DE TRACCION', 'TRUCKS', 'COMPRESOR DE AIRE', 'TURBO', 'GENERADOR BLOWER', 'TANQUE GASOIL', 'FRENO DINAMICO', 'FILTROS', 'RADIADOR', 'CABINA ELECTRICA', 'CABLEADO', 'COMPONENTES ELECTRICOS','LINEA DE SERVICIO', 'INSPECCION', 'ESTRUCTURAL', 'COMPONENTES NEUMATICOS', 'COMPONENTES MECANICOS'];

    const FALLAMOTIVO = ['DAÑADO', 'MAL MONTADO', 'MALA OPERACION', 'FRACTURADO', 'ROTO','INSPECCION', 'SERVICIO', 'RUTINA', 'PREVENTIVO'];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['reportelocomotora_id','locomotora','fecha','turno','area','falla','fallamotivo','descripcion','estatus','responsable','usuario_crea','usuario_actualiza', 'horas'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */

    public static function detalleactividadreporte(){
        return self::select('id', 'reportelocomotora_id','locomotora','fecha','turno','area','falla','fallamotivo','descripcion','estatus','responsable','usuario_crea','usuario_actualiza', 'created_at')
                ->orderBy('fecha', 'asc')
                ->get();
    }


    public function reportedelocomotora()
    {
        return $this->hasOne('App\Models\Reportedelocomotora', 'id', 'reportelocomotora_id');
    }
    
    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    } 
    
    public static function getAllXPeriodo($rangoFechas, $locomotoras){
        $sql = self::select('id', 'reportelocomotora_id','locomotora','fecha','turno','area','falla','fallamotivo','descripcion','estatus','responsable','usuario_crea','usuario_actualiza');

        if (!empty($rangoFechas and $locomotoras))
            $sql = $sql->RangoDeFechas($rangoFechas)->where('locomotora', $locomotoras);

        elseif(!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

}
