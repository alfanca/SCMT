<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Equipo_apoyo extends Model
    {
    protected $table='equipo_apoyo';
    protected $guarded = [];


    public static $rules = [
            'numero_fmo' => ['required', 'max:20'],
            'descripcion' => ['required', 'max:200'],
            'ubicacion' => ['required', 'max:100'],
            'estatus' => ['required', 'max:20'],
            'f_mantenimiento' => [''],
            'sap_ip10' => ['max:20'],
            'fecha_programa' => [''],
    ];


    public function estatusequipo(){
    	return ['Disponible','Mantenimiento','Fuera de Servicio'];
    }

    public static function ultimoregistro(){
        return self::select('updated_at')
                 ->get();
    }

    public static function equipos_numero(){
        return self::select('id', 'numero_fmo', 'descripcion', 'ubicacion','estatus', 'f_mantenimiento', 'sap_ip10', 'fecha_programa', 'foto')
                 ->selectRaw('fecha_programa + f_mantenimiento as programa, fecha_programa - f_mantenimiento as programar')
                 ->whereNotIn('estatus', ['Fuera de Servicio'])
                 ->whereNotNull('f_mantenimiento')
                 ->get();
    }

    public static function equiposGetALL(){
        return self::select('id', 'numero_fmo', 'descripcion', 'ubicacion','estatus', 'f_mantenimiento', 'sap_ip10', 'fecha_programa', 'foto')
                 ->selectRaw('fecha_programa + f_mantenimiento as programa, fecha_programa - f_mantenimiento as programar')
                 ->get();
    }

}
