<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class equipoferroviarios extends Model
{
    protected $table='equipoferroviarios';
    protected $guarded = [];

    public static function getAll(){
    	return self::select('id', 'equipo', 'fmo', 'cantidad', 'parados')
    			->selectRaw('cantidad - parados as real')
    			->get();
    }
}
