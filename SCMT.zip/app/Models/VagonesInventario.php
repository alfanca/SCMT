<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class VagonesInventario extends Model
{
    protected $table='vagones_inventario';
    protected $guarded = [];

    public function vagon()
   	{	
    	return $this->belongsTo(Vagones::class, 'vagones_id')->select('id', 'tipo');
   	}

    public function estatusVagones(){
        return [
            true => 'Activo',
            false => 'No Activo'
        ];
    }

    public function getEstatusAttribute($value){
        $estatus = [            
        	true => 'Activo',
            false => 'No Activo'];
        return $estatus[$value] ?? '';
    }

    public function crear($datos){
        foreach($datos['vagones'] as $vagon_inventario)
        {                
            $vagon = new Self();
            $vagon->vagones_id = $vagon_inventario;
            $vagon->anho = $datos['anho'];
            $vagon->estatus = $datos['estatus'];
            $vagon->usuario_c = Auth::user()->name;
            $vagon->save(); 
        }
    }

    public static function getInventarioPorAnho($anho){
    	return self::select('vagones_id', 'estatus', 'anho')
			->with(['vagon'])
            ->orderBy('vagones_id')
            ->get();
    }
 
}
