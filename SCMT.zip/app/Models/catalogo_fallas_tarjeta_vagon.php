<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class catalogo_fallas_tarjeta_vagon extends Model
{
   protected $table='vagones_catalogo_fallas_tarjeta';
   protected $guarded = [];


   static $rules = [
		'descripcion' => 'required',
		'lugar' => 'required | max:20',
		'responsable' => 'required',
		'nro_sap' => '',
		'nota' => 'max:500',
		'especificaciones_reparaciones' => 'max:500',
		'mecanicos' => 'max:100',
		'soldadores' => 'max:100',
		'supervisor' => 'max:100',
		'responsable_taller' => 'max:100',
		'cant_persona' => 'required',
		'taller_id' => 'required',
    ];

   public static function getall(){
        return self::select('id', 'descripcion','lugar', 'responsable','nro_sap', 'nota', 'especificaciones_reparaciones','mecanicos', 'soldadores', 'supervisor','responsable_taller', 'cant_persona', 'usuario_crea', 'usuario_actualiza','taller_id')
                ->get();
    }

    public static function editarTarjeta($taller_id){
        return self::select('id', 'descripcion','lugar', 'responsable','nro_sap', 'nota', 'especificaciones_reparaciones','mecanicos', 'soldadores', 'supervisor','responsable_taller', 'cant_persona', 'usuario_crea', 'usuario_actualiza','taller_id')
                ->where('taller_id', $taller_id)
                ->get();
    }

    public static function detalleTallerVagonCatalogo($taller_id){
        return self::select('id', 'descripcion','lugar', 'responsable','nro_sap', 'nota', 'especificaciones_reparaciones','mecanicos', 'soldadores', 'supervisor','responsable_taller', 'cant_persona', 'usuario_crea', 'usuario_actualiza','taller_id')
                    ->where('taller_id', $taller_id) 
                    ->get();
    }

    public function lugares(){
    	return ['PZO','CP'];
    }

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }
}
