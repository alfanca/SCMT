<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Reporteconsumiblelocomotora
 *
 * @property $id
 * @property $reportelocomotora_id
 * @property $materiales_id
 * @property $fecha
 * @property $locomotora
 * @property $cantidad
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property Materialeslocomotora $materialeslocomotora
 * @property Reportedelocomotora $reportedelocomotora
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Reporteconsumiblelocomotora extends Model
{
    
    static $rules = [
		'reportelocomotora_id' => 'required',
		'materiales_id' => 'required',
		'fecha' => 'required',
		'locomotora' => 'required',
		'cantidad' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['reportelocomotora_id','materiales_id','fecha','locomotora','cantidad','usuario_crea','usuario_actualiza','preciounitario'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */

    public static function detalleconsumiblereporte(){
        return self::select('id', 'reportelocomotora_id','materiales_id','fecha','locomotora','cantidad','usuario_crea','usuario_actualiza','preciounitario')
                ->get();
    }

    public function materiales()
    {
        return $this->belongsTo('App\Models\materialeslocomotora', 'materiales_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function reportedelocomotora()
    {
        return $this->hasOne('App\Models\Reportedelocomotora', 'id', 'reportelocomotora_id');
    }

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    } 
    
    public static function getAllXPeriodo($rangoFechas, $locomotoras){
        $sql = self::select('id', 'reportelocomotora_id','materiales_id','fecha','locomotora','cantidad','usuario_crea','usuario_actualiza','preciounitario')
                    ->selectRaw('cantidad * preciounitario as total')
                    ->orderBy('cantidad', 'desc');

        if (!empty($rangoFechas and $locomotoras))
            $sql = $sql->RangoDeFechas($rangoFechas)->where('locomotora', $locomotoras);

        elseif(!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }
    

}
