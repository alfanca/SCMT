<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class DatosBasicos extends Model
{
    protected $table='vw_datos_basicos';
    protected $primaryKey ='ficha';
    public $incrementing = false;

    public static function buscarPorFicha($ficha){
      if (isset($ficha)){
        return self::where('ficha', $ficha)->get();
      }
    }

    public static function buscar($id){
      return self::selectRaw("ficha as id, (ficha || ' - ' || nombre) as text")
                  ->whereRaw("lower(nombre) like lower('%$id%')")
                  ->orWhere('ficha', $id)
                  ->limit(50)->get();
    }
}
