<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConsumoVagones extends Model
{
    protected $table='consumo_vagones';
    protected $guarded = [];

    static $rules = [
		'vagon_id' => 'required',
		'fecha' => 'required',
		'componente_id' => 'required',
		'cantidad' => 'required',
    ];

    

    public static function getAll(){
    	return self::select('id', 'vagon_id', 'fecha', 'componente_id', 'cantidad', 'precio')
    			->get();
    }


    public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    }


    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }


    public static function getAllXPeriodo($rangoFechas, $vagones){

        $sql = self::select('id', 'vagon_id', 'fecha', 'componente_id','cantidad', 'precio')
                    ->selectRaw('cantidad * precio as total')
                    ->orderBy('cantidad', 'desc');

        if (!empty($rangoFechas and $vagones))
          
            $sql = $sql->RangoDeFechas($rangoFechas)->where('vagon_id', $vagones);

        elseif (!empty($rangoFechas))

            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

    public static function detalleTallerVagonConsumo($taller_id){
        return self::select('id', 'vagon_id', 'fecha', 'componente_id','cantidad', 'precio','taller_id')
                    ->selectRaw('cantidad * precio as total')
                    ->where('taller_id', $taller_id) 
                    ->get();
    }

    public function materialesvagones()
    {
        return $this->belongsTo('App\Models\materialesvagones', 'componente_id', 'id');
    }
   

}
