<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ViasConsumo
 *
 * @property $id
 * @property $material_vias_id
 * @property $fecha
 * @property $tramo
 * @property $ubicacion_inicial
 * @property $ubicacion_final
 * @property $turno
 * @property $cantidad
 * @property $precio
 * @property $razon
 * @property $descripcion
 * @property $responsable
 * @property $usuario_crea
 * @property $usuario_actualiza
 * @property $created_at
 * @property $updated_at
 *
 * @property ViasMateriale $viasMateriale
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class ViasConsumo extends Model
{
    
    static $rules = [
		'material_vias_id' => 'required',
		'fecha' => 'required',
		'tramo' => 'required',
		'ubicacion_inicial' => 'required',
		'ubicacion_final' => 'required',
		'turno' => 'required',
		'cantidad' => 'required',
		'razon' => 'required',
		'descripcion' => 'required',
		'responsable' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['material_vias_id','fecha','tramo','ubicacion_inicial','ubicacion_final','turno','cantidad','precio','razon','descripcion','responsable','usuario_crea','usuario_actualiza'];

    const TURNO = ['1','2','3'];
    const RAZON = ['CORRECTIVO','PREVENTIVO','DESCARRILAMIENTO', 'AJUSTE', 'CALIBRACIÓN', 'LIMPIEZA','EVENTO NO DESEADO', 'REHABILITACIÓN'];
    const TRAMO = ['NOTA','L/P-PUENTE','TALLERES','L/P','SIDOR','PALUA','PATIO','P.PELLA','O.IRON','COMSIGUA','BRIQVEN'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function viasMateriale()
    {
        return $this->hasOne('App\Models\ViasMateriale', 'id', 'material_vias_id');
    }
    
    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

      public function scopeRangoDeFechas($query, $fechas){
        return $query->whereBetween('fecha', $fechas);
    }  



    public static function getall(){
        return self::select('id','material_vias_id','fecha','tramo','ubicacion_inicial','ubicacion_final','turno','cantidad','precio','razon','descripcion','responsable','usuario_crea','usuario_actualiza')
                    ->whereYear('fecha', now())
                    ->whereMonth('fecha', now())
                    ->get();
    }


    public static function getAllXPeriodo($rangoFechas, $tramosselec){
        $sql = self::select('id','material_vias_id','fecha','tramo','ubicacion_inicial','ubicacion_final','turno','cantidad','precio','razon','descripcion','responsable','usuario_crea','usuario_actualiza')
            ->with(['datos', 'viasMateriale']);

        if (!empty($rangoFechas and $tramosselec))
            $sql = $sql->RangoDeFechas($rangoFechas)->where('tramo', $tramosselec);

        elseif(!empty($rangoFechas))
            $sql = $sql->RangoDeFechas($rangoFechas);
        

        return $sql;

    }

}
