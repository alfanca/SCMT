<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;

class VagonesInspeccion extends Model
{
    protected $table='vagones_inspecciones';
    protected $guarded = [];
    use SoftDeletes;

    public function inspector()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'ficha_inspector');
    }

    public function getFechaAttribute($fecha){
        return \Carbon\Carbon::parse($fecha)->format('Y-m-d');
    }

    public function getHoraSalidaAttribute($fecha){
        return \Carbon\Carbon::parse($fecha)->format('Y-m-d H:i');
    }    

    public function listadTrenesSelect(){
    	return ['TREN 02', 'TREN 04', 'TREN 06', 'TREN EXTRA CARGADO', 'TREN 01', 'TREN 03', 'TREN 05', 'TREN EXTRA VACIO', 'PRODUCTO','PTLB'];
    }

    public function vagones(){	
    	return $this->hasMany(VagonesInspeccionDetalle::class, 'vagones_inspecciones_id', 'id');
   	}

    public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

}
