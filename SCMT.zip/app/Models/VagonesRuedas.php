<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VagonesRuedas extends Model
{

	protected $table='vagones_ruedas';
    protected $guarded = [];

    static $rules = [
		'vagon_id' => 'required',
		'fecha' => 'required',
		'rueda_1' => 'required',
		'rueda_8' => 'required',
		'rueda_2' => 'required',
		'rueda_7' => 'required',
		'rueda_3' => 'required',
		'rueda_6' => 'required',
		'rueda_4' => 'required',
		'rueda_5' => 'required',
    ];



    public static function dataindex($anho){
        return self::select('id','vagon_id','fecha', 'rueda_1', 'rueda_8', 'rueda_2', 'rueda_7','rueda_3','rueda_6', 'rueda_4','rueda_5','usuario_crea','usuario_actualiza')
            ->whereYear('fecha', $anho)
            ->orderBy('fecha', 'desc')->get();
        
    }

    public static function detalleTallerVagon($taller_id){
        return self::select('id', 'vagon_id', 'fecha', 'rueda_1', 'rueda_8', 'rueda_2' ,'rueda_7', 'rueda_3', 'rueda_6', 'rueda_4', 'rueda_5','taller_id')
        			->where('taller_id', $taller_id) 
                    ->get();
    }
}
