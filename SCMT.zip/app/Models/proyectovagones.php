<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class proyectovagones extends Model
{
	protected $table='proyecto_vagones';    
    protected $guarded = [];


    static $rules = [
		'descripcion' => 'required', 'max:500',
		'fecha_inicio' => 'required',
		'fecha_fin' => 'required',
        'responsable' => 'required',
        'jefeareausuaria' => 'required',
        'jefeplanificacion' => 'required',
		'estatus' => 'max:20',
		'nota' => 'max:500',
    ];



    public function estatu(){
        return ['ABIERTA','EN PROCESO','FINALIZADO'];
    }


    public static function getAll(){
        return self::select('id', 'descripcion','fecha_inicio','fecha_fin','estatus','nota', 'responsable', 'jefeareausuaria', 'jefeplanificacion', 'usuario_crea','usuario_actualiza')
                ->get();
    }

    public function datos()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'responsable');
    }

    public function datosjefearea()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'jefeareausuaria');
    }

    public function datosjefeplanificacion()
    {
        return $this->hasOne(DatosBasicos::class, 'ficha', 'jefeplanificacion');
    }
}
