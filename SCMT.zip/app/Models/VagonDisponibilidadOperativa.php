<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VagonDisponibilidadOperativa extends Model
{
    use SoftDeletes;
    protected $table='vagones_disponibilidad_operativa';
    
    protected $guarded = [];

    public function lugaresGondolas(){
    	return ['TOTAL GONDOLAS'];
    }    

    public function lugaresTolvas(){
        return ['TOTAL TOLVAS'];
    }    

	public function scopeFecha($query, $fecha)
    {
        return $query->whereDate('fecha', $fecha);
    }

    public function scopeTurno($query, $turno)
    {
        return $query->where('turno', $turno);
    }    

    public static function listarDisponibilidad(){
    	return self::select('id', 'turno','fecha', 'lugar', 'tipo_vagon', 'cantidad', 'usuario_crea');
    }

    public static function verUltimoTurnoCargado(){
        return self::select(DB::raw('max(fecha) as fecha'), 'turno')
        ->groupBy('turno')
         ->orderByRaw('fecha desc, turno desc')
        ->first();
    }

    public static function verUltimaDisponibilidadCargada($fecha, $turno){
        return self::select(DB::raw('sum(cantidad) as cantidad'), 'tipo_vagon')->whereDate('fecha', '=', $fecha)
        ->where('turno', $turno)
        ->groupBy('tipo_vagon')
        ->get();
    }    
    
}
