<?php

namespace App\Providers;

/*
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
*/

use Illuminate\Contracts\Auth\Access\Gate as GateContract; 
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;


class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot(GateContract $gate)
    {
        $this->registerPolicies($gate);

        $gate->define('isAdmin', function($user){
            return $user->rol == 'admin';
        });

        $gate->define('isJefe', function($user){
            return $user->rol == 'jefe';
        });    

        $gate->define('isplanificador', function($user){
            return $user->rol == 'planificador';
        });     

        $gate->define('isinvitado', function($user){
            return $user->rol == 'invitado';
        });

        $gate->define('isanalistam', function($user){
            return $user->rol == 'analistam';
        });

        $gate->define('issecretaria', function($user){
            return $user->rol == 'secretaria';
        });

        $gate->define('isgestionoperaciones', function($user){
            return $user->rol == 'gestionoperaciones';
        });

        $gate->define('ispasante', function($user){
            return $user->rol == 'pasante';
        });  

        $gate->define('issenale', function($user){
            return $user->rol == 'senale';
        }); 

        $gate->define('isvagones', function($user){
            return $user->rol == 'vagones';
        });     

        $gate->define('islocomotoras', function($user){
            return $user->rol == 'locomotoras';
        });                 
    }
}
