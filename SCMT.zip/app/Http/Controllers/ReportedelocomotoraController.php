<?php

namespace App\Http\Controllers;

use App\Models\Reportedelocomotora;
use App\Models\Reportetiempolocomotora;
use App\Models\Reporteconsumiblelocomotora;
use App\Models\Reporteactividadlocomotora;
use App\Models\Locomotora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class ReportedelocomotoraController
 * @package App\Http\Controllers
 */
class ReportedelocomotoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reportedelocomotoranocerradascorrectivo = Reportedelocomotora::getAllCorrectivo();
        $reportedelocomotoranocerradascorrectivoNotificado = Reportedelocomotora::getAllCorrectivoNotificado();
        $reportedelocomotoranocerradaslineaservicio = Reportedelocomotora::getAllLineaservicio();
        $reportedelocomotoranocerradaspreventivo = Reportedelocomotora::getAllPreventivo();

        return view('app.locomotora.reportedelocomotora.index', compact('reportedelocomotoranocerradascorrectivo', 'reportedelocomotoranocerradaspreventivo', 'reportedelocomotoranocerradaslineaservicio', 'reportedelocomotoranocerradascorrectivoNotificado'))
            ->with('i');
    }

    public function ferroreporte($id)
    {
        $reportedelocomotora = Reportedelocomotora::find($id);
        $reportetiempo = Reportetiempolocomotora::detalletiemporeporte()->where('reportelocomotora_id', $id);
        $reportetiempoconteo = Reportetiempolocomotora::detalletiemporeporte()->where('reportelocomotora_id', $id)->groupBy('responsable')->count();
        $reportetiemposuma = Reportetiempolocomotora::detalletiemporeporte()->where('reportelocomotora_id', $id)->sum('horas');
        $reporteconsumible = Reporteconsumiblelocomotora::detalleconsumiblereporte()->where('reportelocomotora_id', $id);
        $reporteactividad = Reporteactividadlocomotora::detalleactividadreporte()->where('reportelocomotora_id', $id);

        return view('app.locomotora.reportedelocomotora.ferro', compact('reportedelocomotora', 'reportetiempo', 'reporteconsumible', 'reporteactividad', 'reportetiemposuma', 'reportetiempoconteo'));
    }


    public function periodoreporte(Request $request)
    {
        $locomotoras = Locomotora::pluck('numero', 'id');
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $locomotora = $request['locomotora_id'] ?? null;
        $reporte_all = Reportedelocomotora::getAllXPeriodo($fechas, $locomotora)->orderBy('fecha_entrada')->get();

    
        return view('app.locomotora.reportedelocomotora.vista_all', compact('reporte_all', 'fechas', 'locomotoras', 'locomotora'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $reportedelocomotora = new Reportedelocomotora();
        $locomotoras = Locomotora::listadoLocomotorasSelect()->pluck('numero', 'id');
        $estatus = collect(Reportedelocomotora::ESTATUS);
        $ceco = collect(Reportedelocomotora::CECO);
        $planeado = collect(Reportedelocomotora::PLANEADO);
        $escogerplaneado = collect(Reportedelocomotora::ESCOGERPLANEADO);
        $escogernoplaneado = collect(Reportedelocomotora::ESCOGERNOPLANEADO);
        $razonfalla = collect(Reportedelocomotora::RAZONFALLA);
        $razondemora = collect(Reportedelocomotora::RAZONDEMORA);

        return view('app.locomotora.reportedelocomotora.create', compact('reportedelocomotora', 'locomotoras', 'estatus', 'ceco', 'planeado', 'escogerplaneado', 'escogernoplaneado','razonfalla','razondemora'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(Reportedelocomotora::$rules);

        if (empty($request->n_orden)) {
            $request['estatus'] = 'ABIERTA';
        }
        else{
            $request['estatus'] = 'LIBERADA';
        }

        if ($request->planeado == '0') {
            $request['fecha_salida'] = $request->fecha_salida;
        }

        else{
            $request['fecha_salida'] = null;
        }
        
        $request['usuario_crea'] = Auth::user()->name;
        $reportedelocomotora = Reportedelocomotora::create($request->all());


        return redirect()->route('reportedelocomotoras.index')
            ->with('success', 'Reportedelocomotora created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $reportedelocomotora = Reportedelocomotora::find($id);
        $reportetiempo = Reportetiempolocomotora::detalletiemporeporte()->where('reportelocomotora_id', $id);
        $reporteconsumible = Reporteconsumiblelocomotora::detalleconsumiblereporte()->where('reportelocomotora_id', $id);
        $reporteactividad = Reporteactividadlocomotora::detalleactividadreporte()->where('reportelocomotora_id', $id)->sortByDesc('created_at');
        $conteoactividades =$reporteactividad->count();

        $agruparPersonal = $reportetiempo ->groupBy('responsable')->count();
        $horasTaller = $reportetiempo->sum('horas');

        return view('app.locomotora.reportedelocomotora.show', compact('reportedelocomotora', 'reportetiempo', 'reporteconsumible', 'reporteactividad', 'conteoactividades', 'agruparPersonal', 'horasTaller'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $reportedelocomotora = Reportedelocomotora::find($id);
        $locomotoras = Locomotora::listadoLocomotorasSelect()->pluck('numero', 'id');
        $estatus = collect(Reportedelocomotora::ESTATUS);
        $ceco = collect(Reportedelocomotora::CECO);
        $planeado = collect(Reportedelocomotora::PLANEADO);
        $escogerplaneado = collect(Reportedelocomotora::ESCOGERPLANEADO);
        $escogernoplaneado = collect(Reportedelocomotora::ESCOGERNOPLANEADO);
        $razonfalla = collect(Reportedelocomotora::RAZONFALLA);
        $razondemora = collect(Reportedelocomotora::RAZONDEMORA);

        return view('app.locomotora.reportedelocomotora.edit', compact('reportedelocomotora', 'locomotoras', 'estatus', 'ceco', 'planeado', 'escogerplaneado', 'escogernoplaneado','razonfalla','razondemora'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Reportedelocomotora $reportedelocomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Reportedelocomotora $reportedelocomotora)
    {
        request()->validate(Reportedelocomotora::$rules);

        if (empty($request->n_orden) and $request->estatus != 'CERRADA') {
            $request['estatus'] = 'ABIERTA';
        }
        
        elseif (!empty($request->n_orden) and $request->estatus != 'CERRADA'){ 
            $request['estatus'] = 'LIBERADA';
        }
        
        $request['usuario_actualiza'] = Auth::user()->name; 
        $reportedelocomotora->update($request->all());

        return redirect()->route('reportedelocomotoras.index')
            ->with('success', 'Reportedelocomotora updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $reportedelocomotora = Reportedelocomotora::find($id)->delete();

        return redirect()->route('reportedelocomotoras.index')
            ->with('success', 'Reportedelocomotora deleted successfully');
    }
}
