<?php

namespace App\Http\Controllers;

use App\Models\ConsumoVagones;
use App\Models\materialesvagones;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ConsumoVagonesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $vagonconsumos = ConsumoVagones::getAll();

        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $vagones = $request['vagon_id'] ?? null;

        $listadoRegistroDeConsumo = ConsumoVagones::getAllXPeriodo($fechas, $vagones)->get();

        $consumoPorTipo =  $listadoRegistroDeConsumo->groupBy('componente_id');

        $graficaConsumo = $consumoPorTipo->take(6); 


        return view('app.vagones.consumibles_vagones.index', compact('vagonconsumos', 'listadoRegistroDeConsumo', 'consumoPorTipo', 'graficaConsumo'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $vagonconsumo = new ConsumoVagones;

        $materiales = materialesvagones::materialesConsumo();

        return view('app.vagones.consumibles_vagones.create',compact('vagonconsumo', 'materiales'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ConsumoVagones::$rules);

        foreach ($request->componente_id as $index => $componente) {
            $request['precio'] = materialesvagones::where('id',$componente)->first()->preciounitario??0;
            ConsumoVagones::create(
                [
                    'vagon_id' => $request->vagon_id,
                    'fecha' => $request->fecha,
                    'componente_id' => $componente,
                    'cantidad' => $request->cantidad[$index],
                    'precio' => $request->precio,
                    'taller_id' => $request->taller_id,
                    'usuario_crea' => Auth::user()->name
                ]);
        }

        return redirect()->back()
            ->with('success', 'Consumo created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ConsumoVagones  $consumoVagones
     * @return \Illuminate\Http\Response
     */
    public function show(ConsumoVagones $consumoVagones)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ConsumoVagones  $consumoVagones
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $vagonconsumo = ConsumoVagones::find($id);
       
        $materiales = materialesvagones::materialesConsumo();

        return view('app.locomotora.maestropreventivolocomotora.edit', compact('vagonconsumo', 'materiales'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ConsumoVagones  $consumoVagones
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ConsumoVagones $consumoVagones)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ConsumoVagones  $consumoVagones
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $consumoVagones = ConsumoVagones::find($id)->delete();

        return redirect()->back()
            ->with('success', 'Consumo deleted successfully');
    }
}
