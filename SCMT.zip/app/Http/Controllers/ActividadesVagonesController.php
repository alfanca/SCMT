<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Clases\Turno;
use App\Clases\Fechas;
use App\Models\ActividadVagon;

class ActividadesVagonesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $fecha = $request->fecha ?? date('Y-m-d');
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $listadoActividades = ActividadVagon::listarActidades()->fecha($fecha)->get()->sortBy('turno')->groupBy('turno');
        return view('app.vagones.actividades.index', compact('listadoActividades', 'fechas'));
    }

    /**  
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $turnos = Turno::TURNOS;
        $actividad = new ActividadVagon;
        return view('app.vagones.actividades.create', compact('turnos', 'actividad'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        $datos['usuario_crea'] = Auth::user()->name;
        ActividadVagon::create($datos);
        return redirect(route('vagones_actividades.index'))->with('success', 'Creada con exito');
    }

    public function validaData($request){
        return $request->validate([
            'turno' => ['required'],
            'actividad' => ['required'],
            'responsable' => ['required'],
            'fecha' => ['required'],
            'area' => ['required'],
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($fecha)
    {
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $listadoActividades = ActividadVagon::listarActidades()->fecha($fecha)->get()->sortBy('turno')->groupBy('turno');
        return view('app.vagones.actividades.index', compact('listadoActividades', 'fechas'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(ActividadVagon $actividad)
    {
        $turnos = Turno::TURNOS;
        return view('app.vagones.actividades.edit', compact('actividad', 'turnos'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ActividadVagon $actividad)
    {
        $datos = $this->validaData($request);
        $datos['usuario_actualiza'] = Auth::user()->name;
        $actividad->update($datos);
        return redirect(route('vagones_actividades.index'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(ActividadVagon $actividad)
    {
        $actividad->usuario_elimina = Auth::user()->name;
        $actividad->save();
        $actividad->delete();
        return redirect(route('vagones_actividades.index'))->with('success', 'Eliminado con exito');
    }
}
