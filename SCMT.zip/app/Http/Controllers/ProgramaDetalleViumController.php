<?php

namespace App\Http\Controllers;

use App\Models\ProgramaDetalleVium;
use App\Models\ProgramaActiviadesVium;
use App\Models\ProgramaAnualVium;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

/**
 * Class ProgramaDetalleViumController
 * @package App\Http\Controllers
 */
class ProgramaDetalleViumController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(request $request)
    {   
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];

        $programaDetalleVia = ProgramaDetalleVium::getAll($fechas)->orderBy('fecha')->get();

        return view('app.via.programa-detalle-vium.index', compact('programaDetalleVia'))
            ->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programaDetalleVium = new ProgramaDetalleVium();
        $programaAnual = ProgramaAnualVium::selectorAnual();

        return view('app.via.programa-detalle-vium.create', compact('programaDetalleVium', 'programaAnual'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try{
            DB::beginTransaction();


            //request()->validate(ProgramaDetalleVium::$rules, ProgramaDetalleVium::$messages);


            foreach ($request->programa_anual_id as $index => $programa) {

                $fechaProgramaanual = ProgramaAnualVium::whereId($programa)->first();
                $fechaProgramaanual->fecha_actualizacion = $request->fecha[$index];
                $fechaProgramaanual->save();

                ProgramaDetalleVium::create(
                    [
                        'programa_via_id' => $request->programa_via_id,
                        'programa_anual_id' => $programa,
                        'fecha' => $request->fecha[$index],
                        'plan' => $request->plan[$index],
                        'nro_orden' => $request->nro_orden[$index],
                        'nota' => $request->nota[$index],
                        'usuario_crea' => Auth::user()->name

                    ]);

            }
            DB::commit();
           return redirect()->route('programavias.index')
            ->with('success', 'ProgramaDetalleVium created successfully.');    
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'ProgramaDetalleVium created failed: '.$e->getMessage()); 
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programaDetalleVium = ProgramaDetalleVium::find($id);

        return view('app.via.programa-detalle-vium.show', compact('programaDetalleVium'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programaDetalleVium = ProgramaDetalleVium::find($id);

        return view('app.via.programa-detalle-vium.edit', compact('programaDetalleVium', 'programaActividadesVia'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramaDetalleVium $programaDetalleVium
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramaDetalleVium $programaviasdetalle)
    {
        try{
            DB::beginTransaction();


        //request()->validate(ProgramaDetalleVium::$rules);

        $fechaProgramaanual = ProgramaAnualVium::whereId($request->programa_anual_id)->first();
        $fechaProgramaanual->fecha_actualizacion = $request->fecha;
        $fechaProgramaanual->save();

        $request['usuario_actualiza'] = Auth::user()->name; 

        $programaviasdetalle->update($request->all());

         DB::commit();
           return redirect()->route('programavias.index')
            ->with('success', 'ProgramaDetalleVium created successfully.');    
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'No se ha Actulizado, Revise el Formulario '); 
        }
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy(Request $request, ProgramaDetalleVium $programaviasdetalle)
    {
        try{
            DB::beginTransaction();
                $fechaprogramaeditar = ProgramaAnualVium::where('id', $programaviasdetalle->programa_anual_id)->first();
                
                $reprogramacionId = $programaviasdetalle->programa_anual_id;

                $programaviasdetalle->delete();

                $fecha_programa = ProgramaDetalleVium::borradodedetalle($reprogramacionId);
                
                $fechaprogramaeditar->fecha_actualizacion = $fecha_programa;

                $fechaprogramaeditar->save();
            DB::commit();
            return redirect()->back()
                ->with('success', 'El Programa fue Borrado');    
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'No se ha Borrado el Programa'); 
        }

    }
}
