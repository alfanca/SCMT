<?php

namespace App\Http\Controllers;

use App\Models\equipoferroviarios;
use Illuminate\Http\Request;

class EquipoferroviariosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $eqferroviarios = equipoferroviarios::getAll();
       return view('app.via.eqferroviario.index', compact('eqferroviarios'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $eqferroviario = new equipoferroviarios;
        return view('app.via.eqferroviario.create',compact('eqferroviario')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        equipoferroviarios::create($datos);
        return redirect(route('eqferroviario.index'))->with('success', 'Creada con exito');
    }

      public function validaData($request){
        return $request->validate([
            'equipo' => ['required'],
            'fmo' => ['required'],
            'cantidad' => ['required'],
            'parados' => ['required'],
        ]);
    }
    

    /**
     * Display the specified resource.
     *
     * @param  \App\equipoferroviarios  $equipoferroviarios
     * @return \Illuminate\Http\Response
     */
    public function show(equipoferroviarios $equipoferroviarios)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\equipoferroviarios  $equipoferroviarios
     * @return \Illuminate\Http\Response
     */
    public function edit(equipoferroviarios $eqferroviario)
    {
       return view('app.via.eqferroviario.edit', array('eqferroviario' => $eqferroviario));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\equipoferroviarios  $equipoferroviarios
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, equipoferroviarios $eqferroviario)
    {
        $datos = $this->validaData($request);
        $eqferroviario->update($datos);
        return redirect(route('eqferroviario.index'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\equipoferroviarios  $equipoferroviarios
     * @return \Illuminate\Http\Response
     */
    public function destroy(equipoferroviarios $eqferroviario)
    {
        $eqferroviario->delete();
        return redirect(route('eqferroviario.index'))->with('success', 'Eliminado con exito');
    }
}
