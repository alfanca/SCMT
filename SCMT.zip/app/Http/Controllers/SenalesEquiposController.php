<?php

namespace App\Http\Controllers;

use App\Models\senales_equipos;
use Illuminate\Http\Request;

class SenalesEquiposController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $equipos = senales_equipos::equipos();
        $disponible = $equipos->where('estatus', 'Disponible')->count();
        $parcialmente = $equipos->where('estatus', 'Parcialmente')->count();
        $mantenimiento = $equipos->where('estatus', 'Mantenimiento')->count();
        $total = $equipos->count();
        return view('app.senales.equipos.index', compact('equipos','disponible','parcialmente','mantenimiento','total'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $equipo = new senales_equipos;
        return view('app.senales.equipos.create',compact('equipo')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        senales_equipos::create($datos);
        return redirect(route('equipos.index'))->with('success', 'Creada con exito');
    }


    public function validaData($request){
        return $request->validate([
            'equipo' => ['required', 'max:12'],
            'conjunto' => ['max:2'],
            'lugar' => ['required', 'max:20'],
            'ubicacion' => ['required', 'max:20'],
            'descripcion' => ['required', 'max:100'],
            'estatus' => ['required', 'max:20'],
            'tipo_mant' => [''],
            'mantenimiento' => [''],
            'fecha_programa' => [''],
            'sap_ipdiez' => [''],
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\senales_equipos  $senales_equipos
     * @return \Illuminate\Http\Response
     */
    public function show(senales_equipos $senales_equipos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\senales_equipos  $senales_equipos
     * @return \Illuminate\Http\Response
     */
    public function edit(senales_equipos $equipo)
    {
        return view('app.senales.equipos.edit', array('equipo' => $equipo));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\senales_equipos  $senales_equipos
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, senales_equipos $equipo)
    {
        $datos = $this->validaData($request);
        $equipo->update($datos);
        return redirect(route('equipos.index'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\senales_equipos  $senales_equipos
     * @return \Illuminate\Http\Response
     */
    public function destroy(senales_equipos $equipo)
    {
        $equipo->delete();
        return redirect(route('equipos.index'))->with('success', 'Eliminado con exito');
    }
}
