<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

use App\Models\VagonTaller;
use App\Models\VagonesRuedas;
use App\Models\ConsumoVagones;
use App\Models\catalogo_fallas_tarjeta_vagon;
use App\Models\Vagones;
use App\Models\VagonesInspeccionDetalle;

class VagonTallerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $taller = VagonTaller::getActivos();
        $vagonesPatio = $taller->where('estatus_proceso', VagonTaller::EN_LINEA_4)->WhereNull('proyecto_id')->sortBy('vagones_id');
        $vagonesTaller = $taller->where('estatus_proceso', VagonTaller::EN_TALLER)->sortBy('vagones_id');
        $vagonesReparados = $taller->where('estatus_proceso', VagonTaller::EN_TALLER_REPARADO)->sortBy('vagones_id');
        return view('app.vagones.taller.index', compact('taller', 'vagonesPatio', 'vagonesTaller', 'vagonesReparados'));
    }

    public function vagonestallerbusqueda(Request $request)
    {
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $busqueda = VagonTaller::getVagonesRegistradosTaller($fechas);
        $conteoIngresoTaller = $busqueda ->count();

        $vagonesIngresadosTaller = $busqueda->WhereNotNull('fecha_ingreso_taller')->count();

        $VagonesReparadosTaller = $busqueda->WhereNotNull('fecha_reparado_taller')->count();  

        $vagonesEntregados = $busqueda->WhereNotNull('fecha_salida_taller')->count(); 

        if ($conteoIngresoTaller > 0)
            $tiempotaller = round(($busqueda->sum('total'))/$vagonesIngresadosTaller);
        else
            $tiempotaller = 0;

        $horastotal = round($busqueda->sum('total'));   

        $horashombres = round($busqueda->sum('total')*4);


        return view('app.vagones.taller.tallerbusqueda', compact('busqueda', 'conteoIngresoTaller','tiempotaller','horastotal', 'horashombres','VagonesReparadosTaller','vagonesIngresadosTaller', 'vagonesEntregados'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $taller = new VagonTaller();
        return view('app.vagones.taller.create', compact('taller'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try{
            DB::beginTransaction();
                $taller = new VagonTaller;
                $taller->crear($request['vagones'], $request['fecha_ingreso'], $request['proyecto_id']);

                if (!empty($request['proyecto_id'])) {

                    foreach ($request->vagones as $index => $vagon) {
                    $vagones = vagones::whereId($vagon)->first();
                    $vagones->proyecto_recuperacion = 'SI';
                    $vagones->save();
                    }
                    
                }
                
            DB::commit();        
            
            if (!empty($request['proyecto_id'])) {
             
             return redirect(route('proyectoVagones.index'))->with('success', 'Vagon registrado con exito');
            }else{
            return redirect(route('taller.index'))->with('success', 'Vagon registrado con exito');
            }
        }catch (\Exception $e) {
            DB::rollback();
            dd($e);
            \Notify::error('Favor revise algunas locomtoras ya estan registradas');
            return redirect('/');
      }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $tallerVagon = VagonTaller::find($id);

       $tallerVagonCatalogo = catalogo_fallas_tarjeta_vagon::detalleTallerVagonCatalogo($id)->first();

       $tallerVagonRuedas = VagonesRuedas::detalleTallerVagon($id);

       $tallerVagonConsumo = ConsumoVagones::detalleTallerVagonConsumo($id);

        return view('app.vagones.taller.show', compact('tallerVagon', 'tallerVagonRuedas', 'tallerVagonConsumo', 'tallerVagonCatalogo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VagonTaller $taller)
    {
        try{
            if(isset($request['fecha_ingreso'])){
                $lugar = $taller->moverVagonTaller($request['estatus_proceso'], $request['fecha_ingreso']);
                $taller->usuario_a = Auth::user()->name;
                

                if ($taller->verficarVagonReparado()){
                    Vagones::actualizarDisponibilidad($taller->vagones_id, $request['fecha_ingreso'], 'ENTREGADO OPERACIONES', true);    
                    $taller->estatus = VagonTaller::CERRADA;
                }else{
                    Vagones::actualizarDisponibilidad($taller->vagones_id, $request['fecha_ingreso'], $taller->ubicacionTaller(), false); 
                }

                $taller->save();

                if (!empty($taller->proyecto_id and $taller->estatus_proceso > 2)) {
                    $vagones = vagones::whereId($taller->vagones_id)->first();
                    $vagones->proyecto_recuperacion = null;
                    $vagones->save();
                }

                

                return redirect(route('taller.index'))->with('success', 'Proceso realizado con éxito');
            }
            else
                return redirect(route('taller.index'))->with('error', 'Un error ha ocurrido');
        }catch (\Exception $e) {
            DB::rollback();
            dd($e);
            return redirect(route('taller.index'))->with('error', 'Un error ha ocurrido');
      }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(VagonTaller $taller)
    {
        try{
            $taller->usuario_e = Auth::user()->name;
            $taller->delete();

            $vagon = Vagones::findOrFail($taller->vagones_id);
            $vagon->disponible = true;
           
            $UltimaUbicacion = VagonesInspeccionDetalle::getInfoUltimaUbicacionVagon($taller->vagones_id)->inspeccion ?? null;

            $vagon->ultima_ubicacion = $UltimaUbicacion->tren ?? 'DESCONOCIDA';
            $vagon->fecha_ultima_ubicacion = $UltimaUbicacion->hora_salida ?? date('Y-m-d');
            $vagon->save();
            return redirect(route('taller.index'))->with('success', 'Proceso realizado con éxito');
        }catch (\Exception $e) {
            DB::rollback();
            dd($e);
            return redirect(route('taller.index'))->with('error', 'Un error ha ocurrido');
      }
    }

    public function retornar_estatus(VagonTaller $taller){
        
        $fechaAnterior = $taller->retornarEstatus();
        $taller->usuario_a = Auth::user()->name;
        $taller->save();
        
        Vagones::actualizarDisponibilidad($taller->vagones_id, $fechaAnterior, $taller->ubicacionTaller(), false); 

        if (!empty($taller->proyecto_id)) {
        $vagones = vagones::whereId($taller->vagones_id)->first();
        $vagones->proyecto_recuperacion = 'SI';
        $vagones->save();
        }

        return redirect(route('taller.index'))->with('success', 'Proceso realizado con éxito');
    }
}
