<?php

namespace App\Http\Controllers;

use App\Models\materialesvagones;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MaterialesvagonesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $materialesvagones = materialesvagones::all();
        return view('app.vagones.materiales.index', compact('materialesvagones'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $materialesvagone = new materialesvagones;
        return view('app.vagones.materiales.create',compact('materialesvagone')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $registro = Validator::make($request->all(), materialesvagones::$rules, materialesvagones::$error_message)->validate();
        try{
            if($request->hasFile('foto')){
                $file = $request->file('foto');
                $name = time().$file->getClientOriginalName();
                $file -> move(\public_path().'/imagenesmaterialesvagones/', $name);
            }
            if (!empty($request->hasFile('foto'))) {
            $registro['foto'] = $name;

            }
            materialesvagones::create($registro);
            return redirect(route('materialesvagones.index'))->with('success', 'Creada con exito');
        }catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
       }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\materialesvagones  $materialesvagones
     * @return \Illuminate\Http\Response
     */
    public function show(materialesvagones $materialesvagone)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\materialesvagones  $materialesvagones
     * @return \Illuminate\Http\Response
     */
    public function edit(materialesvagones $materialesvagone)
    {
       return view('app.vagones.materiales.edit', array('materialesvagone' => $materialesvagone));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\materialesvagones  $materialesvagones
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, materialesvagones $materialesvagone)
    {
        $registro = Validator::make($request->all(), materialesvagones::$rules, materialesvagones::$error_message)->validate();
        try{
            if($request->hasFile('foto')){
                $file = $request->file('foto');
                $name = time().$file->getClientOriginalName();
                $file -> move(\public_path().'/imagenesmaterialesvagones/', $name);
            }
            if (!empty($request->hasFile('foto'))) {
            $registro['foto'] = $name;

            }
            $materialesvagone->update($registro);
            return redirect(route('materialesvagones.index'))->with('success', 'Creada con exito');
        }catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
       }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\materialesvagones  $materialesvagones
     * @return \Illuminate\Http\Response
     */
    public function destroy(materialesvagones $materialesvagone)
    {
         $materialesvagone->delete();
        return redirect(route('materialesvagones.index'))->with('success', 'Eliminado con exito');
    }
}
