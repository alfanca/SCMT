<?php

namespace App\Http\Controllers;

use App\Clases\Turno;
use App\Clases\Fechas;

use App\Models\LocomotoraConsumo;
use App\Models\Locomotora;
use Illuminate\Http\Request;

class LocomotoraConsumoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $locomotoras = Locomotora::listadoLocomotorasSelect(); 
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $locomotora = $request['locomotora_id'] ?? null;
        $listadoRegistroDeConsumo = LocomotoraConsumo::getAllXPeriodo($fechas, $locomotora)->get();

        $listadoConsumoPorLocomotora = LocomotoraConsumo::getConsumoPorLocomotoraPorFechas($fechas)->groupBy('tipo');
        
        return view('app.locomotora.consumibles.index', 
            compact('listadoRegistroDeConsumo', 'fechas', 'listadoConsumoPorLocomotora', 'locomotoras'));
    }


    public function crear(Request $request)
    {
        if (empty($request['fecha_inicio'])){
            $fechas = array(date('Y-m-d'), date('Y-m-d'));
        }
        else{
            $fechas = array($request['fecha_inicio'], $request['fecha_fin'] ?? $request['fecha_inicio']);
        }


        $listadoRegistroDeConsumo = LocomotoraConsumo::getListadoConsumiblePorFechas($fechas);


        $listadoConsumoPorLocomotora = LocomotoraConsumo::getConsumoPorLocomotoraPorFechas($fechas)->groupBy('tipo');

        
        $locomotoras = Locomotora::listadoLocomotorasSelect(); 
        $hoy = date('Y-m-d');
        
        return view('app.locomotora.consumibles.crear', 
            compact('listadoRegistroDeConsumo', 'fechas', 'listadoConsumoPorLocomotora', 'locomotoras', 'hoy'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $turnos = Turno::TURNOS;
        $locomotoraConsumo = new LocomotoraConsumo;
        $locomotoras = Locomotora::listadoLocomotorasSelect()->where('numero', '!=','S/N')->sortBy('numero'); 
        $hoy = date('Y-m-d');
        return view('app.locomotora.consumibles.create', compact('turnos', 'locomotoraConsumo', 'locomotoras', 'hoy'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        LocomotoraConsumo::create($datos);
        return redirect(route('consumo.create'))->with('success', 'Creada con exito');
    }

    public function validaData($request){
        return $request->validate([
            'locomotora_id' => ['required', 'max:9'],
            'turno' => ['required'],
            'cantidad' => ['required'],
            'tipo' => ['required'],
            'fecha' => ['required'],
            'nota' => ['max:400']
        ]);
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\LocomotoraConsumo  $locomotoraConsumo
     * @return \Illuminate\Http\Response
     */
    public function show($idLocomotora)
    {
        $listadoRegistroDeConsumo = LocomotoraConsumo::getListadoConsumiblePorLocomotora($idLocomotora);
        $listadoConsumoPorLocomotora = LocomotoraConsumo::getConsumoPorLocomotoraPorLocomotora($idLocomotora)->groupBy('tipo');
        $locomotoras = Locomotora::listadoLocomotorasSelect(); 
        $fechas = [];
        return view('app.locomotora.consumibles.index', 
            compact('listadoRegistroDeConsumo', 'fechas', 'listadoConsumoPorLocomotora', 'locomotoras'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LocomotoraConsumo  $locomotoraConsumo
     * @return \Illuminate\Http\Response
     */
    public function edit(LocomotoraConsumo $consumo)
    {
        $turnos = Turno::TURNOS;
        $locomotoras = Locomotora::listadoLocomotorasSelect()->where('numero', '!=','S/N')->sortBy('numero'); 
        return view('app.locomotora.consumibles.edit', array('locomotoraConsumo' => $consumo, 'locomotoras' => $locomotoras, 'turnos' => $turnos));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LocomotoraConsumo  $locomotoraConsumo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LocomotoraConsumo $consumo)
    {
        $datos = $this->validaData($request);
        $consumo->update($datos);
        return redirect(route('crear'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LocomotoraConsumo  $locomotoraConsumo
     * @return \Illuminate\Http\Response
     */
    public function destroy(LocomotoraConsumo $consumo)
    {
        $consumo->delete();
        return redirect(route('crear'))->with('success', 'Eliminado con exito');
    }
}
