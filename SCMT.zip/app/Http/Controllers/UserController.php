<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Requests\UserRequest;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\UserLastLogin;

class UserController extends Controller
{
    /**
     * Display a listing of the users
     *
     * @param  \App\User  $model
     * @return \Illuminate\View\View
     */
    public function index(User $model)
    {
        return view('users.index', ['users' => $model->paginate(15)]);
    }


        public function usuarios(Request $request)
    {

        $usuarios = User::all();


        return view('app.usuarios.usuarios', compact('usuarios'));
    }

    public function edit($id)
    {
        $user = user::find($id);

        return view('app.usuarios.edit', compact('user'));
    }


    public function update(Request $request, user $user)
    {
        $user->update($request->all());

        return redirect()->route('usuarioControl')
            ->with('success', 'Usuario updated successfully');
    }


    public function asistencia(Request $request)
    {
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $asistencias = UserLastLogin::asistencia($fechas)->orderBy('last_login')->get();
    
        return view('app.usuarios.asistencia', compact('asistencias'));
    }


}
