<?php

namespace App\Http\Controllers;

use App\Models\programas_senales;
use App\Models\programas_senales_detalles;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProgramasSenalesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $programas = programas_senales::Getall();

        $cantidadDeProgramas = programas_senales::anualProgramas()->count();

        $cantidadDetallesprogramasenales = programas_senales_detalles::detalleprogramaAnual()->count();

        $cumplimientoDetallesProgramas = programas_senales_detalles::detalleprogramaAnual()->sum('cumplimiento');

        if (!empty($cantidadDetallesprogramasenales)) {
            
            $porcentajeCumplimiento = $cumplimientoDetallesProgramas / $cantidadDetallesprogramasenales;
        }
        else{

            $porcentajeCumplimiento = 0;
        }

        //Corregir por ID del Programa ID Mejorar la Estabilidad

        $detallesprogramasenales = programas_senales_detalles::detalleprogramasenales();

        //

        return view('app.senales.mantenimiento_senales.index', compact('programas', 'cantidadDeProgramas', 'cumplimientoDetallesProgramas', 'porcentajeCumplimiento', 'cantidadDetallesprogramasenales','detallesprogramasenales'));
    }

    public function ferroprogramasenales($id)
    {
        $programa = programas_senales::find($id);

        $detallesprogramasenales = programas_senales_detalles::detalleprogramacumplimiento($id);


        return view('app.senales.mantenimiento_senales.ferroprogramas', compact('programa', 'detallesprogramasenales'));
    }

    public function programasBusqueda(Request $request)
    {
        
        $semanaInicio = $request['semana_inicio'];
        $semanaFin = $request['semana_fin'];
        $fechas = [$semanaInicio, $semanaFin];
        $ano = $request['ano'];

        $programasBusqueda = programas_senales::getAllXPeriodo($fechas, $ano)->orderBy('programa')->get();

        $cantidadDeProgramas = $programasBusqueda->count();

        $cantidadDetallesprogramasenales = programas_senales_detalles::detalleprogramaAnual()->count();

        $cumplimientoDetallesProgramas = programas_senales_detalles::detalleprogramaAnual()->sum('cumplimiento');

        if (!empty($cantidadDetallesprogramasenales)) {
            
            $porcentajeCumplimiento = $cumplimientoDetallesProgramas / $cantidadDetallesprogramasenales;
        }
        else{

            $porcentajeCumplimiento = 0;
        }

        $detallesprogramasenales = programas_senales_detalles::detalleprogramasenales();


        return view('app.senales.mantenimiento_senales.vista_all', compact('programasBusqueda', 'fechas', 'ano', 'cantidadDeProgramas', 'cantidadDetallesprogramasenales', 'porcentajeCumplimiento', 'detallesprogramasenales'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programa = new programas_senales;
        return view('app.senales.mantenimiento_senales.create',compact('programa'));     
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(programas_senales::$rules);

        $request['estatus'] = 'LIBERADA';
        $request['usuario_crea'] = Auth::user()->name;
        $programa = programas_senales::create($request->all());

        return redirect()->route('programas.index')
            ->with('success', 'programas_senales created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\programas_senales  $programas_senales
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programa = programas_senales::find($id);

        $detallesprogramasenales = programas_senales_detalles::detalleprogramacumplimiento($id);

        $sumaCumplimiento = $detallesprogramasenales ->sum('cumplimiento');

        $conteoCumplimiento = $detallesprogramasenales ->count();

        if (!empty($conteoCumplimiento)) {
            
            $cumplimientoTotal = $sumaCumplimiento / $conteoCumplimiento;
        }
        else{

            $cumplimientoTotal = 0;

        }

        return view('app.senales.mantenimiento_senales.show', compact('programa', 'detallesprogramasenales', 'cumplimientoTotal'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\programas_senales  $programas_senales
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

       $programa = programas_senales::find($id);

       return view('app.senales.mantenimiento_senales.edit', compact('programa', 'detallesprogramasenales'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\programas_senales  $programas_senales
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, programas_senales $programa)
    {
        request()->validate(programas_senales::$rules);
        
        $request['usuario_actualiza'] = Auth::user()->name; 
        $programa->update($request->all());

        return redirect()->route('programas.index')
            ->with('success', 'programas_senales updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\programas_senales  $programas_senales
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $programa = programas_senales::find($id)->delete();

        return redirect()->route('programas.index')
            ->with('success', 'Reportedelocomotora deleted successfully');
    }
}
