<?php

namespace App\Http\Controllers;

use App\Models\ProgramaEquipoApoyoDetalle;
use App\Models\Equipo_apoyo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ProgramaEquipoApoyoDetalleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $semanaInicio = $request['fecha_inicio'];
        $semanaFin = $request['fecha_fin'];
        $fechas = [$semanaInicio, $semanaFin];

        $programasBusqueda = ProgramaEquipoApoyoDetalle::getAllXPeriodo($fechas)->orderBy('fecha')->get();

        $conteozpm2 = $programasBusqueda->where('tipo_mant', 'ZPM2')->count();
        $conteozpmi = $programasBusqueda->where('tipo_mant', 'ZPMI')->count();


        if ($programasBusqueda->count() != 0) {
            
            $cumplimiento = round(($programasBusqueda->sum('cumplimiento') / $programasBusqueda->count()));
        
        }
        else{

            $cumplimiento = 0;
        }

        return view('app.vagones.equipo_apoyo.mantenimiento_Programas_detalle.index', compact('programasBusqueda', 'fechas', 'conteozpm2', 'conteozpmi', 'cumplimiento'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programadetalle = new ProgramaEquipoApoyoDetalle;
        $equipos = Equipo_apoyo::equipos_numero();
        return view('app.vagones.equipo_apoyo.mantenimiento_Programas_detalle.create',compact('programadetalle','equipos'));     
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try{
            DB::beginTransaction();

        request()->validate(ProgramaEquipoApoyoDetalle::$rules);

        foreach ($request->equipo_id as $index => $equipo) {
            $fechaPrograma = Equipo_apoyo::whereId($equipo)->first();
            $fechaPrograma->fecha_programa = $request->fecha[$index];
            $fechaPrograma->save();

            ProgramaEquipoApoyoDetalle::create(
                [
                    'equipo_id' => $equipo,
                    'programa_id' => $request->programa_id,
                    'fecha' => $request->fecha[$index],
                    'cumplimiento' => $request->cumplimiento[$index],
                    'responsable' => $request->responsable[$index],
                    'nota' => $request->nota[$index],
                    'tipo_mant' => $request->tipo_mant[$index],
                    'n_orden' => $request->n_orden[$index],
                    'usuario_crea' => Auth::user()->name

                ]);

        }
        DB::commit();
           return redirect()->route('programaEquipoApoyo.index')
            ->with('success', 'ProgramaEquipoApoyoDetalle created successfully.');    
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'ProgramaEquipoApoyoDetalle created failed: '.$e->getMessage()); 
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProgramaEquipoApoyoDetalle  $programaEquipoApoyoDetalle
     * @return \Illuminate\Http\Response
     */
    public function show(ProgramaEquipoApoyoDetalle $programaEquipoApoyoDetalle)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProgramaEquipoApoyoDetalle  $programaEquipoApoyoDetalle
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programadetalle = ProgramaEquipoApoyoDetalle::find($id);
        $equipos = Equipo_apoyo::equipos_numero();
        return view('app.vagones.equipo_apoyo.mantenimiento_Programas_detalle.edit',compact('programadetalle','equipos'));   
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProgramaEquipoApoyoDetalle  $programaEquipoApoyoDetalle
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramaEquipoApoyoDetalle $programaEquipoApoyoDetalle)
    {
        request()->validate(ProgramaEquipoApoyoDetalle::$rules);

        $request['usuario_actualiza'] = Auth::user()->name; 
        $programaEquipoApoyoDetalle->update($request->all());


        $fechaprogramaeditar = Equipo_apoyo::where('id',$request['equipo_id'])->first();

        if ($fechaprogramaeditar->fecha_programa < $request['fecha']) {
        $fechaprogramaeditar->fecha_programa = $request['fecha'];
        $fechaprogramaeditar->save();

        }

        return redirect()->route('programaEquipoApoyo.index')
            ->with('success', 'ProgramaEquipoApoyoDetalle updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProgramaEquipoApoyoDetalle  $programaEquipoApoyoDetalle
     * @return \Illuminate\Http\Response
     */
    public function destroy(request $request,  ProgramaEquipoApoyoDetalle $programaEquipoApoyoDetalle)
    {
        try{
            DB::beginTransaction();
                $fechaprogramaeditar = Equipo_apoyo::where('id', $programaEquipoApoyoDetalle->equipo_id)->first();
                $equipoId = $programaEquipoApoyoDetalle->equipo_id;
                $programaEquipoApoyoDetalle->delete();
                $fecha_programa = ProgramaEquipoApoyoDetalle::borradodedetalle($equipoId);

                
                $fechaprogramaeditar->fecha_programa = $fecha_programa;

                $fechaprogramaeditar->save();
            DB::commit();
            return redirect()->route('programaEquipoApoyo.index')
                ->with('success', 'programaEquipoApoyo deleted successfully');    
        } catch (\Exception $e) {
            DB::rollback();
        }
    }
}
