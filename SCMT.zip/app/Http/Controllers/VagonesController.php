<?php

namespace App\Http\Controllers;

use App\Clases\Util;
use App\Models\Vagones;
use App\Models\VagonDescarrilamiento;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;

class VagonesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
     {
        $vagones = Vagones::getAll();

        //Vagones Gondolas

        $gondolas = $vagones->where('tipo','Gondola'); 

        $gondolasconteo = $gondolas->where('tipo','Gondola')->whereNotIn('ultima_ubicacion', 'DESINCORPORADO')->count();

        $vagonesfisico = $gondolas->where('ultima_ubicacion', '!=','DESCONOCIDA')->whereNotIn('ultima_ubicacion', ['DESINCORPORADO', 'DESCARRILADO']);

        $vagonesdesconocidostabla = $gondolas->where('ultima_ubicacion','DESCONOCIDA');

        $disponibilidad = $gondolas
                ->where('disponible', 'Disponible')
                ->where('ultima_ubicacion', '!=','DESCONOCIDA')
                ->where('bandera_alarma', '!=','ALARMA')
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA','DESINCORPORADO', 'DESCARRILADO'])->count();

        $disponibilidadoperativatabla = $gondolas->where('disponible', 'Disponible')
                ->where('ultima_ubicacion', '!=','DESCONOCIDA')
                ->where('bandera_alarma', '!=','ALARMA');

        $vagonesmantenimiento = $gondolas ->where('ultima_ubicacion', 'TALLER DE VAGONES REPARADO')->count();

        $vagonesdesconocidos = $gondolas->where('ultima_ubicacion','DESCONOCIDA')->count();

        $vagonesalarmatabla = $gondolas 
                ->where('bandera_alarma','ALARMA')
                ->where('ultima_ubicacion', '!=','DESCONOCIDA')
                ->where('disponible', '!=','Mantenimiento')
                ->where('ultima_ubicacion','!=', 'TALLER DE VAGONES REPARADO');

        $vagonesalarmaconteo = $gondolas

                ->where('bandera_alarma','ALARMA')
                ->where('ultima_ubicacion', '!=','DESCONOCIDA')
                ->where('disponible', '!=','Mantenimiento')
                ->where('ultima_ubicacion','!=', 'TALLER DE VAGONES REPARADO')
                ->whereNotIn('ultima_ubicacion',['DESINCORPORADO', 'DESCARRILADO'])
                ->count();

        $flotafisica = $gondolas->whereNotIn('ultima_ubicacion',['DESCONOCIDA','DESINCORPORADO', 'DESCARRILADO'])
                ->count();

        $vagonDescarrilamientosConteoDescarrilados = VagonDescarrilamiento::getAll()->where('estatus','0')->where('vagon_id', '<', 5000)->count();
       

        //Vagones Tolvas

        $tolvas = $vagones->where('tipo','Tolva');

        $tolvasconteo = $vagones->where('tipo','Tolva')->whereNotIn('ultima_ubicacion', ['DESINCORPORADO', 'DESCARRILADO'])->count();

        $tolvasfisica = $tolvas 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA','DESINCORPORADO', 'DESCARRILADO']);


        $tolvastaller = $tolvas 
                ->whereIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4']);


        $tolvastallerconteo = $tolvastaller->count();


        $tolvasoperativasconteo = $tolvas 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4','DESCONOCIDA','DESINCORPORADO','DESCARRILADO'])
                ->count();

        $tolvasfisicoconteo = $tolvas 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES','LINEA 4','DESINCORPORADO','DESCARRILADO'])
                ->count();

        $tolvasreaparadoconteo = $tolvas 
                ->where('ultima_ubicacion','TALLER DE VAGONES REPARADO')
                ->count();

        $tolvasdesconocidasconteo = $tolvas 
                ->where('ultima_ubicacion','DESCONOCIDA')
                ->count();

        $vagonDescarrilamientosConteoDescarriladosTolvas = VagonDescarrilamiento::getAll()->where('estatus','0')->where('vagon_id', '>=', 5000)->count();




        //Vagones Volteo

        $volteo = $vagones->where('tipo','Volteo');

        $volteoconteo =  $volteo->whereNotIn('ultima_ubicacion', 'DESINCORPORADO')->count();

        $volteofisica = $volteo 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA', 'DESINCORPORADO', 'DESCARRILADO']);


        $volteotaller = $volteo 
                ->whereIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4']);


        $volteotallerconteo = $volteotaller->count();


        $volteofisicoconteo = $volteo 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA','DESINCORPORADO', 'DESCARRILADO'])
                ->count();


      //Vagones Tanque

        $tanque = $vagones->where('tipo','Tanque');

        $tanqueconteo =  $tanque->whereNotIn('ultima_ubicacion', 'DESINCORPORADO')->count();

        $tanquefisica = $tanque 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA', 'DESINCORPORADO', 'DESCARRILADO']);


        $tanquetaller = $tanque 
                ->whereIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4']);


        $tanquetallerconteo = $tanquetaller->count();


        $tanquefisicoconteo = $tanque 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA','DESINCORPORADO', 'DESCARRILADO'])
                ->count();


      //Vagones Plataforma

        $plataforma = $vagones->where('tipo','Plataforma');

        $plataformaconteo =  $plataforma->whereNotIn('ultima_ubicacion', 'DESINCORPORADO')->count();

        $plataformafisica = $plataforma 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA', 'DESINCORPORADO', 'DESCARRILADO']);


        $plataformataller = $plataforma 
                ->whereIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4']);


        $plataformatallerconteo = $plataformataller->count();


        $plataformafisicoconteo = $plataforma 
                ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA','DESINCORPORADO', 'DESCARRILADO'])
                ->count();

     


      //Ciclo del Vagon


        $fecha = date('Y-m-d');
        $semanas = date('W');

        $vagones = DB::table('vw_ciclo_vagon')
        ->selectRaw("date_part('year', fecha)::integer as anho, vagon, fecha, date_part('week', fecha)::integer as semana, date_part('month', fecha)::integer as mes")
        ->whereRaw("fecha >= date_trunc('week', '".$fecha."'::date - interval '".$semanas." week')
                    and fecha <date_trunc('week', '".$fecha."'::date)")
        ->get();
        $vagonesSemanas = $vagones->where('anho', date('Y'))->groupBy('semana');

        $vagonesmes = $vagones->where('anho', date('Y'))->groupBy('mes');

        foreach($vagonesSemanas as $semana => $vagonSemana){
            $suma = 0;
            $contadorVagones = 0;
            foreach($vagonSemana as $id => $vagon){
                if (isset ($vagonSemana[$id+1]->vagon) && ($vagon->vagon == $vagonSemana[$id+1]->vagon)){
                    $suma += (strtotime($vagonSemana[$id+1]->fecha) - strtotime($vagon->fecha));
                    $contadorVagones++;
                }
            }
            $ciclos[$semana]['ciclo'] = Util::promedioTiempo($suma, $contadorVagones);
            $ciclos[$semana]['vagones'] =  $contadorVagones;
            $ciclos[$semana]['semana'] =  $semana;
        }


        foreach($vagonesmes as $semana => $vagonMes){
            $suma = 0;
            $contadorVagones = 0;
            foreach($vagonMes as $id => $vagon){
                if (isset ($vagonMes[$id+1]->vagon) && ($vagon->vagon == $vagonMes[$id+1]->vagon)){
                    $suma += (strtotime($vagonMes[$id+1]->fecha) - strtotime($vagon->fecha));
                    $contadorVagones++;
                }
            }
            $ciclosmes[$semana]['ciclo'] = Util::promedioTiempo($suma, $contadorVagones);
            $ciclosmes[$semana]['vagones'] =  $contadorVagones;
            $ciclosmes[$semana]['semana'] =  $semana;
        }


        if (!empty($ciclos)) {
        array('ciclos' => ksort($ciclos));
        array('ciclosmes' => ksort($ciclosmes));
        }
        else{
          $ciclos = 0;
          $ciclosmes = 0;
        }



        return view('app.vagones.admin.index', 
            compact('vagones','disponibilidad', 'flotafisica', 'vagonesmantenimiento', 
            'vagonesfisico', 'vagonesdesconocidostabla','disponibilidadoperativatabla',
            'vagonesalarmatabla','vagonesalarmaconteo', 'gondolasconteo','gondolas', 'tolvas','tolvasconteo','tolvasfisica','tolvastaller','tolvastallerconteo','tolvasfisicoconteo', 'volteo', 'volteoconteo', 'volteofisica', 'volteotaller', 'volteotallerconteo', 'volteofisicoconteo', 'ciclos', 'ciclosmes', 'vagonDescarrilamientosConteoDescarrilados', 'tanque', 'tanqueconteo', 'tanquefisica', 'tanquetaller', 'tanquetallerconteo', 'tanquefisicoconteo', 'plataforma', 'plataformaconteo', 'plataformafisica', 'plataformataller', 'plataformatallerconteo', 'plataformafisicoconteo', 'vagonDescarrilamientosConteoDescarriladosTolvas', 'tolvasoperativasconteo', 'tolvasreaparadoconteo', 'tolvasdesconocidasconteo'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $vagon = new Vagones;
        return view('app.vagones.admin.create',compact('vagon'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        Vagones::create($datos);
        return redirect(route('admin.index'))->with('success', 'Creada con exito');
    }


    public function validaData($request){
        return $request->validate([
            'id' => ['required', 'max:9', 'unique:vagones'],
            'zona_geografica' => ['required'],
            'estatus' => [ Rule::in([0, 1]),],
            'tipo' => [ Rule::in(['Gondola', 'Tolva', 'Volteo', 'Tanque', 'Plataforma']),]
        ]);
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function show(Vagones $admin)
    {
        $vagon = $admin->getVagonInspecciones($admin->id);
        return view('app.vagones.admin.show', array('vagon' => $vagon));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function edit(Vagones $admin)
    {
        return view('app.vagones.admin.edit', array('vagones' => $admin));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Vagones $admin)
    {
        $datos = $this->validaData($request);
        $admin->update($datos);
        return redirect(route('admin.index'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function destroy(Vagones $admin)
    {
        $admin->delete();
        return redirect(route('admin.index'))->with('success', 'Eliminado con exito');
    }

    public function buscar(Request $req){
      return Vagones::buscar($req->id);
    }

    public function buscarTodos(Request $req){
      return Vagones::buscarTodos($req->id);
    }

    public function buscarTodosSinFiltro(Request $req){
      return Vagones::buscarTodosSinFiltro($req->id);
    }


}
