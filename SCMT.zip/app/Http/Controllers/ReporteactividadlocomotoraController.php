<?php

namespace App\Http\Controllers;

use App\Models\Reporteactividadlocomotora;
use App\Models\Reportedelocomotora;
use App\Models\Reportetiempolocomotora;
use Illuminate\Http\Request;
use App\Models\Locomotora;
use Illuminate\Support\Facades\Auth;

/**
 * Class ReporteactividadlocomotoraController
 * @package App\Http\Controllers
 */
class ReporteactividadlocomotoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reporteactividadlocomotoras = Reporteactividadlocomotora::paginate();

        return view('app.locomotora.reporteactividadlocomotora.index', compact('reporteactividadlocomotoras'))
            ->with('i', (request()->input('page', 1) - 1) * $reporteactividadlocomotoras->perPage());
    }

    public function periodoactividad(Request $request)
    {
        $locomotoras = Locomotora::pluck('numero', 'numero');
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $locomotora = $request['locomotora_id'] ?? null;
        $reporte_all = Reporteactividadlocomotora::getAllXPeriodo($fechas, $locomotora)->orderBy('fecha')->get();
    
        return view('app.locomotora.reporteactividadlocomotora.vista_all', compact('reporte_all', 'fechas', 'locomotoras', 'locomotora'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $reporteactividadlocomotora = new Reporteactividadlocomotora();
        $locomotoras = Locomotora::listadoLocomotorasSelect()->pluck('numero', 'numero');
        $estatus = collect(Reporteactividadlocomotora::ESTATUS);
        $turno = collect(Reporteactividadlocomotora::TURNO);
        $area = collect(Reporteactividadlocomotora::AREA);
        $falla = collect(Reporteactividadlocomotora::FALLA);
        $fallamotivo = collect(Reporteactividadlocomotora::FALLAMOTIVO);
        return view('app.locomotora.reporteactividadlocomotora.create', compact('reporteactividadlocomotora', 'estatus', 'turno', 'area', 'falla', 'fallamotivo', 'locomotoras'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(Reporteactividadlocomotora::$rules);
        $request['usuario_crea'] = Auth::user()->name;

        $tiempo = new Reportetiempolocomotora;

        $tiempo->reportelocomotora_id = $request['reportelocomotora_id'];
        $tiempo->fecha = $request['fecha'];
        $tiempo->responsable = $request['responsable'];
        $tiempo->horas = $request['horas'];
        $tiempo->usuario_crea = Auth::user()->name;

        $tiempo->save();
       
        if ($request['estatus'] == '0') {

        $fechafin = new Reportedelocomotora;
       
        $maestro = Reportedelocomotora::where('id',$request['reportelocomotora_id'])->first();


        $maestro->fecha_salida = $request['fecha'];
        $maestro->notificado = true;

        
        $maestro->save();


        $reporteactividadlocomotora = Reporteactividadlocomotora::create($request->all());
       
        }

        else{
        
        $borrarfecha = new Reportedelocomotora;
       
        $borrar = Reportedelocomotora::where('id',$request['reportelocomotora_id'])->first();

        $borrar->notificado = false;

        $borrar->save();

        $reporteactividadlocomotora = Reporteactividadlocomotora::create($request->all());
        
        }

        return redirect()->route('reportedelocomotoras.index')
            ->with('success', 'Reporteactividadlocomotora created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $reporteactividadlocomotora = Reporteactividadlocomotora::find($id);

        return view('app.locomotora.reporteactividadlocomotora.show', compact('reporteactividadlocomotora'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $reporteactividadlocomotora = Reporteactividadlocomotora::find($id);
        $locomotoras = Locomotora::listadoLocomotorasSelect()->pluck('numero', 'numero');
        $estatus = collect(Reporteactividadlocomotora::ESTATUS);
        $turno = collect(Reporteactividadlocomotora::TURNO);
        $area = collect(Reporteactividadlocomotora::AREA);
        $falla = collect(Reporteactividadlocomotora::FALLA);
        $fallamotivo = collect(Reporteactividadlocomotora::FALLAMOTIVO);

        return view('app.locomotora.reporteactividadlocomotora.edit', compact('reporteactividadlocomotora', 'estatus', 'turno', 'area', 'falla', 'fallamotivo', 'locomotoras'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Reporteactividadlocomotora $reporteactividadlocomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Reporteactividadlocomotora $reporteactividadlocomotora)
    {
        request()->validate(Reporteactividadlocomotora::$rules);
        $request['usuario_actualiza'] = Auth::user()->name;
        
        if ($request['estatus'] == '0') {

        $fechafin = new Reportedelocomotora;
       
        $maestro = Reportedelocomotora::where('id',$request['reportelocomotora_id'])->first();

        $maestro->fecha_salida = $request['fecha'];
        $maestro->notificado = true;


        $maestro->save();

        $reporteactividadlocomotora->update($request->all());

        }

        elseif ($request['estatus'] == '1') {
        
        $borrarfecha = new Reportedelocomotora;
       
        $borrar = Reportedelocomotora::where('id',$request['reportelocomotora_id'])->first();


        $borrar->fecha_salida = null;
        $borrar->notificado = false;

        $borrar->save();

        $reporteactividadlocomotora->update($request->all());
        
        }

        else{
            $reporteactividadlocomotora->update($request->all());
        }

        return redirect()->route('reportedelocomotoras.index')
            ->with('success', 'Reporteactividadlocomotora updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $reporteactividadlocomotora = Reporteactividadlocomotora::find($id)->delete();

        return redirect()->back()
            ->with('success', 'Reporteactividadlocomotora deleted successfully');
    }
}
