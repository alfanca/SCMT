<?php

namespace App\Http\Controllers;

use App\Models\ViasConsumo;
use App\Models\ViasMateriale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class ViasConsumoController
 * @package App\Http\Controllers
 */
class ViasConsumoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $viasConsumos = ViasConsumo::getall();

        return view('app.via.viasconsumo.index', compact('viasConsumos'))
            ->with('i');
    }



    public function peridodoconsumo(Request $request)
    {
        $tramoselector = collect(ViasConsumo::TRAMO);
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $tramo = $request['tramo'] ?? null;
        //dd($tramo = $request['tramo'] ?? null);
        $consumo_all = ViasConsumo::getAllXPeriodo($fechas, $tramo)->orderBy('fecha')->get();
    
        return view('app.via.viasconsumo.vista_all', compact('consumo_all', 'fechas', 'tramoselector', 'tramo', 'tramoselector'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $viasConsumo = new ViasConsumo();
        $materialesvias = ViasMateriale::all();
        $tramo = collect(ViasConsumo::TRAMO);
        $turno = collect(ViasConsumo::TURNO);
        $razon = collect(ViasConsumo::RAZON);
        return view('app.via.viasconsumo.create', compact('viasConsumo', 'materialesvias', 'tramo', 'turno', 'razon'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ViasConsumo::$rules);

        $request['usuario_crea'] = Auth::user()->name;

        $request['precio'] = ViasMateriale::where('id',$request['material_vias_id'])->first()->preciounitario;
        
        $viasConsumo = ViasConsumo::create($request->all());

        return redirect()->route('viasconsumo.index')
            ->with('success', 'ViasConsumo created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $viasConsumo = ViasConsumo::find($id);

        return view('app.via.viasconsumo.show', compact('viasConsumo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $viasConsumo = ViasConsumo::find($id);
        $materialesvias = ViasMateriale::all();
        $tramo = collect(ViasConsumo::TRAMO);
        $turno = collect(ViasConsumo::TURNO);
        $razon = collect(ViasConsumo::RAZON);
        return view('app.via.viasconsumo.edit', compact('viasConsumo', 'materialesvias', 'tramo', 'turno', 'razon'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ViasConsumo $viasConsumo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ViasConsumo $viasconsumo)
    {
        request()->validate(ViasConsumo::$rules);

        $request['usuario_actualiza'] = Auth::user()->name; 
        $viasconsumo->update($request->all());

        return redirect()->route('viasconsumo.index')
            ->with('success', 'ViasConsumo updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $viasConsumo = ViasConsumo::find($id)->delete();

        return redirect()->route('viasconsumo.index')
            ->with('success', 'ViasConsumo deleted successfully');
    }
}
