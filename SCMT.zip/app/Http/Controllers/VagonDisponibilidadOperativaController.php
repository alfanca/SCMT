<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Clases\Turno;
use App\Clases\Fechas;
use App\Models\VagonDisponibilidadOperativa;
use App\Models\Nota;
use App\Models\Vagones;

class VagonDisponibilidadOperativaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $turnos =  Turno::TURNOS;
        $fecha = date('Y-m-d');
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $disponibilidad = VagonDisponibilidadOperativa::listarDisponibilidad()->fecha($fecha)->get()->groupBy('tipo_vagon');
       
        $vagonesDisponibilidadNotas = Nota::vagones()->fecha($fecha)->get();
        return view('app.vagones.disponibilidad_operativa.index', compact('fechas', 'turnos', 'disponibilidad', 'vagonesDisponibilidadNotas')); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $turnos = Turno::TURNOS;
        $disponibilidad = new VagonDisponibilidadOperativa; 
        $turno = $request['turno'];
        $fecha = $request['fecha'];
        $tipoVagon=$request['tipo_vagon'];
        $disponibilidadTurno = VagonDisponibilidadOperativa::listarDisponibilidad()->fecha($fecha)->turno($turno)->get();
        $conteoVagonesGondolas = Vagones::getAll()
                  ->where('tipo','Gondola')
                  ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES','Patio vacio', 'DESCONOCIDA','DESINCORPORADO', 'DESCARRILADO'])
                  ->count();

        $conteoVagonesTolvas = Vagones::dashboardvagonesconteo()
                  ->where('tipo','Tolva')
                  ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES REPARADO','TALLER DE VAGONES','Patio vacio','DESINCORPORADO', 'DESCARRILADO'])->count();
        
        $vagonesDisponibilidadNotas = Nota::vagones()->fecha($fecha)->get();
        $gondolasDisponible = Vagones::getAll();

        return view('app.vagones.disponibilidad_operativa.create', compact('turno','disponibilidadTurno', 'fecha' ,'turnos', 'disponibilidad', 'tipoVagon', 'vagonesDisponibilidadNotas', 'gondolasDisponible', 'conteoVagonesGondolas', 'conteoVagonesTolvas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        $datos['usuario_crea'] = Auth::user()->name;
        VagonDisponibilidadOperativa::create($datos);
        return redirect('vagones/disponibilidad/operativa/create?turno='.$request['turno'].'&fecha='.$request['fecha'].'&tipo_vagon='.$request['tipo_vagon'])->with('success', 'Creada con exito');    
    }

    public function validaData($request){
        return $request->validate([
            'turno' => ['required'],
            'tipo_vagon' => ['required'],
            'cantidad' => ['required'],
            'lugar' => ['required'],
            'fecha' => ['required']
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VagonDisponibilidadOperativa  $VagonDisponibilidadOperativa
     * @return \Illuminate\Http\Response
     */
    public function show($fecha)
    {
        if ($fecha == date('Y-m-d')){
            return redirect(route('vagones_disponibilidad_o.index'));
        }

        $disponibilidad = VagonDisponibilidadOperativa::listarDisponibilidad()->fecha($fecha)->get()->groupBy('tipo_vagon');
        $turnos = Turno::TURNOS;
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $vagonesDisponibilidadNotas = Nota::vagones()->fecha($fecha)->get();
        return view('app.vagones.disponibilidad_operativa.show', compact('disponibilidad', 'turnos', 'fechas', 'vagonesDisponibilidadNotas'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VagonDisponibilidadOperativa  $VagonDisponibilidadOperativa
     * @return \Illuminate\Http\Response
     */
    public function destroy(VagonDisponibilidadOperativa $disponibilidad)
    {
        $disponibilidad->usuario_elimina = Auth::user()->name;
        $disponibilidad->save();
        $disponibilidad->delete();
        return redirect(route('vagones_disponibilidad_o.index'))->with('success', 'Eliminado con exito');
    }
}
