<?php

namespace App\Http\Controllers;

use App\Models\VagonDescarrilamiento;
use App\Models\Vagones;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class VagonDescarrilamientoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $vagonDescarrilamientos = VagonDescarrilamiento::getAll();

        $vagonDescarrilamientosConteo = VagonDescarrilamiento::getAll()->count();

        $vagonDescarrilamientosConteoDesincor = VagonDescarrilamiento::getAll()->where('estatus','2')->count();

        $vagonDescarrilamientosConteoEncarrilados = VagonDescarrilamiento::getAll()->where('estatus','1')->count();

        $vagonDescarrilamientosConteoDescarrilados = VagonDescarrilamiento::getAll()->where('estatus','0')->count();

        return view('app.vagones.descarrilamientos.index', compact('vagonDescarrilamientos', 'vagonDescarrilamientosConteo','vagonDescarrilamientosConteoDesincor', 'vagonDescarrilamientosConteoEncarrilados', 'vagonDescarrilamientosConteoDescarrilados'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $vagonDescarrilamiento = new VagonDescarrilamiento;
        $estatus = collect(VagonDescarrilamiento::ESTATUS);
        return view('app.vagones.descarrilamientos.create',compact('vagonDescarrilamiento', 'estatus')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(VagonDescarrilamiento::$rules);

        $request['usuario_crea'] = Auth::user()->name;

        $request['estatus'] = 0;

        $fechafin = new Vagones;
       
        $maestro = Vagones::where('id',$request['vagon_id'])->first();

        $maestro->fecha_ultima_ubicacion = $request['fecha_inicio'];
           
        $maestro->ultima_ubicacion = 'DESCARRILADO';

        $maestro->estatus = false;

        $maestro->disponible = false;
        
        $maestro->save();

        $vagonDescarrilamiento = VagonDescarrilamiento::create($request->all());

        return redirect()->back()
            ->with('success', 'VagonDescarrilamiento created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VagonDescarrilamiento  $vagonDescarrilamiento
     * @return \Illuminate\Http\Response
     */
    public function show(VagonDescarrilamiento $vagonDescarrilamiento)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VagonDescarrilamiento  $vagonDescarrilamiento
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $vagonDescarrilamiento = VagonDescarrilamiento::find($id);
        $estatus = collect(VagonDescarrilamiento::ESTATUS);

        return view('app.vagones.descarrilamientos.edit', compact('vagonDescarrilamiento', 'estatus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\VagonDescarrilamiento  $vagonDescarrilamiento
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VagonDescarrilamiento $vagonDescarrilamiento)
    {
        request()->validate(VagonDescarrilamiento::$rules);

        $request['usuario_actualiza'] = Auth::user()->name;

        if (!empty($request['fecha_fin']) and $request['estatus'] == '0') {

        $fechafin = new Vagones;
       
        $maestro = Vagones::where('id',$request['vagon_id'])->first();

        $maestro->fecha_ultima_ubicacion = $request['fecha_fin'];
      
        $maestro->ultima_ubicacion = 'DESCARRILADO';

        $maestro->estatus = false;

        $maestro->disponible = false;
        
        $maestro->save();

        $vagonDescarrilamiento->update($request->all());

        }

        elseif (!empty($request['fecha_fin']) and $request['estatus'] == '1') {


        $fechafin = new Vagones;
       
        $maestro = Vagones::where('id',$request['vagon_id'])->first();

        $maestro->fecha_ultima_ubicacion = $request['fecha_fin'];
      
        $maestro->ultima_ubicacion = 'ENCARRILADO';

        $maestro->estatus = true;

        $maestro->disponible = true;
        
        $maestro->save();

        $vagonDescarrilamiento->update($request->all());

        }


        elseif (!empty($request['fecha_fin']) || $request['estatus'] == '2') {

        $fechafin = new Vagones;
       
        $maestro = Vagones::where('id',$request['vagon_id'])->first();

        $maestro->fecha_ultima_ubicacion = $request['fecha_fin'];
      
        $maestro->ultima_ubicacion = 'DESINCORPORADO';

        $maestro->estatus = false;

        $maestro->disponible = false;
        
        $maestro->save();

        $vagonDescarrilamiento->update($request->all());

        }

        else{

            $vagonDescarrilamiento->update($request->all());

        }


        return redirect()->route('vagonDescarrilamiento.index')
            ->with('success', 'VagonDescarrilamiento updated successfully');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VagonDescarrilamiento  $vagonDescarrilamiento
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $vagonDescarrilamiento = VagonDescarrilamiento::find($id)->delete();

        return redirect()->route('vagonDescarrilamiento.index')
            ->with('success', 'VagonDescarrilamiento deleted successfully');
    }
}
