<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

use App\Models\DatosBasicos;

class DatosBasicosController extends Controller
{
    public function show($ficha){
        return DatosBasicos::buscarPorFicha($ficha);
    }

    public function buscar(Request $req){
      return DatosBasicos::buscar($req->id);
    }
}
?>
