<?php

namespace App\Http\Controllers;

use App\Models\proyecto_vagones_componentes;
use App\Models\materialesvagones;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ProyectoVagonesComponentesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $vagonesProyectoConsumo = new proyecto_vagones_componentes;

        $materiales = materialesvagones::materialesConsumo();

        return view('app.vagones.consumibles_vagones_proyectos.create',compact('vagonesProyectoConsumo', 'materiales'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try{

        DB::beginTransaction();

        foreach ($request->materiales_vagones_id as $index => $componente) {
            $request['precio_unit'] = materialesvagones::where('id',$componente)->first()->preciounitario??0;
            proyecto_vagones_componentes::create(
                [
                    'vagones_id' => $request->vagones_id,
                    'proyecto_vagones_id' => $request->proyecto_vagones_id,
                    'materiales_vagones_id' => $componente,
                    'taller_id' => $request->taller_id,
                    'cantidad' => $request->cantidad[$index],
                    'precio_unit' => $request->precio_unit,
                    'usuario_crea' => Auth::user()->name
                ]);
        }

        DB::commit();
           return redirect()->back()
            ->with('success', 'Consumo created successfully.');    
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'Revisar Formulario '); 
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\proyecto_vagones_componentes  $proyecto_vagones_componentes
     * @return \Illuminate\Http\Response
     */
    public function show(proyecto_vagones_componentes $proyecto_vagones_componentes)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\proyecto_vagones_componentes  $proyecto_vagones_componentes
     * @return \Illuminate\Http\Response
     */
    public function edit(proyecto_vagones_componentes $proyecto_vagones_componentes)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\proyecto_vagones_componentes  $proyecto_vagones_componentes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, proyecto_vagones_componentes $proyecto_vagones_componentes)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\proyecto_vagones_componentes  $proyecto_vagones_componentes
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $vagonesProyectoConsumo = proyecto_vagones_componentes::find($id)->delete();

        return redirect()->back()
            ->with('success', 'proyecto_vagones_componentes deleted successfully');
    }
}
