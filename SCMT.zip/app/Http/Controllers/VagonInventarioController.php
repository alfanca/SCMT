<?php

namespace App\Http\Controllers;

use App\Models\VagonesInventario;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;


class VagonInventarioController extends Controller
{
    public function index(Request $request)
    {
        $anho = $request->anho ?? date('Y');
        $vagones = VagonesInventario::getInventarioPorAnho($anho);
        return view('app.vagones.inventario.index', compact('vagones', 'anho'));
    }

    public function create()
    {
        $vagones = new VagonesInventario();
        $anho = date('Y');
        return view('app.vagones.inventario.create', compact('vagones', 'anho'));
    }

    public function store(Request $request)
    {
        try{
            DB::beginTransaction();
            	$datos = $this->validaData($request);
                $vagones = new VagonesInventario;
                $vagones->crear($datos);
            DB::commit();        
                    
            return redirect(route('inventario.index'))->with('success', 'Inspección creada con exito');
        }catch (\Exception $e) {
            DB::rollback();
            dd($e);
            \Notify::error('Favor revise algunas locomtoras ya estan registradas');
            return redirect('/');
      }
    }   
    

    private function validaData($request){
        return $request->validate([
            'anho' => ['required'],
            'estatus' => ['required'],
            'vagones' => 'required|min:1'
        ]);
    }       
}
