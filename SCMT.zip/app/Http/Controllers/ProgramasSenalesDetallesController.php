<?php

namespace App\Http\Controllers;

use App\Models\programas_senales_detalles;
use App\Models\senales_equipos;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProgramasSenalesDetallesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programadetalle = new programas_senales_detalles;
        $equipos = senales_equipos::equipos_numero();
        return view('app.senales.mantenimiento_senales_detalle.create',compact('programadetalle','equipos'));     
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(programas_senales_detalles::$rules);



        foreach ($request->equipo_id as $index => $equipo) {
            $fechaPrograma = senales_equipos::whereId($equipo)->first();
            $fechaPrograma->fecha_programa = $request->fecha[$index];
            $fechaPrograma->save();

            programas_senales_detalles::create(
                [
                    'equipo_id' => $equipo,
                    'programa_id' => $request->programa_id,
                    'fecha' => $request->fecha[$index],
                    'cumplimiento' => $request->cumplimiento[$index],
                    'nota' => $request->nota[$index],
                    'n_orden' => $request->n_orden[$index],
                    'usuario_crea' => Auth::user()->name

                ]);
                   
        }

        return redirect()->route('programas.index')
            ->with('success', 'programas_senales_detalles created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\programas_senales_detalles  $programas_senales_detalles
     * @return \Illuminate\Http\Response
     */
    public function show(programas_senales_detalles $programas_senales_detalles)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\programas_senales_detalles  $programas_senales_detalles
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

       $programadetalle = programas_senales_detalles::find($id);
       $equipos = senales_equipos::equipos_numero();

       return view('app.senales.mantenimiento_senales_detalle.edit', compact('programadetalle', 'equipos'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\programas_senales_detalles  $programas_senales_detalles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, programas_senales_detalles $programasdetalle)
    {   
        request()->validate(programas_senales_detalles::$rules);
        
        $request['usuario_actualiza'] = Auth::user()->name; 
        $programasdetalle->update($request->all());

        $fechaprogramaeditar = senales_equipos::where('id',$request['equipo_id'])->first();
        
        if ($fechaprogramaeditar->fecha_programa < $request['fecha']) {
        $fechaprogramaeditar->fecha_programa = $request['fecha'];
        $fechaprogramaeditar->save();
        }

        return redirect()->route('programas.index')
            ->with('success', 'programas_senales_detalles updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\programas_senales_detalles  $programas_senales_detalles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, programas_senales_detalles $programasdetalle)
    {
        try{
            DB::beginTransaction();
                $fechaprogramaeditar = senales_equipos::where('id', $programasdetalle->equipo_id)->first();
                $equipoId = $programasdetalle->equipo_id;
                $programasdetalle->delete();
                $fecha_programa = programas_senales_detalles::borradodedetalle($equipoId);

                
                $fechaprogramaeditar->fecha_programa = $fecha_programa;

                $fechaprogramaeditar->save();
            DB::commit();
            return redirect()->route('programas.index')
                ->with('success', 'programas_senales_detalles deleted successfully');    
        } catch (\Exception $e) {
            DB::rollback();
        }
    }
}


