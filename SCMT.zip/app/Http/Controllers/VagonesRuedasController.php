<?php

namespace App\Http\Controllers;

use App\Models\VagonesRuedas;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class VagonesRuedasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {   

        $anho = $request['anho'] ?? date('Y');

        $anhoActual = date('Y');

        $ruedas = VagonesRuedas::dataindex($anho);

        return view('app.vagones.ruedas.index', compact('ruedas', 'anhoActual', 'anho'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $rueda = new VagonesRuedas;
        return view('app.vagones.ruedas.create',compact('rueda')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(VagonesRuedas::$rules);

        $request['usuario_crea'] = Auth::user()->name;
        $rueda = VagonesRuedas::create($request->all());

        if (!empty($request['taller_id'])) {
            return redirect()->route('taller.index')
            ->with('success', 'vagonesRuedas created successfully.');
        }else{

        return redirect()->route('vagonesRuedas.index')
            ->with('success', 'vagonesRuedas created successfully.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VagonesRuedas  $vagonesRuedas
     * @return \Illuminate\Http\Response
     */
    public function show(VagonesRuedas $vagonesRuedas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VagonesRuedas  $vagonesRuedas
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $rueda = VagonesRuedas::find($id);

        return view('app.vagones.ruedas.edit', compact('rueda'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\VagonesRuedas  $vagonesRuedas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VagonesRuedas $vagonesRueda)
    {
        request()->validate(VagonesRuedas::$rules);

        $request['usuario_actualiza'] = Auth::user()->name; 
        $vagonesRueda->update($request->all());

        if (!empty($request['taller_id'])) {
        return redirect()->route('taller.index')
            ->with('success', 'VagonesRuedas updated successfully');    
        }else{
        return redirect()->route('vagonesRuedas.index')
            ->with('success', 'VagonesRuedas updated successfully');
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VagonesRuedas  $vagonesRuedas
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $rueda = VagonesRuedas::find($id)->delete();

        return redirect()->back()
            ->with('success', 'vagonesRuedas deleted successfully');
    }
}
