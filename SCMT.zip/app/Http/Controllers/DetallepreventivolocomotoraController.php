<?php

namespace App\Http\Controllers;

use App\Models\Detallepreventivolocomotora;
use App\Models\Maestropreventivolocomotora;
use App\Models\Reportedelocomotora;
use App\Models\Locomotora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class DetallepreventivolocomotoraController
 * @package App\Http\Controllers
 */
class DetallepreventivolocomotoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $detallepreventivolocomotoras = Detallepreventivolocomotora::paginate();

        return view('app.locomotora.detallepreventivolocomotora.index', compact('detallepreventivolocomotoras'))
            ->with('i', (request()->input('page', 1) - 1) * $detallepreventivolocomotoras->perPage());
    }

    public function periodoprogramasdetalle(Request $request)
    {
        $locomotoras = Locomotora::listadoLocomotorasSelect()->where('numero', '!=','S/N')->pluck('numero', 'numero');
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $locomotora = $request['locomotora_id'] ?? null;
        $programasdetalle_all = Detallepreventivolocomotora::getAllXPeriodo($fechas, $locomotora)->orderBy('fecha_inicio')->get();
    
        return view('app.locomotora.detallepreventivolocomotora.vista_all', compact('programasdetalle_all', 'fechas', 'locomotoras', 'locomotora'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $detallepreventivolocomotora = new Detallepreventivolocomotora();
        $maestropreventivolocomotoras = Maestropreventivolocomotora::paginate();
        $reportedelocomotoras = Reportedelocomotora::getAllPreventivo();;
        return view('app.locomotora.detallepreventivolocomotora.create', compact('detallepreventivolocomotora', 'maestropreventivolocomotoras', 'reportedelocomotoras'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(Detallepreventivolocomotora::$rules);


        foreach ($request->reportelocomotora_id as $index => $reporte) {
            Detallepreventivolocomotora::create(
                [
                    'reportelocomotora_id' => $reporte,
                    'maestropreventivo_id' => $request->maestropreventivo_id,
                    'locomotora' => $request->locomotora,
                    'fecha_inicio' => $request->fecha_inicio,
                    'fecha_fin' => $request->fecha_fin,
                    'cumplimiento' => $request->cumplimiento,
                    'responsable' => $request->responsable[$index],
                    'usuario_crea' => Auth::user()->name
                ]);
        }

        return redirect()->back()
            ->with('success', 'Detallepreventivolocomotora created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $detallepreventivolocomotora = Detallepreventivolocomotora::find($id);

        return view('app.locomotora.detallepreventivolocomotora.show', compact('detallepreventivolocomotora'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $detallepreventivolocomotora = Detallepreventivolocomotora::find($id);
        $maestropreventivolocomotoras = Maestropreventivolocomotora::paginate();
        $reportedelocomotoras = Reportedelocomotora::getAllPreventivo();

        return view('app.locomotora.detallepreventivolocomotora.edit', compact('detallepreventivolocomotora', 'maestropreventivolocomotoras', 'reportedelocomotoras'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Detallepreventivolocomotora $detallepreventivolocomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Detallepreventivolocomotora $detallepreventivolocomotora)
    {
        request()->validate(Detallepreventivolocomotora::$rules);

        $request['usuario_actualiza'] = Auth::user()->name; 
        $detallepreventivolocomotora->update($request->all());

        return redirect()->route('maestropreventivolocomotora.index')
            ->with('success', 'Detallepreventivolocomotora updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $detallepreventivolocomotora = Detallepreventivolocomotora::find($id)->delete();

        return redirect()->back()
            ->with('success', 'Detallepreventivolocomotora deleted successfully');
    }
}
