<?php

namespace App\Http\Controllers;

use App\Models\Locomotora;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;

class LocomotoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $locomotoras = Locomotora::all()->sortBy('numero');
        return view('app.locomotora.admin.index', compact('locomotoras'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $locomotora = new Locomotora;
        return view('app.locomotora.admin.create',compact('locomotora')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        Locomotora::create($datos);
        return redirect(route('administradorlocomotoras.index'))->with('success', 'Creada con exito');
    }


    public function validaData($request){
        return $request->validate([
            'numero' => ['required', 'max:9'],
            'tipo' => ['required', 'max:7'],
            'marca' => ['required', 'max:5'],
            'modelo' => ['required', 'max:20'],
            'ubicacion' => ['max:3'],
            'ceco' => [''],
            'n_plan' => [''],
            'estatus' => [ Rule::in([0, 1]),],
            'fecha_desincorporacion' => [''],
            'mant' => [''],
        ]);
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function show(Locomotora $locomotora)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function edit(Locomotora $administradorlocomotora)
    {
        return view('app.locomotora.admin.edit', array('locomotora' => $administradorlocomotora));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Locomotora $administradorlocomotora)
    {
        $datos = $this->validaData($request);
        $administradorlocomotora->update($datos);
        return redirect(route('administradorlocomotoras.index'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function destroy(Locomotora $administradorlocomotora)
    {
        $administradorlocomotora->delete();
        return redirect(route('administradorlocomotoras.index'))->with('success', 'Eliminado con exito');
    }
}
