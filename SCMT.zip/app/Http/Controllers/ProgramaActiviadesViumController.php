<?php

namespace App\Http\Controllers;

use App\Models\ProgramaActiviadesVium;
use App\Models\ProgramaDetalleVium;
use App\Models\ProgramaAnualVium;
use App\Models\ProgramaVium;
use App\Models\cambiavias;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


/**
 * Class ProgramaActiviadesViumController
 * @package App\Http\Controllers
 */
class ProgramaActiviadesViumController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(request $request)
    {
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];

        $programaActiviadesVia = ProgramaActiviadesVium::getAllXPeriodo($fechas)->orderBy('fecha')->get();

        $AgruparprogramaActiviadesVia = $programaActiviadesVia->sortBy('programa_anual_id')->groupBy('programa_anual_id');

        $AgruparPorPremisaAnual = $programaActiviadesVia->groupBy('descripcion');

        return view('app.via.programa-activiades-vium.index', compact('programaActiviadesVia', 'fechasInicio', 'fechasFin', 'fechas', 'AgruparprogramaActiviadesVia', 'AgruparPorPremisaAnual'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programaActiviadesVium = new ProgramaActiviadesVium();
        $programasAnualesKm = ProgramaAnualVium::selectorAnual()->whereNotIn('descripcion',['INSPECCION CAMBIAVIAS']);
        $programasAnualesCambiaVias = ProgramaAnualVium::selectorAnual()->where('descripcion','INSPECCION CAMBIAVIAS')->pluck('tramo','id');
        $estatusReportevia = ProgramaActiviadesVium::estatusReporteVia();
        $cambiavias = cambiavias::getall();
        $programasDetalle = ProgramaVium::selectorActividades()->pluck('programa','id');

        return view('app.via.programa-activiades-vium.create', compact('programaActiviadesVium', 'programasAnualesKm', 'programasDetalle', 'estatusReportevia', 'cambiavias', 'programasAnualesCambiaVias'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try{

        DB::beginTransaction();

        //request()->validate(ProgramaActiviadesVium::$rules);

        if (!empty($request['cambiavias_id'])) {

        foreach ($request->cambiavias_id as $index => $cambia) {

                ProgramaActiviadesVium::create(
                    [
                        'programa_anual_id' => $request->programa_anual_id[$index],
                        'programa_id' => $request->programa_id,
                        'cambiavias_id' => $cambia,
                        'fecha' => $request->fecha[$index],
                        'tramo_km_inicio' => '0',
                        'tramo_km_fin' => '0',
                        'tramo_km_total' => '1',
                        'cant_persona' => $request->cant_persona[$index],
                        'tiempo' => $request->tiempo[$index],
                        'responsable' => $request->responsable,
                        'tomar' => $request->tomar,
                        'usuario_crea' => Auth::user()->name

                    ]);

            }
        }

        else{


        $request['tramo_km_total'] = $request['tramo_km_fin'] - $request['tramo_km_inicio'];

        $request['usuario_crea'] = Auth::user()->name;

        $programaActiviadesVium = ProgramaActiviadesVium::create($request->all());

        }
        
        DB::commit();
           return redirect()->back()
            ->with('success', 'ProgramaActiviadesVium created successfully.');    
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'Revisar Formulario '); 
        }
    }



    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programaActiviadesVium = ProgramaActiviadesVium::find($id);

        return view('app.via.programa-activiades-vium.show', compact('programaActiviadesVium'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programaActiviadesVium = ProgramaActiviadesVium::find($id);
        $programasAnuales = ProgramaAnualVium::selectorAnual();
        $estatusReportevia = ProgramaActiviadesVium::estatusReporteVia();
        $programasDetalle = ProgramaVium::selectorActividades()->pluck('programa','id');

        return view('app.via.programa-activiades-vium.edit', compact('programaActiviadesVium', 'programasAnuales', 'programasDetalle', 'estatusReportevia'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramaActiviadesVium $programaActiviadesVium
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramaActiviadesVium $programaviasactividade)
    {

        try{

        DB::beginTransaction();

        //request()->validate(ProgramaActiviadesVium::$rules);

        if (!empty($request['cambiavias_id'])) {

            $request['tramo_km_total'] = 1;
            $request['tramo_km_inicio'] = 0;
            $request['tramo_km_fin'] = 0;
        
        }
        else{

        $request['tramo_km_total'] = $request['tramo_km_fin'] - $request['tramo_km_inicio'];

        }
        
        $request['usuario_actualiza'] = Auth::user()->name;


        $programaviasactividade->update($request->all());

        DB::commit();
           return redirect()->route('programaviasactividades.index')
            ->with('success', 'Activiadad Actualizada con Exito.');    
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'Revisar Formulario '); 
        }

    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programaActiviadesVium = ProgramaActiviadesVium::find($id)->delete();

        return redirect()->route('programaviasactividades.index')
            ->with('success', 'ProgramaActiviadesVium deleted successfully');
    }
}
