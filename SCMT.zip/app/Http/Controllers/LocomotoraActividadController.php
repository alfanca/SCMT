<?php

namespace App\Http\Controllers;

use App\Clases\Turno;
use App\Clases\Fechas;
use App\Models\LocomotoraActividad;
use App\Models\Locomotora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LocomotoraActividadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $fecha = $request->fecha ?? date('Y-m-d');
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $listadoActividades = LocomotoraActividad::listarActidades()->fecha($fecha)->get()->sortBy('turno')->groupBy('turno');
        return view('app.locomotora.actividades.index', compact('listadoActividades', 'fechas'));
    }


      public function listacompleta(Request $request)
    {
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $actividades_alll = LocomotoraActividad::getAllXPeriodo($fechas)->orderBy('fecha')->get();

        return view('app.locomotora.actividades.vista_alll', compact('actividades_alll', 'fechas', 'responsable'));
    }

    
        /**
     * Display the specified resource.
     *
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function show($fecha)
    {
        if ($fecha == date('Y-m-d')){
            return redirect(route('actividades.index'));
        }
        
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $listadoActividades = LocomotoraActividad::listarActidades()->fecha($fecha)->get()->sortBy('turno')->groupBy('turno');
        return view('app.locomotora.actividades.show', compact('listadoActividades', 'fechas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $turnos = Turno::TURNOS;
        $locomotoras = Locomotora::listadoLocomotorasSelect(); 
        $actividad = new LocomotoraActividad;
        return view('app.locomotora.actividades.create', compact('listadoActividades', 'turnos', 'locomotoras', 'actividad'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        $datos['usuario_crea'] = Auth::user()->name;
        LocomotoraActividad::create($datos);
        return redirect(route('actividades.index'))->with('success', 'Creada con exito');
    }

    public function validaData($request){
        return $request->validate([
            'locomotora_id' => ['required', 'max:9'],
            'turno' => ['required'],
            'actividad' => ['required'],
            'responsable' => ['required'],
            'tiempo' => ['required'],
            'estatus' =>  ['required'],
            'fecha' => ['required'],
            'orden' => ['max:7'],
        ]);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LocomotoraActividad  $locomotoraActividad
     * @return \Illuminate\Http\Response
     */
    public function edit(LocomotoraActividad $actividade)
    {
        $locomotoras = Locomotora::listadoLocomotorasSelect(); 
        $turnos = Turno::TURNOS;
        return view('app.locomotora.actividades.edit', array('actividad' => $actividade, 'locomotoras' => $locomotoras, 'turnos'=> $turnos));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LocomotoraActividad  $locomotoraActividad
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LocomotoraActividad $actividade)
    {
        $datos = $this->validaData($request);
        $datos['usuario_actualiza'] = Auth::user()->name;        
        $actividade->update($datos);
        return redirect(route('actividades.index'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LocomotoraActividad  $locomotoraActividad
     * @return \Illuminate\Http\Response
     */
    public function destroy(LocomotoraActividad $actividade)
    {
        $actividade->usuario_elimina = Auth::user()->name;
        $actividade->save();
        $actividade->delete();
        return redirect(route('actividades.index'))->with('success', 'Eliminado con exito');
    }
}

