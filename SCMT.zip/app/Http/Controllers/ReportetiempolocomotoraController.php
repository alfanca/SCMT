<?php

namespace App\Http\Controllers;

use App\Models\Reportetiempolocomotora;
use App\Models\Reportedelocomotora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class ReportetiempolocomotoraController
 * @package App\Http\Controllers
 */
class ReportetiempolocomotoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reportetiempolocomotoras = Reportetiempolocomotora::paginate();

        return view('app.locomotora.reportetiempolocomotora.index', compact('reportetiempolocomotoras'))
            ->with('i', (request()->input('page', 1) - 1) * $reportetiempolocomotoras->perPage());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $reportetiempolocomotora = new Reportetiempolocomotora();
        return view('app.locomotora.reportetiempolocomotora.create', compact('reportetiempolocomotora', 'reportedelocomotora'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        request()->validate(Reportetiempolocomotora::$rules);

        $request['usuario_crea'] = Auth::user()->name;
        $reportetiempolocomotora = Reportetiempolocomotora::create($request->all());

        return redirect()->back()
            ->with('success', 'Reportetiempolocomotora created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $reportetiempolocomotora = Reportetiempolocomotora::find($id);

        return view('reportetiempolocomotora.show', compact('reportetiempolocomotora'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $reportetiempolocomotora = Reportetiempolocomotora::find($id);
        $reportedelocomotora = Reportedelocomotora::find($id);

        return view('app.locomotora.reportetiempolocomotora.edit', compact('reportetiempolocomotora', 'reportedelocomotora'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Reportetiempolocomotora $reportetiempolocomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Reportetiempolocomotora $reportetiempolocomotora)
    {
        request()->validate(Reportetiempolocomotora::$rules);

        $request['usuario_actualiza'] = Auth::user()->name;
        $reportetiempolocomotora->update($request->all());

        return redirect()->route('reportetiempolocomotoras.index')
            ->with('success', 'Reportetiempolocomotora updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $reportetiempolocomotora = Reportetiempolocomotora::find($id)->delete();

        return redirect()->back()
            ->with('success', 'Reportetiempolocomotora deleted successfully');
    }
}
