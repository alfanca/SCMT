<?php

namespace App\Http\Controllers;

use App\Models\materialeslocomotora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MaterialeslocomotoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
     {
        $materialeslocomotoras = materialeslocomotora::all();
        return view('app.locomotora.materiales.index', compact('materialeslocomotoras'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $materialeslocomotora = new materialeslocomotora;
        return view('app.locomotora.materiales.create',compact('materialeslocomotora')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
            
    public function store(Request $request)
    {
        $registro = Validator::make($request->all(), materialeslocomotora::$rules, materialeslocomotora::$error_message)->validate();
        try{
            if($request->hasFile('foto')){
                $file = $request->file('foto');
                $name = time().$file->getClientOriginalName();
                $file -> move(\public_path().'/imagenesmaterialeslocomotora/', $name);
            }

            if (!empty($request->hasFile('foto'))) {
            $registro['foto'] = $name;
            }
            materialeslocomotora::create($registro);
            return redirect(route('materialeslocomotora.index'))->with('success', 'Creada con exito');
        }catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
       }
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\materialeslocomotora  $materialeslocomotora
     * @return \Illuminate\Http\Response
     */
    public function show(materialeslocomotora $materialeslocomotora)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\materialeslocomotora  $materialeslocomotora
     * @return \Illuminate\Http\Response
     */
    public function edit(materialeslocomotora $materialeslocomotora)
    {
        return view('app.locomotora.materiales.edit', array('materialeslocomotora' => $materialeslocomotora));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\materialeslocomotora  $materialeslocomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, materialeslocomotora $materialeslocomotora)
    {
        $registro = Validator::make($request->all(), materialeslocomotora::$rules, materialeslocomotora::$error_message)->validate();

        try{
            if($request->hasFile('foto')){
                $file = $request->file('foto');
                $name = time().$file->getClientOriginalName();
                $file -> move(\public_path().'/imagenesmaterialeslocomotora/', $name);
            }

            if (!empty($request->hasFile('foto'))) {
            $registro['foto'] = $name;
            }
            $materialeslocomotora->update($registro);
            return redirect(route('materialeslocomotora.index'))->with('success', 'Creada con exito');
        }catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
       }     
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\materialeslocomotora  $materialeslocomotora
     * @return \Illuminate\Http\Response
     */
    public function destroy(materialeslocomotora $materialeslocomotora)
    {
        $materialeslocomotora->delete();
        return redirect(route('materialeslocomotora.index'))->with('success', 'Eliminado con exito');
    }
}
