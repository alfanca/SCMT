<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Clases\Turno;
use App\Clases\Fechas;
use App\Models\Locomotora;
use App\Models\Actividad;

class SenalesActividadesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $fecha = $request->fecha ?? date('Y-m-d');
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $listadoActividades = Actividad::listarActidades()->fecha($fecha)->señales()->get()->sortBy('turno')->groupBy('turno');
        return view('app.senales.actividades.index', compact('listadoActividades', 'fechas'));
    }


    public function listacompletasenales(Request $request)
    {
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];

        $actividades_all = Actividad::getAllXPeriodoSenales($fechas)->señales()->orderBy('fecha')->get();
    
        return view('app.senales.actividades.vista_all', compact('actividades_all', 'fechas', 'responsable','tramoselector'));
    }

    /**  
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $turnos = Turno::TURNOS;
        $actividad = new Actividad;
        return view('app.senales.actividades.create', compact('turnos', 'actividad'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        $datos['origen'] = Actividad::SEÑALES;
        $datos['usuario_crea'] = Auth::user()->name;
        Actividad::create($datos);
        return redirect(route('senales_actividades.index'))->with('success', 'Creada con exito');
    }

    public function validaData($request){
        return $request->validate([
            'turno' => ['required'],
            'actividad' => ['required'],
            'responsable' => ['required'],
            'fecha' => ['required'],
            'orden' => ['max:7'],
            'tramo' => ['required']
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($fecha)
    {
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $listadoActividades = Actividad::listarActidades()->fecha($fecha)->señales()->get()->sortBy('turno')->groupBy('turno');
        return view('app.senales.actividades.index', compact('listadoActividades', 'fechas'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Actividad $actividad)
    {
        $turnos = Turno::TURNOS;
        return view('app.senales.actividades.edit', compact('actividad', 'turnos'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Actividad $actividad)
    {
        $datos = $this->validaData($request);
        $datos['usuario_actualiza'] = Auth::user()->name;
        $actividad->update($datos);
        return redirect(route('senales_actividades.index'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Actividad $actividad)
    {
        $actividad->usuario_elimina = Auth::user()->name;
        $actividad->save();
        $actividad->delete();
        return redirect(route('senales_actividades.index'))->with('success', 'Eliminado con exito');
    }
}
