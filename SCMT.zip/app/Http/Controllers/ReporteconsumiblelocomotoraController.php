<?php

namespace App\Http\Controllers;

use App\Models\Reporteconsumiblelocomotora;
use App\Models\materialeslocomotora;
use App\Models\Locomotora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class ReporteconsumiblelocomotoraController
 * @package App\Http\Controllers
 */
class ReporteconsumiblelocomotoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reporteconsumiblelocomotoras = Reporteconsumiblelocomotora::paginate();

        return view('app.locomotora.reporteconsumiblelocomotora.index', compact('reporteconsumiblelocomotoras'))
            ->with('i', (request()->input('page', 1) - 1) * $reporteconsumiblelocomotoras->perPage());
    }

    public function periodoconsumibles(Request $request)
    {
        $locomotoras = Locomotora::pluck('numero', 'numero');
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $locomotora = $request['locomotora_id'] ?? null;
        $reporte_all = Reporteconsumiblelocomotora::getAllXPeriodo($fechas, $locomotora)->orderBy('fecha')->get();

        $agruparConsumibles = $reporte_all->groupBy('materiales_id');

        $graficaConsumo = $agruparConsumibles->take(6); 
    
        return view('app.locomotora.reporteconsumiblelocomotora.vista_all', compact('reporte_all', 'fechas', 'locomotoras', 'locomotora', 'agruparConsumibles', 'graficaConsumo'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $reporteconsumiblelocomotora = new Reporteconsumiblelocomotora();
        $locomotoras = Locomotora::listadoLocomotorasSelect()->pluck('numero', 'numero');
        $materialeslocomotoras = materialeslocomotora::all();
        return view('app.locomotora.reporteconsumiblelocomotora.create', compact('reporteconsumiblelocomotora', 'materialeslocomotoras', 'locomotoras'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(Reporteconsumiblelocomotora::$rules);

        $request['usuario_crea'] = Auth::user()->name;
        $request['preciounitario'] = materialeslocomotora::where('id',$request['materiales_id'])->first()->preciounitario;
        $reporteconsumiblelocomotora = Reporteconsumiblelocomotora::create($request->all());

        return redirect()->back()
            ->with('success', 'Reporteconsumiblelocomotora created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $reporteconsumiblelocomotora = Reporteconsumiblelocomotora::find($id);

        return view('app.locomotora.reporteconsumiblelocomotora.show', compact('reporteconsumiblelocomotora'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $reporteconsumiblelocomotora = Reporteconsumiblelocomotora::find($id);

        return view('app.locomotora.reporteconsumiblelocomotora.edit', compact('reporteconsumiblelocomotora'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Reporteconsumiblelocomotora $reporteconsumiblelocomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Reporteconsumiblelocomotora $reporteconsumiblelocomotora)
    {
        request()->validate(Reporteconsumiblelocomotora::$rules);

        $request['usuario_actualiza'] = Auth::user()->name;
        $reporteconsumiblelocomotora->update($request->all());

        return redirect()->route('reporteconsumiblelocomotoras.index')
            ->with('success', 'Reporteconsumiblelocomotora updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $reporteconsumiblelocomotora = Reporteconsumiblelocomotora::find($id)->delete();

        return redirect()->back()
            ->with('success', 'Reporteconsumiblelocomotora deleted successfully');
    }
}
