<?php

namespace App\Http\Controllers;

use App\Models\ViasMateriale;
use Illuminate\Http\Request;

/**
 * Class ViasMaterialeController
 * @package App\Http\Controllers
 */
class ViasMaterialeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $viasMateriales = ViasMateriale::getall();

        return view('app.via.viasmateriale.index', compact('viasMateriales'))
            ->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $viasMateriale = new ViasMateriale();
        $elegirunidad = collect(ViasMateriale::UNIDAD);
        return view('app.via.viasmateriale.create', compact('viasMateriale', 'elegirunidad'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ViasMateriale::$rules);

        $viasMateriale = ViasMateriale::create($request->all());

        return redirect()->route('viasmateriale.index')
            ->with('success', 'ViasMateriale created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $viasMateriale = ViasMateriale::find($id);

        return view('app.via.viasmateriale.show', compact('viasMateriale'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $viasMateriale = ViasMateriale::find($id);
        $elegirunidad = collect(ViasMateriale::UNIDAD);

        return view('app.via.viasmateriale.edit', compact('viasMateriale', 'elegirunidad'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ViasMateriale $viasMateriale
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ViasMateriale $viasmateriale)
    {
        request()->validate(ViasMateriale::$rules);

        $viasmateriale->update($request->all());

        return redirect()->route('viasmateriale.index')
            ->with('success', 'ViasMateriale updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $viasMateriale = ViasMateriale::find($id)->delete();

        return redirect()->route('viasmateriale.index')
            ->with('success', 'ViasMateriale deleted successfully');
    }
}
