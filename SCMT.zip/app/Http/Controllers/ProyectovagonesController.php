<?php

namespace App\Http\Controllers;

use App\Models\proyectovagones;
use App\Models\proyecto_vagones_componentes;
use App\Models\VagonTaller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ProyectovagonesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $proyectoVagones = proyectovagones::getAll();

        return view('app.vagones.proyecto_vagones.index', compact('proyectoVagones'))
            ->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $proyectoVagon = new proyectovagones();
        
        return view('app.vagones.proyecto_vagones.create', compact('proyectoVagon'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try{
            DB::beginTransaction();

            request()->validate(proyectovagones::$rules);

            $request['estatus'] = 'ABIERTA';
            $request['usuario_crea'] = Auth::user()->name;

            $proyectoVagon = proyectovagones::create($request->all());

            DB::commit();
           return redirect()->route('proyectoVagones.index')
            ->with('success', 'proyectoVagones created successfully.');  

        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'No se pudo crear el programa, revise el formulario'); 
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\proyectovagones  $proyectovagones
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

       $proyectoVagon = proyectovagones::find($id);

       $DetalleproyectoVagon = VagonTaller::detalleTallerProyecto($id);

       $proyectoConsumoVagones = proyecto_vagones_componentes::detalleProyectoVagonConsumo($id);

       $consumoPorTipo =  $proyectoConsumoVagones->groupBy('materiales_vagones_id');

       return view('app.vagones.proyecto_vagones.show', compact('proyectoVagon', 'DetalleproyectoVagon', 'proyectoConsumoVagones', 'consumoPorTipo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\proyectovagones  $proyectovagones
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $proyectoVagon = proyectovagones::find($id);

        return view('app.vagones.proyecto_vagones.edit', compact('proyectoVagon'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\proyectovagones  $proyectovagones
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, proyectovagones $proyectoVagone)
    {
        try{
            DB::beginTransaction();

        request()->validate(proyectovagones::$rules);

        $request['usuario_actualiza'] = Auth::user()->name;

        $proyectoVagone->update($request->all());

        DB::commit();
           return redirect()->route('proyectoVagones.index')
            ->with('success', 'proyectoVagones updated successfully.');  

        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'No se pudo actualizar el programa, revise el formulario'); 
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\proyectovagones  $proyectovagones
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $proyectoVagon = proyectovagones::find($id)->delete();

        return redirect()->route('proyectoVagones.index')
            ->with('success', 'proyectoVagones deleted successfully');
    }
}
