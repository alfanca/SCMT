<?php

namespace App\Http\Controllers;
use App\Clases\Fechas;
use App\Models\Vagones;
use App\Models\VagonesInspeccion;
use App\Models\VagonesInspeccionDetalle;


use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class VagonInspeccionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $fecha = $request->fecha ?? date('Y-m-d');
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $inspeccionesDia = VagonesInspeccion::fecha($fecha)->get()->sortBy('tren');
        return view('app.vagones.inspecciones.index', compact('inspeccionesDia', 'fechas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $inspeccion = new VagonesInspeccion();
        return view('app.vagones.inspecciones.create', compact('inspeccion'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try{
            
            DB::beginTransaction();
                $datos = $this->validaData($request);
                $datos['usuario_c'] = Auth::user()->name;
                $inspeccion = VagonesInspeccion::create($datos);

                if(isset($request['vagones'])){
                    $inspeccionDetalle = new VagonesInspeccionDetalle;
                    $inspeccionDetalle->crear($inspeccion, $request['vagones']);
                }
            DB::commit();        
                    
            return redirect(route('inspeccion.index'))->with('success', 'Inspección creada con exito');
        }catch (\Exception $e) {
            DB::rollback();
            return redirect(route('inspeccion.index'))->with('error', 'Ha ocurrido un error: '.$e->getMessage());
      }
    }

    public function validaData($request){
        return $request->validate([
            'fecha' => ['required', 'date'],
            'tren' => ['required'],
            'n_linea' => [''],
            'ficha_inspector' => ['required'],
            'hora_salida' => [''],
            'nota' => [''],
        ]);
    }    

    /**
     * Display the specified resource.
     *
     * @param  \App\VagonesInspeccion  $vagonesInspeccion
     * @return \Illuminate\Http\Response
     */
    public function show($fecha)
    {
        if ($fecha == date('Y-m-d')){
            return redirect(route('inspeccion.index'));
        }
        
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        $inspeccionesDia = VagonesInspeccion::fecha($fecha)->get()->sortBy('tren');
        return view('app.vagones.inspecciones.index', compact('inspeccionesDia', 'fechas'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VagonesInspeccion  $vagonesInspeccion
     * @return \Illuminate\Http\Response
     */
    public function edit(VagonesInspeccion $inspeccion)
    {
        $vagonesInspeccion = $inspeccion->vagones->sortBy('orden');
        return view('app.vagones.inspecciones.edit', compact('inspeccion', 'vagonesInspeccion'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\VagonesInspeccion  $vagonesInspeccion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VagonesInspeccion $inspeccion)
    {
        try{
            DB::beginTransaction();
                $datos = $this->validaData($request);
                $inspeccion->usuario_a = Auth::user()->name;
                $inspeccion->update($datos);
                
                //verifica si el tren esta en CP o PZO segun su referencia
                if (!strcmp($request['tren'], $inspeccion->tren)){
                    Vagones::actualizarTrenPorInspeccion($inspeccion);
                }
                
                if (!empty($request['vagones'])){
                    $inspeccionDetalle = new VagonesInspeccionDetalle;
                    $inspeccionDetalle->actualizar($inspeccion, $request['vagones']);    
                }
            DB::commit();       
                return redirect(route('inspeccion.index'))->with('success', 'Actualizado con exito');
        }catch (\Exception $e) {
            DB::rollback();
            return redirect(route('inspeccion.index'))->with('error', 'Ha ocurrido un error: '.$e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VagonesInspeccion  $vagonesInspeccion
     * @return \Illuminate\Http\Response
     */
    public function destroy(VagonesInspeccion $inspeccion)
    {
        $actividad->usuario_elimina = Auth::user()->name;
        $actividad->save();
        $actividad->delete();
        return redirect(route('via_actividades.index'))->with('success', 'Eliminado con exito');
    }
}

