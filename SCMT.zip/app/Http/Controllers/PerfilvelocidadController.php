<?php

namespace App\Http\Controllers;

use App\Models\perfilvelocidad;
use Illuminate\Http\Request;

class PerfilvelocidadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(request $request)
    {
        $estatus = $request['estatus'] ?? 'ABIERTA';

        $estatusActual = 'ABIERTA';

        $perfilesTabla = perfilvelocidad::getAll($estatus);

        $perfiltotal = round((((732-$perfilesTabla->pluck('resto')->sum())*45)+($perfilesTabla->pluck('kmtotal')->sum()))/732);
        $kmtotaldiferencia = ($perfilesTabla->pluck('kmdiftotal'))->sum();
        $porcentajereduccion = round(((73.2-($perfilesTabla->sum('total')))/73.2)*100);
        $conteoreducciones = count($perfilesTabla);


        return view('app.via.perfilvelocidad.index', compact('perfiltotal', 'kmtotaldiferencia', 'porcentajereduccion', 'conteoreducciones', 'reducciones', 'perfilesTabla'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $perfil = new perfilvelocidad;
        return view('app.via.perfilvelocidad.create',compact('perfil')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        $datos['estatus'] = 'ABIERTA';
        perfilvelocidad::create($datos);
        return redirect(route('perfilvelocidad.index'))->with('success', 'Creada con exito');
    }

      public function validaData($request){
        return $request->validate([
            'fechareal' => ['required'],
            'kminicial' => ['required'],
            'kmfinal' => ['required'],
            'velplan' => ['required'],
            'velreal' => ['required'],
            'nota' => [''],
            'fecha_fin' => [''],
            'estatus' => ['max:12'],
        ]);
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\perfilvelocidad  $perfilvelocidad
     * @return \Illuminate\Http\Response
     */
    public function show(perfilvelocidad $perfilvelocidad)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\perfilvelocidad  $perfilvelocidad
     * @return \Illuminate\Http\Response
     */
    public function edit(perfilvelocidad $perfilvelocidad)
    {
        return view('app.via.perfilvelocidad.edit', array('perfil' => $perfilvelocidad));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\perfilvelocidad  $perfilvelocidad
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, perfilvelocidad $perfilvelocidad)
    {
        $datos = $this->validaData($request);
        $perfilvelocidad->update($datos);
        return redirect(route('perfilvelocidad.index'))->with('success', 'Actualizado con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\perfilvelocidad  $perfilvelocidad
     * @return \Illuminate\Http\Response
     */
    public function destroy(perfilvelocidad $perfilvelocidad)
    {
        $perfilvelocidad->delete();
        return redirect(route('perfilvelocidad.index'))->with('success', 'Eliminado con exito');
    }
}
