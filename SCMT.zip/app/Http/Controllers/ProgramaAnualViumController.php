<?php

namespace App\Http\Controllers;

use App\Models\ProgramaAnualVium;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

/**
 * Class ProgramaAnualViumController
 * @package App\Http\Controllers
 */
class ProgramaAnualViumController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(request $request)
    {
        $estatus = $request['estatus'] ?? 'ACTIVO';

        $programaestatus = ProgramaAnualVium::estatus();

        $programaAnualVia = ProgramaAnualVium::getAll($estatus);

        return view('app.via.programa-anual-vium.index', compact('programaAnualVia', 'estatus', 'programaestatus'))
            ->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programaAnualVium = new ProgramaAnualVium();

        return view('app.via.programa-anual-vium.create', compact('programaAnualVium'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramaAnualVium::$rules);


        $request['estatus'] = 'ACTIVO';
        $request['usuario_crea'] = Auth::user()->name;

        $programaAnualVium = ProgramaAnualVium::create($request->all());

        return redirect()->route('programaviasanual.index')
            ->with('success', 'ProgramaAnualVium created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programaAnualVium = ProgramaAnualVium::find($id);

        return view('app.via.programa-anual-vium.show', compact('programaAnualVium'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programaAnualVium = ProgramaAnualVium::find($id);

        return view('app.via.programa-anual-vium.edit', compact('programaAnualVium'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramaAnualVium $programaAnualVium
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramaAnualVium $programaviasanual)
    {
        request()->validate(ProgramaAnualVium::$rules);

        $request['usuario_actualiza'] = Auth::user()->name;

        $programaviasanual->update($request->all());

        return redirect()->route('programaviasanual.index')
            ->with('success', 'ProgramaAnualVium updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programaAnualVium = ProgramaAnualVium::find($id)->delete();

        return redirect()->route('programaviasanual.index')
            ->with('success', 'ProgramaAnualVium deleted successfully');
    }
}
