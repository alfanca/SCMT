<?php

namespace App\Http\Controllers;

use App\Clases\Turno;
use App\Clases\Fechas;
use App\Models\Reportedelocomotora;
use App\Models\LocomotoraDisponibilidad;
use App\Models\Nota;
use App\Models\Locomotora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class LocomotoraDisponibilidadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $fecha = $request->fecha ?? date('Y-m-d');
        $locomotorasDisponibilidad = LocomotoraDisponibilidad::fecha($fecha)->get();
        $locomotorasDisponibilidadNotas = Nota::locomotoras()->fecha($fecha)->get();

        $turnos = Turno::TURNOS;
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);
        return view('app.locomotora.disponibilidad.index', 
            compact('locomotorasDisponibilidad', 'turnos', 'fechas', 'locomotorasDisponibilidadNotas'));
    }

    public function disponibilidadPorSemana(Request $request)
    {
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];

        $restafin = strtotime($request['fecha_fin']);
        $restainicio= strtotime($request['fecha_inicio']);

        $restarfechas = intval(((($restafin - $restainicio)/86400)+1)*3);

        $disponibilidadXSemana = LocomotoraDisponibilidad::listarXSemana($fechas)->orderBy('fecha')->get()->groupBy('semana');


        return view('app.locomotora.disponibilidad.disponibilidadXSemana', 
            compact('disponibilidadXSemana', 'restarfechas'));
    }

        /**
     * Display the specified resource.
     *
     * @param  \App\Locomotora  $locomotora
     * @return \Illuminate\Http\Response
     */
    public function show($fecha)
    {
        if ($fecha == date('Y-m-d')){
            return redirect(route('disponibilidad.index'));
        }
        
        $locomotorasDisponibilidad = LocomotoraDisponibilidad::fecha($fecha)->get();
        $locomotorasDisponibilidadNotas = Nota::locomotoras()->fecha($fecha)->get();
        $turnos = Turno::TURNOS;
        $fechas = Fechas::obtenerValoresDiasNavegacion($fecha);

        return view('app.locomotora.disponibilidad.show', 
            compact('locomotorasDisponibilidad', 'turnos', 'fechas', 'locomotorasDisponibilidadNotas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $turnos =  Turno::TURNOS;
        $disponibilidad = new LocomotoraDisponibilidad;
        $locomotoras = Locomotora::listadoLocomotorasSelect()->where('numero', '!=','S/N')->sortBy('numero');
        return view('app.locomotora.disponibilidad.create',compact('disponibilidad', 'turnos', 'locomotoras'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       try { 
            $datosEnArrayPZO = $this->crearArrayStore($request, 'pzo');
            $datosEnArrayCP = $this->crearArrayStore($request, 'cp');
            $disponibilidad = new LocomotoraDisponibilidad;
            DB::beginTransaction();
                $resultado = $disponibilidad->crear(array_merge($datosEnArrayPZO,$datosEnArrayCP));
                if ($resultado){
                    DB::commit();  
                    return redirect(route('disponibilidad.index'))->with('success', 'Actualizado con exito');   
                }
                else{
                       DB::rollback();
                      return redirect(route('disponibilidad.index'))->with('error', 'Data invalida, locomotora duplicada en el turno');
                }
       } catch (Exception $e) {
            DB::rollback();
           return redirect(route('disponibilidad.index'))->with('error', 'Data invalida, locomotora duplicada en el turno');
       }
       
    }

    private function crearArrayStore($entrada, $ubicacionLocomotora){
        $salida = [];
        if (isset($entrada[$ubicacionLocomotora])){
            foreach ($entrada[$ubicacionLocomotora] as $locomotora) {
                $datos['locomotora_id'] = $locomotora;
                $datos['turno'] = $entrada->turno;
                $datos['fecha'] = $entrada->fecha;
                $datos['estatus'] = true;
                $datos['ubicacion'] = $ubicacionLocomotora;
                $datos['usuario_crea'] = Auth::user()->name;
                $salida[]=$datos;
            }
        }
        return $salida;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LocomotoraDisponibilidad  $locomotoraDisponibilidad
     * @return \Illuminate\Http\Response
     */
    public function destroy(LocomotoraDisponibilidad $disponibilidad)
    {
        $disponibilidad->usuario_elimina = Auth::user()->name;
        $disponibilidad->save();
        $disponibilidad->delete();
        return redirect(route('disponibilidad.index'))->with('success', 'Eliminado con exito');
    }


    public function disponibilidadXPeriodo(Request $request){
        if (empty($request['fecha_inicio'])){
            $fechas = array(date('Y-m-d'), date('Y-m-d'));
        }
        else{
            $fechas = array($request['fecha_inicio'], $request['fecha_fin'] ?? $request['fecha_inicio']);
        }

        $restafin = strtotime($request['fecha_fin']);
        $restainicio= strtotime($request['fecha_inicio']);

        $restarfechas = intval(((($restafin - $restainicio)/86400)+1)*24);

         $restarfechascolum = intval((((($restafin - $restainicio)/86400)+1)*24)/2);

        $locomotorasDisponibilidad = LocomotoraDisponibilidad::disponibilidadXPeriodo($fechas);

        $locomotorasDisponibilidaddd = LocomotoraDisponibilidad::conteodelocomotorasoperativastiempo($fechas);

        $conteolocomotoras = $locomotorasDisponibilidaddd->count();
        
        //Maquinas operativas por Tipo

        $locomotora2000hp = $locomotorasDisponibilidaddd->where('numero', '>', '0012')->where('numero', '<', '1052')->where('horasdisponibles', '>=', $restarfechascolum)->count();

        $locomotora4000hp = $locomotorasDisponibilidaddd->where('numero', '>=', '1052')->where('numero', '<', '1058')->where('horasdisponibles', '>=', $restarfechascolum)->count();
        

        $locomotora4300hp = $locomotorasDisponibilidaddd->where('numero', '>=', '1060')->where('numero', '<', '1071')->where('horasdisponibles', '>=', $restarfechascolum)->count();

        $locomotora4400hp = $locomotorasDisponibilidaddd->where('numero', '>=', '1058')->where('numero', '<', '1060')->where('horasdisponibles', '>=', $restarfechascolum)->count();

        $locomotoraDF8 = $locomotorasDisponibilidaddd->where('numero', '>=', '0001')->where('numero', '<', '0013')->where('horasdisponibles', '>=', $restarfechascolum)->count();

        $totalconteo = $locomotora2000hp + $locomotora4000hp + $locomotora4300hp + $locomotora4400hp + $locomotoraDF8;

        if ($conteolocomotoras > 0) {

        $porcentajedecumplimiento = round(($totalconteo / $conteolocomotoras)*100);

        }
        else{

        $porcentajedecumplimiento = 0;

        }

        //Aqui Termina

        $acumuladoHoraXLocomotora = LocomotoraDisponibilidad::acumuladoHoraXLocomotora($locomotorasDisponibilidad);

        

        //cambiar al modelo
        $acumuladoHoraXLocomotoraXUbicacion = $locomotorasDisponibilidad->groupBy('ubicacion');
        $acumulado= [];
        foreach ($acumuladoHoraXLocomotoraXUbicacion as $ubicacion => $datos) {
            $acumulado[$ubicacion] = LocomotoraDisponibilidad::acumuladoHoraXLocomotora($datos);
        }

        
        //Promedio de Horas Operativas Puerto Ordaz y Ciudad Piar//

        if (!empty($acumuladoHoraXLocomotora)) {
       
        $promediohorastotal = round (array_sum($acumuladoHoraXLocomotora)/count($acumuladoHoraXLocomotora, 1), 1);


        }

        if (!empty($acumuladoHoraXLocomotoraXUbicacion ['Ciudad Piar'])) {
       
        $promediohorastotalciudadpiar = round(($acumuladoHoraXLocomotoraXUbicacion ['Ciudad Piar']->pluck('horasdisponibles')->sum())/count($acumuladoHoraXLocomotoraXUbicacion ['Ciudad Piar']),1);
        }

        
        if (!empty($acumuladoHoraXLocomotoraXUbicacion ['Puerto Ordaz'])) {

        $promediohorastotalpuertoordaz = round(($acumuladoHoraXLocomotoraXUbicacion ['Puerto Ordaz']->pluck('horasdisponibles')->sum())/count($acumuladoHoraXLocomotoraXUbicacion ['Puerto Ordaz']),1);
        }

        else{

            $promediohorastotal = 0;
        }


        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $locomotora = $request['locomotora_id'] ?? null;
        $conteoReportes = Reportedelocomotora::getAllXPeriodo($fechas, $locomotora)->where('planeado', '1')->get();




        //cambiar
        return view('app.locomotora.disponibilidad.periodo.index', 
            compact('locomotorasDisponibilidad', 'fechas', 'acumuladoHoraXLocomotora', 'acumulado', 'acumuladoHoraXLocomotoraXUbicacion','promediohorastotal','restarfechas','promediohorastotalciudadpiar','promediohorastotalpuertoordaz', 'locomotora2000hp', 'locomotora4000hp', 'locomotora4300hp', 'locomotora4400hp', 'locomotoraDF8', 'totalconteo', 'locomotorasDisponibilidaddd', 'porcentajedecumplimiento', 'conteoReportes'));
    }
}