<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Equipo_apoyo;
use Illuminate\Support\Facades\Validator;

class Equipo_apoyoController extends Controller
{
 /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $equiposApoyo = Equipo_apoyo::equiposGetALL();
        $dispEquipoApoyo = $equiposApoyo ->where('estatus', '=', 'Disponible')->count();
        $fueradeServicio = $equiposApoyo ->whereIn('estatus', ['Fuera de Servicio', 'Mantenimiento'])->count();
        $totalEquipoApoyo = $equiposApoyo->count();
        return view('app.vagones.equipo_apoyo.index', compact('equiposApoyo', 'dispEquipoApoyo', 'fueradeServicio', 'totalEquipoApoyo'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $equipoApoyo = new Equipo_apoyo;
        return view('app.vagones.equipo_apoyo.create',compact('equipoApoyo')); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $registro = Validator::make($request->all(), Equipo_apoyo::$rules)->validate();
        try{
            if($request->hasFile('foto')){
                $file = $request->file('foto');
                $name = time().$file->getClientOriginalName();
                $file -> move(\public_path().'/imagenesEquipoApoyo/', $name);
            }

            if (!empty($request->hasFile('foto'))) {
            $registro['foto'] = $name;
            }
            Equipo_apoyo::create($registro);
            return redirect(route('equipodeapoyo.index'))->with('success', 'Creada con exito');
        }catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
       }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Equipo_apoyo  $equiposApoyo
     * @return \Illuminate\Http\Response
     */
    public function show(Equipo_apoyo $equipodeapoyo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Equipo_apoyo  $equiposApoyo
     * @return \Illuminate\Http\Response
     */
    public function edit(Equipo_apoyo $equipodeapoyo)
    {
        return view('app.vagones.equipo_apoyo.edit', array('equipoApoyo' => $equipodeapoyo));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Equipo_apoyo  $equiposApoyo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Equipo_apoyo $equipodeapoyo)
    {
         $registro = Validator::make($request->all(), Equipo_apoyo::$rules)->validate();

        try{
            if($request->hasFile('foto')){
                $file = $request->file('foto');
                $name = time().$file->getClientOriginalName();
                $file -> move(\public_path().'/imagenesEquipoApoyo/', $name);
            }

            if (!empty($request->hasFile('foto'))) {
            $registro['foto'] = $name;
            }
            $equipodeapoyo->update($registro);
            return redirect(route('equipodeapoyo.index'))->with('success', 'Actualizado con exito');
        }catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
       }     

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Equipo_apoyo  $equiposApoyo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Equipo_apoyo $equipodeapoyo)
    {
        $equipodeapoyo->delete();
        return redirect(route('equipodeapoyo.index'))->with('success', 'Eliminado con exito');
    }
}
