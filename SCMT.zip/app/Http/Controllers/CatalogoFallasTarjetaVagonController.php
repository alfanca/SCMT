<?php

namespace App\Http\Controllers;

use App\Models\catalogo_fallas_tarjeta_vagon;
use App\Models\VagonTaller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class CatalogoFallasTarjetaVagonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $catalogo = new catalogo_fallas_tarjeta_vagon;

       return view('app.vagones.taller.catalogoTarjeta.create',compact('catalogo'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(catalogo_fallas_tarjeta_vagon::$rules);


        $request['usuario_crea'] = Auth::user()->name;

        $catalogo = catalogo_fallas_tarjeta_vagon::create($request->all());
       
        $taller = VagonTaller::whereId($request['taller_id'])->first();
        $taller->catalogo_fallas_id = $request['taller_id'];
        $taller->save();

        return redirect()->route('taller.index')
            ->with('success', 'catalogo_fallas_tarjeta created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\catalogo_fallas_tarjeta_vagon  $catalogo_fallas_tarjeta_vagon
     * @return \Illuminate\Http\Response
     */
    public function show(catalogo_fallas_tarjeta_vagon $catalogo_fallas_tarjeta_vagon)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\catalogo_fallas_tarjeta_vagon  $catalogo_fallas_tarjeta_vagon
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $catalogo = catalogo_fallas_tarjeta_vagon::editarTarjeta($id)->first();

        return view('app.vagones.taller.catalogoTarjeta.edit', compact('catalogo'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\catalogo_fallas_tarjeta_vagon  $catalogo_fallas_tarjeta_vagon
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, catalogo_fallas_tarjeta_vagon $catalogo_fallas_tarjetum)
    {
        request()->validate(catalogo_fallas_tarjeta_vagon::$rules);

        $request['usuario_actualiza'] = Auth::user()->name; 

        $catalogo_fallas_tarjetum->update($request->all());

        return redirect()->route('taller.index')
            ->with('success', 'catalogo_fallas_tarjeta_vagon updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\catalogo_fallas_tarjeta_vagon  $catalogo_fallas_tarjeta_vagon
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, catalogo_fallas_tarjeta_vagon $catalogo_fallas_tarjetum)
    { 
        try{
            DB::beginTransaction();

        $taller = VagonTaller::where('catalogo_fallas_id',$catalogo_fallas_tarjetum->taller_id)->first();
        $taller->catalogo_fallas_id = null;
        $taller->save();

        $catalogo = catalogo_fallas_tarjeta_vagon::find($catalogo_fallas_tarjetum->id)->delete();

        DB::commit();

        return redirect()->route('taller.index')
            ->with('success', 'catalogo_fallas_tarjeta_vagon deleted successfully');
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'Ha Ocurrido un error'); 
        }
    }
}
