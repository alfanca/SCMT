<?php

namespace App\Http\Controllers;

use App\Models\RegistroPasante;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

/**
 * Class RegistroPasanteController
 * @package App\Http\Controllers
 */
class RegistroPasanteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $anho = $request['anho'] ?? date('Y');

        $anhoActual = date('Y');

        $registrodepasantes = RegistroPasante::dataindex($anho);


        return view('app.gestion.registro-pasante.index', compact('registrodepasantes', 'anho', 'anhoActual'))
            ->with('i');
    }


    public function ferronotificacionriesgo($id)
    {
        $registroPasantes = RegistroPasante::find($id);

        return view('app.gestion.registro-pasante.F-5841', compact('registroPasantes'));
    }

     public function ferronotificacionriesgoexcelente($id)
    {
        $registroPasante = RegistroPasante::find($id);

        return view('app.gestion.registro-pasante.F-5477-EXCELENTE', compact('registroPasante'));
    }

    public function ferroevaluacionpasantebueno($id)
    {
        $registroPasante = RegistroPasante::find($id);

        return view('app.gestion.registro-pasante.F-5477-BUENO', compact('registroPasante'));
    }

    public function ferroevaluacionpasantemuybueno($id)
    {
        $registroPasante = RegistroPasante::find($id);

        return view('app.gestion.registro-pasante.F-5477-MUYBUENO', compact('registroPasante'));
    }

    public function ferroevaluacionpasanteregular($id)
    {
        $registroPasante = RegistroPasante::find($id);

        return view('app.gestion.registro-pasante.F-5477-REGULAR', compact('registroPasante'));
    }

    public function ferroevaluacionpasantedeficiente($id)
    {
        $registroPasante = RegistroPasante::find($id);

        return view('app.gestion.registro-pasante.F-5477-DEFICIENTE', compact('registroPasante'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $registroPasante = new RegistroPasante();
        $gerencia = collect(RegistroPasante::GERENCIA);
        $unidad = collect(RegistroPasante::UNIDAD);
        $division = collect(RegistroPasante::DIVISION);
        $cargo = collect(RegistroPasante::CARGO);
        $universidad = collect(RegistroPasante::UNIVERSIDAD);
        $especialidad = collect(RegistroPasante::ESPECIALIDAD);
        return view('app.gestion.registro-pasante.create', compact('registroPasante', 'gerencia', 'unidad', 'division', 'cargo', 'universidad', 'especialidad'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(RegistroPasante::$rules);


        $request['usuario_crea'] = Auth::user()->name;
        $registroPasante = RegistroPasante::create($request->all());

        return redirect()->route('registrodepasantes.index')
            ->with('success', 'RegistroPasante created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $registroPasante = RegistroPasante::find($id);

        return view('app.gestion.registro-pasante.show', compact('registroPasante'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $registroPasante = RegistroPasante::find($id);
        $gerencia = collect(RegistroPasante::GERENCIA);
        $unidad = collect(RegistroPasante::UNIDAD);
        $division = collect(RegistroPasante::DIVISION);
        $cargo = collect(RegistroPasante::CARGO);
        $universidad = collect(RegistroPasante::UNIVERSIDAD);
        $especialidad = collect(RegistroPasante::ESPECIALIDAD);
        $evaluacion = collect(RegistroPasante::EVALUACION);

        return view('app.gestion.registro-pasante.edit', compact('registroPasante', 'gerencia', 'unidad', 'division', 'cargo', 'universidad', 'especialidad', 'evaluacion'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  RegistroPasante $registroPasante
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RegistroPasante $registrodepasante)
    {
        request()->validate(RegistroPasante::$rules);

        $request['usuario_actualiza'] = Auth::user()->name;
        $registrodepasante->update($request->all());

        return redirect()->route('registrodepasantes.index')
            ->with('success', 'RegistroPasante updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $registroPasante = RegistroPasante::find($id)->delete();

        return redirect()->route('registrodepasantes.index')
            ->with('success', 'RegistroPasante deleted successfully');
    }
}
