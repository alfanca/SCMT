<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

use App\Clases\Turno;
use App\Clases\Fechas;

use App\Models\Nota;

class NotaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $nota = new Nota;

        return view('app.notas.create', 
                array('area' => $request['area'], 'retorno' => $this->retorno($request['area']),
                    'turno' => $request['turno'], 'fecha' => $request['fecha'], 'nota'=>$nota));
    }

    private function retorno($area){
        return ($area === 'locomotoras' ? 'disponibilidad.index' : 'vagones_disponibilidad_o.index');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datos = $this->validaData($request);
        $datos['usuario_crea'] = Auth::user()->name;
        Nota::create($datos);
        $retorno = $this->retorno($datos['area']);

        return redirect(route($retorno))->with('success', 'Creada con exito');
    }

    public function validaData($request){
        return $request->validate([
            'turno' => ['required'],
            'nota' => ['required'],
            'area' => ['required'],
            'fecha' => ['required']
        ]);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Nota $notum)
    {
        return view('app.notas.edit', array('nota'=> $notum, 'retorno' => $this->retorno($notum->area)));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Nota $notum)
    {
        $datos = $this->validaData($request);
        $datos['usuario_actualiza'] = Auth::user()->name;
        $notum->update($datos);
         $retorno = $this->retorno($datos['area']);
         return redirect(route($retorno))->with('success', 'Creada con exito');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Nota $notum)
    {
        $notum->usuario_elimina = Auth::user()->name;
        $notum->save();
        $notum->delete();
        $retorno = $this->retorno($notum->area);

        return redirect(route($retorno))->with('success', 'Eliminado con exito');
    }
}
