<?php

namespace App\Http\Controllers;


use App\Clases\Turno;
use App\Clases\Fechas;

use App\Models\Actividad;
use App\Models\ActividadVagon;
use App\Models\Vagones;
use App\Models\Equipo_apoyo;

use App\Models\Locomotora;
use App\Models\Reportedelocomotora;
use App\Models\LocomotoraActividad;
use App\Models\LocomotoraConsumo;
use App\Models\LocomotoraDisponibilidad;

use App\Models\VagonDisponibilidadOperativa;

use App\Models\senales_equipos;

use App\Models\equipoferroviarios;
use App\Models\perfilvelocidad;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        //Señales (Equipos)//

        $señalesequipos = senales_equipos::disponibilidadhome();
        $señalesequiposhome = ($señalesequipos->where('estatus', 'Disponible')->count())+($señalesequipos->where('estatus', 'Parcialmente')->count());
        $disponibilidadoperativahome = $señalesequipos->where('estatus', 'Disponible')->count();
        $total = $señalesequipos->count();
        $ultimoregistro = senales_equipos::ultimoregistro()->last();


        //Locomotoras//

        $ultimoTurnoLocomotoraDisponibilidad = LocomotoraDisponibilidad::verUltimoTurnoCargado();
        $locomotoraDisponibilidad = LocomotoraDisponibilidad::verUltimaDisponibilidadCargada($ultimoTurnoLocomotoraDisponibilidad->fecha, $ultimoTurnoLocomotoraDisponibilidad->turno);

        //Vagones y Equipos de Apoyo//

        $ultimoTurnoVagonesDisponibilidadOperativa = VagonDisponibilidadOperativa::verUltimoTurnoCargado();
        $vagonesDisponibilidadOperativa = VagonDisponibilidadOperativa::verUltimaDisponibilidadCargada($ultimoTurnoVagonesDisponibilidadOperativa->fecha, $ultimoTurnoVagonesDisponibilidadOperativa->turno);

        $gondolasDisponible = $vagonesDisponibilidadOperativa->where('tipo_vagon', 'gondola')->first()['cantidad'] ?? 0;
        $tolvasDisponible = $vagonesDisponibilidadOperativa->where('tipo_vagon', 'tolva')->first()['cantidad'] ?? 0;
        $totalDisponible = $gondolasDisponible + $tolvasDisponible;
        $hoy = date('Y-m-d');

        $conteoVagonesGondolas = Vagones::dashboardvagonesconteo()
                  ->where('tipo','Gondola')
                  ->where('ultima_ubicacion', '!=','DESCONOCIDA')
                  ->whereNotIn('ultima_ubicacion', ['TALLER DE VAGONES','LINEA 4', 'DESCONOCIDA','DESINCORPORADO', 'DESCARRILADO'])
                  ->count();

        $conteoVagonesTolvas = Vagones::dashboardvagonesconteo()
                  ->where('tipo','Tolva')
                  ->whereNotIn('ultima_ubicacion',['TALLER DE VAGONES','LINEA 4','DESINCORPORADO','DESCARRILADO'])
                  ->count();


        $equiposApoyo = Equipo_apoyo::all();
        $dispEquipoApoyo = $equiposApoyo ->where('estatus', '=', 'Disponible')->count();
        $fueradeServicio = $equiposApoyo ->where('estatus', '=', 'Fuera de Servicio')->count();
        $totalEquipoApoyo = Equipo_apoyo::all()->count();
        $ultimoregistroeqpoyoyo = perfilvelocidad::ultimoregistro()->last();


        //Actividades Areas//

        $listadoActividadesLocomotora = Reportedelocomotora::getAllCorrectivoHome();
        //$listadoActividadesLocomotora = LocomotoraActividad::listarActidades()->fecha($hoy)->get()->sortBy('turno');
        $listadoActividadesVagones = ActividadVagon::listarActidades()->fecha($hoy)->get()->sortBy('turno');
        $listadoActividadesVia = Actividad::listarActidades()->fecha($hoy)->via()->get()->sortBy('turno');
        $listadoActividadesSeñales = Actividad::listarActidades()->fecha($hoy)->señales()->get()->sortBy('turno');

        //Consumibles de Locomotoras//

        $locomotoraConsumoMensual = LocomotoraConsumo::getConsumoPorMes(date('m'));
        $ultimoregistroConsumo = LocomotoraConsumo::ultimoregistroConsumo()->last();


        //Vias y Equipos Ferroviarios//

        $perfilvelocidad = perfilvelocidad::dashboard();
        $reduccioneshome = round(((73.2-($perfilvelocidad ->pluck('total')->sum()))/73.2)*100);
  
        $eqferroviarios = equipoferroviarios::getAll();
        $eqferroviarioshome = round((($eqferroviarios->pluck('real')->sum())/$eqferroviarios->pluck('cantidad')->sum())*100);

        $perfilvelocidadhome = round((((732-$perfilvelocidad->pluck('resto')->sum())*45)+($perfilvelocidad->pluck('kmtotal')->sum()))/732);

        $ultimoregistrovs = perfilvelocidad::ultimoregistro()->last();

       

        return view('dashboard', compact('locomotoraDisponibilidad', 
                        'gondolasDisponible', 'tolvasDisponible', 'totalDisponible',
                        'locomotoraConsumoMensual',
                        'listadoActividadesLocomotora',
                        'listadoActividadesVagones',
                        'listadoActividadesSeñales',
                        'ultimoregistro',
                        'listadoActividadesVia',
                        'señalesequipos',
                        'total',
                        'reduccioneshome',
                        'eqferroviarioshome',
                        'ultimoregistroConsumo',
                        'perfilvelocidadhome',
                        'señalesequiposhome',
                        'ultimoregistrovs',
                        'disponibilidadoperativahome',
                        'ultimoTurnoVagonesDisponibilidadOperativa',
                        'conteoVagonesGondolas',
                        'conteoVagonesTolvas',
                        'dispEquipoApoyo',
                        'fueradeServicio',
                        'ultimoregistroeqpoyoyo',
                        'totalEquipoApoyo', 
                        'ultimoTurnoLocomotoraDisponibilidad'));
    }
}
