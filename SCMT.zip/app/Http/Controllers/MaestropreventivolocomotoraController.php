<?php

namespace App\Http\Controllers;

use App\Models\Maestropreventivolocomotora;
use App\Models\Detallepreventivolocomotora;
use App\Models\Reportedelocomotora;
use App\Models\Locomotora;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Class MaestropreventivolocomotoraController
 * @package App\Http\Controllers
 */
class MaestropreventivolocomotoraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $maestropreventivolocomotorasfiltro = Maestropreventivolocomotora::programasindex()->sortBy('fecha_inicio');
        $maestropreventivolocomotorasconteo = Maestropreventivolocomotora::programasindexconteo()->where('fecha_reprogramacion', null)->count();
        $maestropreventivolocomotorasconteoreprogramado = Maestropreventivolocomotora::programasindexconteo()->where('fecha_reprogramacion', '!=', null)->count();
        $detallespreventivosportada = Detallepreventivolocomotora::getcumplimientoportada();
        $detallespreventivos = Detallepreventivolocomotora::getcumplimiento();

        $programasfechatope = Maestropreventivolocomotora::programatope();

        $conteoreprogramacion = $maestropreventivolocomotorasfiltro ->where('fecha_reprogramacion', '!=', null)->count();

        $conteonota = $maestropreventivolocomotorasfiltro ->where('nota', '!=', null)->count();

        return view('app.locomotora.maestropreventivolocomotora.index', compact('maestropreventivolocomotoras', 'detallespreventivos','maestropreventivolocomotorasfiltro', 'detallespreventivosportada', 'programasfechatope', 'maestropreventivolocomotorasconteo', 'conteoreprogramacion', 'conteonota', 'maestropreventivolocomotorasconteoreprogramado'))
            ->with('i');
    }


     public function ferroprograma($id)
    {
        $maestropreventivolocomotora = Maestropreventivolocomotora::find($id);
        $detallespreventivos = Detallepreventivolocomotora::detallecumplimiento()->where('maestropreventivo_id', $id);
       
        $sumadecumplimiento = $detallespreventivos->pluck('cumplimiento')->sum();

        $conteocumplimiento = $detallespreventivos->pluck('cumplimiento')->count();

        return view('app.locomotora.maestropreventivolocomotora.f_programa', compact('maestropreventivolocomotora', 'detallespreventivos', 'sumadecumplimiento', 'conteocumplimiento'));
    }

     public function ferroreprogramacion($id)
    {
        $maestropreventivolocomotora = Maestropreventivolocomotora::find($id);

        return view('app.locomotora.maestropreventivolocomotora.F-5331', compact('maestropreventivolocomotora'));
    }

    public function periodoprograma(Request $request)
    {
        $locomotoras = Locomotora::listadoLocomotorasSelect()->where('numero', '!=','S/N')->pluck('numero', 'id');
        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];
        $locomotora = $request['locomotora_id'] ?? null;
        $programa_all = Maestropreventivolocomotora::getAllXPeriodo($fechas, $locomotora)->orderBy('fecha_inicio')->get();
        $cantidadinspecciones = Detallepreventivolocomotora::getcumplimientofecha($fechas)->count();
        $cantidadreprogramaciones = $programa_all->where('fecha_reprogramacion', '!=', null)->count();
        $cumplimientosuma = Detallepreventivolocomotora::getcumplimientofecha($fechas)->pluck('cumplimiento')->sum();
        if ($cantidadinspecciones == '0') {
            $cumplimientototal = 0;
        }
        else{
        $cumplimientototal = round($cumplimientosuma/$cantidadinspecciones);
        }
        $detallespreventivos = Detallepreventivolocomotora::getcumplimiento();

        $conteoreprogramacion = $programa_all ->where('fecha_reprogramacion', '!=', null)->count();

        $conteonota = $programa_all ->where('nota', '!=', null)->count();

        $cantidaddeProgramciones = $programa_all ->where('fecha_reprogramacion', null)->count();
    
        return view('app.locomotora.maestropreventivolocomotora.vista_all', compact('programa_all', 'fechas', 'locomotoras', 'locomotora', 'detallespreventivos', 'cantidadinspecciones', 'cumplimientototal', 'conteoreprogramacion', 'conteonota', 'cantidadreprogramaciones', 'cantidaddeProgramciones'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $maestropreventivolocomotora = new Maestropreventivolocomotora();
        $locomotoras = Locomotora::listadoLocomotorasSelectProgramas()->where('numero', '!=','S/N')->where('mant', '!=', null)->pluck('numero', 'id');
        return view('app.locomotora.maestropreventivolocomotora.create', compact('maestropreventivolocomotora', 'locomotoras', 'estatus'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(Maestropreventivolocomotora::$rules);

        $request['estatus'] = '0';
        $request['usuario_crea'] = Auth::user()->name;
        $maestropreventivolocomotora = Maestropreventivolocomotora::create($request->all());

        return redirect()->route('maestropreventivolocomotora.index')
            ->with('success', 'Maestropreventivolocomotora created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $maestropreventivolocomotora = Maestropreventivolocomotora::with(['datosPlanificador', 'datosjefePlanificador', 'datosTallerLoc', 'datosTallerVag' ])->find($id);
        $detallespreventivos = Detallepreventivolocomotora::detallecumplimiento()->where('maestropreventivo_id', $id);
       
        $sumadecumplimiento = $detallespreventivos->pluck('cumplimiento')->sum();

        $conteocumplimiento = $detallespreventivos->pluck('cumplimiento')->count();


        return view('app.locomotora.maestropreventivolocomotora.show', compact('maestropreventivolocomotora', 'detallespreventivos', 'sumadecumplimiento', 'conteocumplimiento'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $maestropreventivolocomotora = Maestropreventivolocomotora::find($id);
        $locomotoras = Locomotora::listadoLocomotorasSelect()->where('numero', '!=','S/N')->pluck('numero', 'id');
        $estatus = collect(Maestropreventivolocomotora::ESTATUS);

        return view('app.locomotora.maestropreventivolocomotora.edit', compact('maestropreventivolocomotora', 'locomotoras', 'estatus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Maestropreventivolocomotora $maestropreventivolocomotora
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Maestropreventivolocomotora $maestropreventivolocomotora)
    {
        request()->validate(Maestropreventivolocomotora::$rules);

        if (!empty($request['fecha_reprogramacion'])) {
             $request['fecha_r_realizada'] = now(); 
             $request['usuario_actualiza'] = Auth::user()->name; 
             $maestropreventivolocomotora->update($request->all());
        }
        else{
        $request['usuario_actualiza'] = Auth::user()->name; 
        $maestropreventivolocomotora->update($request->all());
         }
  
        return redirect()->route('maestropreventivolocomotora.index')
            ->with('success', 'Maestropreventivolocomotora updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $maestropreventivolocomotora = Maestropreventivolocomotora::find($id)->delete();

        return redirect()->route('maestropreventivolocomotora.index')
            ->with('success', 'Maestropreventivolocomotora deleted successfully');
    }
}
