<?php

namespace App\Http\Controllers;

use App\Models\ProgramaVium;
use App\Models\ProgramaDetalleVium;
use App\Models\ProgramaActiviadesVium;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

/**
 * Class ProgramaViumController
 * @package App\Http\Controllers
 */
class ProgramaViumController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $programaVia = ProgramaVium::getAll();

        return view('app.via.programa-vium.index', compact('programaVia'))
            ->with('i');
    }

    public function ProgramaHistorico(request $request)
    {

        $fechasInicio = $request['fecha_inicio'] ?? date('Y-m-d');
        $fechasFin = $request['fecha_fin'] ?? date('Y-m-d');
        $fechas = [$fechasInicio, $fechasFin];

        $programaVia = ProgramaVium::getAllXPeriodo($fechas)->orderBy('fecha_inicio')->get();

        return view('app.via.programa-vium.historico', compact('programaVia'))
            ->with('i');
    }


    public function ferroprograma($id)
    {
        $programaVium = ProgramaVium::find($id);

        $programaActividades = ProgramaActiviadesVium::detalleprogramacumplimiento($id);

        $programaDetalleVia = ProgramaDetalleVium::detalleprogramacumplimiento($id);

        return view('app.via.programa-vium.ferroprogramas', compact('programaVium', 'programaDetalleVia', 'programaActividades'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programaVium = new ProgramaVium();
        return view('app.via.programa-vium.create', compact('programaVium'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramaVium::$rules);

        $request['estatus'] = 'LIBERADA';
        $request['usuario_crea'] = Auth::user()->name;

        $programaVium = ProgramaVium::create($request->all());

        return redirect()->route('programavias.index')
            ->with('success', 'ProgramaVium created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programaVium = ProgramaVium::find($id);

        $programaActividades = ProgramaActiviadesVium::detalleprogramacumplimiento($id);

        $programaDetalleVia = ProgramaDetalleVium::detalleprogramacumplimiento($id);

        return view('app.via.programa-vium.show', compact('programaVium', 'programaDetalleVia', 'programaActividades'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programaVium = ProgramaVium::find($id);
        $estatus = ProgramaVium::estatus();

        return view('app.via.programa-vium.edit', compact('programaVium', 'estatus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramaVium $programaVium
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramaVium $programavia)
    {
        request()->validate(ProgramaVium::$rules);

        $request['usuario_actualiza'] = Auth::user()->name;

        $programavia->update($request->all());

        return redirect()->route('programavias.index')
            ->with('success', 'ProgramaVium updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        
        $programaDetalleVia = ProgramaDetalleVium::detalleprogramacumplimiento($id)->count();

        try{
            DB::beginTransaction();

        if ($programaDetalleVia == 0) {
           
        $programaVium = ProgramaVium::find($id)->delete();

        }

        else{

            return redirect()->back()
            ->with('error', 'No se Puede Borrar por que hay inspecciones asociadas a este Programa'); 
        }

        DB::commit();
           return redirect()->route('programavias.index')
            ->with('success', 'ProgramaDetalleVium deleted successfully.');    
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()
            ->with('error', 'No se Puede Borrar por que el Programa esta siendo usado en las actividades de Vias'); 
        }
    }
}
