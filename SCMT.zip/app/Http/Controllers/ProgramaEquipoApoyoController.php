<?php

namespace App\Http\Controllers;

use App\Models\ProgramaEquipoApoyo;
use App\Models\ProgramaEquipoApoyoDetalle;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ProgramaEquipoApoyoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $programas = ProgramaEquipoApoyo::Getall();

        $cantidadDetallesprogramasenales = ProgramaEquipoApoyoDetalle::detalleprogramaDetalleAnual()->count();

        $cumplimientoDetallesProgramas = ProgramaEquipoApoyoDetalle::detalleprogramaDetalleAnual()->sum('cumplimiento');

        if (!empty($cantidadDetallesprogramasenales)) {
            
            $porcentajeCumplimiento = $cumplimientoDetallesProgramas / $cantidadDetallesprogramasenales;
        }
        else{

            $porcentajeCumplimiento = 0;
        }

        $cantidadDeProgramas = ProgramaEquipoApoyo::anualProgramas()->count();

        //Corregir por ID del Programa ID Mejorar la Estabilidad

        $detallesprogramasenales = ProgramaEquipoApoyoDetalle::detalleprogramaEqApoyo();

        //

        return view('app.vagones.equipo_apoyo.mantenimiento_Programas.index', compact('programas', 'cantidadDeProgramas', 'cantidadDetallesprogramasenales', 'porcentajeCumplimiento', 'detallesprogramasenales'));
    }


    public function ferroprogramaApoyo($id)
    {
        $programaApoyo = ProgramaEquipoApoyo::find($id);

        $detallesprogramaApoyo = ProgramaEquipoApoyoDetalle::detalleprogramacumplimiento($id);


        return view('app.vagones.equipo_apoyo.mantenimiento_Programas.ferroprogramaApoyo', compact('programaApoyo', 'detallesprogramaApoyo'));
    }


    public function programasBusqueda(Request $request)
    {
        
        $semanaInicio = $request['semana_inicio'];
        $semanaFin = $request['semana_fin'];
        $fechas = [$semanaInicio, $semanaFin];
        $ano = $request['ano'];

        $programasBusqueda = ProgramaEquipoApoyo::getAllXPeriodo($fechas, $ano)->orderBy('programa')->get();

        $cantidadDeProgramas = $programasBusqueda->count();

        $cantidadDetallesprogramasenales = ProgramaEquipoApoyoDetalle::detalleprogramaDetalleAnual()->count();

        $cumplimientoDetallesProgramas = ProgramaEquipoApoyoDetalle::detalleprogramaDetalleAnual()->sum('cumplimiento');

        if (!empty($cantidadDetallesprogramasenales)) {
            
            $porcentajeCumplimiento = $cumplimientoDetallesProgramas / $cantidadDetallesprogramasenales;
        }
        else{

            $porcentajeCumplimiento = 0;
        }

        $detallesprogramasenales = ProgramaEquipoApoyoDetalle::detalleprogramaEqApoyo();


        return view('app.vagones.equipo_apoyo.mantenimiento_Programas.vista_all', compact('programasBusqueda', 'fechas', 'ano', 'cantidadDeProgramas', 'cantidadDetallesprogramasenales', 'porcentajeCumplimiento', 'detallesprogramasenales'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programa = new ProgramaEquipoApoyo;
        return view('app.vagones.equipo_apoyo.mantenimiento_Programas.create',compact('programa'));     
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramaEquipoApoyo::$rules);

        $request['estatus'] = 'LIBERADA';
        $request['usuario_crea'] = Auth::user()->name;
        $programa = ProgramaEquipoApoyo::create($request->all());

        return redirect()->route('programaEquipoApoyo.index')
            ->with('success', 'ProgramaEquipoApoyo created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProgramaEquipoApoyo  $programaEquipoApoyo
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $programa = ProgramaEquipoApoyo::find($id);

        $detallesprogramasenales = ProgramaEquipoApoyoDetalle::detalleprogramacumplimiento($id);

        $sumaCumplimiento = $detallesprogramasenales ->sum('cumplimiento');

        $conteoCumplimiento = $detallesprogramasenales ->count();

        if (!empty($conteoCumplimiento)) {
            
            $cumplimientoTotal = $sumaCumplimiento / $conteoCumplimiento;
        }
        else{

            $cumplimientoTotal = 0;

        }
        

        return view('app.vagones.equipo_apoyo.mantenimiento_Programas.show', compact('programa', 'detallesprogramasenales', 'cumplimientoTotal'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProgramaEquipoApoyo  $programaEquipoApoyo
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

       $programa = ProgramaEquipoApoyo::find($id);

       return view('app.vagones.equipo_apoyo.mantenimiento_Programas.edit', compact('programa'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProgramaEquipoApoyo  $programaEquipoApoyo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramaEquipoApoyo $programaEquipoApoyo)
    {
        request()->validate(ProgramaEquipoApoyo::$rules);
        
        $request['usuario_actualiza'] = Auth::user()->name; 
        $programaEquipoApoyo->update($request->all());

        return redirect()->route('programaEquipoApoyo.index')
            ->with('success', 'ProgramaEquipoApoyo updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProgramaEquipoApoyo  $programaEquipoApoyo
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $programa = ProgramaEquipoApoyo::find($id)->delete();

        return redirect()->route('programaEquipoApoyo.index')
            ->with('success', 'ProgramaEquipoApoyo deleted successfully');
    }
}
