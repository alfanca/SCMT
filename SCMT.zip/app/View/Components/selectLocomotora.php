<?php

namespace App\View\Components;

use Illuminate\View\Component;

use App\Models\Locomotora;

class selectLocomotora extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */

    public $listadoLocomotoras;
    public $selected;
    public $datos


    public function __construct($selected = null, $listadoLocomotoras)
    {
        $this->selected = $selected;
        $this->listadoLocomotoras = $listadoLocomotoras;
    }

    public function isSelected($option)
    {
        return $option === $this->selected;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.select-locomotora');
    }
}
