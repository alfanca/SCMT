<div class="card-group col-12 text-center mx-5">
		<label class="col-form-label">{{ __('SEM INICIO:') }}&nbsp</label>

	        <input type="number" class="form-control text-center" min="1" id="semana_inicio" name="semana_inicio" value="{{$fechas['semana_inicio'] ?? ''}}"/>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp


		<label class="col-form-label">{{ __('SEM FIN:') }}&nbsp</label>

	        <input type="number" class="form-control text-center" min="1" id="semana_fin" name="semana_fin" value="{{$fechas['semana_fin']  ?? ''}}"/>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp


    <label class="col-form-label">{{ __('AÑO:') }}&nbsp</label>

          <input type="number" class="form-control text-center" min="2000" id="ano" name="ano" value="{{$fechas['ano']  ?? ''}}"/>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp


    <button type="submit" class="btn btn-primary">Buscar</button>

</div>
