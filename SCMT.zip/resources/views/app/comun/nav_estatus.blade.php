<form id="form">
  <div class="text-center">
    <div class="form-group">
        <div class="col-md-12">
          Consultar Estatus:&nbsp&nbsp 
            <select class= "custom-select" id="estatus" name="estatus" style="width:12%" onchange="this.form.submit()">

                  <option value="" selected="">SELECCIONAR</option>

                  <option value="ABIERTA">ABIERTA</option>

                  <option value="CERRADA">CERRADA</option>

              </select>
        </div>
    </div>
  </div>
</form>