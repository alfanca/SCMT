<div class="row col-md-12 mx-5">
		<label class="col-form-label">{{ __('FECHA INICIO') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control text-center"  id="fecha_inicio" type="text" name="fecha_inicio" value="{{$fechas['fecha_inicio'] ?? ''}}"/>
	   	</div>

		<label class="col-form-label">{{ __('FECHA FIN') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control text-center"  id="fecha_fin" type="text" name="fecha_fin" value="{{$fechas['fecha_fin']  ?? ''}}"/>
	   	</div>


          <div class="row justify-content col-4">

            <label class="col-form-label">{{ __('N° Vagon') }}</label>
            <div class="col-md-8">
              <div class="form-group{{ $errors->has('vagon_id') ? ' has-danger' : '' }} text-center">
                <select name="vagon_id" class="vagones_poruno" style="width: 100%;">
                  @if (!empty($vagonconsumo->vagon_id))
                    <option value="{{$vagonconsumo->vagon_id}}">{{ $vagonconsumo->vagon_id}}</option>
                  @endif
                </select>
                @if ($errors->has('vagon_id'))
                  <span id="name-error" class="error text-danger" for="input-vagon_id">{{ $errors->first('vagon_id') }}</span>
                @endif
              </div>
            </div>

            <div class="col-md-1">
              <button type="submit" class="btn btn-primary">Buscar</button>
            </div>
          </div>

</div>
