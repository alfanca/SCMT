<div class="row">
	<div class="col-sm-4">
		<a class="btn btn-sm btn-primary btn-rounded" href="/{{$url}}{{$fechas['diaanterior']}}" style="background-image: linear-gradient(to right, #6a1816,#d2091d); border-radius: 10px;">
	 		<b> Anterior / {{\Carbon\Carbon::parse($fechas['diaanterior'])->format('d-m')}}</b>
		</a>
	</div>

	<div class="col-sm-4 centered text-center">
		<h4 style="text-transform: uppercase; font-weight: normal;">{{\Carbon\Carbon::parse($fechas['fechaAListar'])->isoFormat('dddd DD-MM-YYYY')}}</h4>
	</div>

  @if (isset($fechas['diaPosterior']))
	<div class="col-sm-4 text-right">
		<a class="btn btn-sm btn-primary btn-rounded" href="/{{$url}}{{$fechas['diaPosterior']}}" style="background-image: linear-gradient(to right, #6a1816,#d2091d); border-radius: 10px;">
			<b>Siguiente / {{\Carbon\Carbon::parse($fechas['diaPosterior'])->format('d-m')}}</b>
		</a>
	</div>
  @endif
</div>

