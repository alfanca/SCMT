<div class="row">
		<label class="col-form-label">{{ __('FECHA INICIO') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control"  id="fecha_inicio" type="text" name="fecha_inicio" value="{{$fechas['fecha_inicio'] ?? ''}}"/>
	   	</div>

		<label class="col-form-label">{{ __('FECHA FIN') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control"  id="fecha_fin" type="text" name="fecha_fin" value="{{$fechas['fecha_fin']  ?? ''}}"/>
	   	</div>

               <div class="row justify-content">
               <label class="col-form-label col-md-7 text-center ">{{ __('SELECCIONAR TRAMO') }}</label>


              <select  onchange="buscarDetalleFormulario('formBusqueda', this.value)"
                            class="custom-select col-md-5" name="tramo" id="input-tramo">
              <option value="">SELECCIONE</option>
              @foreach($tramoselector as $tramo)
                <option value="{{$tramo}}">{{$tramo}}</option>
              @endforeach
            </select>

          </div>
            <div class="col-md-2 text-center">
              <button type="submit" class="btn btn-primary">Buscar</button>
            </div>

</div>
