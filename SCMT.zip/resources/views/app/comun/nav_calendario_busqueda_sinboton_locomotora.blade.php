<div class="card-group col-12 mt-4 mx-5">
		<label class="col-form-label">{{ __('FECHA INICIO') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control text-center"  id="fecha_inicio" type="text" name="fecha_inicio" value="{{$fechas['fecha_inicio'] ?? ''}}"/>
	   	</div>

		<label class="col-form-label">{{ __('FECHA FIN') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control text-center"  id="fecha_fin" type="text" name="fecha_fin" value="{{$fechas['fecha_fin']  ?? ''}}"/>
	   	</div>

               <div class="row justify-content">
               <label class="col-form-label col-md-7 text-center ">{{ __('SELECCIONAR LOCOMOTORA') }}</label>


              <select  onchange="buscarDetalleFormulario('formBusqueda', this.value)"
                            class="custom-select col-md-5" name="locomotora_id" id="input-locomotora">
              <option value="">SELECCIONE</option>
              @foreach($locomotoras as $locomotora)
                <option value="{{$locomotora->id}}">{{$locomotora->numero}}</option>
              @endforeach
            </select>

          </div>
            <div class="col-md-2 text-center">
              <button type="submit" class="btn btn-primary">Buscar</button>
            </div>

</div>
