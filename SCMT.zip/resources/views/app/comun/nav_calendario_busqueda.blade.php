<div class="row col-md-12">
		<label class="col-md-3 col-form-label">{{ __('FECHA INICIO') }}</label>
	   	<div class="col-md-3">
	        <input type="date" class="form-control"  id="fecha_inicio" type="text" name="fecha_inicio" value="{{$fechas['fecha_inicio'] ?? ''}}"/>
	   	</div>

		<label class="col-md-2 col-form-label">{{ __('FECHA FIN') }}</label>
	   	<div class="col-md-3">
	        <input type="date" class="form-control"  id="fecha_fin" type="text" name="fecha_fin" value="{{$fechas['fecha_fin']  ?? ''}}"/>
	   	</div>
	   	<div class="col-md-1">
	   		<input type="submit" value="Buscar" class="btn btn-primary">
	   	</div>
</div>
