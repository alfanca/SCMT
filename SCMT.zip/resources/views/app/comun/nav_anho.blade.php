<form id="form">
  <div class="text-center">
    <div class="form-group">
        <div class="col-md-12">
          Año a Consultar:&nbsp&nbsp 
            <select class= "custom-select col-md-1" id="anho" name="anho" style="width:100%" onchange="this.form.submit()">
                @for ($anyo = 2022; $anyo <= $anhoActual; $anyo++)
                 @if($anyo == $anho) 
                  <option value="{{$anyo}}" selected="selected">{{$anyo}}</option>
                 @else
                  <option value="{{$anyo}}">{{$anyo}}</option>
                 @endif

                @endfor
              </select>
        </div>
    </div>
  </div>
</form>