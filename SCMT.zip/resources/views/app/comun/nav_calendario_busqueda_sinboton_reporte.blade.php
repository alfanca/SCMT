<div class="row col-md-12">
		<label class="col-form-label">{{ __('FECHA INICIO') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control text-center"  id="fecha_inicio" type="text" name="fecha_inicio" value="{{$fechas['fecha_inicio'] ?? ''}}"/>
	   	</div>

		<label class="col-form-label">{{ __('FECHA FIN') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control text-center"  id="fecha_fin" type="text" name="fecha_fin" value="{{$fechas['fecha_fin']  ?? ''}}"/>
	   	</div>


          <div class="row justify-content col-4">

            <label class="col-form-label col-md-7 text-center ">{{ __('N° LOCOMOTORA') }}</label>
            {{ Form::select('locomotora_id',$locomotoras, '', ['class' => 'form-control col-5 text-center' . ($errors->has('locomotora_id') ? ' is-invalid' : ''), 'placeholder' => 'SELECCIONE']) }}
            {!! $errors->first('locomotora_id', '<div class="invalid-feedback">:message</div>') !!}

          </div>
            <div class="col-md-2 text-center">
              <button type="submit" class="btn btn-primary">Buscar</button>
            </div>

</div>
