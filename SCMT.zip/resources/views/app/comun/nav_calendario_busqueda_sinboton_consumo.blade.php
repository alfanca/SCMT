<div class="row col-md-12">
		<label class="col-form-label">{{ __('FECHA INICIO') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control"  id="fecha_inicio" type="text" name="fecha_inicio" value="{{$fechas['fecha_inicio'] ?? ''}}"/>
	   	</div>

		<label class="col-form-label">{{ __('FECHA FIN') }}</label>
	   	<div class="col-md-2">
	        <input type="date" class="form-control"  id="fecha_fin" type="text" name="fecha_fin" value="{{$fechas['fecha_fin']  ?? ''}}"/>
	   	</div>


          <div class="row justify-content col-5">

            <label class="col-form-label col-md-6 text-center ">{{ __('SELECCIONAR TRAMO') }}</label>
            {{ Form::select('tramo', $tramoselector,'', ['class' => 'form-control col-6 text-center' . ($errors->has('tramo') ? ' is-invalid' : ''), 'placeholder' => 'SELECCIONAR']) }}

          </div>
            <div class="col-md-1 text-center">
              <button type="submit" class="btn btn-primary">Buscar</button>
            </div>

</div>
