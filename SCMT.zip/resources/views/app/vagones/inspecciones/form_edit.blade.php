<div class="card-body mb-4" style="text-align: left;">
	<div class="row d-flex justify-content-between">
	@foreach ($vagonesInspeccion->chunk(25) as $chunk)
    	<div class="col-xs-3 p-4">
    	<table class="table table-responsive table-bordered"> 
		<tr>
			<th>Orden</th>
			<th>N° Vagón</th>
			<th></th>
		</tr>
        @forelse ($chunk as $vagones)
		<tr id="vagones{{$vagones->id}}">
		<td class="text-center">{{$vagones->orden + 1}}</td>
			<td class="text-center">{{$vagones->vagones_id}}</td>
			@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
			<td>
				<a rel="tooltip" class="btn btn-danger btn-link btn-sm" title="Borrar" onclick="eliminarVagonInpseccion('{{$vagones->id}}', '{{Auth::user()->name}}')"> <i class="material-icons">delete</i></a>	
			</td>
			@endif 
		</tr>				
		@empty
		<tr id="vagones{{$vagones->id}}">
			<td colspan="2">No hay Vagones</td>
		</tr>
		@endforelse	
		</table>
		</div>

	@endforeach
    </div>
</div>
