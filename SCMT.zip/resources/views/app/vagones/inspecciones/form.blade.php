<div class="card-body mb-4" style="text-align: left;">
  <div class="row">
	  
	  <label class="col-md-2 col-form-label">{{ __('FECHA:') }}</label>
	  <div class="col-md-4">
	    <div class="form-group{{ $errors->has('hora_inicio') ? ' has-danger' : '' }}">
	      <input type="date" name="fecha" value="{{ old('fecha') ?? $inspeccion->fecha }}">   
	    @if ($errors->has('fecha'))
	      <span id="name-error" class="error text-danger" for="input-fecha">{{ $errors->first('fecha') }}</span>
	    @endif
	    </div>
	  </div>  

  <label class="col-md-2 col-form-label">{{ __('TREN') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('tren') ? ' has-danger' : '' }}">
    	<?php $tren = old('fecha') ?? $inspeccion->fecha ?>
      <select class="custom-select form-control{{ $errors->has('tren') ? ' is-invalid' : '' }}" name="tren" id="input-tren" placeholder="{{ __('Ingrese el tren') }}" required="true">

        <option value="">SELECCIONE</option>
        @foreach ($inspeccion->listadTrenesSelect() as $trenListado)
          <option value="{{$trenListado}}" {{$inspeccion->tren == $trenListado ? 'selected' : '' }}>{{$trenListado}}</option>
        @endforeach
      </select>
      @if ($errors->has('tren'))
        <span id="name-error" class="error text-danger" for="input-tren">{{ $errors->first('tren') }}</span>
      @endif
    </div>
  </div>

	</div>
  <div class="row">
	  <label class="col-md-2 col-form-label">{{ __('HORA ENTRADA/SALIDA:') }}</label>
	  <div class="col-md-4">
	    <div class="form-group{{ $errors->has('hora_salida') ? ' has-danger' : '' }}">
	      <input type="text" name="hora_salida" value="{{ old('hora_salida') ?? $inspeccion->hora_salida }}">   
	    @if ($errors->has('hora_salida'))
	      <span id="name-error" class="error text-danger" for="input-hora_salida">{{ $errors->first('hora_salida') }}</span>
	    @endif
	    </div>
	  </div>      
  </div>

  <div class="row">
	  <label class="col-md-2 col-form-label">{{ __('INSPECTOR') }}</label>
	  <div class="col-md-4">
	    <div class="form-group{{ $errors->has('ficha_inspector') ? ' has-danger' : '' }}">
		    <select name="ficha_inspector" class="responsable" style="width: 80%">
		      @if (!empty($inspeccion->inspector->nombre))
		        <option value="{{$inspeccion->ficha_inspector}}">{{ $inspeccion->inspector->nombre}}</option>
		      @endif
		    </select>
		    @if ($errors->has('ficha_inspector'))
		      <span id="name-error" class="error text-danger" for="input-ficha_inspector">{{ $errors->first('ficha_inspector') }}</span>
		    @endif
	    </div>
	  </div>

	  <label class="col-md-2 col-form-label">{{ __('N#. Y NOMBRE DE LÍNEA:') }}</label>
	  <div class="col-md-4">
	    <div class="form-group{{ $errors->has('n_linea') ? ' has-danger' : '' }}">
	      <input type="text" name="n_linea" value="{{ old('n_linea') ?? $inspeccion->n_linea }}">   
	    @if ($errors->has('n_linea'))
	      <span id="name-error" class="error text-danger" for="input-n_linea">{{ $errors->first('n_linea') }}</span>
	    @endif
	    </div>
	  </div>
  </div> <!-- fin fila -->

  <div class="row">
  	<label class="col-md-2 col-form-label">{{ __('VAGONES') }}</label>
	  <div class="col-md-10">
	    <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
		    <select name="vagones[]" class="vagones" multiple="multiple" style="width: 100%">
		      @if (!empty($inspeccion->datos->nombre))
		        <option value="{{$inspeccion->responsable}}">{{ $inspeccion->datos->nombre}}</option>
		      @endif
		    </select>
		    @if ($errors->has('responsable'))
		      <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
		    @endif
	    </div>
	  </div>
  </div>

  <div class="row">
	  <label class="col-md-2 col-form-label">{{ __('NOTA:') }}</label>
	  <div class="col-md-10">
	    <div class="form-group{{ $errors->has('nota') ? ' has-danger' : '' }}">
	      <input type="text" name="nota" value="{{ old('nota') ?? $inspeccion->nota }}" style="width: 100%">   
	    @if ($errors->has('nota'))
	      <span id="name-error" class="error text-danger" for="input-nota">{{ $errors->first('nota') }}</span>
	    @endif
	    </div>
	  </div>

</div> <!--fin card -->

  <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
  <script src="{{ asset('material') }}/js/plugins/moment.min.js"></script>
  <script src="{{ asset('material') }}/js/plugins/bootstrap-datetimepicker.min.js"></script>

  <script type="text/javascript">
$('.hora_inicio').datetimepicker({
    icons: {
        time: "fa fa-clock-o",
        date: "fa fa-calendar",
        up: "fa fa-chevron-up",
        down: "fa fa-chevron-down",
        previous: 'fa fa-chevron-left',
        next: 'fa fa-chevron-right',
        today: 'fa fa-screenshot',
        clear: 'fa fa-trash',
        close: 'fa fa-remove'
    },
    format: 'DD-MM-YYYY',
    maxDate : 'now',
    defaultDate: new Date(),
    useCurrent: true 
});
  </script>