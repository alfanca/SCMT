@extends('layouts.app', ['activePage' => 'vagon_inspeccion', 'titlePage' => __('Actualizar Vagon')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header card-header-primary">
              <h5 class="card-title">{{ __('ACTUALIZAR INSPECCION') }}</h5>
            </div>
            <form method="post" action="{{route('inspeccion.update', [$inspeccion->id])}}" autocomplete="off" class="form-horizontal">
              @csrf
              @method('patch')
              @include('app.vagones.inspecciones.form')
              
            <div class="col-md-12" align="center">
            <div class="card-footer justify-content-center">
            <a href="{{URL::previous()}}" class="btn btn-danger">{{ __('Volver') }}</a>
            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
              <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
              @endif 
            </div>
          </div>
          @include('app.vagones.inspecciones.form_edit')
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
