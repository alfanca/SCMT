@extends('layouts.app', ['activePage' => 'vagon_inspeccion', 'titlePage' => __('Registrar inspección de trenes')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <form method="post" action="{{route('inspeccion.store')}}" autocomplete="off" class="form-horizontal">
              @csrf

              @include('app.vagones.inspecciones.form')

              <div class="card-footer justify-content-center">
                <a href="{{route('inspeccion.index')}}" class="btn btn-danger">{{ __('Regresar') }}</a>
                  <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
              </div>
            </form>
          </div>
          <hr>
        </div>
      </div>
      </div>
  </div>
@endsection
