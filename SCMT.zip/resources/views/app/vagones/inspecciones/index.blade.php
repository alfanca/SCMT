@extends('layouts.app', ['activePage' => 'vagon_inspeccion', 'titlePage' => __('Disponibilidad Operativa de Vagones')])
@section('content')

<div class="content">
	<div class="container-fluid">
		@include('app.comun.nav_dias', 	['url'=> 'vagones/inspeccion/'])

        <div class="card-body text-center" style="font-weight: normal;" >INSPECCIÓN DE TRENES <br>
        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
        <a rel="tooltip" title="Agregar inspeccion  de vagones"
			              		href="{{route('inspeccion.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
	        		      			<i class="col-md-5">Crear + </i>
		            	 		</a> @endif 
        </div>                            

        <div class="row">
        @foreach($inspeccionesDia as $inspeccion)
        <div class="col-md-3">
            <div class="card">

                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-7">
                        <h5 class="card-title">{{$inspeccion->tren}}</h5>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam')|| Gate::check('isinvitado'))
                    <div class="col-md-5 mx-1 text-right">
                        <a rel="tooltip" title="Agregar inspeccion  de vagones"
                                href="{{route('inspeccion.edit', $inspeccion->id)}}" class="btn btn-sm btn-rounded text-right" style="background-color: #9B945F;">
                                     <i class="fa fa-fw fa-file-alt"></i>
                                </a>         
                        </div>
                      @endif
                    </div>


                <div class="card-body">
                    <div class="row"> 
                        <div class="col-md-6">Fecha:</div>
                        <div class="col-md-6">{{\Carbon\Carbon::parse($inspeccion->fecha)->format('d/m/Y')}}</div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">Hora salida:</div>
                        <div class="col-md-6">{{\Carbon\Carbon::parse($inspeccion->hora_salida)->format('d/m/Y H:i')}}</div>
                    </div>


                    <div class="row">
                        <div class="col-md-6">Inspector:</div>
                        <div class="col-md-6">{{$inspeccion->inspector->nombre}}</div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">Gondolas:</div>
                        <div class="col-md-6">{{$inspeccion->vagones->where('vagones_id', '<', 5000)->count()}}</div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">Tolvas:</div>
                        <div class="col-md-6">{{$inspeccion->vagones->where('vagones_id', '>=', 5000)->count()}}</div>
                    </div>
                    @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="row">
                        <div class="col-md-6">Creado:</div>
                        <div class="col-md-6">{{$inspeccion->usuario_c}}</div>
                    </div>
                    @if(!empty($inspeccion->usuario_a))
                    <div class="row">
                        <div class="col-md-6">Actualizado:</div>
                        <div class="col-md-6">{{$inspeccion->usuario_a}}</div>
                    </div>
                    @endif
                    @endif

                    @if(!empty($inspeccion->nota))
                    <div class="row mt-2">
                        <div class="col-md-12" style="text-transform: uppercase;"><strong style="font-weight: bold;">Nota:</strong> {{$inspeccion->nota}}</div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
        @endforeach
    </div>
    </div>
</div>
@endsection
