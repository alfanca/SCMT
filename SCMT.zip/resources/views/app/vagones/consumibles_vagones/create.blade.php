@extends('layouts.app', ['activePage' => 'consumovagones', 'titlePage' => __('Registrar Componentes de Vagones')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="card card-default">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Registrar Componentes</h4>
                      </div>

                      <div class="col-md-6" style="text-align: right;">

                        <a rel="tooltip" title="Ir al Taller de Vagones" 
                            href="{{ route('taller.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-cog"></i>
                        </a> 

                        @if(!empty($_GET['id_v']))
                        <a rel="tooltip" title="Agregar Medición de Rueda" 
                            href="{{ route('vagonesRuedas.create',['id_v'=>$_GET['id_v']]) }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fas fa-drafting-compass" style="font-size: 16px;"></i>
                        </a>
                        @else
                        <a rel="tooltip" title="Agregar Medición de Rueda" 
                            href="{{ route('vagonesRuedas.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fas fa-drafting-compass" style="font-size: 16px;"></i>
                        </a>
                        @endif

                        <a rel="tooltip" title="Ir a Consumo de Vagones" 
                            href="{{ route('consumoVagones.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-home"></i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>

                    <div class="card-body">
                        <form method="POST" action="{{ route('consumoVagones.store') }}"  role="form" enctype="multipart/form-data">
                            @csrf

                            @include('app.vagones.consumibles_vagones.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

