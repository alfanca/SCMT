@extends('layouts.app', ['activePage' => 'reportelocomotora', 'titlePage' => __('Historial de Consumo de Locomotora')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Historial de Consumo de Locomotoras</h4>
                        <p class="card-category">Busqueda de Consumo de Locomotora</p>
                      </div>
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{route('reportedelocomotoras.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i> Regresar
                        </a>  
                      </div>
                    </div>

            <div class="card-body">
             <div class="card-body">

           <form method="get" autocomplete="off" action="{{route('periodo.reporte.consumibles')}}" class="form-horizontal" role="form">
            @include('app.comun.nav_calendario_busqueda_sinboton_reporte')
           </form>

          
           </div>
             <div class="card-body">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-striped table-hover">
                                <thead class="thead">    
                                        <th class="text-center col-1">N° Orden</th>
                                        <th class="text-center">Fecha</th>
                                        <th class="text-center">N° Loc</th>
                                        <th class="text-center">N° SAP</th>
                                        <th class="text-center">N° Parte</th>
                                        <th class="text-center">Descripción</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Precio Unit</th>
                                        <th class="text-center">Precio Total</th>
                                </tr>
                                </thead>
                                <tbody>
                                    @forelse ($reporte_all as $consumiblelocomotora)
                                        <tr>
                                        <td class="text-center">{{$consumiblelocomotora->reportedelocomotora->n_orden}}</td>
                                        <td class="text-center">{{\Carbon\Carbon::parse($consumiblelocomotora->fecha)->format('d/m/Y')}}</td>
                                        <td class="text-center">{{$consumiblelocomotora->locomotora}}</td>
                                        <td class="text-center">{{$consumiblelocomotora->materiales->sap}}</td>
                                        <td class="text-center">{{$consumiblelocomotora->materiales->parte}}</td>
                                        <td>{{$consumiblelocomotora->materiales->descripcion}}</td>
                                        <td class="text-center">{{$consumiblelocomotora->cantidad}}</td>
                                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                        <td class="text-center">{{$consumiblelocomotora->preciounitario}}</td>
                                        <td class="text-center">{{($consumiblelocomotora->preciounitario)*$consumiblelocomotora->cantidad}}</td>
                                        @endif
                                        </tr>
                                        @empty
                                        <tr><td colspan="7">No hay registradas</td></tr>
                                 @endforelse
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Componentes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


@endsection
