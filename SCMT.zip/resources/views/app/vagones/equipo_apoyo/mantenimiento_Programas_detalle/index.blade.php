@extends('layouts.app', ['activePage' => 'eq_apoyo', 'titlePage' => __('Histórico de Programa Detallado de Equipos de Apoyo')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

              <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-7">
                <h4 class="card-title ">Inspecciones y Mantenimiento de Equipos de Apoyo (Histórico Detallado)</h4>
                <p class="card-category">Registro y Administración de Equipos de Apoyo "Detalle"</p>
              </div>
                <div class="col-md-5" style="text-align: right;">
                <a rel="tooltip" title="Regresar a Programas de Equipos de Apoyo"
                    href="{{route('programaEquipoApoyo.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="material-icons">reply</i> Regresar
                  
                </a>  
              </div>
            </div>

            <div class="card-body mt-3">

           <div class="row justify-content-center h-100">
           <form method="get" autocomplete="off" action="{{route('programaEquipoApoyoDetalle.index')}}" class="form-horizontal">
            <div class="row col-md-12">
            <label class="col-md-3 col-form-label">{{ __('FECHA INICIO') }}</label>
              <div class="col-md-3">
                  <input type="date" class="form-control"  id="fecha_inicio" type="text" name="fecha_inicio"/>
              </div>

            <label class="col-md-2 col-form-label">{{ __('FECHA FIN') }}</label>
              <div class="col-md-3">
                  <input type="date" class="form-control"  id="fecha_fin" type="text" name="fecha_fin"/>
              </div>
              <div class="col-md-1">
                <input type="submit" value="Buscar" class="btn btn-primary">
              </div>
        </div>
           </form>            
           </div>

           <br>

           <div class="card-group">

           <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545;border-top-left-radius: 10px;" >

                          <div class="text-center mt-4" style="font-size: 15px; margin-bottom: 20px; color: white;">ZPM2</div>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Cantidad</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$conteozpm2}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb;border-top-left-radius: 10px;">
           
                          <div class="text-center mt-4" style="font-size: 15px; margin-bottom: 20px; color: white;">ZPMI</div>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Cantidad</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$conteozpmi}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #28a745;border-top-left-radius: 10px;">
           
                          <div class="text-center mt-4" style="font-size: 15px; margin-bottom: 20px; color: white;">Total</div>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Cantidad</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$conteozpm2 + $conteozpmi}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        @if($cumplimiento > 89)
                        <div class="col-md-3 text-center" style="background-color: #28a745;border-top-left-radius: 10px;">
                        @elseif($cumplimiento > 70)
                        <div class="col-md-3 text-center" style="background-color: #ffc107;border-top-left-radius: 10px;">
                        @else
                        <div class="col-md-3 text-center" style="background-color: #dc3545;border-top-left-radius: 10px;">
                        @endif

                          <div class="text-center mt-4" style="font-size: 25px; margin-bottom: 20px; color: white;">%</div>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Cunmplimiento</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$cumplimiento}}%</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              </div>

              </div>

            <div class="card-body">

              <div class="table-responsive">
                <table class="table" id="myTable">
                  <thead class=" text-primary">
                    <tr>
                      <th class="text-center">N° Equipo</th>
                      <th class="text-center">Descripción</th>
                      <th class="text-center">Nro Semana</th>
                      <th class="text-center">Fecha</th>
                      <th class="text-center">tipo_mant</th>
                      <th class="text-center">Cumplimiento</th>
                      <th class="text-center">Nota</th>
                      <th class="text-center">Nro Orden</th>
                      <th class="text-center">Responsable</th>

                    </tr>
                  </thead>
                  <tbody>
                    @forelse($programasBusqueda as $programaequipoapoyo)
                    <tr>
  
                      <td class="text-center">{{$programaequipoapoyo->equiposApoyo->numero_fmo}}</td>
                      <td class=""style="text-transform: uppercase;">{{ $programaequipoapoyo->equiposApoyo->descripcion }}</td>
                      <td class="text-center">{{$programaequipoapoyo->programas_EquipoApoyo->programa}}</td>
                      <td class="text-center">{{\Carbon\Carbon::parse($programaequipoapoyo->fecha)->format('d/m/Y')}}</td>
                      <td class="text-center">{{$programaequipoapoyo->tipo_mant}}</td>


                      @if($programaequipoapoyo->cumplimiento > 89)
                       <td class="text-center" style="color: #28a745">
                      @elseif($programaequipoapoyo->cumplimiento > 70)
                       <td class="text-center" style="color: #ffc107">
                       @else
                       <td class="text-center" style="color: #dc3545">
                      @endif
                      {{$programaequipoapoyo->cumplimiento}}
                      </td>
                      <td class="text-center">
                      @if(!empty($programaequipoapoyo->nota))
                       <a href="" style="" data-toggle="modal" data-target="#nota_programaEqAPoyoDellate" data-observacion="{{$programaequipoapoyo->nota}}"><i class="material-icons">book</i></a>
                      @endif
                      </td>
                      <td class="text-center">{{$programaequipoapoyo->n_orden}}</td>
                      <td class="text-center">{{$programaequipoapoyo->responsable}}</td>


                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->

  <div class="modal" id="nota_programaEqAPoyoDellate" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Notas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <p id="nota-modal"></p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </form>
    </div>
  </div>

  <!-- End Modal -->

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

@endsection
