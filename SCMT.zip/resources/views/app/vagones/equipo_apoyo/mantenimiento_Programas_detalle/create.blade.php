@extends('layouts.app', ['activePage' => 'eq_apoyo', 'titlePage' => __('Programa de Equipos de Apoyo')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
          <div class="card-header card-header-primary">
            <h4 class="card-title">{{ __('Agregar Programas Equipos de Apoyo') }}</h4>
          </div>
          <form method="post" action="{{ route('programaEquipoApoyoDetalle.store') }}" autocomplete="off" class="form-horizontal">
            @csrf
            @include('app.vagones.equipo_apoyo.mantenimiento_Programas_detalle.form')

             <div class="box-footer mt20 mt-4 text-center" style="position: fixed;
              bottom: 15px;
              right: 40%;
              z-index: 99;
              height: 50px;
              overflow: hidden;
              transition: all 0.5s ease;">
              <a href="{{ route('programaEquipoApoyo.index') }}" class="btn btn-danger">{{ __('Cancelar') }}</a>
              <button type="submit" class="btn btn-primary">Crear</button>
             </div>

          </form>
        </div>
      </div>
    </div>
  </div>

@endsection
