<div class="box box-info padding-1">
    <div class="box-body">
    
            <input class="col-2" type="number" name="equipo_id" value="{{$programadetalle->equipo_id}}" style="visibility: hidden">
            <input class="col-2" type="number" name="programa_id" value="{{$programadetalle->programa_id}}" style="visibility: hidden">

        <div class="card-group mt-2">


            <h4 class="col-3">Nro Equipo: <label>{{$programadetalle->equiposApoyo->numero_fmo}}</label></h4>
            <h4 class="col-4">Descripción: <label>{{$programadetalle->equiposApoyo->descripcion}}</label></h4>
            <h4 class="col-5">Ubicación: <label>{{$programadetalle->equiposApoyo->ubicacion}}</label></h4>

          <div class="card-group col-12 mt-4">
            

            {{ Form::label('Fecha') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha', $programadetalle->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('% Cumplimiento') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('cumplimiento', $programadetalle->cumplimiento, ['class' => 'form-control text-center' . ($errors->has('cumplimiento') ? ' is-invalid' : ''), 'min' => '0', 'max' => '100' , 'step' => '0.2', 'placeholder' => 'Ingrese']) }}
            {!! $errors->first('cumplimiento', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Nota') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('nota', $programadetalle->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese Nota']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Nro Orden') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('n_orden', $programadetalle->n_orden, ['class' => 'form-control text-center' . ($errors->has('n_orden') ? ' is-invalid' : ''), 'min' => '0', 'placeholder' => 'Ingrese']) }}
            {!! $errors->first('n_orden', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp


          </div>
            <div class="card-group mt-5 col-12">
            {{ Form::label('Responsable:') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            <div class="col-3 form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
            <select name="responsable" class="responsable col-md-12">
              @if (!empty($programadetalle->datos->nombre))
                <option value="{{$programadetalle->responsable}}">{{ $programadetalle->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
            @endif

            </div>

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Tipo Mant:') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            <div class="form-group{{ $errors->has('tipo_mant') ? ' has-danger' : '' }}">
            <select class="custom-select form-control{{ $errors->has('tipo_mant') ? ' is-invalid' : '' }} text-center" name="tipo_mant" id="input-tipo_mant"placeholder="{{ __('Seleccione') }}">
            <option value="">SELECCIONE</option>
            @foreach($programadetalle->Tipo_mant() as $tipo)
            <option value="{{$tipo}}" {{$programadetalle->tipo_mant == $tipo ? 'selected' : '' }}>{{$tipo}}</option>
            @endforeach
          </select>
          </div>

          </div>

        </div>

       

            </div>
          </div>

