@extends('layouts.app', ['activePage' => 'eq_apoyo', 'titlePage' => __('Crear Programa de Equipos de Apoyo')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
          <div class="card-header card-header-primary">
            <h4 class="card-title">{{ __('Crear Programa de Equipos de Apoyo') }}</h4>
          </div>
          <form method="post" action="{{ route('programaEquipoApoyo.store') }}" autocomplete="off" class="form-horizontal">
            @csrf
            @include('app.vagones.equipo_apoyo.mantenimiento_Programas.form')
            <div class="card-footer justify-content-center">
              <a href="{{route('programaEquipoApoyo.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

@endsection
