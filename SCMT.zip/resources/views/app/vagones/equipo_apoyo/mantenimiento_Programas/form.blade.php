<div class="box box-info padding-1">
    <div class="box-body">
      
        <div class="card-group col-12 my-4">

            {{ Form::label('Programa N°:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::number('programa', $programa->programa, ['class' => 'form-control text-center' . ($errors->has('programa') ? ' is-invalid' : ''), 'min' => '0', 'max' => '100', 'placeholder' => 'Ingrese']) }}
            {!! $errors->first('programa', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Fecha Inicio:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha', $programa->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Fecha Fin:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_fin', $programa->fecha_fin, ['class' => 'form-control' . ($errors->has('fecha_fin') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
            {!! $errors->first('fecha_fin', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Nota:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('nota', $programa->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la nota']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}

            </div>

            <div class="card-group mt-5">

            @if(!empty($programa->estatus))

            &nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Cantidad de Personas:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::number('cant_persona', $programa->cant_persona, ['class' => 'form-control text-center' . ($errors->has('cant_persona') ? ' is-invalid' : ''), 'min' => '0', 'placeholder' => 'Ingrese']) }}
            {!! $errors->first('cant_persona', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Tiempo:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::number('tiempo', $programa->tiempo, ['class' => 'form-control text-center' . ($errors->has('tiempo') ? ' is-invalid' : ''), 'min' => '0', 'placeholder' => 'Ingrese']) }}
            {!! $errors->first('tiempo', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Estatus:') }}&nbsp&nbsp&nbsp&nbsp

            <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }} text-center"
                name="estatus" id="input-estatus"placeholder="{{ __('Seleccione') }}"
              >
              <option value="">SELECCIONE</option>
              @foreach($programa->programaEstatus() as $programaestatus)
                <option value="{{$programaestatus}}" {{$programa->estatus == $programaestatus ? 'selected' : '' }}>{{$programaestatus}}</option>
              @endforeach
            </select>


            @if ($errors->has('estatus'))
              <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
            @endif
          </div>

          @endif

        </div>




          <table class="table-responsive mt-4 col-12"> 
              
              <thead>
                
                <tr>
                  
                  <th class="text-center col-4">{{ Form::label('Planificador:') }}</th>
                  <th></th>
                  <th class="text-center col-4">{{ Form::label('Jefe Turno Area:') }}</th>
                  <th></th>
                  <th class="text-center col-4">{{ Form::label('Jefe de Planificación:') }}</th>

                </tr>

              </thead>
              <tbody>
                <tr>


                  <td>

                    <div class="form-group{{ $errors->has('planificador') ? ' has-danger' : '' }}">
                    <select name="planificador" class="responsable col-md-12">
                    @if (!empty($programa->datosplanificador->nombre))
                     <option value="{{$programa->planificador}}">{{ $programa->datosplanificador->nombre}}</option>
                   @endif
                   </select>
                    @if ($errors->has('planificador'))
                    <span id="name-error" class="error text-danger" for="input-planificador">{{ $errors->first('planificador') }}</span>
                   @endif
                  </div>

                  </td>

                  <td></td>

                  <td>

                  <div class="form-group{{ $errors->has('jefeturnoarea') ? ' has-danger' : '' }}">
                  <select name="jefeturnoarea" class="responsable col-md-12">
                    @if (!empty($programa->datosjefeTurnoarea->nombre))
                      <option value="{{$programa->jefeturnoarea}}">{{ $programa->datosjefeTurnoarea->nombre}}</option>
                    @endif
                  </select>
                  @if ($errors->has('jefeturnoarea'))
                    <span id="name-error" class="error text-danger" for="input-jefeturnoarea">{{ $errors->first('jefeturnoarea') }}</span>
                  @endif

                  </div>

                </td>


                <td></td>

            <td>

            <div class="form-group{{ $errors->has('jefeplanificacion') ? ' has-danger' : '' }}">
            <select name="jefeplanificacion" class="responsable col-md-12">
              @if (!empty($programa->datosjefeplanificacion->nombre))
                <option value="{{$programa->jefeplanificacion}}">{{ $programa->datosjefeplanificacion->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('jefeplanificacion'))
              <span id="name-error" class="error text-danger" for="input-jefeplanificacion">{{ $errors->first('jefeplanificacion') }}</span>
            @endif

            </div>

          </td>

                </tr>
              </tbody>

            </table>





