@extends('layouts.app', ['activePage' => 'eq_apoyo', 'titlePage' => __('Crear Equipo de Apoyo')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
          <div class="card-header card-header-primary">
            <h4 class="card-title">{{ __('Crear Equipo') }}</h4>
          </div>
          <form method="post" action="{{ route('equipodeapoyo.store') }}" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
            @csrf
            @include('app.vagones.equipo_apoyo.form')
            <div class="card-footer justify-content-center">
              <a href="{{route('equipodeapoyo.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

@endsection
