   <script type="text/javascript">
      
    function Programa(){

    var number = document.getElementById('input-Frecuencia');

    var fechaPrograma = new Date (document.getElementById('input-fecha_programa').value);
    var dias = parseInt(number.value);


    fechaPrograma.setDate(fechaPrograma.getDate() + dias + 1);


    resultado.innerText = fechaPrograma.getDate() + '/' + (fechaPrograma.getMonth() + 1) + '/' + fechaPrograma.getFullYear();
  }

  </script>

  <div class="card-body ">
    <div class="row my-3">
      <label class="col-sm-2 col-form-label">{{ __('Número FMO') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('numero_fmo') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="numero_fmo" id="input-name" type="text" placeholder="{{ __('Ingrese numero FMO del Equipo') }}"
            value="{{ old('numero_fmo') ?? $equipoApoyo->numero_fmo }}" required="true"/>
          @if ($errors->has('numero_fmo'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('numero_fmo') }}</span>
          @endif
        </div>
      </div>
    </div>
    <div class="row my-3">
        <label class="col-sm-2 col-form-label">{{ __('Descripción') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('descripcion') ? ' is-invalid' : '' }}"
              name="descripcion" id="input-descripcion" type="text" placeholder="{{ __('Descripción del Equipo') }}"
              value="{{ old('descripcion') ?? $equipoApoyo->descripcion }}" required="true"/>
            @if ($errors->has('descripcion'))
              <span id="name-error" class="error text-danger" for="input-descripcion">{{ $errors->first('descripcion') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row my-3">
        <label class="col-sm-2 col-form-label">{{ __('Ubicación') }}</label>
        <div class="col-sm-7">

            <textarea class="form-control{{ $errors->has('descripcion') ? ' has-danger' : '' }} col-md-12" type="text" name="ubicacion"  placeholder="Ingrese la ubicación del equipo" />{{ old('ubicacion') ?? $equipoApoyo->ubicacion}}</textarea>

        </div>
    </div>

    <div class="row my-3">
        <label class="col-sm-2 col-form-label">{{ __('Estatus') }}</label>
        <div class="col-sm-3">
          <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }} text-center"
                name="estatus" id="input-estatus" placeholder="{{ __('Ingrese estatus del equipo') }}" required="true" value="{{$equipoApoyo->numero_fmo}}"
              >
              <option value="">SELECCIONE</option>
              @foreach($equipoApoyo->estatusequipo() as $equipo)
                <option value="{{$equipo}}" {{$equipoApoyo->estatus == $equipo ? 'selected' : '' }}>{{$equipo}}</option>
              @endforeach
            </select>


            @if ($errors->has('estatus'))
              <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
            @endif
          </div>
        </div>
        <label class="col-sm-2 col-form-label">{{ __('Frecuencia de Mantt') }}</label>
      <div class="col-sm-2">
        <div class="form-group{{ $errors->has('f_mantenimiento') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
            name="f_mantenimiento" id="input-Frecuencia" type="number" min="0" placeholder="{{ __('Ingrese') }}"
            value="{{ old('f_mantenimiento') ?? $equipoApoyo->f_mantenimiento }}"/>
        </div>
      </div>
      <div class="card-group col-12 row mt-4">
      <label class="col-md-2 col-form-label">Imagen</label>
        <div class="col-md-4">
           <input type="file" accept="image/*" name="foto" id="foto" class="form-control">
      </div>
      <label class="col-sm-1 col-form-label">{{ __('IP10') }}</label>
      <div class="col-sm-1">
        <div class="form-group{{ $errors->has('sap_ip10') ? ' has-danger' : '' }}">
          <input class="text-center form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="sap_ip10" id="input-name" type="number" min="0" placeholder="{{ __('Ingrese') }}"
            value="{{ old('sap_ip10') ?? $equipoApoyo->sap_ip10 }}"/>
          @if ($errors->has('sap_ip10'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('sap_ip10') }}</span>
          @endif
        </div>
      </div>
      </div>
        <div class="card-group col-12 mt-4 row">
          
          <label class="col-2 col-form-label">{{ __('Fecha Programa') }}</label>
          &nbsp&nbsp&nbsp&nbsp
          <div class="form-group{{ $errors->has('fecha_programa') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('fecha_programa') ? ' is-invalid' : '' }}"
              name="fecha_programa" id="input-fecha_programa" type="date"
              value="{{ old('fecha_programa') ?? $equipoApoyo->fecha_programa}}"/>
            @if ($errors->has('fecha_programa'))
              <span id="name-error" class="error text-danger" for="input-fecha_programa">{{ $errors->first('fecha_programa') }}</span>
            @endif
          </div>

          <span class="mt-2">&nbsp&nbsp&nbsp&nbsp&nbsp------>&nbsp&nbsp&nbsp&nbsp&nbsp</span>

          <label class="mt-2">Resultado (Fecha + Frecuencia): &nbsp&nbsp&nbsp&nbsp&nbsp<span style="font-weight: bold;" id="resultado"></span></label>&nbsp&nbsp&nbsp&nbsp&nbsp
          <a href="#" class="badge badge-danger mt-2" style="color: white; font-size: 12px; height: 20px; font-weight: bold;" onclick="Programa()">Calcular</a>

        </div>
  </div>
