<div class="box box-info padding-1">
    <div class="box-body">
      
        @if(!empty($_GET['id_v']))
        <input type="text" name="vagones_id" value="{{$_GET['id_v']}}" style="visibility: hidden;">
        <input type="text" name="proyecto_vagones_id" value="{{$_GET['id_P']}}" style="visibility: hidden;">
        <input type="text" name="taller_id" value="{{$_GET['id_T']}}" style="visibility: hidden;">
        <div class="card-group">
          @else
        <div class="card-group">

           <label class="col-form-label">{{ __('N° Vagon') }}</label>
            <div class="col-md-3">
              <div class="form-group{{ $errors->has('vagones_id') ? ' has-danger' : '' }}">
                <select name="vagones_id" class="vagones_poruno" style="width: 80%">
                  @if (!empty($vagonesProyectoConsumo->vagon_id))
                    <option value="{{$vagonesProyectoConsumo->vagones_id}}">{{ $vagonesProyectoConsumo->vagones_id}}</option>
                  @endif
                </select>
                @if ($errors->has('vagones_id'))
                  <span id="name-error" class="error text-danger" for="input-vagones_id">{{ $errors->first('vagones_id') }}</span>
                @endif
              </div>
            </div>
            @endif      

        </div>
        <br>
        <br>

        <div class="form-group" style="margin-left: 80%">
        <label>Buscador:</label><br>
        <input type="text" class="form-control pull-right" id="search" placeholder="Escriba su Busqueda">
        </div>

        <br>

          <div class="table-responsive">
                <table class="table" id="mytable" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center col-1">N° Parte</th>
                        <th class="text-center col-1">N° SAP</th>
                        <th class="text-center col-6">Descripción</th>
                        <th class="text-center col-1">Unid</th>
                        <th class="text-center col-1">Cantidad</th>
                        <th class="text-center col-1" hidden="true">Seleccionar</th>
                        <th class="text-center col-1">Precio Unit.</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($materiales as $id => $material)
                      <tr>
                      <td class="text-center">{{$material->parte}}</td>
                      <td class="text-center">{{$material->sap}}</td>
                      <td style="text-transform: uppercase;">{{$material->descripcion}}</td>
                      <td class="text-center">{{$material->unidad}}</td>
                      <td class="text-center"> <input class="text-center col-12" type="number" name="cantidad[{{$id}}]" onKeyUp="marcar(this)" min="0" value="{{$vagonesProyectoConsumo->cantidad}}"></td>
                      <td class="text-center" hidden="true"> <input type="checkbox" disabled="disabled" name="materiales_vagones_id[{{$id}}]" value="{{$material->id}}"></td>
                      <td class="text-center">{{$material->preciounitario}}</td>

                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>



<script src="{{ asset('js') }}/jQueryv310.js"></script>

<script>
 // Write on keyup event of keyword input element
 $(document).ready(function(){
 $("#search").keyup(function(){
 _this = this;
 // Show only matching TR, hide rest of them
 $.each($("#mytable tbody tr"), function() {
 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
 $(this).hide();
 else
 $(this).show();
 });
 });
});
</script>

<script type="text/javascript">
function marcar(obj) {
  chk = obj.parentNode.parentNode;
  chk = chk.getElementsByTagName('input')[1];
  chk.checked = (obj.value.length > 0);
  chk.disabled = !chk.checked;
}  
</script>
                             
  </div>
               



   <div class="box-footer mt20 mt-4 text-center" style="position: fixed;
      bottom: 15px;
      right: 40%;
      z-index: 99;
      height: 50px;
      overflow: hidden;
      transition: all 0.5s ease;">
        <a href="{{ route('proyectoVagones.show', $_GET['id_P']) }}" class="btn btn-danger">{{ __('Cancelar') }}</a>
        <button type="submit" class="btn btn-primary">Crear</button>
    </div>
</div>