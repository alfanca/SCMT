@extends('layouts.app', ['activePage' => 'vagon_taller', 'titlePage' => __('Consumo de Vagones')])
@section('content')
<section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Consumo de Vagones</h4>
                        <p class="card-category">Administración de Consumo</p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{ route('consumoVagones.create') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Agregar <i class="material-icons">add</i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>

                    <div class="card-body">
                        <form class="mt-2" method="get" autocomplete="off" action="{{route('consumoVagones.index')}}" class="form-horizontal">
                        @include('app.comun.nav_calendario_busqueda_sinboton_consumoVag')
                       </form>
                       <div class="col-md-12 mt-4">

                    <div class="card-header card-header-tabs card-header-warning mt-2">
                      <div class="nav-tabs-navigation">
                        <div class="nav-tabs-wrapper">
                          <span class="nav-tabs-title">TABLAS:</span>
                          <ul class="nav nav-tabs" data-tabs="tabs">
                            <li class="nav-item">
                              <a class=" nav-link active" href="#tab-detalle" data-toggle="tab">
                                <i class="fas fa-bars" style="font-size: 15px;"></i> Detalle
                                <div class="ripple-container"></div>
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class=" nav-link" href="#tab-resumen" data-toggle="tab">
                                <i class="fas fa-balance-scale" style="font-size: 15px;"></i> Resumen
                                <div class="ripple-container"></div>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>

                      <div class="tab-content">

                        <div class="tab-pane active mt-2" id="tab-detalle">

                        <div class="table-responsive mt-2">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        
										<th class="text-center">N° Vagon</th>
										<th class="text-center">Fecha</th>
										<th class="text-center">Componente</th>
										<th class="text-center">Cantidad</th>
										<th class="text-center">Precio Unit.</th>
                                        <th class="text-center">Precio Total</th>
                                        <th class="text-center">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($listadoRegistroDeConsumo as $consumo)
                                        <tr>
                                            

											<td class="text-center">{{ $consumo->vagon_id }}</td>
											<td class="text-center">{{\Carbon\Carbon::parse($consumo->fecha)->format('d/m/Y')}}</td>
											<td style="text-transform: uppercase;">{{ $consumo->materialesvagones->descripcion }}</td>
											<td class="text-center">{{ $consumo->cantidad }}</td>
											<td class="text-center">{{ $consumo->precio }}</td>
                                            <td class="text-center">{{ $consumo->precio * $consumo->cantidad }}</td>

                                            <td class="text-center">
                                                <form action="{{ route('consumoVagones.destroy',$consumo->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link text-center" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <div class="tab-pane" id="tab-resumen">


                        <div class="table-responsive mt-2">
                            <table class="table table-striped table-hover" id="myTable2">
                                <thead class="thead">
                                    <tr>
                                        
                                        <th class="text-center">Componente</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Precio Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($consumoPorTipo as $grupoConsumo)
                                        <tr>
                                            <td style="text-transform: uppercase;">{{$grupoConsumo[0]->materialesvagones->descripcion??''}}</td>
                                            <td class="text-center" style="text-transform: uppercase;">
                                               @php
                                               $sumaplan = 0;
                                               @endphp
                                               @foreach ($grupoConsumo as $consumoCantidad)

                                               <!--{{$sumaplan+=$consumoCantidad->cantidad}}-->
                                    
                                               @endforeach

                                               {{$sumaplan}}


                                            </td>

                                            <td class="text-center" style="text-transform: uppercase;">

                                               @php
                                               $total = 0;
                                               @endphp
                                               @foreach ($grupoConsumo as $consumoCantidad)

                                               <!--{{$total+=$consumoCantidad->total}}-->
                                    
                                               @endforeach

                                               {{$total}}



                                            </td>



                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>


                    </div>



                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['10'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['10'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>

@endsection
