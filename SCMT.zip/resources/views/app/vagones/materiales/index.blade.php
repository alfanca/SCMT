@extends('layouts.app', ['activePage' => 'materialvagon', 'titlePage' => __('Registro de Materiales de Vagones')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
             <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Materiales de Vagones y Eq. Apoyo</h4>
                <p class="card-category">Administración de Materiales de Vagones y Eq. Apoyo</p>
              </div>
              @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('ispasante'))
            <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Crear Material"
                    href="{{route('materialesvagones.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Crear Material
                  <i class="material-icons">add</i>
                </a>  
              </div>
              @endif
            </div>

            <div class="card-body">

              <div class="table-responsive">
                <table class="table" id="myTable">
                  <thead class=" text-primary">
                    <tr>
                    	<th class="text-center">N° Parte</th>
                    	<th class="text-center">N° SAP</th>
                    	<th class="text-center">Tipo</th>
                        <th class="text-center">Descripción</th>
                        <th class="text-center">Detalles</th>
                        <th class="text-center">Unid</th>
                        <th class="text-center">Categoria</th>
                        <th class="text-center">Sistema</th>
                        <th class="text-center">Precio Unit.$</th>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('ispasante'))
                    	<th class="text-center">Acciones</th>
                      @endif
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($materialesvagones as $materiales)
										<tr>
                      <td class="text-center">{{$materiales->parte}}</td>
                      <td class="text-center">{{$materiales->sap}}</td>
                      <td class="text-center">{{$materiales->tipo}}</td>
                      <td style="text-transform: uppercase;">{{$materiales->descripcion}}</td>
                      <td class="text-center"><a href="" style="" data-toggle="modal" data-target="#ubicacionmaterialvagones" data-observacion="{{$materiales->ubicacion}}" data-foto="{{asset('/imagenesmaterialesvagones/' .trim($materiales->foto))}}">

                      @if(!empty ($materiales->foto))
                      <i class="fas fa-camera" style="font-size: 20px;"></i>
                      @else
                      <i class="fa fa-fw fa-file-alt" style="font-size: 20px;"></i>
                      @endif

                      </a></td>
                      <td class="text-center">{{$materiales->unidad}}</td>
                      <td class="text-center">{{$materiales->catergoria}}</td> 
                      <td class="text-center">{{$materiales->sistema}}</td> 
                      <td class="text-center">{{$materiales->preciounitario}}</td>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('ispasante'))
                      <td class="td-actions text-center card-group">
				                <a rel="tooltip" class="btn btn-success btn-link" href="{{route('materialesvagones.edit', [$materiales->id])}}" data-original-title="" title="Editar">
                          <i class="material-icons">edit</i>
                          <div class="ripple-container"></div>
                        </a>
                        <form method="post" id="formDeleteVagone-{{$materiales->id}}" action="{{route('materialesvagones.destroy', [$materiales->id] ) }}" class="">
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteVagone-{{$materiales->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      </td>
                      @endif
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>


           <!-- Modal -->

  <div class="modal" id="ubicacionmaterialvagones" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Detalles</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <p style="text-transform: uppercase;" id="nota-modal"></p>
            <img id="foto-modal" src="" width="450" height="500" alt="NO SE ENCUENTRA LA IMAGEN">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </form>
    </div>
  </div>

 <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['10'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Materiales)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

@endsection
