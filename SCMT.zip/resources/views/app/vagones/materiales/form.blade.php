  <div class="card-body ">
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('N° Parte:') }}</label>
      <div class="col-sm-4">
        <div class="form-group{{ $errors->has('parte') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="parte" id="input-name" type="text" placeholder="{{ __('Ingrese numero de Parte') }}"
            value="{{ old('parte') ?? $materialesvagone->parte }}"/>
          @if ($errors->has('parte'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('parte') }}</span>
          @endif
        </div>
      </div>

      <label class="col-sm-2 col-form-label">{{ __('N° SAP:') }}</label>
      <div class="col-sm-4">
        <div class="form-group{{ $errors->has('sap') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="sap" id="input-name" type="number" min="0" placeholder="{{ __('Ingrese numero de SAP') }}"
            value="{{ old('sap') ?? $materialesvagone->sap }}"/>
          @if ($errors->has('sap'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('sap') }}</span>
          @endif
        </div>
      </div>

    </div>
    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Tipo:') }}</label>
        <div class="col-sm-3">
          <div class="form-group{{ $errors->has('tipo') ? ' has-danger' : '' }}">
            <select class="custom-select form-control{{ $errors->has('tipo') ? ' is-invalid' : '' }}"
                name="tipo" id="input-tipo"placeholder="{{ __('Ingrese el tipo de Vagon') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($materialesvagone->tipos() as $tipo)
                <option value="{{$tipo}}" {{$materialesvagone->tipo == $tipo ? 'selected' : '' }}>{{$tipo}}</option>
              @endforeach
            </select>


            @if ($errors->has('tipo'))
              <span id="name-error" class="error text-danger" for="input-tipo">{{ $errors->first('tipo') }}</span>
            @endif
          </div>
        </div>

        
        <label class="col-sm-1 col-form-label">{{ __('Unidad:') }}</label>
        <div class="col-sm-2">
          <div class="form-group{{ $errors->has('unidad') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('unidad') ? ' is-invalid' : '' }}"
                name="unidad" id="input-unidad"placeholder="{{ __('Ingrese la unidad') }}" required="true"
              >
              
              <option value="">SELECCIONE</option>
              @foreach($materialesvagone->unidades() as $unidad)
                <option value="{{$unidad}}" {{$materialesvagone->unidad == $unidad ? 'selected' : '' }}>{{$unidad}}</option>
              @endforeach
            </select>


            @if ($errors->has('unidad'))
              <span id="name-error" class="error text-danger" for="input-unidad">{{ $errors->first('unidad') }}</span>
            @endif
          </div>
        </div>


        <label class="col-form-label">{{ __('Categoria:') }}</label>
        <div class="col-sm-2">
          <div class="form-group{{ $errors->has('catergoria') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('catergoria') ? ' is-invalid' : '' }}"
                name="catergoria" id="input-catergoria"placeholder="{{ __('Ingrese la Categoria') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($materialesvagone->catergorias() as $catergoria)
                <option value="{{$catergoria}}" {{$materialesvagone->catergoria == $catergoria ? 'selected' : '' }}>{{$catergoria}}</option>
              @endforeach
            </select>


            @if ($errors->has('catergoria'))
              <span id="name-error" class="error text-danger" for="input-catergoria">{{ $errors->first('catergoria') }}</span>
            @endif
          </div>
        </div>
</div>
<div class="row">
        <label class="col-2 col-form-label">{{ __('Sistema:') }}</label>
        <div class="col-sm-3">
          <div class="form-group{{ $errors->has('sistema') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('sistema') ? ' is-invalid' : '' }}"
                name="sistema" id="input-sistema"placeholder="{{ __('Ingrese la Sistema') }}"
              >
              <option value="">SELECCIONE</option>
              @foreach($materialesvagone->sistemas() as $sistemaCat)
                <option value="{{$sistemaCat}}" {{$materialesvagone->sistema == $sistemaCat ? 'selected' : '' }}>{{$sistemaCat}}</option>
              @endforeach
            </select>


            @if ($errors->has('sistema'))
              <span id="name-error" class="error text-danger" for="input-sistema">{{ $errors->first('sistema') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Descripción:') }}</label>
      <div class="col-sm-10">
        <div class="form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="descripcion" id="input-name" type="text" placeholder="{{ __('Ingrese la descripcion') }}"
            value="{{ old('descripcion') ?? $materialesvagone->descripcion }}" required="true"/>
          @if ($errors->has('descripcion'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('descripcion') }}</span>
          @endif
        </div>
      </div>
    </div>

    <div class="row">

      <label class="col-md-2 col-form-label">{{ __('Ubicación:') }}</label>
          <div class="col-md-10 form-group{{ $errors->has('ubicacion') ? ' has-danger' : '' }}">
        <textarea class="col-md-12" type="text" name="ubicacion" />{{ old('ubicacion') ?? $materialesvagone->ubicacion}}</textarea>
        @if ($errors->has('ubicacion'))
         <span id="name-error" class="error text-danger" for="input-ubicacion">{{ $errors->first('ubicacion') }}</span>
         @endif
         </div>

    </div>

    <div class="row">
    <label class="col-sm-2 col-form-label">{{ __('Precio Unit.') }}</label>
      <div class="col-sm-2">
        <div class="form-group{{ $errors->has('preciounitario') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="preciounitario" id="input-name" type="number" min="0.01" step="0.01" 
            value="{{ old('preciounitario') ?? $materialesvagone->preciounitario }}">
          @if ($errors->has('preciounitario'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('preciounitario') }}</span>
          @endif
        </div>
    </div>

    <label class="col-md-1 col-form-label">Imagen</label>
        <div class="col-md-4">
           <input type="file" accept="image/*" name="foto" id="foto" class="form-control">


    </div>
  </div>
</div>
