  <div class="card-body ">
    <div class="row">
      <label class="col-md-2 col-form-label">{{ __('N° Vagon') }}</label>
    <div class="col-md-3">
      <div class="form-group{{ $errors->has('ficha_inspector') ? ' has-danger' : '' }}">
        <select name="vagon_id" class="vagones_poruno" style="width: 80%">
          @if (!empty($vagonDescarrilamiento->vagon_id))
            <option value="{{$vagonDescarrilamiento->vagon_id}}">{{ $vagonDescarrilamiento->vagon_id}}</option>
          @endif
        </select>
        @if ($errors->has('ficha_inspector'))
          <span id="name-error" class="error text-danger" for="input-ficha_inspector">{{ $errors->first('ficha_inspector') }}</span>
        @endif
      </div>
    </div>
    </div>
    <div class="row">
        <label class="col-md-2 col-form-label">{{ __('Fecha Inicio:') }}</label>
    <div class="col-md-2">
      <div class="form-group{{ $errors->has('fecha_inicio') ? ' has-danger' : '' }}">
        <input class="form-control" type="text" name="fecha_inicio" value="{{old('fecha_inicio') ?? \Carbon\Carbon::parse($vagonDescarrilamiento->fecha_inicio) ?? \Carbon\Carbon::now()}}">   
      @if ($errors->has('fecha_inicio'))
        <span id="name-error" class="error text-danger" for="input-fecha_inicio">{{ $errors->first('fecha_inicio') }}</span>
      @endif
      </div>
    </div> 
    </div>
    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Observación') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('observacion') ? ' has-danger' : '' }}">
            <textarea class="form-control col-md-12" name="observacion" placeholder="Ingrese la Observación" />{{ old('observacion') ?? $vagonDescarrilamiento->observacion}}</textarea>
            @if ($errors->has('observacion'))
            @endif
          </div>
        </div>
    </div>
    <div class="row">
        <label class="col-md-2 col-form-label">{{ __('Fecha Fin:') }}</label>
    <div class="col-md-2">
      <div class="form-group{{ $errors->has('fecha_fin') ? ' has-danger' : '' }}">
        <input class="form-control" type="text" name="fecha_fin" value="{{old('fecha_fin') ?? \Carbon\Carbon::parse($vagonDescarrilamiento->fecha_fin)}}">   
      @if ($errors->has('fecha_fin'))
        <span id="name-error" class="error text-danger" for="input-fecha_fin">{{ $errors->first('fecha_fin') }}</span>
      @endif
      </div>
    </div> 
     <label class="col-md-1 col-form-label">{{ __('Estatus:') }}</label>
            {{ Form::select('estatus', $estatus, $vagonDescarrilamiento->estatus, ['class' => 'form-control col-2 text-center' . ($errors->has('estatus') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('estatus', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    </div>

  </div>
