@extends('layouts.app', ['activePage' => 'adminvagonesdescarrilados', 'titlePage' => __('Descarrilamientos y Desincorporaciones')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Descarrilamientos y Desincorporaciones</h4>
                <p class="card-category">Administración de los Vagones Descarrilados y Desincorporados</p>
              </div>
              @if(Gate::check('isplanificador') || Gate::check('isJefe'))
            <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Ingresar Vagon"
                    href="{{route('vagonDescarrilamiento.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Ingresar
                  <i class="material-icons">add</i>
                </a>  
              </div>
              @endif
            </div>

            <div class="card-body">

              <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb;" >

                          <i class="fas fa-sign-out-alt text-center mt-4" style="font-size: 25px; color: white; transform: rotate(90deg);"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Ingresados</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonDescarrilamientosConteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #ff8000;">
           
                          <i class="fa fa-ban text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Descarrilados</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonDescarrilamientosConteoDescarrilados}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #28a745;">
           
                          <i class="fa fa-check text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Encarrilados</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonDescarrilamientosConteoEncarrilados}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545;">
           
                          <i class="fas fa-sign-out-alt text-center mt-4" style="font-size: 25px; color: white;transform: rotate(-90deg);"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Desincorporados</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonDescarrilamientosConteoDesincor}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


              <div class="table-responsive table col-md-12">
                <table id="myTable" class="table">
                  <thead class=" text-primary">
                    <tr>
                    	<th class="text-center">N° Vagon</th>
                    	<th class="text-center">Fecha Inicio</th>
                    	<th class="text-center">Observación</th>
                      <th class="text-center">Fecha Fin</th>
                      <th class="text-center">Estatus</th>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    	<th class="text-center col-md-1">Acciones</th>
                      @endif
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($vagonDescarrilamientos as $descarrilamiento)
										<tr>
                      <td class="text-center">{{$descarrilamiento->vagon_id}}</td>
                      <td class="text-center">{{\Carbon\Carbon::parse($descarrilamiento->fecha_inicio)->format('d/m/Y H:i')}}</td>
                      <td style="text-transform: uppercase;">{{$descarrilamiento->observacion}}</td>
                      <td class="text-center">
                        @if(!empty($descarrilamiento->fecha_fin))
                        {{\Carbon\Carbon::parse($descarrilamiento->fecha_fin)->format('d/m/Y H:i')}}
                        @endif
                        </td>
                      <td class="text-center">{{$descarrilamiento::ESTATUS[$descarrilamiento->estatus]}}</td>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                      <td class="td-actions card-group col-md-12" align="center">
				                <a rel="tooltip" class="btn btn-success btn-link text-center" href="{{route('vagonDescarrilamiento.edit', [$descarrilamiento->id])}}" data-original-title="" title="Editar">
                          <i class="material-icons">edit</i>
                          <div class="ripple-container"></div>
                        </a>
                        <form method="post" id="formDeleteEq-{{$descarrilamiento->id}}" action="{{route('vagonDescarrilamiento.destroy', [$descarrilamiento->id] ) }}" class="">
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link text-center" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteEq-{{$descarrilamiento->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      </td>
                      @endif
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>


 <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['20'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Materiales)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

@endsection
