<div class="card-body mb-4" style="text-align: left;">
    <div class="row">
        <div class="col-sm-6">
            <label class="label-control">FECHA</label>
            <div class="col-sm-6">
                <input type="date" name="fecha" class="form-control col-sm-6"  required="true"
                  value="{{$fecha ?? \Carbon\Carbon::parse($disponibilidad->fecha)->format('Y-m-d')}}"
                />
            </div>
        </div>
        <div class="form-group col-md-6">
            <label class="label-control">TURNO</label>
            <select class="form-control col-sm-6{{ $errors->has('turno') ? ' is-invalid' : '' }}"
                name="turno" id="input-turno"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true">                         >
              <option value="">SELECCIONE</option>
              @foreach($turnos as $turnoActual)
                <option value="{{$turnoActual}}" @if ($turnoActual == $turno) selected @endif >{{$turnoActual}}</option>
              @endforeach
            </select>
        </div>
    </div>

    <!-- Fila -->
    <div class="row">
        <div class="form-group col-md-6">
            <label class="label-control">LUGAR</label>
                @if ($tipoVagon == 'gondola')
                <input type="hidden" name="tipo_vagon" value="gondola">
                @else
                <input type="hidden" name="tipo_vagon" value="tolva">
                @endif


            <select class="form-control col-sm-6 {{ $errors->has('lugar') ? ' is-invalid' : '' }}"
                name="lugar" id="input-lugar"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true" readonly="">             
                @if ($tipoVagon == 'gondola')
                  
                    <option value="TOTAL GONDOLAS">GONDOLAS</option>
                @else

                    <option value="TOTAL TOLVAS">TOLVAS</option>

                @endif

            </select>            
        </div>

        <div class="col-md-6">
            <label class="col-md-6">CANTIDAD</label>
            @if ($tipoVagon == 'gondola')
            <input type="number" class="form-control col-sm-6"  value="{{$conteoVagonesGondolas}}" id="cantidad" type="text" name="cantidad" max="1105" min="0" />
            @else
            <input type="number" class="form-control col-sm-6"  value="{{$conteoVagonesTolvas}}" id="cantidad" type="text" name="cantidad" max="1105" min="0" />
            @endif
        </div>
    </div>
</div>

