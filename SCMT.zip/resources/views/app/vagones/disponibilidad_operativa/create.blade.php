@extends('layouts.app', ['activePage' => 'vagones_disponibilidad', 'titlePage' => __('Registrar Disponibilidad Operativa de Vagones')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <form method="post" action="{{ route('vagones_disponibilidad_o.store') }}" autocomplete="off" class="form-horizontal">
              @csrf

              @include('app.vagones.disponibilidad_operativa.form')
          
              <div class="card-footer justify-content-center">
                <a href="{{route('vagones_disponibilidad_o.index')}}" class="btn btn-danger">{{ __('Regresar') }}</a>
                  <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
              </div>
            </form>
          </div>
          <hr>
        </div>
      </div>
          <!-- Disponibilidad guardada -->
      <div class="row">
        <div class="col-md-12">
          <div class="card-body">  
           <div class="col-md-6" align="center">TOTAL GÓNDOLAS ACTUAL:&nbsp&nbsp {{$conteoVagonesGondolas}}</div>
           <br>        

                <div class="card-body">
                <div class="col-md-6" align="center">TOTAL TOLVAS: &nbsp&nbsp{{$conteoVagonesTolvas}}</div>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
  </div>
</div>
@endsection
