@extends('layouts.app', ['activePage' => 'vagones_disponibilidad', 'titlePage' => __('Disponibilidad Operativa de Vagones')])
@section('content')

<div class="content">
	<div class="container-fluid">
		@include('app.comun.nav_dias', 	['url'=> 'vagones/disponibilidad/operativa/'])

		<div class="card-body text-center" style="font-weight: normal;">DISPONIBILIDAD OPERATIVA DE VAGONES</div>

		<div class="row">

      	@foreach($turnos as $turno)
      	    <?php $notasTurno = $vagonesDisponibilidadNotas->where('turno', $turno); ?>
      		<div class="col-md-4">
	 			<div class="card">
		            <div class="card-header card-header-primary">
		            	<div class="row">
		            		<div class="col-md-12"><h4 class="card-title text-center">TURNO {{$turno}}</h4></div>
		            		@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
		            		<div class="col-md-4"><a rel="tooltip" title="Agregar disponibilidad de Gondolas"
			              		href="{{route('vagones_disponibilidad_o.create')}}?turno={{$turno}}&fecha={{$fechas['fechaAListar']}}&tipo_vagon=gondola" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
	        		      			<i class="col-md-5">Góndolas</i>
		            	 		</a>
		            	 	</div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		            	 	<div class="col-md-4"><a rel="tooltip" title="Agregar disponibilidad de Tolvas"
			              		href="{{route('vagones_disponibilidad_o.create')}}?turno={{$turno}}&fecha={{$fechas['fechaAListar']}}&tipo_vagon=tolva" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
	        		      			<i class="col-md-5">Tolvas</i>
		            	 		</a>
		            	 	</div>
		            	 	@endif 
		            	</div>
		            </div>
		            <div class="card-body">
		            	<div class="text-center" style="font-weight: bold;">VAGONES GÓNDOLAS</div>
		            	<hr>
		            	<?php
                              $disponibilidadTurno  = [];
                             if (!empty($disponibilidad['gondola']))
                                 $disponibilidadTurno = $disponibilidad['gondola']->where('turno', $turno) ?? ""; 
                                ?>
	            		@forelse($disponibilidadTurno as $disponible)
		            	<div class="row">
		            		<div class="col-md-5">TOTAL GÓNDOLAS:</div>
		            		<div class="col-md-3">{{$disponible->cantidad}}</div>
		            		@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
		            		<div class="col-md-2">
		        				<form method="post" id="formDeleteDisponibilidad-{{$disponible->id}}" action="{{route('vagones_disponibilidad_o.destroy', [$disponible->id] ) }}">
	            	            @csrf
	            	            @method('delete')
	                          <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteDisponibilidad-{{$disponible->id}}')" 
                                    ><i class="material-icons">delete</i></a>
		                        </form>
		            		</div>
		            		@endif 
		              	</div>
		              	@empty
		              	@endforelse 
		              	<hr>
		              	<!--<div class="row">
		              		<div class="col-md-8">Total Góndolas:</div>
		              		<div class="col-md-2">
                                @if (!empty($disponibilidad['gondola']))
                                    {{$disponibilidadTurno->sum('cantidad')}}  
                                @endif

						 </div>
			             </div>-->
		           	
                    <div class="text-center" style="font-weight: bold;">VAGONES TOLVAS</div>
                    <hr>

                    <?php 
                                $disponibilidadTurno  = [];
                                if (!empty($disponibilidad['tolva']))
                                    $disponibilidadTurno = $disponibilidad['tolva']->where('turno', $turno); ?>
	            		@forelse($disponibilidadTurno as $disponible)
		            	<div class="row">
		            		<div class="col-md-5" style="text-transform: uppercase;">{{$disponible->lugar}}</div>
		            		<div class="col-md-3">{{$disponible->cantidad}}</div>
		            		@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
		            		<div class="col-md-2">
		        				<form method="post" id="formDeleteDisponibilidad-{{$disponible->id}}" action="{{route('vagones_disponibilidad_o.destroy', [$disponible->id] ) }}">
	            	            @csrf
	            	            @method('delete')
	                          <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteDisponibilidad-{{$disponible->id}}')" 
                                    ><i class="material-icons">delete</i></a>
		                        </form>
		            		</div>
		            		@endif 
		              	</div>
		              	@empty
		              	@endforelse
		              	<hr>

			             <div class="row">
		              		<div class="col-md-8">Notas:
		              			@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
		              			<a rel="tooltip" class="btn btn-success btn-link" data-original-title="" title="Agregar Nota"
                      				href="{{route('nota.create')}}?area=vagones&turno={{$turno}}&fecha={{$fechas['fechaAListar']}}">
                    				<i class="material-icons">add</i>
                    			</a>
                    			@endif 
			              	</div>
			             </div>
			               <div class="row">
				            @forelse ($notasTurno as $nota)
				            	<div class="col-md-7" style="text-transform: uppercase;"><li>{{$nota->nota}}</li></div>
				            	@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
				            	<div class="col-md-2">
									<a rel="tooltip" class="btn btn-success btn-link" href="{{route('nota.edit', [$nota->id])}}" data-original-title="" title="Editar"><i class="material-icons">edit</i></a>
				            	</div>
				            	<div class="col-md-2 text-center">
									<form method="post" id="formDeleteConsumo-{{$nota->id}}" 
										action="{{route('nota.destroy', [$nota->id] ) }}">
				                      @csrf
				                      @method('delete')
				                      <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
				                        onclick="eliminarRegistro('formDeleteConsumo-{{$nota->id}}')" 
				                      ><i class="material-icons">delete</i></a>
				                    </form>

				            	</div>
				            	@endif 
				            	<hr>
			              	@empty
			              	@endforelse
		              	</div>

		            </div>
		        </div>
      		</div>
      	@endforeach
    </div>
  	</div>
</div>  	
@endsection
