@extends('layouts.app', ['activePage' => 'vagon_taller', 'titlePage' => __('Historial del Taller de Vagones')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">Taller de Vagones</h4>
              <p class="card-category">Busqueda de Registro</p>
            </div>
            <div class="card-body">
              <div class="card-body">
              <div class="row">
    
             </div>
           <div class="row justify-content-center h-100">
           <form method="get" autocomplete="off" action="{{route('vagontaller')}}" class="form-horizontal">
            @include('app.comun.nav_calendario_busqueda')
           </form>            
           </div>
              

               <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;">
           
                          <i class="fa fa-cog text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Ingresados al Taller</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonesIngresadosTaller}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dab100; color: white;">
           
                          <i class="fa fa-info text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Vagones Reparados</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$VagonesReparadosTaller}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #28a745; color: white;">
           
                          <i class="fa fa-check text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Vagones Entregados</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonesEntregados}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>


              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #e36b2c; color: white;">
           
                          <i class="fas fa-stopwatch text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Promedio Horas Taller</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tiempotaller}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb; color: white;">
           
                          <i class="fa fa-clock text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Horas Total</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$horastotal}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #007c71; color: white;">
           
                          <i class="fas fa-user-clock text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Horas Hombre</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$horashombres}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

              <div class="table-responsive">
                <table id= 'myTable' class="table">
                  <thead class=" text-primary">
                    <tr>
                          
                          <th class="text-center">N° Vagon</th>
                          <th class="text-center">Proyecto</th>
                          <!--<th class="text-center">Estatus</th>-->
                          <th class="text-center">Fecha de Ingreso</th>
                          <th class="text-center">Fecha Ingreso al Taller</th>
                          <th class="text-center">Fecha Reparado</th>
                          <th class="text-center">Fecha de Salida</th>
                   
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($busqueda as $actividades)
                    <tr>

                      <td class="text-center">

                          @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))  

                          @if(!empty($actividades->catalogo_fallas_id))
                          <a rel="tooltip" class="badge badge-danger" href="{{ route('taller.show',$actividades->id) }}" title="Ver Detalle" style="font-size: 12px;">
                            {{$actividades->vagones_id}}

                          </a>
                          @else
                          <a rel="tooltip" class="badge badge-primary" title="Crear Tarjeta" href="{{ route('catalogo_fallas_tarjeta.create',['id_T'=>$actividades->id])}}" style="font-size: 12px;">
                            {{$actividades->vagones_id}}

                          </a>
                          @endif
                          @endif
                            </td>
                      
                          <!--<td class="text-center">{{$actividades->estatus_proceso}}</td>-->
                          <td> @if(!empty($actividades->proyecto_id))<a style="color: #808080" href="{{ route('proyectoVagones.show',$actividades->proyecto_id) }}"><i rel="tooltip" title="{{$actividades->vagon_proyecto->descripcion}}" class="fab fa-product-hunt" style="font-size: 18px"></i></a> @endif</td>
                          <td class="text-center">{{$actividades->fecha_ingreso}}</td>
                          <td class="text-center">{{$actividades->fecha_ingreso_taller}}</td>
                          <td class="text-center">{{$actividades->fecha_reparado_taller}}</td>
                          <td class="text-center">{{$actividades->fecha_salida_taller}}</td>
                
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {
    ordering: false,
    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


@endsection
