<div class="modal" id="modal_cambio_estatus_vagon" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Cambiar Ubicación Taller</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="" autocomplete="off" class="form-horizontal" id="form_vagon_taller">
          <input type="hidden" name="estatus_proceso" id="estatus_proceso" readonly="true">
          <input type="hidden" name="id" id="id" readonly="true">
        @csrf
        @method('patch')
        <div class="row">
          <label class="col-md-2 col-form-label">VAGÓN</label>
          <div class="col-md-4">
            <div class="form-group">
               <input type="text" class="form-control" id="vagon" readonly="true">  
            </div>
          </div>  
        </div>
        <div class="row">
          <label class="col-md-2 col-form-label">Fecha</label>
          <div class="col-md-4">
            <div class="form-group">
              <input type="text" name="fecha_ingreso" id="fecha_ingreso" value="{{\Carbon\Carbon::parse(now())->format('Y-m-d h:i')}}">   
            </div>
          </div>  
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
    </form>
    </div>
  </div>
</div>