<div class="card-body mb-4" style="text-align: left;">
  @if(!empty($_GET['id_proyecto']))
  <input type="number" name="proyecto_id" value="{{$_GET['id_proyecto']}}" hidden="yes">
  @endif
  <div class="row">
	  <label class="col-md-2 col-form-label">{{ __('FECHA:') }}</label>
	  <div class="col-md-2">
	    <div class="{{ $errors->has('fecha_ingreso') ? ' has-danger' : '' }}">
	      <input class="form-control" type="text" name="fecha_ingreso" value="{{ old('fecha_ingreso') ?? $taller->fecha_ingreso }}">   
	    @if ($errors->has('fecha_ingreso'))
	      <span id="name-error" class="error text-danger" for="input-fecha_ingreso">{{ $errors->first('fecha_ingreso') }}</span>
	    @endif
	    </div>
	  </div>  

	</div>

  <div class="row mt-2">
  	<label class="col-md-2 col-form-label">{{ __('VAGONES') }}</label>
	  <div class="col-md-10"> 
		    <select name="vagones[]" class="vagones" multiple="multiple" style="width: 100%">
		    </select>
	  </div>
  </div>
</div> <!--fin card -->

  <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
  <script src="{{ asset('material') }}/js/plugins/moment.min.js"></script>
  <script src="{{ asset('material') }}/js/plugins/bootstrap-datetimepicker.min.js"></script>

  <script type="text/javascript">
$('.hora_inicio').datetimepicker({
    icons: {
        time: "fa fa-clock-o",
        date: "fa fa-calendar",
        up: "fa fa-chevron-up",
        down: "fa fa-chevron-down",
        previous: 'fa fa-chevron-left',
        next: 'fa fa-chevron-right',
        today: 'fa fa-screenshot',
        clear: 'fa fa-trash',
        close: 'fa fa-remove'
    },
    format: 'DD-MM-YYYY',
    maxDate : 'now',
    defaultDate: new Date(),
    useCurrent: true 
});
  </script>