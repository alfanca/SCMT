@extends('layouts.app', ['activePage' => 'equipossenales', 'titlePage' => __('Programas de Mantenimiento Preventivo de Señales')])
@section('content')

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Taller de Vagones Nro Vagon: {{$tallerVagon->vagones_id}}</h4>
                        <p class="card-category">Programas de Mantenimiento Semanal Cumplimiento 


                        </p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{ route('taller.index') }}" title="Regresar al Taller de Vagones" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>
                        </a> 

                        <a rel="tooltip" title="Ver Ferro" 
                             class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-file-alt"></i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>
                    <br>
                    <br>
                    <br>
                    <div class="card-body">

                        <div class="col-md-12">
                        
                        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
                        <br>
                        
                        <div class="card-group mt-4">
                        <div class="form-group col-2">
                            <strong><b>Vagon Nro:</b> {{$tallerVagon->vagones_id}}</strong>
                            
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Ingreso:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse($tallerVagon->fecha_ingreso)->format('d/m/Y H:i')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Ingreso Taller:</b>&nbsp&nbsp </strong>
                            @if(!empty($tallerVagon->fecha_ingreso_taller))
                            {{\Carbon\Carbon::parse($tallerVagon->fecha_ingreso_taller)->format('d/m/Y H:i')}}
                            @endif
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Reparado:</b>&nbsp&nbsp </strong>
                            @if(!empty($tallerVagon->fecha_reparado_taller))
                            {{\Carbon\Carbon::parse($tallerVagon->fecha_reparado_taller)->format('d/m/Y H:i')}}
                            @endif
                        </div>
                        </div>
                        <hr>
                        <h4 class="col-md-12 text-center mt-3">Tarjeta</h4>
                        <div class="text-right">
                        @if((Gate::check('isplanificador') || Gate::check('isJefe')) and empty($tallerVagon->fecha_salida_taller)) 

                        <a rel="tooltip" class="btn btn-sm btn" href="{{route('catalogo_fallas_tarjeta.edit', [$tallerVagon->id, 'id_T'=>$tallerVagon->id])}}" title="Editar Catalogo" style="font-size: 12px;background-color: #9B945F;">
                        <i class="fa fa-fw fa-edit"></i></a>
 
                        @endif
                        </div>
                        <br>
                        <br>
                        <div class="card-group mt-4">
                        <div class="form-group col-2">
                            <strong><b>Lugar:</b></strong>
                            {{$tallerVagonCatalogo->lugar}}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Descripción:</b></strong>
                            {{$tallerVagonCatalogo->descripcion}}
                        </div>
                        <div class="form-group col-6">
                            <strong><b>Especificaciones de las Reparaciones:</b></strong>
                            {{$tallerVagonCatalogo->especificaciones_reparaciones}}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>Nro Orden:</b></strong>
                            {{$tallerVagonCatalogo->nro_sap}}
                        </div>
                        <div class="form-group col-4">
                             <strong><b>Responsable:</b></strong>
                            {{$tallerVagonCatalogo->datos->nombre}}    
                        </div>
                        <div class="form-group col-2">
                            <strong><b>Cant Persona:</b></strong>
                            {{$tallerVagonCatalogo->cant_persona}}
                        </div>
                        </div>

                       <hr>
                        <h4 class="col-md-12 text-center mt-3">Ruedas</h4>
                        <div class="text-right">
                        @if((Gate::check('isplanificador') || Gate::check('isJefe')) and count($tallerVagonRuedas) == 0 and empty($tallerVagon->fecha_salida_taller)) 

                        <a class="btn btn-sm btn" rel="tooltip" title="Crear Medición Ruedas" href="{{ route('vagonesRuedas.create',['id_R'=>$tallerVagon->id, 'id_V'=>$tallerVagon->vagones_id])}}" style="font-size: 18px; background-color: #9B945F;"><i class="fas fa-drafting-compass"></i></a>

 
                        @endif
                        </div>
                        <br>

                        <div class="card-body">
                        <div class="table-responsive mt-2">
                            <table class="table table-striped table-hover">
                                <thead>
                    <tr>
                        <th class="text-center">Fecha</th>
                        <th class="text-center">1</th>
                        <th class="text-center">8</th>
                        <th class="text-center">2</th>
                        <th class="text-center">7</th>
                        <th class="text-center">3</th>
                        <th class="text-center">6</th>
                        <th class="text-center">4</th>
                        <th class="text-center">5</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tallerVagonRuedas as $rueda)
                      <tr>
                      <td class="text-center">{{\Carbon\Carbon::parse($rueda->fecha)->format('d/m/Y')}}</td>
                      <td class="text-center">{{$rueda->rueda_1}}</td>
                      <td class="text-center">{{$rueda->rueda_8}}</td>
                      <td class="text-center">{{$rueda->rueda_2}}</td>
                      <td class="text-center">{{$rueda->rueda_7}}</td>
                      <td class="text-center">{{$rueda->rueda_3}}</td>
                      <td class="text-center">{{$rueda->rueda_6}}</td>
                      <td class="text-center">{{$rueda->rueda_4}}</td>
                      <td class="text-center">{{$rueda->rueda_5}}</td>
                      <td class="td-actions text-center">
                        @if((Gate::check('isplanificador') || Gate::check('isJefe')) and empty($tallerVagon->fecha_salida_taller)) 
                        <form method="post" id="formDeletevagonesRuedas-{{$rueda->id}}" action="{{route('vagonesRuedas.destroy', [$rueda->id] ) }}" class="">
                                <a rel="tooltip" class="btn btn-success btn-link" href="{{route('vagonesRuedas.edit', [$rueda->id, 'id_R'=>$tallerVagon->id, 'id_V'=>$tallerVagon->vagones_id] ) }}" data-original-title="" title="Editar">
                          <i class="material-icons">edit</i>
                          <div class="ripple-container"></div>
                        </a>
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeletevagonesRuedas-{{$rueda->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                        @endif
                      </td>
        
                         </tr>
                             @endforeach
                                </tbody>

                            </table>
                        </div>
                    </div>
                    <hr>
                        <h4 class="col-md-12 text-center mt-3">Consumibles</h4>
                        <div class="text-right">
                        @if((Gate::check('isplanificador') || Gate::check('isJefe')) and empty($tallerVagon->fecha_salida_taller)) 

                        <a class="btn btn-sm btn" rel="tooltip" title="Crear Consumo" href="{{ route('consumoVagones.create',['id_v'=>$tallerVagon->vagones_id,'id_T'=>$tallerVagon->id])}}" style="font-size: 18px; background-color: #9B945F"><i class="fas fa-cart-plus"></i></a>
 
                        @endif
                        </div>
                        <br>

                        <div class="table-responsive mt-2">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        
                                        <th class="text-center">Fecha</th>
                                        <th class="text-center">Componente</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Precio Unit.</th>
                                        <th class="text-center">Precio Total</th>
                                        <th class="text-center">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($tallerVagonConsumo as $consumo)
                                        <tr>
                                            
                                            <td class="text-center">{{\Carbon\Carbon::parse($consumo->fecha)->format('d/m/Y')}}</td>
                                            <td style="text-transform: uppercase;">{{ $consumo->materialesvagones->descripcion }}</td>
                                            <td class="text-center">{{ $consumo->cantidad }}</td>
                                            <td class="text-center">{{ $consumo->precio }}</td>
                                            <td class="text-center">{{ $consumo->precio * $consumo->cantidad }}</td>

                                            <td class="text-center">
                                                @if((Gate::check('isplanificador') || Gate::check('isJefe')) and empty($tallerVagon->fecha_salida_taller)) 
                                                <form action="{{ route('consumoVagones.destroy',$consumo->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link text-center" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                    </div>

                    


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
