  <div class="card-body ">
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Especifique los Defectos') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="descripcion" id="input-name" type="text" placeholder="{{ __('Ingrese descripcion') }}"
            value="{{ old('descripcion') ?? $catalogo->descripcion }}" required="true"/>
          @if ($errors->has('descripcion'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('descripcion') }}</span>
          @endif
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Lugar') }}</label>
      <div class="col-sm-2 text-center">
          <div class="form-group{{ $errors->has('lugar') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('lugar') ? ' is-invalid' : '' }} text-center"
                name="lugar" id="input-lugar"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($catalogo->lugares() as $lug)
                <option value="{{$lug}}" {{$catalogo->lugar == $lug ? 'selected' : '' }}>{{$lug}}</option>
              @endforeach
            </select>

            @if ($errors->has('lugar'))
              <span id="name-error" class="error text-danger" for="input-lugar">{{ $errors->first('lugar') }}</span>
            @endif
          </div>
        </div>
      </div>
    <div class="row">
      <label class="col-md-2 col-form-label">{{ __('RESPONSABLE') }}</label>
      <div class="col-md-4">
        <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
        <select name="responsable" class="responsable" style="width: 100%">
          @if (!empty($catalogo->datos->nombre))
            <option value="{{$catalogo->responsable}}">{{ $catalogo->datos->nombre}}</option>
          @endif
        </select>
        @if ($errors->has('responsable'))
          <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
        @endif

        </div>
      </div>
    </div>
    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Nro SAP') }}</label>
      <div class="col-sm-2">
        <div class="form-group{{ $errors->has('nro_sap') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
            name="nro_sap" min="0" id="input-name" type="number" placeholder="{{ __('Ingrese Nro sap') }}"
            value="{{ old('nro_sap') ?? $catalogo->nro_sap }}"/>
          @if ($errors->has('nro_sap'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('nro_sap') }}</span>
          @endif
        </div>
      </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Nota') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('nota') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="nota" id="input-name" type="text" placeholder="{{ __('Ingrese nota') }}"
            value="{{ old('nota') ?? $catalogo->nota }}"/>
          @if ($errors->has('nota'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('nota') }}</span>
          @endif
        </div>
      </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Especifique las Reparaciones') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('especificaciones_reparaciones') ? ' has-danger' : '' }}">
            <textarea class="form-control{{ $errors->has('especificaciones_reparaciones') ? ' is-invalid' : '' }}"
              name="especificaciones_reparaciones" id="input-especificaciones_reparaciones" placeholder="Ingrese lo que se realizo"/>{{ old('especificaciones_reparaciones') ?? $catalogo->especificaciones_reparaciones }}</textarea>
            @if ($errors->has('especificaciones_reparaciones'))
              <span id="name-error" class="error text-danger" for="input-especificaciones_reparaciones">{{ $errors->first('especificaciones_reparaciones') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('F. Mécanicos') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('mecanicos') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="mecanicos" id="input-name" type="text" placeholder="{{ __('Ingrese mecanicos, Ejemplo(xxxx,xxxx,xxxx)') }}"
            value="{{ old('mecanicos') ?? $catalogo->mecanicos }}"/>
          @if ($errors->has('mecanicos'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('mecanicos') }}</span>
          @endif
        </div>
      </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('F. Soldadores') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('soldadores') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="soldadores" id="input-name" type="text" placeholder="{{ __('Ingrese soldadores, Ejemplo(xxxx,xxxx,xxxx)') }}"
            value="{{ old('soldadores') ?? $catalogo->soldadores }}"/>
          @if ($errors->has('soldadores'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('soldadores') }}</span>
          @endif
        </div>
      </div>
        </div>

        <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('F. Responsable Taller') }}</label>
        <div class="col-sm-7">
        <div class="form-group{{ $errors->has('responsable_taller') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="responsable_taller" id="input-name" type="text" placeholder="{{ __('Ingrese responsable taller, Ejemplo(xxxx,xxxx,xxxx)') }}"
            value="{{ old('responsable_taller') ?? $catalogo->responsable_taller }}">
          @if ($errors->has('responsable_taller'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('responsable_taller') }}</span>
          @endif
        </div>
      </div>
        </div>

        <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('F. Supervisor') }}</label>
        <div class="col-sm-7">
        <div class="form-group{{ $errors->has('supervisor') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="supervisor" id="input-name" type="text" placeholder="{{ __('Ingrese supervisor, Ejemplo(xxxx,xxxx,xxxx)') }}"
            value="{{ old('supervisor') ?? $catalogo->supervisor }}"/>
          @if ($errors->has('supervisor'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('supervisor') }}</span>
          @endif
        </div>
      </div>
        </div>

        <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Cant. Personas') }}</label>
        <div class="col-sm-2">
        <div class="form-group{{ $errors->has('cant_persona') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
            name="cant_persona" id="input-name" type="number" min="0" placeholder="{{ __('Ingrese cant persona') }}"
            value="{{ old('cant_persona') ?? $catalogo->cant_persona }}"/>
          @if ($errors->has('cant_persona'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('cant_persona') }}</span>
          @endif
        </div>
      </div>
        </div>

        <input type="number" name="taller_id" value="{{$_GET['id_T']}}" hidden="yes">

 
  </div>
