@extends('layouts.app', ['activePage' => 'vagon_taller', 'titlePage' => __('Catalogo de Fallas Tarjeta')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">

            <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Actualizar Tarjeta de Vagon</h4>
              </div>
            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
            <div class="col-md-6" style="text-align: right;">
                <form method="post" id="formDeleteCatalogo-{{$catalogo->id}}" action="{{route('catalogo_fallas_tarjeta.destroy', [$catalogo->id] ) }}" class="">
                @csrf
                @method('delete')
                 <a rel="tooltip" class="btn btn-sm btn-rounded" title="Borrar" onclick="eliminarRegistro('formDeleteCatalogo-{{$catalogo->id}}')"style="background-color: #9B945F;"><i class="material-icons" style="font-size: 22px;">delete</i></a>
                </form>
                </a>  
              </div>
              @endif
            </div>

            <form method="post" action="{{route('catalogo_fallas_tarjeta.update', [$catalogo->id])}}" autocomplete="off" class="form-horizontal">
              @csrf
              @method('patch')
              @include('app.vagones.taller.catalogoTarjeta.form')
            <div class="col-md-12" align="center">
            <div class="card-footer justify-content-center">
            <a href="{{ route('taller.index') }}" class="btn btn-danger">{{ __('Cancelar') }}</a>
              <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
            </div>
          </div>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

