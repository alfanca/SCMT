@extends('layouts.app', ['activePage' => 'vagon_taller', 'titlePage' => __('Locomotoras')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

            <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Locomotoras</h4>
                        <p class="card-category">Administración de locomotoras</p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{route('administradorlocomotoras.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Agregar <i class="material-icons">add</i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>


            <div class="card-body">

              <div class="table-responsive">
                <table class="table" id="myTable2">
                  <thead class=" text-primary">
                    <tr>
                    	<th class="text-center">N° Loc</th>
                    	<th class="text-center">Tipo</th>
                    	<th class="text-center">Marca</th>
                        <th class="text-center">Modelo</th>
                        <th class="text-center">CECO</th>
                        <th class="text-center">N° Plan</th>
                        <th class="text-center">¿Desincorporada?</th>
                        <th class="text-center col-1">Fecha Desincorporación</th>
                    	<th class="text-center">Acciones</th>
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($locomotoras as $locomotora)
										<tr>
                      <td class="text-center">{{$locomotora->numero}}</td>
                      <td class="text-center">{{$locomotora->tipo}}</td>
                      <td class="text-center">{{$locomotora->marca}}</td>
                      <td class="text-center">{{$locomotora->modelo}}</td>
                      <td class="text-center">{{$locomotora->ceco}}</td>
                      <td class="text-center">{{$locomotora->n_plan}}</td>
                      <td class="text-center">{{$locomotora->estatus}}</td>
                      <td class="text-center">                      
                      @if ($locomotora->estatus == 'SI')
                      {{\Carbon\Carbon::parse($locomotora->fecha_desincorporacion)->format('d/m/Y')}}
                      @endif
                      </td>
                      <td class="td-actions text-center">
                        <form method="post" id="formDeleteLocomotora-{{$locomotora->id}}" action="{{route('administradorlocomotoras.destroy', [$locomotora->id] ) }}" class="">
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteLocomotora-{{$locomotora->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      </td>
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>

            <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
            <script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>
            <script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['52'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>

@endsection
