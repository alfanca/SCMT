@extends('layouts.app', ['activePage' => 'vagon_taller', 'titlePage' => __('Administración del Taller de Vagones')])
@section('content')

<div class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Taller de Vagones</h4>
                <p class="card-category">Administrar Taller de Vagones </p>
              </div>
            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
            <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Ingresar Vagon"
                    href="{{route('taller.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Ingresar Vagon
                  <i class="material-icons">add</i>
                </a>  
              </div>
              @endif
            </div>

        <div class="card-group mt-4" align="center">

              <div class="col-lg-4 col-md-6 col-sm-6">
          <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between">

                <p class="card-title col-12" style="font-size: 16px;">GONDOLAS</p>

                </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-tag text-center mt-1" style="font-size: 14px; color: #007c71; font-weight: bold;"></i> L/4</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesPatio->where('vagones_id', '<', 5000)->where('vagones_id', '>', 1000)->count()}}</h5></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-cogs text-center mt-1" style="font-size: 14px; color: #e66302; font-weight: bold;"></i> TALLER</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesTaller->where('vagones_id', '<', 5000)->where('vagones_id', '>', 1000)->count()}}</h5></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-wrench text-center mt-1" style="font-size: 14px; color: #6a8829; font-weight: bold;"></i> REPARADOS</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesReparados->where('vagones_id', '<', 5000)->where('vagones_id', '>', 1000)->count()}}</h5></div>
                </div>

                <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-exclamation-triangle text-center mt-1" style="font-size: 14px; color: #dc3545; font-weight: bold;"></i> TOTAL</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$taller->where('vagones_id', '<', 5000)->where('vagones_id', '>', 1000)->count()}}</h5></div>
              </div>
              </div>
            </div>            
           </div>


           <div class="col-lg-4 col-md-6 col-sm-6">
          <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between">

                <p class="card-title col-12" style="font-size: 16px;">TOLVAS</p>

                </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-tag text-center mt-1" style="font-size: 14px; color: #007c71; font-weight: bold;"></i> L/4</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesPatio->where('vagones_id', '>=', 5000)->count()}}</h5></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-cogs text-center mt-1" style="font-size: 14px; color: #e66302; font-weight: bold;"></i> TALLER</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesTaller->where('vagones_id', '>=', 5000)->count()}}</h5></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-wrench text-center mt-1" style="font-size: 14px; color: #6a8829; font-weight: bold;"></i> REPARADOS</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesReparados->where('vagones_id', '>=', 5000)->count()}}</h5></div>
                </div>

                <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-exclamation-triangle text-center mt-1" style="font-size: 14px; color: #dc3545; font-weight: bold;"></i> TOTAL</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$taller->where('vagones_id', '>=', 5000)->count()}}</h5></div>
              </div>
              </div>
            </div>            
           </div>


           <div class="col-lg-4 col-md-6 col-sm-6">
          <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between">

                <p class="card-title col-12" style="font-size: 16px;">VOLTEO</p>

                </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-tag text-center mt-1" style="font-size: 14px; color: #007c71; font-weight: bold;"></i> L/4</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesPatio->where('vagones_id', '<', 1000)->count()}}</h5></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-cogs text-center mt-1" style="font-size: 14px; color: #e66302; font-weight: bold;"></i> TALLER</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesTaller->where('vagones_id', '<', 1000)->count()}}</h5></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-wrench text-center mt-1" style="font-size: 14px; color: #6a8829; font-weight: bold;"></i> REPARADOS</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$vagonesReparados->where('vagones_id', '<', 1000)->count()}}</h5></div>
                </div>

                <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-exclamation-triangle text-center mt-1" style="font-size: 14px; color: #dc3545; font-weight: bold;"></i> TOTAL</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{$taller->where('vagones_id', '<', 1000)->count()}}</h5></div>
              </div>
              </div>
            </div>            
           </div>

            </div>
  
        <div class="row col-2" style="text-align: right; margin-left: 82%;">
                    <h6><b>Buscada General:&nbsp&nbsp&nbsp&nbsp</b></h6><br>
                    <input type="number" class="form-control pull-right" id="search" placeholder="Escriba su Busqueda">
                    </div>
        <div class="card-group mt-3">
            <div class="col-md-4">
              <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between" style="background: #007c71; border-radius: 10px;">
                           <p class="card-title col-12 text-center " style="font-size: 16px;"><i class="fa fa-tag text-center" style="font-size: 18px;"></i> &nbspLinea 4</p>
                    </div>
            <div class="card-body">
              <table id="taller" class="table table-hover col-md-4">              
                @foreach($vagonesPatio as $vagon)
                    <tr>
                         @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
                        <td>
                            <form method="post" id="formDeleteVagon-{{$vagon->id}}" 
                                        action="{{route('taller.destroy', [$vagon->id] ) }}">
                                      @csrf
                                      @method('delete')
                                      <a rel="tooltip" class="badge btn-link btn-sm puntero" title="Borrar"
                                        onclick="eliminarRegistro('formDeleteVagon-{{$vagon->id}}')" 
                                      ><i class="material-icons">delete</i></a>
                                    </form>
                        </td>
                         @endif
                        <td class="text-center">

                          @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))  

                          @if(!empty($vagon->catalogo_fallas_id))
                          <a rel="tooltip" class="badge badge-danger" href="{{ route('taller.show',$vagon->id) }}" title="Ver Detalle" style="font-size: 12px;">
                            {{$vagon->vagones_id}}

                          </a>
                          @else
                          <a rel="tooltip" class="badge badge-primary" title="Crear Tarjeta" href="{{ route('catalogo_fallas_tarjeta.create',['id_T'=>$vagon->id])}}" style="font-size: 12px;">
                            {{$vagon->vagones_id}}

                          </a>
                          @endif
                          @endif
                            </td>

                        <td class="text-center">{{$vagon->fecha_ingreso}}</td>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
                        <td>
                            <a class="badge btn-link btn-sm puntero" data-toggle="modal" 
                                data-target="#modal_cambio_estatus_vagon" 
                                data-vagon="{{$vagon->vagones_id}}"
                                data-id="{{$vagon->id}}"
                                data-estatus_proceso="2"
                                rel="tooltip"
                                title="Pasar al Taller" 
                                >
                                <i class="fa fa-cogs text-center" style="font-size: 16px;"></i>
                            </a>
                        </td>
                        @endif
                    </tr>
                @endforeach
                </table>
              </div>
            </div>            
           </div>

           <div class="col-md-4">
           <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between" style="background: #e66302; border-radius: 10px;">

                <p class="card-title col-12 text-center " style="font-size: 16px;"><i class="fa fa-cogs text-center" style="font-size: 18px;"></i> &nbspTaller (En Reparación) 

                      </p>

                    </div>
            <div class="card-body">
              <table id="taller" class="table table-hover col-md-4">  
                @foreach($vagonesTaller as $vagon)
                    <tr>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))                       
                        <td>
                            <form method="post" id="formRegresarVagon-{{$vagon->id}}" 
                                        action="{{route('taller.devolver_patio', [$vagon->id] ) }}">
                                      @csrf
                                      @method('patch')
                                      <a rel="tooltip" class="badge btn-link btn-sm puntero" title="Regresar al Patio"
                                        onclick="retornarEstatus('formRegresarVagon-{{$vagon->id}}')" 
                                      ><i class="material-icons">reply</i></a>
                            </form>
                        </td>
                        @endif
                        <td class="text-center">

                          @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))  

                          @if(!empty($vagon->catalogo_fallas_id))
                          <a rel="tooltip" class="badge badge-danger" href="{{ route('taller.show',$vagon->id) }}" title="Ver Detalle" style="font-size: 12px;">
                            {{$vagon->vagones_id}}

                          </a>
                          @else
                          <a rel="tooltip" class="badge badge-primary" title="Crear Tarjeta" href="{{ route('catalogo_fallas_tarjeta.create',['id_T'=>$vagon->id])}}" style="font-size: 12px;">
                            {{$vagon->vagones_id}}

                          </a>
                          @endif
                          @endif
                            </td>
                            <td> @if(!empty($vagon->proyecto_id))<a style="color: #808080" href="{{ route('proyectoVagones.show',$vagon->proyecto_id) }}"><i rel="tooltip" title="{{$vagon->vagon_proyecto->descripcion}}" class="fa fa-fw fa-folder-open" style="font-size: 18px"></i></a> @endif</td>
                        <td class="text-center">{{$vagon->fecha_ingreso_taller}}</td>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
                        <td>
                            <a  class="badge btn-link btn-sm puntero" data-toggle="modal" 
                                data-target="#modal_cambio_estatus_vagon" 
                                data-vagon="{{$vagon->vagones_id}}"
                                data-id="{{$vagon->id}}"
                                data-estatus_proceso="3"
                                rel="tooltip"
                                title="Pasar a Reparados" 
                                >
                                <i class="fa fa-wrench text-center" style="font-size: 16px;"></i>
                            </a>
                        </td>
                        @endif
                    </tr>
                @endforeach
                    </table>    
              </div>

            </div>  
          </div>


          <div class="col-md-4">
            <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between" style="background: #6a8829; border-radius: 10px;">

                <p class="card-title col-12 text-center " style="font-size: 16px;"><i class="fa fa-wrench text-center" style="font-size: 18px;"></i> &nbspTaller (Reparados) 

                          </p>

                    </div>
            <div class="card-body">
              <table id="taller" class="table table-hover col-md-4">              
                @foreach($vagonesReparados as $vagon)
                    <tr>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))                        
                        <td>
                            <form method="post" id="formRegresarVagonReparado-{{$vagon->id}}" 
                                        action="{{route('taller.devolver_patio', [$vagon->id] ) }}">
                                      @csrf
                                      @method('patch')
                                      <a rel="tooltip" class="badge btn-link btn-sm puntero" title="Regresar al Taller"
                                        onclick="retornarEstatus('formRegresarVagonReparado-{{$vagon->id}}')" 
                                      ><i class="material-icons">reply</i></a>
                            </form>
                        </td>
                        @endif
                        <td class="text-center">

                          @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))  

                          @if(!empty($vagon->catalogo_fallas_id))
                          <a rel="tooltip" class="badge badge-danger" href="{{ route('taller.show',$vagon->id) }}" title="Ver Detalle" style="font-size: 12px;">
                            {{$vagon->vagones_id}}

                          </a>
                          @else
                          <a rel="tooltip" class="badge badge-primary" title="Crear Tarjeta" href="{{ route('catalogo_fallas_tarjeta.create',['id_T'=>$vagon->id])}}" style="font-size: 12px;">
                            {{$vagon->vagones_id}}

                          </a>
                          @endif
                          @endif
                            </td>
                            <td> @if(!empty($vagon->proyecto_id))<a style="color: #808080" href="{{ route('proyectoVagones.show',$vagon->proyecto_id) }}"><i rel="tooltip" title="{{$vagon->vagon_proyecto->descripcion}}" class="fa fa-fw fa-folder-open" style="font-size: 18px"></i></a> @endif</td>
                        <td class="text-center">{{$vagon->fecha_ingreso_taller}}</td>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))  
                        <td>
                            <a class="badge btn-link btn-sm puntero" data-toggle="modal" 
                                data-target="#modal_cambio_estatus_vagon" 
                                data-vagon="{{$vagon->vagones_id}}"
                                data-id="{{$vagon->id}}"
                                data-estatus_proceso="4"
                                rel="tooltip"
                                title="Entregar a Operaciones"
                                >
                                <i class="material-icons">subway</i>
                            </a>
                        </td>
                        @endif
                    </tr>
                @endforeach
              </table>
              </div>
            </div>    
              </div>

            </div>
            </div> 

            </div>

                </div>

<script src="{{ asset('js') }}/jQueryv310.js"></script>

<script>
 // Write on keyup event of keyword input element
 $(document).ready(function(){
 $("#search").keyup(function(){
 _this = this;
 // Show only matching TR, hide rest of them
 $.each($("#taller tbody tr"), function() {
 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
 $(this).hide();
 else
 $(this).show();
 });
 });
});
</script>


@include('app.vagones.taller.modal_cambio_estatus')
@endsection