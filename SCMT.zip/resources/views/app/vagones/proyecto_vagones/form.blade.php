  <div class="card-body ">
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Descripción') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="descripcion" id="input-name" type="text" placeholder="{{ __('Ingrese descripcion del Proyecto') }}"
            value="{{ old('descripcion') ?? $proyectoVagon->descripcion }}" required="true"/>
          @if ($errors->has('descripcion'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('descripcion') }}</span>
          @endif
        </div>
      </div>
    </div>
    
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Fecha Inicio') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('fecha_inicio') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="fecha_inicio" id="input-name" type="date"
            value="{{ old('fecha_inicio') ?? $proyectoVagon->fecha_inicio }}">
          @if ($errors->has('fecha_inicio'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('fecha_inicio') }}</span>
          @endif
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Fecha Fin') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('fecha_fin') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="fecha_fin" id="input-name" type="date"
            value="{{ old('fecha_fin') ?? $proyectoVagon->fecha_fin }}">
          @if ($errors->has('fecha_fin'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('fecha_fin') }}</span>
          @endif
        </div>
      </div>
    </div>

    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Responsable') }}</label>
      <div class="form-group col-4{{ $errors->has('responsable') ? ' has-danger' : '' }}">
        <select name="responsable" class="responsable col-md-12">
          @if (!empty($proyectoVagon->datos->nombre))
          <option value="{{$proyectoVagon->responsable}}">{{ $proyectoVagon->datos->nombre}}</option>
          @endif
        </select>
          @if ($errors->has('responsable'))
          <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
          @endif
      </div>
    </div>

    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Jefe de Area Usuaria') }}</label>
      <div class="form-group col-4{{ $errors->has('responsable') ? ' has-danger' : '' }}">
        <select name="jefeareausuaria" class="responsable col-md-12">
          @if (!empty($proyectoVagon->datosjefearea->nombre))
          <option value="{{$proyectoVagon->jefeareausuaria}}">{{ $proyectoVagon->datosjefearea->nombre}}</option>
          @endif
        </select>
          @if ($errors->has('jefeareausuaria'))
          <span id="name-error" class="error text-danger" for="input-jefeareausuaria">{{ $errors->first('jefeareausuaria') }}</span>
          @endif
      </div>
    </div>


    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Jefe de Area Planificación') }}</label>
      <div class="form-group col-4{{ $errors->has('jefeplanificacion') ? ' has-danger' : '' }}">
        <select name="jefeplanificacion" class="responsable col-md-12">
          @if (!empty($proyectoVagon->datosjefeplanificacion->nombre))
          <option value="{{$proyectoVagon->jefeplanificacion}}">{{ $proyectoVagon->datosjefeplanificacion->nombre}}</option>
          @endif
        </select>
          @if ($errors->has('jefeplanificacion'))
          <span id="name-error" class="error text-danger" for="input-jefeplanificacion">{{ $errors->first('jefeplanificacion') }}</span>
          @endif
      </div>
    </div>



    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Nota') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('nota') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('nota') ? ' is-invalid' : '' }}"
              name="nota" id="input-nota" type="text" placeholder="{{ __('Ingrese Nota') }}"
              value="{{ old('nota') ?? $proyectoVagon->nota }}"/>
            @if ($errors->has('nota'))
              <span id="name-error" class="error text-danger" for="input-nota">{{ $errors->first('nota') }}</span>
            @endif
          </div>
        </div>
    </div>

   



  </div>
