@extends('layouts.app', ['activePage' => 'vagon_taller', 'titlePage' => __('Proyecto de Vagones')])
@section('content')

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Detalles de Proyecto</h4>
                        <p class="card-category">{{$proyectoVagon->descripcion}}
                        </p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{ route('proyectoVagones.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply" title="Regresar a Proyectos"></i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>
                    <br>
                    <br>
                    <br>
                    <div class="card-body">

                        <div class="col-md-12">
                        
                        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
                        <div class="text-right">
                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                        @if($proyectoVagon->estatus != 'FINALIZADO')
                        <a class="btn btn-sm btn" style="background-color: #9B945F;" href="{{ route('proyectoVagones.edit',[$proyectoVagon->id]) }}"><i class="fa fa-fw fa-edit"></i> Editar</a>
                        @endif  
                        @endif
                        </div>
                        <br>
              
                        <div class="card-group mt-4">
                        <div class="form-group col-2">
                            <strong><b>N° Loc: </b></strong>
                            {{ $proyectoVagon->descripcion }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Inicio:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse($proyectoVagon->fecha_inicio)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Fin:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse($proyectoVagon->fecha_fin)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>Estatus: </b>&nbsp&nbsp</strong>
                            {{ $proyectoVagon->estatus }}
                        </div>
                        </div>
                        <hr>
                        <h4 class="col-md-12 text-center mt-3">Responsables</h4>
                        <br>
                        <div class="card-group mt-4">
                        <div class="form-group col-4">
                            <strong><b>Responsable:</b>&nbsp&nbsp</strong>
                            {{ $proyectoVagon->datos->nombre }}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Jefe del Area Usuaria:</b>&nbsp&nbsp</strong>
                            {{ $proyectoVagon->datosjefearea->nombre }}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Jefe de Planificación:</b>&nbsp&nbsp</strong>
                            {{ $proyectoVagon->datosjefeplanificacion->nombre }}
                        </div>
                        </div>

                        <hr>
                        <h4 class="col-md-12 text-center mt-3">Notas y Responsables</h4>
                        <br>
                        <div class="card-group mt-4">
                        <div class="form-group col-6">
                            <strong><b>Nota:</b></strong>
                            {{ $proyectoVagon->nota }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Usuario Crea:</b></strong>
                            {{ $proyectoVagon->usuario_crea }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Usuario Actualiza:</b></strong>
                            {{ $proyectoVagon->usuario_actualiza }}
                        </div>
                    </div>

                     <hr>
                    <h4 class="col-md-12 text-center mt-3">Proyecto Detalle</h4>
                    <br>
              
                    <div class="card-body">


            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-vagones" data-toggle="tab">
                        <i class="fas fa-tasks" style="font-size: 15px;"></i>  Inventario
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-consumibles" data-toggle="tab">
                        <i class="fas fa-boxes" style="font-size: 15px;"></i> Consumibles
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-consumibles_agrupado" data-toggle="tab">
                        <i class="fas fa-box" style="font-size: 15px;"></i> Consumibles Resumen
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
                <div class="tab-content">

                <div class="tab-pane active" id="tab-vagones">
                <br>
                <div class="text-right">
                @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                @if($proyectoVagon->estatus != 'FINALIZADO')
                <a class="btn btn-sm btn" style="background-color: #9B945F;" href="{{ route('taller.create',['id_proyecto'=>$proyectoVagon->id]) }}"><i class="fas fa-plus"></i> Agregar Vagon</a>
                @endif
                @endif
                </div>
                </br>
                <div class="table-responsive">
                <table class="table" id="myTable">
                  <thead class="thead">
                    <tr>
                        <th class="text-center">Nro Vagon</th>
                        <th class="text-center">Fecha Ingreso</th>
                        <th class="text-center">Descripción</th>
                        <th class="text-center">Pasar al Taller</th>
                        <th class="text-center">Fecha Salida</th>
                        <th class="text-center">Borrar</th>

                        
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($DetalleproyectoVagon as $vagones)
                                        <tr>
                      <td class="text-center"><a href="{{ route('proyectoVagonesConsumo.create',['id_P'=>$proyectoVagon->id,'id_v'=>$vagones->vagones_id,'id_T'=>$vagones->id]) }}">{{ $vagones->vagones_id }}</a></td>
                      <td class="text-center">{{ $vagones->fecha_ingreso }}</td>
                      <td style="text-transform: uppercase;">{{ $vagones->descripcion }}</td>
                      <td class="text-center">
                        @if(empty($vagones->fecha_ingreso_taller))
                            <a class="badge btn-link btn-sm puntero" data-toggle="modal" 
                                data-target="#modal_cambio_estatus_vagon" 
                                data-vagon="{{$vagones->vagones_id}}"
                                data-id="{{$vagones->id}}"
                                data-estatus_proceso="2"
                                rel="tooltip"
                                title="Pasar al Taller" 
                                >
                                <i class="fa fa-cogs text-center" style="font-size: 16px;"></i>
                            </a>
                            @else
                            Fue Ingresado el: {{$vagones->fecha_ingreso_taller}}
                        @endif
                        </td>
                      <td class="text-center">{{ $vagones->fecha_salida_taller }}</td>
                      <td class="text-center">
                       @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))

                       <form method="post" id="formDeleteVagon-{{$vagones->id}}" action="{{route('taller.destroy', [$vagones->id] ) }}">
                        @csrf
                        @method('delete')
                        <a rel="tooltip" class="badge btn-link btn-sm puntero" title="Borrar" onclick="eliminarRegistro('formDeleteVagon-{{$vagones->id}}')">
                        <i class="material-icons">delete</i></a>
                        </form>

                        @endif
                     </td>
                      
                    </tr>
                    @empty
                    <tr><td colspan="4">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
          </div>

          <div class="tab-pane" id="tab-consumibles">

            <div class="table-responsive mt-2">
                            <table class="table table-striped table-hover" id="myTable2">
                                <thead class="thead">
                                    <tr>
                                        
                                        <th class="text-center">N° Vagon</th>
                                        <th class="text-center">N° Parte</th>
                                        <th class="text-center">N° SAP</th>
                                        <th class="text-center">Componente</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Precio Unit.</th>
                                        <th class="text-center">Precio Total</th>
                                        <th class="text-center">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($proyectoConsumoVagones as $consumo)
                                        <tr>
                                            

                                            <td class="text-center">{{ $consumo->vagones_id }}</td>
                                            <td class="text-center">{{ $consumo->materialesvagones->parte }}</td>
                                            <td class="text-center">{{ $consumo->materialesvagones->sap }}</td>
                                            <td style="text-transform: uppercase;">{{ $consumo->materialesvagones->descripcion }}</td>
                                            <td class="text-center">{{ $consumo->cantidad }}</td>
                                            <td class="text-center">{{ $consumo->precio_unit }}</td>
                                            <td class="text-center">{{ $consumo->precio_unit * $consumo->cantidad }}</td>

                                            <td class="text-center">
                                                <form action="{{ route('proyectoVagonesConsumo.destroy',$consumo->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link text-center" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

          </div>


          <div class="tab-pane" id="tab-consumibles_agrupado">

            <div class="table-responsive mt-2">
                            <table class="table table-striped table-hover" id="myTable3">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">Nro Orden</th>
                                        <th class="text-center">Nro SAP</th>
                                        <th class="text-center">Componente</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Precio Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($consumoPorTipo as $grupoConsumo)
                                        <tr>
                                            <td class="text-center">{{$grupoConsumo[0]->materialesvagones->parte??''}}</td>
                                            <td class="text-center">{{$grupoConsumo[0]->materialesvagones->sap??''}}</td>
                                            <td style="text-transform: uppercase;">{{$grupoConsumo[0]->materialesvagones->descripcion??''}}</td>
                                            <td class="text-center" style="text-transform: uppercase;">
                                               @php
                                               $sumaplan = 0;
                                               @endphp
                                               @foreach ($grupoConsumo as $consumoCantidad)

                                               <!--{{$sumaplan+=$consumoCantidad->cantidad}}-->
                                    
                                               @endforeach

                                               {{$sumaplan}}


                                            </td>

                                            <td class="text-center" style="text-transform: uppercase;">

                                               @php
                                               $total = 0;
                                               @endphp
                                               @foreach ($grupoConsumo as $consumoCantidad)

                                               <!--{{$total+=$consumoCantidad->total}}-->
                                    
                                               @endforeach

                                               {{$total}}



                                            </td>



                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

          </div>


                    </div>
                    


       
                </div>
            </div>
        </div>
    </section>
    @include('app.vagones.taller.modal_cambio_estatus')
    <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['10'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['10'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable3').DataTable( {

    lengthMenu: ['10'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable3 thead tr').clone(true).appendTo( '#myTable3 thead' );
    $('#myTable3 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable3').DataTable();
} );
</script>
@endsection
