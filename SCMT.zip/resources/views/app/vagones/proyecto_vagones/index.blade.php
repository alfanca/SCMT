@extends('layouts.app', ['activePage' => 'vagon_taller', 'titlePage' => __('Proyectos de Vagones')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

            <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Proyectos de Vagones</h4>
                        <p class="card-category">Administración de Proyecto de Vagones</p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{route('proyectoVagones.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Agregar <i class="material-icons">add</i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>


            <div class="card-body">

              <div class="table-responsive">
                <table class="table" id="myTable2">
                  <thead class=" text-primary">
                    <tr>
                      <th class="text-center">Nro</th>
                    	<th class="text-center">Descripción</th>
                    	<th class="text-center">Fecha Inicio</th>
                    	<th class="text-center">Fecha Fin</th>
                        <th class="text-center">Estatus</th>
                        <th class="text-center">Nota</th>
                        <th class="text-center">U.C</th>
                        <th class="text-center">U.A</th>
                    	<th class="text-center">Acciones</th>
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($proyectoVagones as $proyecto)
										<tr>
                      <td class="text-center">{{ ++$i }}</td>
                      <td><a rel="tooltip" title="Ver Proyecto" class="" href="{{ route('proyectoVagones.show',$proyecto->id) }}">{{$proyecto->descripcion}}</a></td>
                      <td class="text-center">{{$proyecto->fecha_inicio}}</td>
                      <td class="text-center">{{$proyecto->fecha_fin}}</td>
                      <td class="text-center">{{$proyecto->estatus}}</td>
                      <td class="text-center">{{$proyecto->nota}}</td>
                      <td class="text-center">{{$proyecto->usuario_crea}}</td>
                      <td class="text-center">{{$proyecto->usuario_actualiza}}</td>

                      <td class="td-actions text-center">
                        <form method="post" id="formDeleteLocomotora-{{$proyecto->id}}" action="{{route('proyectoVagones.destroy', [$proyecto->id] ) }}" class="">
				                <a rel="tooltip" class="btn btn-success btn-link" href="{{route('proyectoVagones.edit', [$proyecto->id] ) }}" data-original-title="" title="Editar">
                          <i class="material-icons">edit</i>
                          <div class="ripple-container"></div>
                        </a>
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteLocomotora-{{$proyecto->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      </td>
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>

            <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
            <script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>
            <script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['52'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>

@endsection
