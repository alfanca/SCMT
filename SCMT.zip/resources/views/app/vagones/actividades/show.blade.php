@extends('layouts.app', ['activePage' => 'Actividades_Vagones', 'titlePage' => __('Actividades de Vagones')])

@section('content')
<div class="content">
	<div class="container-fluid">
		@include('app.comun.nav_dias', 	['url'=> 'vagones/actividades/'])
			
      	@foreach($listadoActividades as $turno => $actividades)
    	<div class="row">
      		<div class="col-md-12">
	 			<div class="card">
		            <div class="card-header card-header-primary">
		              <h4 class="card-title text-center">TURNO {{$turno}}</h4>
		            </div>
		            <div class="card-body">
		            	<?php $actividadPorTurno = $actividades->where('turno', $turno)->sortBy('locomotora_id'); ?>
		            	<div class="row">
		            		<table class="table table-hover table-bordered table-responsive table-small">
		            			<thead>
		            				<tr>
		            					<th class="col-2 text-center">Area</th>
		            					<th class="col-5 text-center">Descripción del Servicio</th>
		            					<th>Responsable</th>
		            					<th>Tiempo de ejecución</th>
		            					<th>Estatus</th>
		            					@can('isJefe')
										<th class="text-center">Analista</th>
		            					@endcan				            					
		            				</tr>
		            			</thead>
		            	@forelse($actividadPorTurno as $actividad)
		            		<tbody>
			            		<tr>
				                	<td>{{$actividad->area}}</td>
				                	<td class="text-justify"style="text-transform: uppercase;">{{$actividad->actividad}}</td>
				                	<td class="text-center">{{$actividad->datos->nombre}}</td>
				                	<td class="text-center">{{$actividad->tiempo}} horas</td>
				                	<td class="text-center">{{$actividad->estatus}}</td>
	            					@can('isJefe')
										<td class="text-center">
											{{$actividad->usuario_crea}} / 
											{{\Carbon\Carbon::parse($actividad->created_at)->format('d-m H:i')}}
										</td>
	            					@endcan						                	
				              		</tr>
			              	</tbody>		            	
		            	@empty
		            	@endforelse
		            	</table>
		            </div>
		        </div>
      		</div>
    	</div>
  </div>
      	@endforeach
</div>
</div>
@endsection