@extends('layouts.app', ['activePage' => 'admingondola', 'titlePage' => __('Actualizar Vagon')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header card-header-primary">
              <h4 class="card-title">{{ __('ACTUALIZAR INSPECCION') }}</h4>
            </div>
            <form method="post" action="{{route('inspeccion.update', [$inspeccion->id])}}" autocomplete="off" class="form-horizontal">
              @csrf
              @method('patch')
              @include('app.vagones.inspecciones.form')
              
            <div class="col-md-12" align="center">
            <div class="card-footer justify-content-center">
            <a href="{{route('inspeccion.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
              <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
            </div>
          </div>
          @include('app.vagones.inspecciones.form_edit')
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
