@extends('layouts.app', ['activePage' => 'inventario_vagon', 'titlePage' => __('Disponibilidad Operativa de Vagones')])
@section('content')

<div class="content">
	<div class="container-fluid">

        <div class="card-body text-center">INVENTARIO DE VAGONES
        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
        <a rel="tooltip" title="Agregar vagones al inventario"
			href="{{route('inventario.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
	        <i class="col-md-5">Crear + </i>
		</a>
         @endif
        </div>                            

        <div class="row">
        <div class="card-body mb-3" style="text-align: left;">
            <div>Cantidad registrada: {{$vagones->count()}}</div>
    <div class="row d-flex justify-content-between">
    @foreach ($vagones->chunk(100) as $chunk)
        <div class="col-xs-3 p-4">
        <table class="table table-responsive table-bordered"> 
        <tr>
            <th>N° Vagón</th>
            <th>Estatus</th>
            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
            <th>Borrar</th>
            @endif
        </tr>
        @forelse ($chunk as $vagones)
        <tr id="vagones{{$vagones->id}}">
            <td class="text-center">{{$vagones->vagones_id}}</td>
            <td class="text-center">{{$vagones->estatus}}</td>
            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
            <td>
                <a rel="tooltip" class="btn btn-danger btn-link btn-sm" title="Borrar" onclick="eliminarVagonInventario('{{$vagones->id}}', '{{Auth::user()->name}}')"> <i class="material-icons">delete</i></a>    
            </td>
            @endif
        </tr>               
        @empty
        <tr id="vagones{{$vagones->id}}">
            <td colspan="2">No hay Vagones</td>
        </tr>
        @endforelse 
        </table>
        </div>

    @endforeach
    </div>
</div>
    </div>
    </div>
</div>
@endsection
