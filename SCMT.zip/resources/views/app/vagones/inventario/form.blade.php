<div class="card-body mb-4" style="text-align: left;">
  <div class="row">
	  
	  <label class="col-md-2 col-form-label">{{ __('AÑO:') }}</label>
	  <div class="col-md-4">
	    <div class="form-group{{ $errors->has('hora_inicio') ? ' has-danger' : '' }}">
	      <input type="number" name="anho" value="{{ old('anho') ?? $anho }}" min="2020">   
	    @if ($errors->has('anho'))
	      <span id="name-error" class="error text-danger" for="input-anho">{{ $errors->first('anho') }}</span>
	    @endif
	    </div>
	  </div>  

	</div>
  <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('ESTATUS') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">
          <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }}"
              name="estatus" id="input-estatus"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true"
            >
            <option value="">SELECCIONE</option>
            @foreach($vagones->estatusVagones() as $clave => $valor)
              <option value="{{$clave}}">{{$valor}}</option>
            @endforeach
          </select>
          @if ($errors->has('estatus'))
            <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
          @endif
        </div>
      </div>
  </div>

  <div class="row">
    <label class="col-md-2 col-form-label">{{ __('VAGONES') }}</label>
    <div class="col-md-10">
      <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
        <select name="vagones[]" class="vagones_sin_filtro" multiple="multiple" style="width: 100%">
          @if (!empty($vagones->datos->nombre))
            <option value="{{$vagones->responsable}}">{{ $vagones->datos->nombre}}</option>
          @endif
        </select>
        @if ($errors->has('responsable'))
          <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
        @endif
      </div>
    </div>
  </div>
  
</div> 


