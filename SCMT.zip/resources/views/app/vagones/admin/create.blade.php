@extends('layouts.app', ['activePage' => 'adminvagones', 'titlePage' => __('Crear Vagon')])

@section('content')


  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
          <div class="card-header card-header-primary">
            <h4 class="card-title">{{ __('Crear Vagon') }}</h4>
          </div>
          <form method="post" action="/vagones/admin" autocomplete="off" class="form-horizontal">
            @csrf
            @include('app.vagones.admin.form')
            <div class="card-footer justify-content-center">
              <a href="{{route('admin.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

@endsection
