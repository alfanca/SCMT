@extends('layouts.app', ['activePage' => 'adminvagones', 'titlePage' => __('Administrar Góndolas')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Vagones Góndolas</h4>
                <p class="card-category">Viajes realizados por Góndolas</p>
              </div>
             
            </div>
             <div class="row d-flex justify-content-center">
              <div class="col-md-10">
                <table id="myTable"  class="table table-responsive table-bordered" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th></th>
                    	<th>Fecha</th>
                    	<th>Tren</th>
                    	<th>Hora movimiento</th>
                      <br>
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($vagon as $viaje)
										<tr class="text-center">
                      <td>{{$loop->index+1}}</td>
                      <td>{{\Carbon\Carbon::parse($viaje->fecha)->format('d-m-Y')}}</td>
                      <td>{{$viaje->tren}}</td>
                      <td>{{\Carbon\Carbon::parse($viaje->hora_salida)->format('d/m/Y H:i')}}</td>
                    </tr>
                    @empty
                   	<tr><td colspan="3">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    var table = $('#myTable').DataTable();
} );
</script>

@endsection

