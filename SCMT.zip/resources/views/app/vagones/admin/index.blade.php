@extends('layouts.app', ['activePage' => 'adminvagones', 'titlePage' => __('Administrador de Vagones')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-tabs card-header-primary">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TIPO:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-gondola" data-toggle="tab">
                        <span class="badge badge-danger text-center" style="color: white; font-size: 12px; font-weight: bold;">

                          {{$disponibilidad+$vagonesmantenimiento+$vagonesalarmaconteo}}

                        </span> GONDOLAS
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-tolva" data-toggle="tab">
                        <span class="badge badge-danger text-center" style="color: white; font-size: 12px; font-weight: bold;">

                          {{$tolvasfisicoconteo}}

                        </span> TOLVAS
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-volteo" data-toggle="tab">
                        <span class="badge badge-danger text-center" style="color: white; font-size: 12px; font-weight: bold;">

                          {{$volteoconteo - $volteotallerconteo}}

                        </span> VOLTEO
                        <div class="ripple-container"></div>
                      </a>
                    </li>


                    <li class="nav-item">
                      <a class="nav-link" href="#tab-tanque" data-toggle="tab">
                        <span class="badge badge-danger text-center" style="color: white; font-size: 12px; font-weight: bold;">

                          {{$tanqueconteo - $tanquetallerconteo}}

                        </span> Tanque
                        <div class="ripple-container"></div>
                      </a>
                    </li>

                    <li class="nav-item">
                      <a class="nav-link" href="#tab-plataforma" data-toggle="tab">
                        <span class="badge badge-danger text-center" style="color: white; font-size: 12px; font-weight: bold;">

                          {{$plataformaconteo - $plataformatallerconteo}}

                        </span> Plataforma
                        <div class="ripple-container"></div>
                      </a>
                    </li>

                    @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-ciclo" data-toggle="tab">
                        <span class="badge badge-danger text-center" style="color: white; font-weight: bold;"><i class="fa fa-recycle" style="font-size: 14px"></i></span> Ciclo
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    @endif
                  </ul>
                </div>
              </div>
            </div>

            <div class="tab-content">

                <div class="tab-pane active" id="tab-gondola">

                  <div class="card-body">

              <div class="col-sm-12 text-center" align="center">


              <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: black; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-tag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{'1.105'}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-info text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Activa</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{count($gondolas)}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-times text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Fuera de Servicio</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{1105-(count($gondolas))}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #ff8000; color: white; border-top-left-radius: 10px;">
           
                          <i class="fas fa-ban text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; font-weight: normal; border-radius: 10px;">Descarrilados</div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonDescarrilamientosConteoDescarrilados}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>



              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #37589b; border-top-left-radius: 10px;" >
           
                          <i class="fa fa-circle text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Flota Física</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$flotafisica}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #28a745;border-top-left-radius: 10px;" >
           
                          <i class="fa fa-check text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Operativos</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$disponibilidad ?? ''}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #ffc107;border-top-left-radius: 10px;">
           
                          <i class="fa fa-wrench text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Reparados</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonesmantenimiento}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-exclamation-triangle text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Fuera de Ciclo</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonesalarmaconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
            </div>
            <br>
 

            <div class="row">
        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-activa" data-toggle="tab">
                        <i class="fa fa-info" style="font-size: 15px;"></i> Flota Activa
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-fisica" data-toggle="tab">
                        <i class="fa fa-circle" style="font-size: 15px;"></i> Flota Física
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-operativa" data-toggle="tab">
                        <i class="fa fa-check" style="font-size: 15px;"></i> Operativos
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-alarma" data-toggle="tab">
                        <i class="fa fa-exclamation-triangle" style="font-size: 15px;"></i> Fuera de Ciclo
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-recuperacion" data-toggle="tab">
                        <i class="fa fa-cogs" style="font-size: 15px;"></i> Por Recuperación
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

              <div class="tab-content">

                <div class="tab-pane" id="tab-activa">
                   <div class="card-body table-responsive">
                    <table id="myTable4"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Estado</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($gondolas as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td class="{{$vagon->bandera_alarma}}" style="border-radius: 20px;">{{$vagon->bandera_alarma}}
                      </td>
                      <td style="text-transform: uppercase;">{{$vagon->ultima_ubicacion}}</td>
                      @if ($vagon->disponible === 'Mantenimiento')
                      <td>{{$vagon->disponible}}</td>
                      @elseif ($vagon->bandera_alarma === 'ALARMA')
                      <td>Fuera de Ciclo</td>
                      @elseif ($vagon->ultima_ubicacion === 'DESCONOCIDA')
                      <td>Averiado</td>
                      @else
                      <td>{{$vagon->disponible}}</td>
                      @endif
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>


                <div class="tab-pane" id="tab-fisica">
                   <div class="card-body table-responsive">
                    <table id="myTable2"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Estado</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($vagonesfisico as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      @if ($vagon->disponible === 'Mantenimiento')
                      <td>{{$vagon->zona_geografica}}</td>
                      @elseif ($vagon->bandera_alarma === 'ALARMA')
                      <td>Ciudad Piar</td>
                      @else
                      <td>{{$vagon->zona_geografica}}</td>
                      @endif
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td class="{{$vagon->bandera_alarma}}" style="border-radius: 20px;">{{$vagon->bandera_alarma}}
                      </td>
                      @if ($vagon->disponible === 'Mantenimiento')
                      <td style="text-transform: uppercase;">{{$vagon->ultima_ubicacion}}</td>
                      @elseif ($vagon->bandera_alarma === 'ALARMA')
                      <td style="text-transform: uppercase;">Averiado</td>
                      @else
                      <td style="text-transform: uppercase;">{{$vagon->ultima_ubicacion}}</td>
                      @endif
                      @if ($vagon->disponible === 'Mantenimiento')
                      <td>{{$vagon->disponible}}</td>
                      @elseif ($vagon->bandera_alarma === 'ALARMA')
                      <td>Fuera de Ciclo</td>
                      @elseif ($vagon->ultima_ubicacion === 'DESCONOCIDA')
                      <td>Averiado</td>
                      @else
                      <td>{{$vagon->disponible}}</td>
                      @endif
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                <div class="tab-pane active" id="tab-operativa">
                   <div class="card-body table-responsive">
                    <table id="myTable"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Estado</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($disponibilidadoperativatabla as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      @if ($vagon->disponible === 'Mantenimiento')
                      <td>{{$vagon->zona_geografica}}</td>
                      @elseif ($vagon->bandera_alarma === 'ALARMA')
                      <td>Ciudad Piar</td>
                      @else
                      <td>{{$vagon->zona_geografica}}</td>
                      @endif
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td class="{{$vagon->bandera_alarma}}" style="border-radius: 20px;">{{$vagon->bandera_alarma}}
                      </td>
                      @if ($vagon->disponible === 'Mantenimiento')
                      <td style="text-transform: uppercase;">{{$vagon->ultima_ubicacion}}</td>
                      @elseif ($vagon->bandera_alarma === 'ALARMA')
                      <td style="text-transform: uppercase;">Averiado</td>
                      @else
                      <td style="text-transform: uppercase;">{{$vagon->ultima_ubicacion}}</td>
                      @endif
                      @if ($vagon->disponible === 'Mantenimiento')
                      <td>{{$vagon->disponible}}</td>
                      @elseif ($vagon->bandera_alarma === 'ALARMA')
                      <td>Averiado</td>
                      @elseif ($vagon->ultima_ubicacion === 'DESCONOCIDA')
                      <td>Averiado</td>
                      @else
                      <td>{{$vagon->disponible}}</td>
                      @endif
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-alarma">
                   <div class="card-body table-responsive">
                    <table id="myTable5"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Estado</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($vagonesalarmatabla as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>

                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td class="{{$vagon->bandera_alarma}}" style="border-radius: 20px;">{{$vagon->bandera_alarma}}
                      </td>
                      <td style="text-transform: uppercase;">{{$vagon->ultima_ubicacion}}</td>  
                      @if ($vagon->bandera_alarma === 'ALARMA')
                      <td>Fuera de Ciclo</td>
                      @else
                      <td>{{$vagon->disponible}}</td>
                      @endif
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-recuperacion">
                   <div class="card-body table-responsive">
                    <table id="myTable3"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Dias ultimo reg.</th>
                      <th>Estado</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($vagonesdesconocidostabla as $vagon)
                    <tr class="text-center">
                      <td>{{$vagon->id}}</td>
                      <td style="text-transform: uppercase;">{{$vagon->ultima_vez}}</td>
                      <td class="{{$vagon->bandera_alarma}}" style="border-radius: 20px;">{{$vagon->bandera_alarma}}
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>
              </div>


        </div>




            </div>
          </div>      

      </div>


          <div class="tab-pane" id="tab-tolva">


            <div class="card-body">

              <div class="col-sm-12">


              <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: black; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-tag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{'988'}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-info text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Activa</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tolvasconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-times text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Fuera de Servicio</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{988-$tolvasconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #ff8000; color: white; border-top-left-radius: 10px;">
           
                          <i class="fas fa-ban text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; font-weight: normal; border-radius: 10px;">Descarrilados</div>
                          <p class="text-center" style="font-size: 18px;">{{$vagonDescarrilamientosConteoDescarriladosTolvas}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>



              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #37589b;border-top-left-radius: 10px;">
           
                          <i class="fa fa-circle text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Física</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tolvasconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                         <div class="col-md-3 text-center" style="background-color: #28a745;border-top-left-radius: 10px;" >
           
                          <i class="fa fa-check text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Operativa</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tolvasoperativasconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>


              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #ffc107;border-top-left-radius: 10px;">
           
                          <i class="fa fa-wrench text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Reparados</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tolvasreaparadoconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-exclamation-triangle text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Ubic. Desconocida</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tolvasdesconocidasconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
            <br>
            <br>

        <div class="row">
        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-activatolva" data-toggle="tab">
                        <i class="fa fa-info" style="font-size: 15px;"></i> Flota Activa
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-fisicatolva" data-toggle="tab">
                        <i class="fa fa-circle" style="font-size: 15px;"></i> Flota Física
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-tallertolva" data-toggle="tab">
                        <i class="fa fa-cogs" style="font-size: 15px;"></i> Taller
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
 
              <div class="tab-content" style="width:100%">

                <div class="tab-pane" id="tab-activatolva">
                   <div class="card-body table-responsive">
                    <table id="tablatone"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tolvas as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>


                <div class="tab-pane active" id="tab-fisicatolva">
                   <div class="card-body table-responsive">
                    <table id="tablados"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tolvasfisica as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-tallertolva">
                   <div class="card-body table-responsive">
                    <table id="tablatres"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tolvastaller as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>
              </div>
        </div>
      </div>
     </div>
      </div>
          </div>




          <div class="tab-pane" id="tab-volteo">


            <div class="card-body">

              <div class="col-sm-12">


              <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: black; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-tag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{'38'}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-info text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Activa</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$volteoconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-times text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Fuera de Servicio</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{38-$volteoconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>



              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #37589b;border-top-left-radius: 10px;">
           
                          <i class="fa fa-circle text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Física</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$volteofisicoconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
            <br>
            <br>

        <div class="row">
        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-activavolteo" data-toggle="tab">
                        <i class="fa fa-info" style="font-size: 15px;"></i> Flota Activa
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-fisicavolteo" data-toggle="tab">
                        <i class="fa fa-circle" style="font-size: 15px;"></i> Flota Física
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-tallervolteo" data-toggle="tab">
                        <i class="fa fa-cogs" style="font-size: 15px;"></i> Taller
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
 
              <div class="tab-content" style="width:100%">

                <div class="tab-pane" id="tab-activavolteo">
                   <div class="card-body table-responsive">
                    <table id="tablavolteoactivo"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($volteo as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>


                <div class="tab-pane active" id="tab-fisicavolteo">
                   <div class="card-body table-responsive">
                    <table id="tablavolteofisico"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($volteofisica as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-tallervolteo">
                   <div class="card-body table-responsive">
                    <table id="tablavolteotaller"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($volteotaller as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>
              </div>
        </div>
      </div>
     </div>
      </div>

          </div>


          <div class="tab-pane" id="tab-tanque">


            <div class="card-body">

              <div class="col-sm-12">


              <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: black; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-tag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{'13'}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-info text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Activa</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tanqueconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-times text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Fuera de Servicio</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{13-$tanqueconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>



              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #37589b;border-top-left-radius: 10px;">
           
                          <i class="fa fa-circle text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Física</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tanquefisicoconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
            <br>
            <br>

        <div class="row">
        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-activatanque" data-toggle="tab">
                        <i class="fa fa-info" style="font-size: 15px;"></i> Flota Activa
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-fisicatanque" data-toggle="tab">
                        <i class="fa fa-circle" style="font-size: 15px;"></i> Flota Física
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-tallertanque" data-toggle="tab">
                        <i class="fa fa-cogs" style="font-size: 15px;"></i> Taller
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
 
              <div class="tab-content" style="width:100%">

                <div class="tab-pane" id="tab-activatanque">
                   <div class="card-body table-responsive">
                    <table id="tablatanqueactivo"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tanque as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>


                <div class="tab-pane active" id="tab-fisicatanque">
                   <div class="card-body table-responsive">
                    <table id="tablatanquefisico"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tanquefisica as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-tallertanque">
                   <div class="card-body table-responsive">
                    <table id="tablatanquetaller"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tanquetaller as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>
              </div>
        </div>
      </div>
     </div>
      </div>

          </div>


          <div class="tab-pane" id="tab-plataforma">


            <div class="card-body">

              <div class="col-sm-12">


              <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: black; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-tag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{'37'}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-info text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Activa</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$plataformaconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-times text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Fuera de Servicio</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{37-$plataformaconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>



              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #37589b;border-top-left-radius: 10px;">
           
                          <i class="fa fa-circle text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Flota Física</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$plataformatallerconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
            <br>
            <br>

        <div class="row">
        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-activaplataforma" data-toggle="tab">
                        <i class="fa fa-info" style="font-size: 15px;"></i> Flota Activa
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-fisicaplataforma" data-toggle="tab">
                        <i class="fa fa-circle" style="font-size: 15px;"></i> Flota Física
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-tallerplataforma" data-toggle="tab">
                        <i class="fa fa-cogs" style="font-size: 15px;"></i> Taller
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
 
              <div class="tab-content" style="width:100%">

                <div class="tab-pane" id="tab-activaplataforma">
                   <div class="card-body table-responsive">
                    <table id="tablaplataformaactivo"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($plataforma as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>


                <div class="tab-pane active" id="tab-fisicaplataforma">
                   <div class="card-body table-responsive">
                    <table id="tablaplataformafisico"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($plataformafisica as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-tallerplataforma">
                   <div class="card-body table-responsive">
                    <table id="tablaplataformataller"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($plataformataller as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>
              </div>
        </div>
      </div>
     </div>
      </div>

          </div>



          @if(!empty($ciclos))
          <div class="tab-pane" id="tab-ciclo">
          
          <div class="card-body">

          <div class="col-sm-12">

        <div class="card-header card-header-tabs card-header-primary mt-4" style="background: #9B945F;">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-detalle" data-toggle="tab">
                        <i class="fas fa-bars" style="font-size: 15px;"></i> Detalle
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-graficas" data-toggle="tab">
                        <i class="fas fa-chart-line" style="font-size: 15px;"></i> Gráficas
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

          <div class="tab-content">

                <div class="tab-pane active" id="tab-detalle">

            <div class="card-body">
              <div class="row">
              </div>
              <div class="table-responsive">
                <table id="ciclovagon"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                      <th class="text-center">Semana</th>
                      <th class="text-center">Vagones procesados</th>
                      <th class="text-center">Ciclo</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($ciclos as $ciclo)
                    <tr>
                      <td class="text-center">{{$ciclo['semana']}}</td>
                      <td class="text-center">{{$ciclo['vagones']}}</td>
                      <td class="text-center">{{$ciclo['ciclo']}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>

          </div>


            <div class="tab-pane" id="tab-graficas">
                 <div class="card-group col-md-12">

                 <div id="container" class="container my-4" style="border: solid; border-width: 0.8px; border-color: black;">
                 </div>

                 <div id="containerdos" class="container my-4" style="border: solid; border-width: 0.8px; border-color: black;">
                 </div>

            </div>

            </div>

        </div>

      </div>
    </div>


      </div>
      @endif





             
          </div>
      </div>
    </div>
  </div>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tabla').DataTable( {

    lengthMenu: ['10'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
</script>


<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable3').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable3 thead tr').clone(true).appendTo( '#myTable3 thead' );
    $('#myTable3 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable3').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable4').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable4 thead tr').clone(true).appendTo( '#myTable4 thead' );
    $('#myTable4 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable4').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable5').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable5 thead tr').clone(true).appendTo( '#myTable5 thead' );
    $('#myTable5 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable5').DataTable();
} );
</script>


<script type="text/javascript">
  $(document).ready( function () {
    $('#tablatone').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablatone thead tr').clone(true).appendTo( '#tablatone thead' );
    $('#tablatone thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablatone').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablados').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablados thead tr').clone(true).appendTo( '#tablados thead' );
    $('#tablados thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablados').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablatres').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablatres thead tr').clone(true).appendTo( '#tablatres thead' );
    $('#tablatres thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablatres').DataTable();
} );
</script>


<script type="text/javascript">
  $(document).ready( function () {
    $('#tablavolteoactivo').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablavolteoactivo thead tr').clone(true).appendTo( '#tablavolteoactivo thead' );
    $('#tablavolteoactivo thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablavolteoactivo').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablavolteofisico').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablavolteofisico thead tr').clone(true).appendTo( '#tablavolteofisico thead' );
    $('#tablavolteofisico thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablavolteofisico').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablavolteotaller').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablavolteotaller thead tr').clone(true).appendTo( '#tablavolteotaller thead' );
    $('#tablavolteotaller thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablavolteotaller').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#ciclovagon').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    var table = $('#ciclovagon').DataTable();
} );
</script>


<script type="text/javascript">
  $(document).ready( function () {
    $('#tablatanqueactivo').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablatanqueactivo thead tr').clone(true).appendTo( '#tablatanqueactivo thead' );
    $('#tablatanqueactivo thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablatanqueactivo').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablatanquefisico').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablatanquefisico thead tr').clone(true).appendTo( '#tablatanquefisico thead' );
    $('#tablatanquefisico thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablatanquefisico').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablatanquetaller').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablatanquetaller thead tr').clone(true).appendTo( '#tablatanquetaller thead' );
    $('#tablatanquetaller thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablatanquetaller').DataTable();
} );
</script>


<script type="text/javascript">
  $(document).ready( function () {
    $('#tablaplataformaactivo').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablaplataformaactivo thead tr').clone(true).appendTo( '#tablaplataformaactivo thead' );
    $('#tablaplataformaactivo thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablaplataformaactivo').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablaplataformafisico').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablaplataformafisico thead tr').clone(true).appendTo( '#tablaplataformafisico thead' );
    $('#tablaplataformafisico thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablaplataformafisico').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablaplataformataller').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablaplataformataller thead tr').clone(true).appendTo( '#tablaplataformataller thead' );
    $('#tablaplataformataller thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablaplataformataller').DataTable();
} );
</script>


   <script src="{{ asset('highchart') }}/code/highcharts.js"></script>
   <script src="{{ asset('highchart') }}/code/highcharts-3d.js"></script>
   <script src="{{ asset('highchart') }}/code/highcharts-3d.src.js"></script>
   <script src="{{ asset('highchart') }}/code/modules/data.js"></script>
   <script src="{{ asset('highchart') }}/code/modules/exporting.js"></script>
   <script src="{{ asset('highchart') }}/code/modules/offline-exporting.js"></script>

   @if(!empty($ciclos))

    <table id="datatable" hidden="true">
        <thead>
            <tr>
                <th class="col-3 text-center"></th>
                <th class="col-3 text-center">Ciclo (Horas)</th>
            </tr>
        </thead>
        <tbody>
          @php 

          $hoy = \Carbon\Carbon::parse(now())->format('W');

          $cuatrosemanas = $hoy - 5;

          @endphp


          @forelse(array_slice(Arr::except($ciclos, [52] ),$cuatrosemanas) as $ciclo)
            <tr>
                <td>Sem #{{$ciclo['semana']}}</td>
                <td>{{$ciclo['ciclo']}}</td>
            </tr>
            @empty
            @endforelse

        </tbody>
    </table>

    <table id="datatabledos" hidden="true">
        <thead>
            <tr>
                <th class="col-3 text-center"></th>
                <th class="col-3 text-center">Ciclo (Horas)</th>
            </tr>
        </thead>
        <tbody>
          @forelse($ciclosmes as $ciclo)
            <tr>
                <td>@if($ciclo['semana'] == 1)
                  ENERO
                  @elseif($ciclo['semana'] == 2)
                  FEBRERO
                  @elseif($ciclo['semana'] == 3)
                  MARZO
                  @elseif($ciclo['semana'] == 4)
                  ABRIL
                  @elseif($ciclo['semana'] == 5)
                  MAYO
                  @elseif($ciclo['semana'] == 6)
                  JUNIO
                  @elseif($ciclo['semana'] == 7)
                  JULIO
                  @elseif($ciclo['semana'] == 8)
                  AGOSTO
                  @elseif($ciclo['semana'] == 9)
                  SEPTIEMBRE
                  @elseif($ciclo['semana'] == 10)
                  OCTUBRE
                  @elseif($ciclo['semana'] == 11)
                  NOVIEMBRE
                  @elseif($ciclo['semana'] == 12)
                  DICIEMBRE
                  @endif
                </td>
                <td>{{$ciclo['ciclo']}}</td>
            </tr>
            @empty
            @endforelse

        </tbody>
    </table>




    <script type="text/javascript">
Highcharts.chart('container', {
    data: {
        table: 'datatable'
    },
    chart: {
        
    },

    credits:{
      enabled: false
    },

    title: {
        text: '<strong style = "color: black;">CICLO DE VAGONES SEMANAL (HORAS)</strong>'
    },

    xAxis: {
        type: 'category',
        min: 0,
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: '<strong style = "color: black;">HORAS</strong>'
        }
    },


    plotOptions: {

        series: {
            color: '#d2091d',
            colorByPoint: false,
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y: f}'
            }

        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>'+'La ' +this.point.name.toLowerCase() + ' tiene' + ' ' +this.point.y +'<p> Hrs/Min</p>';
        }
    }
});
    </script>

      <script type="text/javascript">
Highcharts.chart('containerdos', {
    data: {
        table: 'datatabledos'
    },
    chart: {
        
    },

    credits:{
      enabled: false
    },

    title: {
        text: '<strong style = "color: black;">CICLO DE VAGONES MENSUAL (HORAS)</strong>'
    },

    xAxis: {
        type: 'category',
        min: 0,
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: '<strong style = "color: black;">HORAS</strong>'
        }
    },


    plotOptions: {

        series: {
            color: '#d2091d',
            colorByPoint: false,
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y: f}'
            }

        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>'+ 'El mes de '+this.point.name.toLowerCase() + ' tiene' + ' ' +this.point.y +'<p> Hrs/Min</p>';
        }
    }
});
    </script>

    @endif

@endsection

