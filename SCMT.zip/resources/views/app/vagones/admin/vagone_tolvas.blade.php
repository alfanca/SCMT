@extends('layouts.app', ['activePage' => 'admintolva', 'titlePage' => __('Administrar Tolvas')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Vagones Tolvas</h4>
                <p class="card-category">Administración Vagones Tolvas</p>
              </div>
              @if(Gate::check('isplanificador') || Gate::check('isJefe'))
            <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Crear vagón"
                    href="{{route('admin.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Crear vagón
                  <i class="material-icons">add</i>
                </a>  
              </div>
              @endif
            </div>
            <div class="card-body">

              <div class="col-sm-12">


              <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: black; color: white;">
           
                          <i class="fa fa-tag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Flota</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{'998'}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;">
           
                          <i class="fa fa-info text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Flota Activa</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tolvasconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;">
           
                          <i class="fa fa-times text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Fuera de Servicio</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{998-$tolvasconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>



              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb;" >
           
                          <i class="fa fa-circle text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>Flota Física</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$tolvasfisicoconteo}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
            <br>
            <br>

        <div class="row">
        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-activa" data-toggle="tab">
                        <i class="fa fa-info" style="font-size: 15px;"></i> Flota Activa
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-fisica" data-toggle="tab">
                        <i class="fa fa-circle" style="font-size: 15px;"></i> Flota Física
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-taller" data-toggle="tab">
                        <i class="fa fa-cogs" style="font-size: 15px;"></i> Taller
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
 
              <div class="tab-content" style="width:100%">

                <div class="tab-pane" id="tab-activa">
                   <div class="card-body table-responsive">
                    <table id="tablatone"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tolvas as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>


                <div class="tab-pane active" id="tab-fisica">
                   <div class="card-body table-responsive">
                    <table id="tablados"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tolvasfisica as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-taller">
                   <div class="card-body table-responsive">
                    <table id="tablatres"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th>N° Vagon</th>
                      <th>Zona</th>
                      <th>Ultimo registro</th>
                      <th>Dias ultimo reg.</th>
                      <th>Ubicación</th>
                      <th>Estatus</th>
                      <br>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($tolvastaller as $vagon)
                    <tr class="text-center">
                      <td><a target="_blank" href="{{route('admin.show', [$vagon->id])}}" rel="tooltip">{{$vagon->id}}</a></td>
                      <td>{{$vagon->zona_geografica}}</td>
                      <td>{{$vagon->fecha_ultima_ubicacion}}</td>
                      <td>{{$vagon->ultima_vez}}</td>
                      <td>{{$vagon->ultima_ubicacion}}</td>
                      <td>{{$vagon->disponible}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>
              </div>
        </div>
      </div>
          

            

             
          </div>
      </div>
    </div>
  </div>
</div>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablatone').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablatone thead tr').clone(true).appendTo( '#tablatone thead' );
    $('#tablatone thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablatone').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablados').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablados thead tr').clone(true).appendTo( '#tablados thead' );
    $('#tablados thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablados').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#tablatres').DataTable( {

    lengthMenu: ['1200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );
  $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#tablatres thead tr').clone(true).appendTo( '#tablatres thead' );
    $('#tablatres thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#tablatres').DataTable();
} );
</script>



@endsection

