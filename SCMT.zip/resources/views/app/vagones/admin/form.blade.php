  <div class="card-body">

    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('NÚMERO') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('id') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="id" id="input-name" type="text" placeholder="{{ __('Ingrese número del vagón') }}"
            value="{{ old('id') ?? $vagon-> id }}" required="true"/>
          @if ($errors->has('id'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('id') }}</span>
          @endif
        </div>
      </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('ZONA') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">
            <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }}" name="zona_geografica" class="form-select" aria-label="Default select example">
            <option selected>SELECCIONE</option>
            <option value="Puerto Ordaz">Puerto Ordaz</option>
            <option value="Ciudad Piar">Ciudad Piar</option>
            </select>
            @if ($errors->has('estatus'))
              <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('ESTATUS') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">
            <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }}"
                name="estatus" id="input-estatus"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($vagon->estatusVagones() as $clave => $valor)
                <option value="{{$clave}}" {{$vagon->estatus == $valor ? 'selected' : '' }}>{{$valor}}</option>
              @endforeach
            </select>
            @if ($errors->has('estatus'))
              <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('TIPO VAGÓN') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('tipo') ? ' has-danger' : '' }}">
            <select class="custom-select form-control{{ $errors->has('tipo') ? ' is-invalid' : '' }}"
                name="tipo" id="input-tipo"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($vagon->tipoVagones() as $valor)
                <option value="{{$valor}}" {{$vagon->tipo == $valor ? 'selected' : '' }}>{{$valor}}</option>
              @endforeach
            </select>
            @if ($errors->has('tipo'))
              <span id="name-error" class="error text-danger" for="input-tipo">{{ $errors->first('tipo') }}</span>
            @endif
          </div>
        </div>
    </div>

  </div>
