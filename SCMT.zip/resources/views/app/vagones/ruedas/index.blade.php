@extends('layouts.app', ['activePage' => 'Vagones', 'titlePage' => __('Medición de Rueda de Vagones')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

            <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Vagones Ruedas</h4>
                        <p class="card-category">Medición de Rueda de Vagones</p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                      <a rel="tooltip" title="Ir al Taller de Vagones" 
                            href="{{ route('taller.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-cog"></i>
                        </a> 
                        <a rel="tooltip"
                            href="{{route('vagonesRuedas.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Agregar <i class="material-icons">add</i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>


            <div class="card-body">
              <div align="center" >@include('app.comun.nav_anho')</div>
              <div class="table-responsive">
                <table class="table" id="myTable2">
                  <thead class=" text-primary">
                    <tr>
                    	<th class="text-center">N° Vagon</th>
                    	<th class="text-center">Fecha</th>
                    	<th class="text-center">1</th>
                        <th class="text-center">8</th>
                        <th class="text-center">2</th>
                        <th class="text-center">7</th>
                        <th class="text-center">3</th>
                        <th class="text-center">6</th>
                        <th class="text-center">4</th>
                        <th class="text-center">5</th>
                        <th class="text-center">Max</th>
                    	<th class="text-center">Acciones</th>
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($ruedas as $rueda)
										<tr>
                      <td class="text-center">{{$rueda->vagon_id}}</td> 
                      <td class="text-center">{{\Carbon\Carbon::parse($rueda->fecha)->format('d/m/Y')}}</td>
                      <td class="text-center">{{$rueda->rueda_1}}</td>
                      <td class="text-center">{{$rueda->rueda_8}}</td>
                      <td class="text-center">{{$rueda->rueda_2}}</td>
                      <td class="text-center">{{$rueda->rueda_7}}</td>
                      <td class="text-center">{{$rueda->rueda_3}}</td>
                      <td class="text-center">{{$rueda->rueda_6}}</td>
                      <td class="text-center">{{$rueda->rueda_4}}</td>
                      <td class="text-center">{{$rueda->rueda_5}}</td>
                      @if(max($rueda->rueda_1, $rueda->rueda_2, $rueda->rueda_3, $rueda->rueda_4, $rueda->rueda_5, $rueda->rueda_6, $rueda->rueda_7, $rueda->rueda_8) == 7)
                      <td class="text-center" style="background-color: yellow; color: black; border-radius: 20px; height: 10px; width: 10px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">{{max($rueda->rueda_1, $rueda->rueda_2, $rueda->rueda_3, $rueda->rueda_4, $rueda->rueda_5, $rueda->rueda_6, $rueda->rueda_7, $rueda->rueda_8)}}</td>
                      @elseif(max($rueda->rueda_1, $rueda->rueda_2, $rueda->rueda_3, $rueda->rueda_4, $rueda->rueda_5, $rueda->rueda_6, $rueda->rueda_7, $rueda->rueda_8) > 7)
                      <td class="text-center" style="background-color: red; color: black; border-radius: 10px; border-radius: 20px; height: 5px; width: 30px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">{{max($rueda->rueda_1, $rueda->rueda_2, $rueda->rueda_3, $rueda->rueda_4, $rueda->rueda_5, $rueda->rueda_6, $rueda->rueda_7, $rueda->rueda_8)}}</td>
                      @else
                      <td class="text-center">{{max($rueda->rueda_1, $rueda->rueda_2, $rueda->rueda_3, $rueda->rueda_4, $rueda->rueda_5, $rueda->rueda_6, $rueda->rueda_7, $rueda->rueda_8)}}</td>
                      @endif


                      <td class="td-actions text-center">
                        <form method="post" id="formDeletevagonesRuedas-{{$rueda->id}}" action="{{route('vagonesRuedas.destroy', [$rueda->id] ) }}" class="">
				                <a rel="tooltip" class="btn btn-success btn-link" href="{{route('vagonesRuedas.edit', [$rueda->id] ) }}" data-original-title="" title="Editar">
                          <i class="material-icons">edit</i>
                          <div class="ripple-container"></div>
                        </a>
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeletevagonesRuedas-{{$rueda->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      </td>
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>

            <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
            <script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>
            <script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['52'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>

@endsection
