  <div class="card-body ">
    <div class="card-group">
                <label class="col-form-label">{{ __('N° Vagon') }}</label>
            <div class="col-md-3">
              <div class="form-group{{ $errors->has('vagon_id') ? ' has-danger' : '' }}">
                <select name="vagon_id" class="vagones_poruno" style="width: 80%">
                  @if (!empty($rueda->vagon_id))
                    <option value="{{$rueda->vagon_id}}">{{ $rueda->vagon_id}}</option>
                  @endif
                </select>
                @if ($errors->has('vagon_id'))
                  <span id="name-error" class="error text-danger" for="input-vagon_id">{{ $errors->first('vagon_id') }}</span>
                @endif
              </div>
            </div>

            <label class="label-control">Fecha</label>

                   <div class="col-md-4">
                   <div class="form-group{{ $errors->has('fecha') ? ' has-danger' : '' }} text-center">
                   <input  type="date" name="fecha" class="form-control" style="width:40%; text-align: center;" 
                    value="{{ old('fecha') ?? $rueda->fecha }}"/>
                    @if ($errors->has('fecha'))
                    <span id="name-error" class="error text-danger" for="input-fecha">{{ $errors->first('fecha') }}</span>
                    @endif
                  </div>
                </div>

              
              </div>

                <div class="table-responsive mt-4">
                <table class="table table-responsive">
                  <thead class=" text-primary">
                    <tr>
                      <th class="text-center" colspan="12" style="background-color: #6a1816; color: white; border-radius: 10px;">N° Ruedas</th>
                    </tr>
                    <tr>
                      <th class="text-center">1</th>
                        <th class="text-center">8</th>
                        <th class="text-center">2</th>
                        <th class="text-center">7</th>
                        <th class="text-center">3</th>
                        <th class="text-center">6</th>
                        <th class="text-center">4</th>
                        <th class="text-center">5</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="text-center">

                      <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
                      name="rueda_1" id="input-name" type="number" value="{{ old('rueda_1') ?? $rueda->rueda_1 }}" min="0" max="9">

                      </td> 

                      <td class="text-center">

                      <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
                      name="rueda_8" id="input-name" type="number" value="{{ old('rueda_8') ?? $rueda->rueda_8 }}" min="0" max="9">

                      </td>
                      
                      <td class="text-center">

                      <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
                      name="rueda_2" id="input-name" type="number" value="{{ old('rueda_2') ?? $rueda->rueda_2 }}" min="0" max="9">

                      </td>
                      
                      <td class="text-center">

                      <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
                      name="rueda_7" id="input-name" type="number" value="{{ old('rueda_7') ?? $rueda->rueda_7 }}" min="0" max="9">

                      </td>
                      
                      <td class="text-center">

                      <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
                      name="rueda_3" id="input-name" type="number" value="{{ old('rueda_3') ?? $rueda->rueda_3 }}" min="0" max="9">

                      </td>
                      
                      <td class="text-center">

                      <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
                      name="rueda_6" id="input-name" type="number" value="{{ old('rueda_6') ?? $rueda->rueda_6 }}" min="0" max="9">

                      </td>
                      
                      <td class="text-center">

                      <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
                      name="rueda_4" id="input-name" type="number" value="{{ old('rueda_4') ?? $rueda->rueda_4 }}" min="0" max="9">

                      </td>
                      
                      <td class="text-center">

                      <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
                      name="rueda_5" id="input-name" type="number" value="{{ old('rueda_5') ?? $rueda->rueda_5 }}" min="0" max="9">

                      </td>
                      
                    </tr>
                  </tbody>
                </table>
              </div>

  </div>
