@extends('layouts.app', ['activePage' => 'asistencia', 'titlePage' => __('Asistencia')])
@section('content')
@if(auth()->user()->id == 11 || Gate::check('isJefe'))
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">Asistencia Planificación de Mantenimiento</h4>
              <p class="card-category">Control de Asistencia</p>
            </div>
            <div class="card-body">
              <div class="card-body">
              <div class="row">
    
             </div>
           <div class="row justify-content-center h-100">
           <form method="get" autocomplete="off" action="{{route('asistenciaControl')}}" class="form-horizontal">
            @include('app.comun.nav_calendario_busqueda')
           </form>            
           </div>
              </div>
              <div class="table-responsive">
                <table id= 'myTable' class="table">
                  <thead class=" text-primary">
                    <tr>
                          
                          <th class="col-4 text-center">Personal</th>
                          <th class="text-center">Semana</th>
                          <th class="text-center">Día</th>
                          <th class="text-center">Fecha</th>
                          <th class="text-center">Hora</th>
                          <th class="text-center">Turno</th>
                   
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($asistencias as $asistencia)
                    <tr>
                      
                          <td align="center" style="text-transform: uppercase;">{{$asistencia->user}}</td>
                          <td align="center">{{\Carbon\Carbon::parse($asistencia->last_login)->isoFormat('w')}}</td>
                          <td class="text-center" style="text-transform: uppercase;">{{\Carbon\Carbon::parse($asistencia->last_login)->isoFormat('dddd')}}</td>
                          <td class="text-center" >{{\Carbon\Carbon::parse($asistencia->last_login)->isoFormat('DD-MM-YYYY')}}</td>
                          <td class="text-center">{{\Carbon\Carbon::parse($asistencia->last_login)->format('H:i')}}</td>
                          @if(\Carbon\Carbon::parse($asistencia->last_login)->format('H') > '22' | \Carbon\Carbon::parse($asistencia->last_login)->format('H') < '7' )
                          <td align="center">1</td>
                          @elseif(\Carbon\Carbon::parse($asistencia->last_login)->format('H') < '15' )
                          <td align="center">2</td>
                          @elseif(\Carbon\Carbon::parse($asistencia->last_login)->format('H') > '14' | \Carbon\Carbon::parse($asistencia->last_login)->format('H') < '22' )
                          <td align="center">3</td>
                          @endif


                
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {
    ordering: false,
    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Registros)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

@else
<div class="content">
  <div class="container-fluid">
  <div class="row align-items-center">
<h1 class="text-center col-sm-12 mt-5">No tiene Permisos Para Ver Esta Función</h1>
<h1 class="text-center col-sm-12 mt-3">
<a href="{{route('home')}}" class="text-center btn btn-danger" style="font-size: 18px">{{ __('Regresar') }}</a>
</h1>
</div>
</div>
</div>
@endif
@endsection
