@extends('layouts.app', ['activePage' => 'asistencia', 'titlePage' => __('Asistencia')])
@section('content')
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                 <div class="card ">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">{{ __('Actualizar Usuario') }}</h4>
                  </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('user.update', $user->id) }}"  role="form">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('app.usuarios.form')

                            <div class="col-md-12" align="center">
                            <div class="card-footer justify-content-center">
                            <a href="{{route('usuarioControl')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                              <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
                            </div>
                          </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
