  <div class="card-body ">
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Nombre y Apellido') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="name" id="input-name" type="text" placeholder="{{ __('Ingrese Nombre y Apellido') }}"
            value="{{ old('name') ?? $user->name }}" required="true" readonly="true" />
          @if ($errors->has('name'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('name') }}</span>
          @endif
        </div>
      </div>
    </div>

    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Usuario') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('email') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"
            name="email" id="input-email" type="text" placeholder="{{ __('Ingrese Nombre y Apellido') }}"
            value="{{ old('email') ?? $user->email}}" required= "true" readonly="true"/>
          @if ($errors->has('email'))
            <span id="email-error" class="error text-danger" for="input-email">{{ $errors->first('email') }}</span>
          @endif
        </div>
      </div>
    </div>


    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Permiso') }}</label>
      <div class="col-sm-7">
          <div class="form-group{{ $errors->has('rol') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('rol') ? ' is-invalid' : '' }}"
                name="rol" id="input-rol"placeholder="{{ __('Ingrese potencia de user') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($user->permisos() as $use)
                <option value="{{$use}}" {{$user->rol == $use ? 'selected' : '' }}>{{$use}}</option>
              @endforeach
            </select>


            @if ($errors->has('rol'))
              <span id="name-error" class="error text-danger" for="input-rol">{{ $errors->first('rol') }}</span>
            @endif
          </div>
        </div>
      </div>
    


    </div>

