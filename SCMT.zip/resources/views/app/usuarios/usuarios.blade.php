@extends('layouts.app', ['activePage' => 'usuarios', 'titlePage' => __('Control de Usuarios')])
@section('content')
@if(auth()->user()->id == 11 || Gate::check('isJefe'))
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Usuarios Planificación de Mantenimiento y Control (SPMC)</h4>
                <p class="card-category">Control de Usuarios</p>
              </div>
              @if(auth()->user()->id == 11 || Gate::check('isJefe'))
            <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Crear Usuario"
                    href="{{route('register')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                  <i class="fas fa-user-plus" style="font-size: 18px;"></i>
                </a>  
              </div>
              @endif
            </div>


            <div class="card-body">

              <div class="table-responsive">
                <table id= 'myTable' class="table">
                  <thead class=" text-primary">
                    <tr>
                          
                          <th class="col-4 text-center">Nombre y Apellido</th>
                          <th class="text-center">Usuario</th>
                          <th class="text-center">Creado</th>
                          <th class="text-center">Modificado</th>
                          <th class="text-center">Permiso</th>
                          <th class="text-center">Acciones</th>
                   
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($usuarios as $usuario)
                    <tr>
                      
                          <td align="center" style="text-transform: uppercase;">{{$usuario->name}}</td>
                          <td align="center">{{$usuario->email}}</td>
                          <td align="center">{{$usuario->created_at}}</td>
                          <td align="center">{{$usuario->updated_at}}</td>
                          <td align="center" style="text-transform: uppercase;">{{$usuario->rol}}</td>
                           <td class="td-actions text-center">
                            @if(auth()->user()->id == 11 || Gate::check('isJefe'))
                            <a rel="tooltip" class="btn btn-success btn-link" href="{{route('user.edit', [$usuario->id])}}" data-original-title="" title="Editar">
                              <i class="material-icons">edit</i>
                              <div class="ripple-container"></div>
                            </a>
                            @endif
                          </td>

                         


                
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {
    ordering: false,
    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Registros)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

@else
<div class="content">
  <div class="container-fluid">
  <div class="row align-items-center">
<h1 class="text-center col-sm-12 mt-5">No tiene Permisos Para Ver Usuarios</h1>
<h1 class="text-center col-sm-12 mt-3">
<a href="{{route('home')}}" class="text-center btn btn-danger" style="font-size: 18px">{{ __('Regresar') }}</a>
</h1>
</div>
</div>
</div>
@endif
@endsection
