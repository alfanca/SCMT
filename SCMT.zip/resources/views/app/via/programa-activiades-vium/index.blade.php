@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Actividades de Vías')])
@section('content')
 <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Actividades de Vías</h4>
                        <p class="card-category">Inspecciones y Correctivos Realizados en Vias</p>
                      </div>
                    <div class="col-md-6" style="text-align: right;">
                      <div class="btn-group">
                        <button class="btn btn-sm btn-rounded dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background: #9b945f; color: white;" rel="tooltip" title="Ir a:">
                          <i class="fas fa-location-arrow" style="font-size: 17px"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdownProfile" style="border: 3px solid; border-radius: 20px; border-color: white;">
                           <a class="dropdown-item" href="{{route('programavias.index')}}" style="border-radius: 20px;">{{ __('Programa Vías') }}</a>
                           <div class="dropdown-divider"></div>
                           <a class="dropdown-item" href="{{route('programaviasanual.index')}}" style="border-radius: 20px;">{{ __('Premisa Anual') }}</a>
                           
                        </div> 
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                      <div class="btn-group">
                      <button class="btn btn-sm btn-rounded dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background: #9b945f; color: white;">
                      <i class="fas fa-plus" style="font-size: 17px"></i>
                      <div class="ripple-container"></div></button>
                      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile" style="border: 3px solid; border-radius: 20px; border-color: white;">
                         <a class="dropdown-item" href="{{route('programaviasactividades.create',['tipo'=>'KM'])}}" style="border-radius: 20px;">{{ __('Inspección Km') }}</a>
                         <div class="dropdown-divider"></div>
                         <a class="dropdown-item" href="{{route('programaviasactividades.create',['tipo'=>'EA'])}}" style="border-radius: 20px;">{{ __('Inspeccion CambiaVias') }}</a>
                      </div>
                    </div>
                      @endif
                      </div>
                    </div>
                    <div class="card-body">

                       <form method="get" autocomplete="off" action="{{route('programaviasactividades.index')}}" class="form-horizontal" style="margin-left: 260px" role="form">
                         <div class="row col-md-8">
                           <label class="col-md-3 col-form-label">{{ __('FECHA INICIO') }}</label>
                           <div class="col-md-3">
                               <input type="date" class="form-control"  id="fecha_inicio" type="text" name="fecha_inicio" value="{{$fechas['fecha_inicio'] ?? ''}}"/>
                           </div>

                           <label class="col-md-2 col-form-label">{{ __('FECHA FIN') }}</label>
                           <div class="col-md-3">
                               <input type="date" class="form-control"  id="fecha_fin" type="text" name="fecha_fin" value="{{$fechas['fecha_fin']  ?? ''}}"/>
                           </div>
                           <div class="col-md-1">
                               <input type="submit" value="Buscar" class="btn btn-primary">
                           </div>
                        </div>
                       </form>



                         <div class="mt-5">

                        <div class="card-header card-header-tabs card-header-warning">
                          <div class="nav-tabs-navigation">
                            <div class="nav-tabs-wrapper">
                              <span class="nav-tabs-title">TABLAS:</span>
                              <ul class="nav nav-tabs" data-tabs="tabs">
                                <li class="nav-item">
                                  <a class=" nav-link active" href="#tab-resumen" data-toggle="tab">
                                    <i class="fa fa-fw fa-clipboard-list" style="font-size: 15px;"></i> Resumen
                                    <div class="ripple-container"></div>
                                  </a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="#tab-detalle" data-toggle="tab">
                                    <i class="fa fa-fw fa-file-alt" style="font-size: 15px;"></i> Detalle
                                    <div class="ripple-container"></div>
                                  </a>
                                </li>

                              </ul>
                            </div>
                          </div>
                        </div>

              <div class="tab-content">
                <div class="tab-pane active" id="tab-resumen">
                  <div class="card-group" align="center">

                  @foreach($AgruparPorPremisaAnual as $agrupar =>$datos)
                  <div class="col-xl-3 col-md-4 mt-1">
                    <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                      <div class="card-content">
                          <div class="media align-items-stretch">
                              @if($agrupar == 'INSPECCION CAMBIAVIAS')
                            <div class="col-md-3 text-center" style="background-color: #eb3f3f; color: white;">
                              <i class="fas fa-route text-center mt-4" style="font-size: 25px;"></i>
                              @elseif($agrupar == 'INSPECCION A PIE')
                            <div class="col-md-3 text-center" style="background-color: #ced159; color: white;">
                              <i class="fas fa-walking text-center mt-4" style="font-size: 25px;"></i>
                              @elseif($agrupar == 'INSPECCION ALTO RIEL')
                            <div class="col-md-3 text-center" style="background-color: #374ed3; color: white;">
                              <i class="fas fa-truck-pickup text-center mt-4" style="font-size: 25px;"></i>
                              @elseif($agrupar == 'INSPECCION LOCOMOTORA')
                            <div class="col-md-3 text-center" style="background-color: #06bb48; color: white;">
                              <i class="fas fa-train text-center mt-4" style="font-size: 25px;"></i>
                              @elseif($agrupar == 'INSPECCION PUENTE')
                            <div class="col-md-3 text-center" style="background-color: #a3896a; color: white;">
                              <i class="fas fa-archway text-center mt-4" style="font-size: 25px;"></i>
                              @endif
                            
                          </div>
                            <div class="media-body col-sm-10">
                              <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;"><strong>{{$agrupar}}</strong></div>
                              <p class="text-center" style="font-size: 18px;">{{$datos->sum('tramo_km_total')}}
                              @if($agrupar == 'INSPECCION CAMBIAVIAS')
                                 <span style="font-size: 10px">EA</span>
                              @else
                                 <span style="font-size: 10px">KM</span>
                              @endif
                              </p>
                            </div>
                          </div>
                      </div>
                    </div>
                  </div>
                  @endforeach
                </div>


                    <div class="table-responsive mt-3">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>  
                                    <th class="text-center">Descripción</th>
                                    <th class="text-center">Unid</th>
                                    <th class="text-center">Tramo</th>
                                    <th class="text-center">Tramo Total</th>  
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($AgruparprogramaActiviadesVia as $agrupar =>$datos)
                                    <tr>
                                    <td class="text-center">{{$datos[0]->programaAnualVium->descripcion}}</td>
                                    <td class="text-center">{{$datos[0]->programaAnualVium->unidad}}</td>
                                    <td class="text-center">{{$datos[0]->programaAnualVium->tramo }} ({{$datos[0]->programaAnualVium->tramo_km_inicio }} - {{ $datos[0]->programaAnualVium->tramo_km_fin }})</td>
                                    <td class="text-center">{{$datos->sum('tramo_km_total')}}</td>
                                    @empty
                                    </tr>
                                    <tr><td colspan="4" class="text-center">No hay Actividades registradas durante la Fecha</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                      </div>
                    </div>

                    <div class="tab-pane" id="tab-detalle">

                        <div class="table-responsive mt-3">
                            <table class="table table-striped table-hover" id="myTable2">
                                <thead class="thead">
                                    <tr>                                      
                										<th class="text-center col-3">Premisa Anual</th>
                										<th class="text-center">Programa Sem #</th>
                										<th class="text-center">Fecha</th>
                										<th class="text-center">Km Inicio</th>
                										<th class="text-center">Km Fin</th>
                										<th class="text-center">Total</th>
                										<th class="text-center">Cant Persona</th>
                										<th class="text-center">Tiempo</th>
                										<th class="text-center">Responsable</th>
                										<th class="text-center">Tipo</th>
                                    <th class="text-center">Cambiavias</th>
                										<th class="text-center">Nota</th>
                										<th class="text-center">Usuario Crea</th>
                										<th class="text-center">Usuario Actualiza</th>
                                    <th class="text-center col-1">Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($programaActiviadesVia as $programaActiviadesVium)
                                        <tr>
                      											<td>{{$programaActiviadesVium->programaAnualVium->descripcion }} {{$programaActiviadesVium->programaAnualVium->tramo }} ({{ $programaActiviadesVium->programaAnualVium->tramo_km_inicio }} - {{ $programaActiviadesVium->programaAnualVium->tramo_km_fin }})</td>
                      											<td class="text-center">
                                              @if(!empty($programaActiviadesVium->programa_id))
                                              Sem #{{$programaActiviadesVium->programaVium->programa ?? '(-)'}}
                                              @else
                                              S/R
                                              @endif
                                            </td>
                      											<td class="text-center">{{\Carbon\Carbon::parse($programaActiviadesVium->fecha)->format('d/m/Y')}}</td>
                      											<td class="text-center">
                                              @if($programaActiviadesVium->tramo_km_inicio == 0 and $programaActiviadesVium->tramo_km_fin == 0)

                                              N/A

                                              @else

                                              {{ $programaActiviadesVium->tramo_km_inicio }}

                                              @endif
                                            </td>
                      											<td class="text-center">
                                              @if($programaActiviadesVium->tramo_km_inicio == 0 and $programaActiviadesVium->tramo_km_fin == 0)

                                              N/A

                                              @else

                                              {{ $programaActiviadesVium->tramo_km_fin }}
                                              @endif
                                            </td>
                      											<td class="text-center">{{ $programaActiviadesVium->tramo_km_total }}</td>
                      											<td class="text-center">{{ $programaActiviadesVium->cant_persona }}</td>
                      											<td class="text-center">{{ $programaActiviadesVium->tiempo }}</td>
                      											<td class="text-center">{{ $programaActiviadesVium->datos->nombre }}</td>
                      											<td class="text-center">
                                            @if($programaActiviadesVium->tomar == 0)
                                            CORRECTIVO
                                            @else
                                            PREVENTIVO
                                            @endif
                                            </td>
                                            <td class="text-center">
                                              @if(!empty($programaActiviadesVium->cambiavias_id))

                                              {{ $programaActiviadesVium->cambiavias->ubicacion }} 
                                              <br> 
                                              TRAMO: {{ $programaActiviadesVium->cambiavias->tramo }}
                                              
                                              @else
                                              N/A
                                              @endif

                                            </td>
                      											<td class="text-center">{{ $programaActiviadesVium->nota }}</td>
                      											<td class="text-center">{{ $programaActiviadesVium->usuario_crea }}</td>
                      											<td class="text-center">{{ $programaActiviadesVium->usuario_actualiza }}</td>

                                            <td class="td-actions text-center">
                                                <form action="{{ route('programaviasactividades.destroy',$programaActiviadesVium->id) }}" method="POST">

                                                  <a class="btn btn-link btn-success" href="{{ route('programaviasactividades.edit',$programaActiviadesVium->id) }}"><i class="fa fa-fw fa-edit"></i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                            </td>
                                            @empty
                                        </tr>
                                     <tr><td colspan="14" class="text-center">No hay Actividades registradas durante la Fecha</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>



                </div>


                  
                </div>
            </div>
        </div>
    </div>
</section>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>
@endsection
