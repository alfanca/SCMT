<div class="box box-info padding-1">
    <div class="box-body">
     
      <div class="table-responsive col-12 mt-4">
                <table class="table" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center col-1">Semana #</th>
                        <th class="text-center col-1" id="fecha_text">Fecha</th>
                        <th class="text-center col-1" id="inicio_text">Km Inicio</th>
                        <th class="text-center col-1" id="fin_text">Km Fin</th>
                        <th class="text-center col-1" id="persona_text">Cant Persona</th>
                        <th class="text-center col-1" id="tiempo_text">Tiempo</th>
                        <th class="text-center col-2">Responsable</th>
                        <th class="text-center col-1">¿Tomar?</th>
                        <th class="text-center col-4" id="nota_text">Nota</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                        <th class="text-center">
                       {{ Form::select('programa_id', $programasDetalle ,$programaActiviadesVium->programa_id, ['class' => 'form-control text-center' . ($errors->has('programa_id') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
                        {!! $errors->first('programa_id', '<div class="invalid-feedback">:message</div>') !!}
                       </th>
                        <th class="text-center col-2" id="fecha">
                        {{ Form::date('fecha', $programaActiviadesVium->fecha, ['class' => 'form-control text-center' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
                        {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="inicio">
                        {{ Form::number('tramo_km_inicio', $programaActiviadesVium->tramo_km_inicio, ['class' => 'form-control text-center' . ($errors->has('tramo_km_inicio') ? ' is-invalid' : ''), 'min' =>'0', 'step' =>'0.01','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('tramo_km_inicio', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="fin">
                        {{ Form::number('tramo_km_fin', $programaActiviadesVium->tramo_km_fin, ['class' => 'form-control text-center' . ($errors->has('tramo_km_fin') ? ' is-invalid' : ''),  'min' =>'0', 'step' =>'0.01','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('tramo_km_fin', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="persona">
                        {{ Form::number('cant_persona', $programaActiviadesVium->cant_persona, ['class' => 'form-control text-center' . ($errors->has('cant_persona') ? ' is-invalid' : ''), 'min' =>'0', 'placeholder' => 'Ingrese']) }}
                        {!! $errors->first('cant_persona', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="tiempo">
                        {{ Form::number('tiempo', $programaActiviadesVium->tiempo, ['class' => 'form-control text-center' . ($errors->has('tiempo') ? ' is-invalid' : ''), 'min' =>'0', 'step' =>'0.01','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('tiempo', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center">
                        <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
                        <select name="responsable" class="responsable col-md-6" style="width: 100%">
                          @if (!empty($programaActiviadesVium->datos->nombre))
                            <option value="{{$programaActiviadesVium->responsable}}">{{ $programaActiviadesVium->datos->nombre}}</option>
                          @endif
                        </select>
                        @if ($errors->has('responsable'))
                          <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
                        @endif

                        </div>

                        </th>
                        <th class="text-center">
                        {{ Form::select('tomar', $estatusReportevia,$programaActiviadesVium->tomar, ['class' => 'form-control text-center' . ($errors->has('tomar') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
                        {!! $errors->first('tomar', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="nota">
                        {{ Form::text('nota', $programaActiviadesVium->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'maxlength' => '500','placeholder' => 'Nota']) }}
                        {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                    </tr>
                  </tbody>
                </table>
              </div>

        <div class="card-group mt-3" style="margin-left: 83%">
        <label>Buscador:</label><br>
        <input type="text" class="form-control pull-right" id="search" placeholder="Escriba su Busqueda">
        </div>

       <div class="table-responsive col-12 mt-3">
                <table class="table" id="mytable" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center">Seleccionar</th>
                        <th class="text-center col-2">Descripción</th>
                        <th class="text-center">Unid</th>
                        <th class="text-center col-4">Tramo</th>
                        <th class="text-center">Plan</th>
                        <th class="text-center">Semana</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($programasAnualesKm as $anual)
                      <tr>
                      <td class="text-center"> 
                      <input type="radio" name="programa_anual_id" value="{{$anual->id}}"></td>    
                      <td class="text-center">{{ $anual->descripcion }}</td>
                      <td class="text-center">{{ $anual->unidad }}</td>
                      <td class="text-center">{{ $anual->tramo }} ({{ $anual->tramo_km_inicio }} - {{ $anual->tramo_km_fin }})</td>
                      <td class="text-center">{{ $anual->plan }}</td>  


                      @if(\Carbon\Carbon::parse($anual->fecha_actualizacion)->isoFormat('w') <= now()->isoFormat('w'))
                      <td class="text-center" style="color: red">
                      @elseif(now()->isoFormat('w') >= \Carbon\Carbon::parse($anual->fecha_actualizacion)->isoFormat('w')-1)
                      <td class="text-center" style="color: #ffc107">
                      @else
                      <td class="text-center" style="color: #28a745">
                      @endif
                      
                        @if(!empty($anual->fecha_actualizacion))
                        Sem #{{\Carbon\Carbon::parse($anual->fecha_actualizacion)->isoFormat('w')}}
                        @endif

                      </td>

                    </tr>

                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
        </div>      
    </div>
<script src="{{ asset('js') }}/jQueryv310.js"></script>

<script>
 // Write on keyup event of keyword input element
 $(document).ready(function(){
 $("#search").keyup(function(){
 _this = this;
 // Show only matching TR, hide rest of them
 $.each($("#mytable tbody tr"), function() {
 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
 $(this).hide();
 else
 $(this).show();
 });
 });
});
</script>

<script>
 // Write on keyup event of keyword input element
 $(document).ready(function(){
 $("#searchdos").keyup(function(){
 _this = this;
 // Show only matching TR, hide rest of them
 $.each($("#cambiavias tbody tr"), function() {
 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
 $(this).hide();
 else
 $(this).show();
 });
 });
});
</script>

</div>
