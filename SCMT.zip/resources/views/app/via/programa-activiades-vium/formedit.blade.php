<div class="box box-info padding-1">
    <div class="box-body">

      <h4 class="text-center mt-4">{{$programaActiviadesVium->programaAnualVium->descripcion }} {{$programaActiviadesVium->programaAnualVium->tramo }} ({{ $programaActiviadesVium->programaAnualVium->tramo_km_inicio }} - {{ $programaActiviadesVium->programaAnualVium->tramo_km_fin }})</h4>

      <div class="table-responsive col-12 mt-4">
                <table class="table" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center col-1">Semana #</th>
                        <th class="text-center col-1" id="fecha_text">Fecha</th>
                        <th class="text-center col-1" id="inicio_text">Km Inicio</th>
                        <th class="text-center col-1" id="fin_text">Km Fin</th>
                        <th class="text-center col-1" id="persona_text">Cant Persona</th>
                        <th class="text-center col-1" id="tiempo_text">Tiempo</th>
                        <th class="text-center col-2">Responsable</th>
                        <th class="text-center col-1">¿Tomar?</th>
                        <th class="text-center col-4" id="nota_text">Nota</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                        <th class="text-center">
                       {{ Form::select('programa_id', $programasDetalle ,$programaActiviadesVium->programa_id, ['class' => 'form-control text-center' . ($errors->has('programa_id') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
                        {!! $errors->first('programa_id', '<div class="invalid-feedback">:message</div>') !!}
                       </th>
                        <th class="text-center col-2" id="fecha">
                        {{ Form::date('fecha', $programaActiviadesVium->fecha, ['class' => 'form-control text-center' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
                        {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="inicio">
                        {{ Form::number('tramo_km_inicio', $programaActiviadesVium->tramo_km_inicio, ['class' => 'form-control text-center' . ($errors->has('tramo_km_inicio') ? ' is-invalid' : ''), 'min' =>'0', 'step' =>'0.01','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('tramo_km_inicio', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="fin">
                        {{ Form::number('tramo_km_fin', $programaActiviadesVium->tramo_km_fin, ['class' => 'form-control text-center' . ($errors->has('tramo_km_fin') ? ' is-invalid' : ''),  'min' =>'0', 'step' =>'0.01','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('tramo_km_fin', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="persona">
                        {{ Form::number('cant_persona', $programaActiviadesVium->cant_persona, ['class' => 'form-control text-center' . ($errors->has('cant_persona') ? ' is-invalid' : ''), 'min' =>'0', 'placeholder' => 'Ingrese']) }}
                        {!! $errors->first('cant_persona', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="tiempo">
                        {{ Form::number('tiempo', $programaActiviadesVium->tiempo, ['class' => 'form-control text-center' . ($errors->has('tiempo') ? ' is-invalid' : ''), 'min' =>'0', 'step' =>'0.01','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('tiempo', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center">
                        <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
                        <select name="responsable" class="responsable col-md-6" style="width: 100%">
                          @if (!empty($programaActiviadesVium->datos->nombre))
                            <option value="{{$programaActiviadesVium->responsable}}">{{ $programaActiviadesVium->datos->nombre}}</option>
                          @endif
                        </select>
                        @if ($errors->has('responsable'))
                          <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
                        @endif

                        </div>

                        </th>
                        <th class="text-center">
                        {{ Form::select('tomar', $estatusReportevia,$programaActiviadesVium->tomar, ['class' => 'form-control text-center' . ($errors->has('tomar') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
                        {!! $errors->first('tomar', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                        <th class="text-center" id="nota">
                        {{ Form::text('nota', $programaActiviadesVium->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'maxlength' => '500','placeholder' => 'Nota']) }}
                        {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                    </tr>
                  </tbody>
                </table>
              </div>

                        <th><input hidden="true" id="editas" type="number" name="programa_anual_id" value="{{$programaActiviadesVium->programa_anual_id}}"></th>
                        <th><input hidden="true" id="editas" type="number" name="cambiavias_id" value="{{$programaActiviadesVium->cambiavias_id}}"></th>

    </div>

</div>
