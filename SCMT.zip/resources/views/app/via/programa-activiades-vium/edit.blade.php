@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Actividades de Vías')])
@section('content')
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                <div class="card card-default">
                        <div class="card-header card-header-primary">
                        <h4 class="card-title">{{ __('Actualizar Actividad de Vías') }}</h4>
                      </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('programaviasactividades.update', $programaActiviadesVium->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('app.via.programa-activiades-vium.formedit')

                            <div class="box-footer mt20 mt-4 text-center" 
                              style="position: fixed;
                              bottom: 15px;
                              right: 40%;
                              z-index: 99;
                              height: 50px;
                              overflow: hidden;
                              transition: all 0.5s ease;">
                             <a href="{{route('programaviasactividades.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                             <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
                             </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
