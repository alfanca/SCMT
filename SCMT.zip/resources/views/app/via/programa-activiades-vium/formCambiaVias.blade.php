<div class="box box-info padding-1">
    <div class="box-body">
      <div class="table-responsive col-12 mt-4">
                <table class="table" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center col-1">Semana #</th>
                        <th class="text-center col-2">Responsable</th>
                        <th class="text-center col-1">¿Tomar?</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                        <th class="text-center">
                       {{ Form::select('programa_id', $programasDetalle ,$programaActiviadesVium->programa_id, ['class' => 'form-control text-center' . ($errors->has('programa_id') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
                        {!! $errors->first('programa_id', '<div class="invalid-feedback">:message</div>') !!}
                       </th>
                        
                        <th class="text-center">
                        <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
                        <select name="responsable" class="responsable col-md-6" style="width: 100%">
                          @if (!empty($programaActiviadesVium->datos->nombre))
                            <option value="{{$programaActiviadesVium->responsable}}">{{ $programaActiviadesVium->datos->nombre}}</option>
                          @endif
                        </select>
                        @if ($errors->has('responsable'))
                          <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
                        @endif

                        </div>

                        </th>
                        <th class="text-center">
                        {{ Form::select('tomar', $estatusReportevia,$programaActiviadesVium->tomar, ['class' => 'form-control text-center' . ($errors->has('tomar') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
                        {!! $errors->first('tomar', '<div class="invalid-feedback">:message</div>') !!}
                        </th>
                    </tr>
                  </tbody>
                </table>
              </div>
          

        <div class="card-group mt-3" style="margin-left: 83%">
        <label>Buscador:</label><br>
        <input type="text" class="form-control pull-right" id="searchdos" placeholder="Escriba su Busqueda">
        </div>
                <table class="table mt-3" id="cambiavia" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center">Seleccionar</th>
                        <th class="text-center">Ubicación</th>
                        <th class="text-center">Tipo</th>
                        <th class="text-center">Tramo</th>
                        <th class="text-center col-1">Premisa</th>
                        <th class="text-center">Fecha</th>
                        <th class="text-center">Cant Persona</th>
                        <th class="text-center">Tiempo</th>
                        <th class="text-center">Nota</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($cambiavias as $id => $cambia)
                      <tr>
                      <td class="text-center"> 
                      <input type="checkbox" id="select_cambiavias[{{$id}}]" name="cambiavias_id[{{$id}}]" value="{{$cambia->id}}"></td>    
                      <td>{{ $cambia->ubicacion }}</td>
                      <td class="text-center">{{ $cambia->tipo }}</td>
                      <td class="text-center">{{ $cambia->tramo }}</td>
                      <th class="text-center">
                       <select class="custom-select text-center form-control{{ $errors->has('programa_anual_id') ? ' is-invalid' : '' }}"
                          name="programa_anual_id[{{$id}}]" placeholder="SELECCIONE"
                        >
                        <option value="">PREMISA</option>
                        @foreach($programasAnualesCambiaVias as $anualID => $cambiaviasinput)
                          <option value="{{$anualID}}" {{$programaActiviadesVium->programa_anual_id == $cambiaviasinput ? 'selected' : '' }}>{{$cambiaviasinput}}</option>
                        @endforeach
                      </select>
                       </th>
                      <th class="text-center col-2">
                        <input type="date" name="fecha[{{$id}}]" class="text-center form-control">
                        </th>
                      <th class="text-center">
                        <input type="number" min="0" name="cant_persona[{{$id}}]" class="text-center form-control" placeholder="Ingrese">
                        </th>
                      <th class="text-center">
                        <input type="number" min="0" step="0.1" name="tiempo[{{$id}}]" class="text-center form-control" placeholder="Ingrese">
                      </th>

                      <th class="text-center">
                        <input type="text" maxlength="500" name="nota[{{$id}}]" class="text-center form-control" placeholder="Ingrese">
                      </th>
                    
                    </tr>

                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
              </div>

<script>
 // Write on keyup event of keyword input element
 $(document).ready(function(){
 $("#searchdos").keyup(function(){
 _this = this;
 // Show only matching TR, hide rest of them
 $.each($("#cambiavia tbody tr"), function() {
 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
 $(this).hide();
 else
 $(this).show();
 });
 });
});
</script>

</div>
