@extends('layouts.app', ['activePage' => 'consumovias', 'titlePage' => __('Consumo de Vías')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">{{ __('Show') }} Programa Activiades Vium</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('programaviasactividades.index') }}"> {{ __('Back') }}</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Programa Anual Id:</strong>
                            {{ $programaActiviadesVium->programa_anual_id }}
                        </div>
                        <div class="form-group">
                            <strong>Programa Detalle Id:</strong>
                            {{ $programaActiviadesVium->programa_detalle_id }}
                        </div>
                        <div class="form-group">
                            <strong>Fecha:</strong>
                            {{ $programaActiviadesVium->fecha }}
                        </div>
                        <div class="form-group">
                            <strong>Tramo Km Inicio:</strong>
                            {{ $programaActiviadesVium->tramo_km_inicio }}
                        </div>
                        <div class="form-group">
                            <strong>Tramo Km Fin:</strong>
                            {{ $programaActiviadesVium->tramo_km_fin }}
                        </div>
                        <div class="form-group">
                            <strong>Tramo Km Total:</strong>
                            {{ $programaActiviadesVium->tramo_km_total }}
                        </div>
                        <div class="form-group">
                            <strong>Cant Persona:</strong>
                            {{ $programaActiviadesVium->cant_persona }}
                        </div>
                        <div class="form-group">
                            <strong>Tiempo:</strong>
                            {{ $programaActiviadesVium->tiempo }}
                        </div>
                        <div class="form-group">
                            <strong>Responsable:</strong>
                            {{ $programaActiviadesVium->responsable }}
                        </div>
                        <div class="form-group">
                            <strong>Tomar:</strong>
                            {{ $programaActiviadesVium->tomar }}
                        </div>
                        <div class="form-group">
                            <strong>Nota:</strong>
                            {{ $programaActiviadesVium->nota }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Crea:</strong>
                            {{ $programaActiviadesVium->usuario_crea }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Actualiza:</strong>
                            {{ $programaActiviadesVium->usuario_actualiza }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
