@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Actividades de Vías')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="card card-default">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-10">
                        <h4 class="card-title ">Registrar Actividad de Vías</h4>
                      </div>
                      
                      
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('programaviasactividades.store') }}"  role="form" enctype="multipart/form-data">
                            @csrf

                            @if($_GET['tipo'] == 'KM')
                            @include('app.via.programa-activiades-vium.form')
                            @else
                            @include('app.via.programa-activiades-vium.formCambiaVias')
                            @endif

                     <div class="box-footer mt20 mt-4 text-center" style="position: fixed;
                      bottom: 15px;
                      right: 40%;
                      z-index: 99;
                      height: 50px;
                      overflow: hidden;
                      transition: all 0.5s ease;">
                     <a href="{{route('programaviasactividades.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                     <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
                     </div>

                        </form>
                    </div>

            </div>
        </div>
    </section>
@endsection
