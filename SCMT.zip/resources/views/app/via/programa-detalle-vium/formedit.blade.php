<div class="box box-info padding-1">
    <div class="box-body">
          

           <h4 class="col-12 text-center">{{ $programaDetalleVium->programaAnualVium->descripcion }} {{ $programaDetalleVium->programaAnualVium->tramo }} ({{ $programaDetalleVium->programaAnualVium->tramo_km_inicio }} - {{ $programaDetalleVium->programaAnualVium->tramo_km_fin }})</h4>


          <table class="table-resposive mt-5">
            <thead>
              <tr>
                <th class="text-center col-2">Fecha:</th>
                <th class="text-center col-1">Plan:</th>
                <th class="text-center col-3">Nro Orden:</th>
                <th class="text-center col-6">Nota:</th>
                <th style="visibility: hidden;"></th>
                <th style="visibility: hidden;"></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{{ Form::date('fecha', $programaDetalleVium->fecha, ['class' => 'form-control text-center' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}</td>
                <td>{{ Form::number('plan', $programaDetalleVium->plan, ['class' => 'form-control text-center' . ($errors->has('plan') ? ' is-invalid' : ''), 'min' => '0', 'step'=>'0.1','placeholder' => 'Ingrese']) }}
                 {!! $errors->first('plan', '<div class="invalid-feedback">:message</div>') !!}</td>
                <td>{{ Form::number('nro_orden', $programaDetalleVium->nro_orden, ['class' => 'form-control text-center' . ($errors->has('nro_orden') ? ' is-invalid' : ''), 'min' => '0','placeholder' => 'Ingrese Nro Orden']) }}
                 {!! $errors->first('nro_orden', '<div class="invalid-feedback">:message</div>') !!}</td>
                <td>{{ Form::text('nota', $programaDetalleVium->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese']) }}
                 {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}</td>
                <td style="visibility: hidden;">{{ Form::text('programa_via_id', $programaDetalleVium->programa_via_id, ['class' => 'form-control' . ($errors->has('programa_via_id') ? ' is-invalid' : ''),'placeholder' => 'Programa Via Id']) }}
                 {!! $errors->first('programa_via_id', '<div class="invalid-feedback">:message</div>') !!}</td>
                <td style="visibility: hidden;">{{ Form::text('programa_anual_id', $programaDetalleVium->programa_anual_id, ['class' => 'form-control' . ($errors->has('programa_anual_id') ? ' is-invalid' : ''), 'placeholder' => 'Programa Anual Id']) }}
                 {!! $errors->first('programa_anual_id', '<div class="invalid-feedback">:message</div>') !!}</td>
              </tr>
            </tbody>
          </table>


    </div>
</div>