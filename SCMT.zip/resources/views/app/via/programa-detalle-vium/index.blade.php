@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Histórico de Inspecciones y Mantenimiento de Vías')])
@section('content')
 <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Histórico de Inspecciones y Mantenimiento de Vías </h4>
                        <p class="card-category">Registro y Administración de Mantenimiento de Vías (Detalle Histórico)</p>
                      </div> 
                      <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip" title="Regresar a Programas"
                            href="{{ route('programavias.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="fas fa-reply" style="font-size: 18px;"></i>
                        </a>  
                      </div>
                    </div>

                    <div class="card-body">
                        <div class="col-7 mt-3" style="margin-left: 220px">
                        <form method="get" autocomplete="off" action="{{route('programaviasdetalle.index')}}" class="form-horizontal">
                        @include('app.comun.nav_calendario_busqueda')
                        </form>
                        </div>
                        <div class="table-responsive mt-3">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th class="text-center">Semana #</th>
										<th class="text-center">Premisa Anual</th>
										<th class="text-center">Fecha</th>
										<th class="text-center">Plan</th>
										<th class="text-center">Nro Orden</th>
										<th class="text-center">Nota</th>
										<th class="text-center">Usuario Crea</th>
										<th class="text-center">Usuario Actualiza</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($programaDetalleVia as $programaDetalleVium)
                                        <tr>
                                            <td class="text-center">{{ ++$i }}</td>
                                            
											<td class="text-center">{{ $programaDetalleVium->programaVium->programa }}</td>
											<td>{{$programaDetalleVium->programaAnualVium->descripcion }} {{$programaDetalleVium->programaAnualVium->tramo }} ({{ $programaDetalleVium->programaAnualVium->tramo_km_inicio }} - {{ $programaDetalleVium->programaAnualVium->tramo_km_fin }})</td>
											<td class="text-center">{{ \Carbon\Carbon::parse($programaDetalleVium->fecha)->format('d/m/Y') }}</td>
											<td class="text-center">{{ $programaDetalleVium->plan }}</td>
											<td class="text-center">{{ $programaDetalleVium->nro_orden }}</td>
											<td class="text-center">{{ $programaDetalleVium->nota }}</td>
											<td class="text-center">{{ $programaDetalleVium->usuario_crea }}</td>
											<td class="text-center">{{ $programaDetalleVium->usuario_actualiza }}</td>

                                        @empty
                                        </tr>
                                     <tr><td colspan="14" class="text-center">No hay registros durante la Fecha</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
@endsection
