<div class="box box-info padding-1">
    <div class="box-body">

        <input type="text" name="programa_via_id" value="{{$_GET['id']}}" style="visibility: hidden;">

        <div class="card-group" style="margin-left: 83%">
        <label>Buscador:</label><br>
        <input type="text" class="form-control pull-right" id="search" placeholder="Escriba su Busqueda">
        </div>

       <div class="table-responsive col-12">
                <table class="table" id="mytable" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center">Seleccionar</th>
                        <th class="text-center col-2">Descripción</th>
                        <th class="text-center">Unid</th>
                        <th class="text-center col-2">Tramo</th>
                        <th class="text-center">Fecha</th>
                        <th class="text-center">Semana</th>
                        <th class="text-center col-1">Plan</th>
                        <th class="text-center col-4">Nota</th>
                        <th class="text-center col-2">Nro Orden</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($programaAnual as $id => $anual)
                      <tr>
                      <td class="text-center"> 
                      <input type="checkbox" name="programa_anual_id[{{$id}}]" value="{{$anual->id}}"></td>    
                      <td class="text-center">{{ $anual->descripcion }}</td>
                      <td class="text-center">{{ $anual->unidad }}</td>
                      <td class="text-center">{{ $anual->tramo }} ({{ $anual->tramo_km_inicio }} - {{ $anual->tramo_km_fin }})</td>

                      <td><input class="form-control text-center" type="date" name="fecha[{{$id}}]" value="{{$anual->programa}}"></td>

                      @if(\Carbon\Carbon::parse($anual->programa)->isoFormat('w') <= now()->isoFormat('w'))
                      <td class="text-center" style="color: red">
                      @elseif(now()->isoFormat('w') >= \Carbon\Carbon::parse($anual->programa)->isoFormat('w')-1)
                      <td class="text-center" style="color: #ffc107">
                      @else
                      <td class="text-center" style="color: #28a745">
                      @endif

                      Sem #{{\Carbon\Carbon::parse($anual->programa)->isoFormat('w')}}

                      </td>

                      <td><input class="form-control text-center" min="0" max="100" step="0.01" placeholder="Ingrese" type="number" name="plan[{{$id}}]" value="{{$anual->plan}}"></td>
                      
                      <td><input class="form-control" placeholder="Ingrese Nota" maxlength="500" type="text" name="nota[{{$id}}]"></td>
                      <td><input class="form-control text-center" min="0" placeholder="Ingrese" type="number" name="nro_orden[{{$id}}]"></td>
                      
                    </tr>

                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>

            </div>
          </div>

 <script src="{{ asset('js') }}/jQueryv310.js"></script>

<script>
 // Write on keyup event of keyword input element
 $(document).ready(function(){
 $("#search").keyup(function(){
 _this = this;
 // Show only matching TR, hide rest of them
 $.each($("#mytable tbody tr"), function() {
 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
 $(this).hide();
 else
 $(this).show();
 });
 });
});
</script>


</div>