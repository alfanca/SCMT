@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Programa de Vias')])
@section('content')
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header card-header-primary">
                    <h4 class="card-title">{{ __('Actualizar Programa de Vias') }}</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('programaviasdetalle.update', $programaDetalleVium->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('app.via.programa-detalle-vium.formedit')

                            <div class="card-footer justify-content-center">
                             <a href="/programavias/{{$programaDetalleVium->programa_via_id}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                             <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
                             </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
