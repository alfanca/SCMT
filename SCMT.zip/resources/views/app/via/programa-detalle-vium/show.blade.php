@extends('layouts.app', ['activePage' => 'consumovias', 'titlePage' => __('Consumo de Vías')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">{{ __('Show') }} Programa Detalle Vium</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('programaviasdetalle.index') }}"> {{ __('Back') }}</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Programa Via Id:</strong>
                            {{ $programaDetalleVium->programa_via_id }}
                        </div>
                        <div class="form-group">
                            <strong>Programa Anual Id:</strong>
                            {{ $programaDetalleVium->programa_anual_id }}
                        </div>
                        <div class="form-group">
                            <strong>Fecha:</strong>
                            {{ $programaDetalleVium->fecha }}
                        </div>
                        <div class="form-group">
                            <strong>Plan:</strong>
                            {{ $programaDetalleVium->plan }}
                        </div>
                        <div class="form-group">
                            <strong>Real:</strong>
                            {{ $programaDetalleVium->real }}
                        </div>
                        <div class="form-group">
                            <strong>Nro Orden:</strong>
                            {{ $programaDetalleVium->nro_orden }}
                        </div>
                        <div class="form-group">
                            <strong>Nota:</strong>
                            {{ $programaDetalleVium->nota }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Crea:</strong>
                            {{ $programaDetalleVium->usuario_crea }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Actualiza:</strong>
                            {{ $programaDetalleVium->usuario_actualiza }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
