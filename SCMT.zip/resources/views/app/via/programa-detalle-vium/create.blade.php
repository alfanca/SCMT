@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Programa de Vías')])
@section('content')
    <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
          <div class="card-header card-header-primary">
            <h4 class="card-title">{{ __('Agregar Programas de Vias') }}</h4>
          </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('programaviasdetalle.store') }}"  role="form" enctype="multipart/form-data">
                            @csrf

                            @include('app.via.programa-detalle-vium.form')

                            <div class="box-footer mt20 mt-4 text-center" style="position: fixed;
                              bottom: 15px;
                              right: 40%;
                              z-index: 99;
                              height: 50px;
                              overflow: hidden;
                              transition: all 0.5s ease;">
                              <a href="/programavias/{{$_GET['id']}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                              <button type="submit" class="btn btn-primary">Crear</button>
                             </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
@endsection
