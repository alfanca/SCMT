  <div class="card-body ">
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Equipo:') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('equipo') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="equipo" id="input-name" type="text" placeholder="{{ __('Ingrese la descripción del Equipo') }}"
            value="{{ old('equipo') ?? $eqferroviario->equipo }}" required="true"/>
          @if ($errors->has('equipo'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('equipo') }}</span>
          @endif
        </div>
      </div>
    </div>
    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('N° FMO:') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('fmo') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="fmo" id="input-name" type="text" placeholder="{{ __('Ingrese el N° FMO del Equipo') }}"
            value="{{ old('fmo') ?? $eqferroviario->fmo }}" required="true"/>
          @if ($errors->has('fmo'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('fmo') }}</span>
          @endif
        </div>
      </div>
    </div>

    <div class="row">
        <label class="col-md-2 col-form-label">{{ __('Cantidad Eq.:') }}</label>

       <div class="col-md-4 form-group{{ $errors->has('cantidad') ? ' has-danger' : '' }}">

      <input type="number" name="cantidad" class="form-control col-md-4" style="width:40%" 
      value="{{ old('cantidad') ?? $eqferroviario->cantidad }}"/>
      @if ($errors->has('cantidad'))
      <span id="name-error" class="error text-danger" for="input-cantidad">{{ $errors->first('cantidad') }}</span>
      @endif

     </div>

      <label class="col-md-2 col-form-label">{{ __('Cantidad Eq. Parados:') }}</label>

       <div class="col-md-4 form-group{{ $errors->has('parados') ? ' has-danger' : '' }}">

      <input type="number" name="parados" class="form-control col-md-4" style="width:40%" 
      value="{{ old('parados') ?? $eqferroviario->parados }}"/>
      @if ($errors->has('parados'))
      <span id="name-error" class="error text-danger" for="input-parados">{{ $errors->first('parados') }}</span>
      @endif

     </div>
    </div>
    </div>

