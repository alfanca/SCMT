@extends('layouts.app', ['activePage' => 'eqferroviarios', 'titlePage' => __('Equipos Ferroviarios')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

            <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Equipos Ferroviarios</h4>
                <p class="card-category">Disponibilidad de Equipos Ferroviarios</p>
              </div>
              @if(Gate::check('isplanificador') || Gate::check('isJefe'))
              <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Agregar Equipo"
                    href="eqferroviario/create" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Agregar
                  <i class="material-icons">add</i>
                </a>  
              </div>
              @endif
            </div>
            <div class="card-body">

              <div class="card-group" align="center">

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb; border-top-left-radius: 10px;">
                          
                          <i class="fas fa-snowplow text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Eq. (Total)</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$eqferroviarios->sum('cantidad')}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #ffc107; border-top-left-radius: 10px;">
           
                          <i class="fa fa-wrench text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Eq. Parados (Total)</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$eqferroviarios->sum('parados')}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #28a745; border-top-left-radius: 10px;">
           
                          <i class="fa fa-check text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Eq. Disp. (Total)</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$eqferroviarios->sum('real')}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb; border-top-left-radius: 10px;">
           
                          <i class="fa fa-percent text-center mt-4" style="font-size: 25px; color: white;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Disp. Oper.(%)</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{round((($eqferroviarios->sum('real'))/$eqferroviarios->sum('cantidad'))*100)}} %</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

              <div class="table-responsive">
                <table class="table">
                  <thead class=" text-primary">
                    <tr>
                    	<th class="text-center">Equipo</th>
                    	<th class="text-center">N° FMO</th>
                    	<th class="text-center">Cantidad Eq.</th>
                        <th class="text-center">Cantidad Eq. Parados</th>
                        <th class="text-center">Cantidad Eq. Disp.</th>
                        <th class="text-center">Disp. Oper. Sem (%)</th>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    	  <th class="text-center">Acciones</th>
                        @endif
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($eqferroviarios as $eqferroviario)
										<tr>
                      <td class="text-center">{{$eqferroviario->equipo}}</td>
                      <td class="text-center">{{$eqferroviario->fmo}}</td>
                      <td class="text-center">{{$eqferroviario->cantidad}}</td>
                      <td class="text-center">{{$eqferroviario->parados}}</td>
                      <td class="text-center">{{$eqferroviario->real}}</td>
                      <td class="text-center">{{round((($eqferroviario->real)/($eqferroviario->cantidad))*100)}} %</td>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                      <td class="td-actions text-center">
                        <form method="post" id="formDeleteLocomotora-{{$eqferroviario->id}}" action="{{route('eqferroviario.destroy', [$eqferroviario->id] ) }}" class="">
				                <a rel="tooltip" class="btn btn-success btn-link" href="{{route('eqferroviario.edit', [$eqferroviario->id])}}" data-original-title="" title="Editar">
                          <i class="material-icons">edit</i>
                          <div class="ripple-container"></div>
                        </a>
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteLocomotora-{{$eqferroviario->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      </td>
                      @endif
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>

@endsection
