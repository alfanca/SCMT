@extends('layouts.app', ['activePage' => 'eqferroviarios', 'titlePage' => __('Actualizar Equipo Ferroviario')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header card-header-primary">
              <h4 class="card-title">{{ __('Actualizar Locomotora') }}</h4>
            </div>
            <form method="post" action="{{route('eqferroviario.update', [$eqferroviario->id])}}" autocomplete="off" class="form-horizontal">
              @csrf
              @method('patch')
              @include('app.via.eqferroviario.form')
            <div class="col-md-12" align="center">
            <div class="card-footer justify-content-center">
            <a href="{{route('eqferroviario.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
              <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
            </div>
          </div>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

