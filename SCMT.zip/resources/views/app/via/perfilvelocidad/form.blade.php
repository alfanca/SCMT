<div class="card-body ">

<script type="text/javascript">
        
        function seleccionar_fechaSalida(){

        var selectorPlan = document.getElementById('input-estatus').value;

        if (selectorPlan == 'CERRADA') {
            document.getElementById("input-fecha_fin").style.display = '';
            document.getElementById("input-fecha_fin").required = true;
            document.getElementById("label-fin").style.display = '';
        }

        else{
            document.getElementById("input-fecha_fin").style.display = 'none';
            document.getElementById("input-fecha_fin").required = false;
            document.getElementById("label-fin").style.display = 'none';
        }

        }      

    </script>


    <div class="row">
     
     <label class="col-md-2 col-form-label">{{ __('Fecha Inicio') }}</label>&nbsp&nbsp&nbsp&nbsp

     <div class="form-group{{ $errors->has('fechareal') ? ' has-danger' : '' }}">
     <input type="date" name="fechareal" class="form-control col-12" 
      value="{{ old('fechareal') ?? $perfil->fechareal }}"/>
      @if ($errors->has('fechareal'))
      <span id="name-error" class="error text-danger" for="input-fechareal">{{ $errors->first('fechareal') }}</span>
      @endif
    </div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

    @if(!empty($perfil->estatus))

            <label class="col-md-1 col-form-label">{{ __('Estatus') }}</label>

            <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }} text-center"
                name="estatus" id="input-estatus"placeholder="{{ __('Seleccione') }}" onclick="seleccionar_fechaSalida()" 
              >
              <option value="">SELECCIONE</option>
              @foreach($perfil->estatusPerfil() as $Estatus)
                <option value="{{$Estatus}}" {{$perfil->estatus == $Estatus ? 'selected' : '' }}>{{$Estatus}}</option>
              @endforeach
            </select>


            @if ($errors->has('estatus'))
              <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
            @endif
          </div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
      @endif
  <label class="col-md-1 col-form-label" id="label-fin" style="display: none;">{{ __('Fecha Fin') }}</label>

     <div class="form-group{{ $errors->has('fecha_fin') ? ' has-danger' : '' }}">
     <input type="date" name="fecha_fin" class="form-control col-12" 
      value="{{ old('fecha_fin') ?? $perfil->fecha_fin }}" id="input-fecha_fin" style="display: none;"/>
      @if ($errors->has('fecha_fin'))
      <span id="name-error" class="error text-danger" for="input-fecha_fin">{{ $errors->first('fecha_fin') }}</span>
      @endif
    </div>

    </div>


    <div class="row">
      <label class="col-md-2 col-form-label">{{ __('Desde KM:') }}</label>

      <div class="col-md-4 form-group{{ $errors->has('kminicial') ? ' has-danger' : '' }}">

    <input type="number" step="0.1" name="kminicial" class="form-control col-md-4" style="width:40%" 
      value="{{ old('kminicial') ?? $perfil->kminicial }}"/>
      @if ($errors->has('kminicial'))
      <span id="name-error" class="error text-danger" for="input-kminicial">{{ $errors->first('kminicial') }}</span>
      @endif

     </div>

      <label class="col-md-2 col-form-label">{{ __('Hasta KM:') }}</label>

      <div class="col-md-4 form-group{{ $errors->has('kmfinal') ? ' has-danger' : '' }}">

    <input type="number" step="0.1" name="kmfinal" class="form-control col-md-4" style="width:40%" 
      value="{{ old('kmfinal') ?? $perfil->kmfinal }}"/>
      @if ($errors->has('kmfinal'))
      <span id="name-error" class="error text-danger" for="input-kmfinal">{{ $errors->first('kmfinal') }}</span>
      @endif

     </div>

     <label class="col-md-2 col-form-label">{{ __('Velocidad Plan') }}</label>

      <div class="col-md-4 form-group{{ $errors->has('velplan') ? ' has-danger' : '' }}">

    <input type="number" step="0.1" name="velplan" class="form-control col-md-4" style="width:40%" 
      value="{{ old('velplan') ?? $perfil->velplan }}"/>
      @if ($errors->has('velplan'))
      <span id="name-error" class="error text-danger" for="input-velplan">{{ $errors->first('velplan') }}</span>
      @endif

     </div>

      <label class="col-md-2 col-form-label">{{ __('Velocidad Real:') }}</label>

      <div class="col-md-4 form-group{{ $errors->has('velreal') ? ' has-danger' : '' }}">

    <input type="number" step="0.1" name="velreal" class="form-control col-md-4" style="width:40%" 
      value="{{ old('velreal') ?? $perfil->velreal }}"/>
      @if ($errors->has('velreal'))
      <span id="name-error" class="error text-danger" for="input-velreal">{{ $errors->first('velreal') }}</span>f
      @endif

     </div>

    </div>
    <div class="row">
    <label class="col-md-2 col-form-label">{{ __('Nota:') }}</label>
      <div class="col-md-10 form-group{{ $errors->has('nota') ? ' has-danger' : '' }}">
    <textarea class="form-control col-md-9" type="text" name="nota" />{{ old('nota') ?? $perfil->nota}}</textarea>
    @if ($errors->has('nota'))
      <span id="name-error" class="error text-danger" for="input-nota">{{ $errors->first('nota') }}</span>
    @endif
    </div>
        </div>
  </div>
