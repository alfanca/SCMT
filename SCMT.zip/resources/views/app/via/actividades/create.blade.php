@extends('layouts.app', ['activePage' => 'via', 'titlePage' => __('Registrar actividades de vias')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
          <form method="post" action="{{ route('via_actividades.store') }}" autocomplete="off" class="form-horizontal">
            @csrf
            <div class="card-body mb-4">
              @include('app.via.actividades.form')
                              
            <div class="card-footer justify-content-center">
              <a href="{{route('via_actividades.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

@endsection
