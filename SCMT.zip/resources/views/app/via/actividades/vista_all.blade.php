@extends('layouts.app', ['activePage' => 'via', 'titlePage' => __('Actividad General')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title ">Actividades</h4>
              <p class="card-category">Busqueda de Actividades</p>
            </div>
            <div class="card-body">
             <div class="card-body">

           <form method="get" autocomplete="off" action="{{route('via_actividades.vista_all')}}" class="form-horizontal">
            @include('app.comun.nav_calendario_busqueda_sinboton')
           </form>

          
           </div>
              <div class="table-responsive">
                <table id= 'myTable' class="table">
                  <thead class=" text-primary">
                    <tr>
                      <th class="text-center">Turno</th>
                      <th class="text-center">Fecha</th>
                      <th class="text-center col-md-6">Actividad</th>
                      <th class="text-center">Tramo</th>
                      <th class="text-center">Orden</th>
                      <th class="text-center">Responsable Area</th>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
                          <th class="text-center">Opciones</th>
                          @endif
                          @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <th class="text-center">Analista</th>
                          @endif   
                      
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($actividades_all as $actividades)
                    <tr>
                      <td class="text-center">{{$actividades-> turno}}</td>
                      <td class="text-center">{{\Carbon\Carbon::parse($actividades->fecha)->format('d/m/Y')}}</td>
                      <td class="col-md-6" style="text-transform: uppercase;">{{$actividades->actividad}}</td>
                      <td class="text-center" >{{$actividades->tramo}}</td>
                      <td  class="text-center">{{$actividades->orden}}</td>
                      <td  class="text-center">{{$actividades->datos->nombre}}</td>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                            <td class="td-actions row">
                         
                              <div class="text-center col-md-12 card-group" style="text-align: center;">

                          <a rel="tooltip" class="btn btn-success btn-link" href="{{route('via_actividades.edit', [$actividades->id])}}" data-original-title="" title="Editar">
                                    <i class="material-icons">edit</i>
                                  </a>

                                  <form method="post" id="formDeleteActividades-{{$actividades->id}}" action="{{route('via_actividades.destroy', [$actividades->id] ) }}">
                                    @csrf
                                    @method('delete')

                                    <a rel="tooltip" class="btn btn-danger btn-link mx-2" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteActividades-{{$actividades->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                                  </form>

                                  </div>
                              </td>
                              @endif  
                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <td class="text-center">
                      {{$actividades->usuario_crea}} / 
                      {{\Carbon\Carbon::parse($actividades->created_at)->format('d-m H:i')}}
                    </td>
                        @endif  
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {
    ordering: false,
    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


@endsection
