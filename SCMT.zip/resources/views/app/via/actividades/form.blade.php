<script type="text/javascript">
function saltar() {
texto = actividad.value.length;
cant = actividad.cols;
limite = cant;
  if(texto == cant) {
    limite = cant;
  }
  else {
    for(i=1;i<100;i++) {
      if(texto == (cant*i)) {
        limite = (cant*i);
      }
    }
  }
  if((texto == limite)||(event.KeyCode==13)) {
    actividad.rows = actividad.rows+1;
  }
}
</script>

<div class="row">
  <label class="col-md-2 col-form-label">{{ __('FECHA') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('fecha') ? ' has-danger' : '' }}">
    <input type="date"  name="fecha" class="form-control" style="width:40%" 
      value="{{ old('fecha') ?? $actividad->fecha }}"/>
    @if ($errors->has('fecha'))
      <span id="name-error" class="error text-danger" for="input-fecha">{{ $errors->first('fecha') }}</span>
    @endif

    </div>
  </div>

  <label class="col-md-2 col-form-label">{{ __('TURNO') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('turno') ? ' has-danger' : '' }}">

      <select class=" col-md-4 text-center custom-select form-control{{ $errors->has('turno') ? ' is-invalid' : '' }}" name="turno" id="input-turno"
        placeholder="{{ __('Ingrese el turno') }}" required="true">
        <option value="">SELECCIONE</option>
        @foreach($turnos as $turno)
         <option value="{{$turno}}" {{$actividad->turno == $turno ? 'selected' : '' }}>{{$turno}}</option>
        @endforeach
      </select>
    @if ($errors->has('turno'))
      <span id="name-error" class="error text-danger" for="input-turno">{{ $errors->first('turno') }}</span>
    @endif

    </div>
  </div>
</div>

<div class="row">
  <label class="col-md-2 col-form-label">{{ __('ACTIVIDAD') }}</label>
  <div class="col-md-10">
    <div class="form-group{{ $errors->has('actividad') ? ' has-danger' : '' }}">
    <textarea class="form-control col-md-9" name="actividad" id="actividad" col="80" rows="5" onKeyPress="saltar()">{{ old('actividad') ?? $actividad->actividad }}</textarea> 
    @if ($errors->has('actividad'))
      <span id="name-error" class="error text-danger" for="input-actividad">{{ $errors->first('actividad') }}</span>
    @endif

    </div>
  </div>
</div>

<div class="row">
  <label class="col-md-2 col-form-label">{{ __('RESPONSABLE') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
    <select name="responsable" class="responsable" style="width: 100%">
      @if (!empty($actividad->datos->nombre))
        <option value="{{$actividad->responsable}}">{{ $actividad->datos->nombre}}</option>
      @endif
    </select>
    @if ($errors->has('responsable'))
      <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
    @endif

    </div>
  </div>

  
        <label class="col-sm-1 col-form-label">{{ __('TRAMO') }}</label>
        <div class="col-sm-2">
          <div class="form-group{{ $errors->has('tramo') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('tramo') ? ' is-invalid' : '' }}"
                name="tramo" id="input-tramo"placeholder="{{ __('Ingrese el tramo') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($actividad->tramovia() as $tramo)
                <option value="{{$tramo}}" {{$actividad->tramo == $tramo ? 'selected' : '' }}>{{$tramo}}</option>
              @endforeach
            </select>


            @if ($errors->has('tramo'))
              <span id="name-error" class="error text-danger" for="input-tramo">{{ $errors->first('tramo') }}</span>
            @endif
          </div>
        </div>

</div>
<div class="row">
  <label class="col-md-2 col-form-label">{{ __('ORDEN:') }}</label>
      <div class="col-md-4 form-group{{ $errors->has('orden') ? ' has-danger' : '' }}">
    <input type="text" name="orden" class="form-control col-md-4" style="width:40%" 
      value="{{ old('orden') ?? $actividad->orden }}"/>
    @if ($errors->has('orden'))
      <span id="name-error" class="error text-danger" for="input-orden">{{ $errors->first('orden') }}</span>
    @endif
</div>
    </div>
 
