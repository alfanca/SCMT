@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Programa de Vías')])
@section('content')

 <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">

                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Inspecciones y Mantenimiento de Vías </h4>
                        <p class="card-category">Registro y Administración de Mantenimiento de Vías</p>
                      </div>
                         
                      <div class="col-md-6" style="text-align: right;">



                    <!-- Small button groups (default and split) -->
                    <div class="btn-group">
                      <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background: #9b945f; color: white;" rel="tooltip" title="Ir a:">
                        <i class="fas fa-location-arrow" style="font-size: 17px"></i>
                      </button>
                      <div class="dropdown-menu" style="border: 3px solid; border-radius: 20px; border-color: white;">
                         <a class="dropdown-item" href="{{route('programaviasactividades.index')}}" style="border-radius: 20px;">{{ __('Actividades') }}</a>
                           <div class="dropdown-divider"></div>
                         <a class="dropdown-item" href="{{route('programaviasanual.index')}}" style="border-radius: 20px;">{{ __('Premisa Anual') }}</a>
                      </div>
                    </div>
                    <div class="btn-group">
                      <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background: #9b945f; color: white;" rel="tooltip" title="Históricos">
                        <i class="fas fa-calendar-alt" style="font-size: 17px"></i>
                      </button>
                      <div class="dropdown-menu" style="border: 3px solid; border-radius: 20px; border-color: white;">
                           <a class="dropdown-item" href="{{route('historico_programa_vias')}}" style="border-radius: 20px;">{{ __('Histórico Programa') }}</a>
                           <div class="dropdown-divider"></div>
                           <a class="dropdown-item" href="{{route('programaviasdetalle.index')}}" style="border-radius: 20px;">{{ __('Historico Detalle') }}</a>
                      </div>
                    </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                        <a rel="tooltip" title="Crear Programa"
                            href="{{ route('programavias.create') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="far fa-calendar-plus" style="font-size: 18px;"></i>
                        </a>  
                      @endif
                      </div>
                    </div>


                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th class="text-center">Programa</th>
										<th class="text-center">Fecha Inicio</th>
										<th class="text-center">Fecha Fin</th>
										<th class="text-center">Estatus</th>
										<th class="text-center">Planificador</th>
										<th class="text-center">Jefe Superintendencia</th>
										<th class="text-center">Jefe Planificacion</th>
										<th class="text-center">Nota</th>
										<th class="text-center">Usuario Crea</th>
										<th class="text-center">Usuario Actualiza</th>

                                        <th class="text-center">Borrar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($programaVia as $programaVium)
                                        <tr>
                                            <td>{{ ++$i }}</td>
                                            
											<td><a class="btn btn-link btn-primary " href="{{ route('programavias.show',$programaVium->id) }}">Sem #{{ $programaVium->programa }}</a></td>
											<td class="text-center">{{\Carbon\Carbon::parse( $programaVium->fecha_inicio )->format('d/m/Y')}}</td>
											<td class="text-center">{{\Carbon\Carbon::parse($programaVium->fecha_fin)->format('d/m/Y')}}</td>
											<td class="text-center">{{ $programaVium->estatus }}</td>
											<td class="text-center">{{$programaVium->datosplanificador->nombre}}</td>
											<td class="text-center">{{$programaVium->datosjefeTurnoarea->nombre}}</td>
											<td class="text-center">{{$programaVium->datosjefeplanificacion->nombre}}</td>
											<td class="text-center">{{ $programaVium->nota }}</td>
											<td class="text-center">{{ $programaVium->usuario_crea }}</td>
											<td class="text-center">{{ $programaVium->usuario_actualiza }}</td>

                                            <td class="text-center">
                                              @if((Gate::check('isplanificador') || Gate::check('isJefe')) and $programaVium->estatus == 'LIBERADA' )
                                                <form action="{{ route('programavias.destroy',$programaVium->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
@endsection
