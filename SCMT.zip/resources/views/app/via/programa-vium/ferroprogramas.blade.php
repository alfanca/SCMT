@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Formato de Programa de Vías')])
@section('content')
<section class="content container-fluid">
	    <div class="container-fluid">
        	 	<div class="card" align="center">
        	 		<div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title text-left">Programa de Vías Sem N°{{$programaVium->programa}}</h4>
                        <p class="card-category text-left">Ferro de inspección y mantenimiento de Vías</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="col-md-6" style="text-align: right;">
                    	 <a rel="tooltip" title="Regresar" 
                            href="/programavias/{{$programaVium->id}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>
                        </a> 
                        <a rel="tooltip" title="Imprimir"
                            href="" onclick="javascript:imprim1r(imprimir);" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="material-icons">print</i>
                        </a>  
                      </div>
                      @endif
                    </div>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<meta name="generator" content="LibreOffice 6.0.7.3 (Linux)"/>
	<meta name="created" content="2023-01-23T14:20:36.398407178"/>
	<meta name="changed" content="2023-01-24T11:58:28.836396203"/>
	<style type="text/css">
		@page { margin: 2cm }
		p { margin-bottom: 0.25cm; line-height: 115% }
		td p { margin-bottom: 0cm }
		a:link { so-language: zxx }
	</style>
	<script type="text/javascript">
		function imprim1r (imprimir){
			var printContents = document.getElementById('imprimir').innerHTML;
				w = window.open();
				w.document.write(printContents);
		w.print();
		w.close();
		return true;
		}
	</script>
</head>
<body lang="es-VE" dir="ltr">
	<div id="imprimir">	
<p align="center" style="margin-bottom: 0cm; font-style: normal; line-height: 100%; text-decoration: none">
<br/>

</p>
<p align="center" style="margin-bottom: 0cm; font-style: normal; line-height: 100%; text-decoration: none">
<br/>

</p>
<table width="665" cellpadding="4" cellspacing="0">
	<col width="100">
	<col width="546">
	<tr>
		<td width="100" valign="top" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><img src="{{asset('/images/logofmo.png')}}" name="Imagen1" align="left" width="94" height="99" border="0"/>
<br/>

			</p>
		</td>
		<td width="546" style="border: 1px solid #000000; padding: 0.1cm">
			<p align="center" style="margin-top: 0.1cm; margin-bottom: 0.1cm; font-style: normal; text-decoration: none">
			<font face="ang eco sang, serif"><font size="2" style="font-size: 9pt"><b>GERENCIA
			DE FERROCARRIL</b></font></font></p>
			<p align="center" style="margin-top: 0.1cm; font-style: normal; text-decoration: none">
			<font face="ang eco sang, serif"><font size="2" style="font-size: 9pt"><b>PROGRAMA DE MANTENIMIENTO PREVENTIVO E INSPECCIONES</b></font></font></p>
			<p align="center" style="margin-top: 0.1cm; font-style: normal; text-decoration: none">
			<font face="ang eco sang, serif"><font size="2" style="font-size: 9pt"><b>PROGRAMA DE LA SEMANA #{{ $programaVium->programa }}</b></font></font></p>
		</td>
	</tr>
</table>
<p align="center" style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p align="center" style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<table width="665" cellpadding="4" cellspacing="0">
	<col width="248">
	<col width="237">
	<col width="153">
	<tr>
		<td colspan="5" width="655" valign="top" style="border: 1px solid #000000; padding: 0.1cm">
			<p align="center"><font face="Liberation Sans, sans-serif"><b>Area:</b>
			<span style="text-decoration: none"><font size="3" style="font-size: 12pt"><span style="font-style: normal"><span style="font-weight: normal">SUPV
			MANTTO DE VÍAS</span></span></font></span></font></p>
		</td>
	</tr>
	<tr valign="top">
		<td width="248" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><b>Fecha de Inicio: <br>{{\Carbon\Carbon::parse($programaVium->fecha_inicio)->format('d/m/Y')}}</b></p>
		</td>
		<td width="237" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><b>Fecha Fin: <br> {{\Carbon\Carbon::parse($programaVium->fecha_fin)->format('d/m/Y')}}</b></p>
		</td>
		<td width="153" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
			<p align="center"><b>Cant. Pers: </b> <br>{{$programaActividades->sum('cant_persona')}}
			</p>
		</td>
		<td width="153" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
			<p align="center"><b>Horas: </b> <br> {{$programaActividades->sum('tiempo')}} Hrs
			</p>
		</td>
		<td width="153" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
			<p align="center"><b>H.H: </b><br>{{$programaActividades->sum('cant_persona') * $programaActividades->sum('tiempo')}} Hrs
			</p>
		</td>
	</tr>
</table>
<p align="center" style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p align="center" style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<table width="665" cellpadding="4" cellspacing="0">
	<col width="70">
	<col width="189">
	<col width="45">
	<col width="82">
	<col width="155">
	<col width="73">
	<tr valign="top">
		<td rowspan="2" width="70" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font size="2" style="font-size: 10pt"><b>NRO
			ORDEN</b></font></p>
		</td>
		<td rowspan="2" width="189" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center" style="margin-bottom: 0cm; font-style: normal; text-decoration: none">
			<font face="Liberation Sans, sans-serif"><font size="2" style="font-size: 10pt"><b>DESCRIPCIÓN
			DE ACTIVIDAD</b></font></font></p>
			<p align="center"><br/>

			</p>
		</td>
		
		<td rowspan="2" width="82" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center" style="font-style: normal; text-decoration: none">
			<font face="Liberation Sans, sans-serif"><font size="2" style="font-size: 10pt"><b>FECHA</b></font></font></p>
		</td>
		<td rowspan="2" width="155" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font size="2" style="font-size: 10pt"><b>PLAN</b></font></p>
		</td>
		<td rowspan="2" width="45" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font size="2" style="font-size: 10pt"><b>REAL</b></font></p>
		</td>
		<td rowspan="2" width="45" style="border: 1px solid #000000; padding: 0.1cm">

			<p align="center"><font size="2" style="font-size: 10pt"><b>CUMPLI (%).</b></font></p>
		</td>

		<tr>
			
		</tr>
	</tr>
		@foreach ($programaDetalleVia as $programaDetalleVium)
	<tr valign="top">
		<td width="70" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center">{{ $programaDetalleVium->nro_orden }}
			</p>
		</td>
		<td width="189" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="left">{{ $programaDetalleVium->programaAnualVium->descripcion }} {{ $programaDetalleVium->programaAnualVium->tramo }} ({{ $programaDetalleVium->programaAnualVium->tramo_km_inicio }} - {{ $programaDetalleVium->programaAnualVium->tramo_km_fin }})
			</p>
		</td>
		<td width="45" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center" style="text-transform: uppercase;">
				{{\Carbon\Carbon::parse($programaDetalleVium->fecha)->isoformat('dddd D/MM/Y')}}
			</p>
		</td>
		<td width="82" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center">{{ $programaDetalleVium->programaAnualVium->plan }}
			</p>
		</td>
		<td width="155" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center">{{$programaActividades->where('programa_anual_id',$programaDetalleVium->programa_anual_id)->sum('tramo_km_total')}}
			</p>
		</td>
		<td width="73" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
			<p align="center">
				{{round((($programaActividades->where('programa_anual_id',$programaDetalleVium->programa_anual_id)->sum('tramo_km_total'))/ $programaDetalleVium->programaAnualVium->plan)*100) }}%
			</p>
		</td>
	</tr>
		@endforeach
</table>
<p align="center" style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p align="center" style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<table width="665" cellpadding="4" cellspacing="0">
	<col width="204">
	<col width="7">
	<col width="215">
	<col width="7">
	<col width="192">
	<tr valign="top">
		<td width="204" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center">{{$programaVium->datosplanificador->nombre}}

			</p>
		</td>
		<td width="7" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="215" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center">{{$programaVium->datosjefeTurnoarea->nombre}}
			</p>
		</td>
		<td width="7" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="192" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center">{{$programaVium->datosjefeplanificacion->nombre}}

			</p>
		</td>
	</tr>
	<tr valign="top">
		<td width="204" style="border: none; padding: 0cm">
			<p align="center">Planificador de Mantenimiento</p>
		</td>
		<td width="7" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="215" style="border: none; padding: 0cm">
			<p align="center">Jefe de Turno del Área</p>
		</td>
		<td width="7" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="192" style="border: none; padding: 0cm">
			<p align="center">Jefe de Planificación de Mantenimiento</p>
		</td>
	</tr>
</table>
<p align="center" style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
</div>
</body>
</html>

</div>
</div>
</div>
</section>
@endsection