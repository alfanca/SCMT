@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Programa de Vías (Detalle)')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Programa de Vías Sem N°{{$programaVium->programa}}</h4>
                        <p class="card-category">Programas de Mantenimiento Semanal Cumplimiento 


                        </p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">

                        <a rel="tooltip" title="Ferro de Inspección" 
                            href="{{ route('f_programa_via',$programaVium->id) }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-file-alt"></i>
                        </a> 
                        <a rel="tooltip" title="Regresar"  
                            href="{{ route('programavias.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>

                    <div class="card-body">
                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                        @if($programaVium->estatus != 'CERRADA')
                        <div class="col-12 text-right mt-4">
                         <a class="btn btn-sm btn-rounded" style="background-color: #9B945F;" href="{{ route('programavias.edit',$programaVium->id) }}"><i class="fa fa-fw fa-edit"></i> Editar</a> 
                          @csrf
                        </div>
                        @endif
                        @endif
                        
                        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>

                        <br>
              
                        <div class="card-group mt-4">
                        <div class="form-group col-2">
                            <strong><b>Programa Sem N° {{ $programaVium->programa }}</b></strong>
                            
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Inicio:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse( $programaVium->fecha_inicio )->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Fin:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse($programaVium->fecha_fin)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Estatus:</b>&nbsp&nbsp </strong>
                            {{$programaVium->estatus}}
                        </div>
                        </div>
                        <hr>
                        <h4 class="col-md-12 text-center mt-3">Responsables</h4>
                        <br>
                        <div class="card-group mt-4">
                        <div class="form-group col-4">
                            <strong><b>Planificador:</b></strong>
                            {{$programaVium->datosplanificador->nombre}}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Superintendente:</b></strong>
                            {{$programaVium->datosjefeTurnoarea->nombre}}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Jefe de Planificación:</b></strong>
                            {{$programaVium->datosjefeplanificacion->nombre}}
                        </div>
                        </div>

                        <hr>
                        <h4 class="col-md-12 text-center mt-3">Otros Datos</h4>
                        <br>
                        <div class="card-group mt-6">
                        <div class="form-group col-2">
                            <strong><b>Nota: {{ $programaVium->nota }}</b></strong>
                            
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Usuario Crea:</b>&nbsp&nbsp </strong>
                            {{$programaVium->usuario_crea}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Usuario Actualiza:</b>&nbsp&nbsp </strong>
                            {{$programaVium->usuario_actualiza}}
                        </div>
                        </div>

                        <hr>

                        <div class="text-right">
                        @if((Gate::check('isplanificador') || Gate::check('isJefe')) and $programaVium->estatus == 'LIBERADA') 
                        <a class="btn btn-sm btn" style="background-color: #9B945F;" href="{{ route('programaviasdetalle.create' ,['id'=>$programaVium->id]) }}"><i class="fa fa-fw fa-upload"></i> Agregar Programa</a>
                        @endif
                        </div>

                        <div class="card-body">

                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>                                        
                                        <th>Descripción</th>
                                        <th class="text-center">Unid</th>
                                        <th class="text-center">Tramo</th>
                                        <th class="text-center">Fecha</th>
                                        <th class="text-center">Plan</th>
                                        <th class="text-center">Real</th>
                                        <th class="text-center">Cumpli.(%)</th>
                                        <th class="text-center">Nro Orden</th>
                                        <th class="text-center">Nota</th>
                                        <th class="text-center">Usuario Crea</th>
                                        <th class="text-center">Usuario Actualiza</th>

                                        <th class="text-center">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($programaDetalleVia as $programaDetalleVium)
                                        <tr>

                                            <td>{{ $programaDetalleVium->programaAnualVium->descripcion }}</td>
                                            <td class="text-center">{{ $programaDetalleVium->programaAnualVium->unidad }}</td>
                                            <td class="text-center">{{ $programaDetalleVium->programaAnualVium->tramo }} ({{ $programaDetalleVium->programaAnualVium->tramo_km_inicio }} - {{ $programaDetalleVium->programaAnualVium->tramo_km_fin }})</td>
                                            
                                            <td class="text-center" style="text-transform: uppercase;">{{\Carbon\Carbon::parse($programaDetalleVium->fecha)->isoformat('dddd D/MM/Y')}}</td>

                                            <td class="text-center">{{ $programaDetalleVium->plan }}</td>

                                            <td class="text-center">
                                                
                                                {{$programaActividades->where('programa_anual_id',$programaDetalleVium->programa_anual_id)->sum('tramo_km_total')}}

                                            </td>

                                            @if(round((($programaActividades->where('programa_anual_id',$programaDetalleVium->programa_anual_id)->sum('tramo_km_total'))/ $programaDetalleVium->programaAnualVium->plan)*100) >= 85)
                                            <th class="text-center" style="color: #28a745">
                                            @elseif(round((($programaActividades->where('programa_anual_id',$programaDetalleVium->programa_anual_id)->sum('tramo_km_total'))/ $programaDetalleVium->programaAnualVium->plan)*100) >= 50)
                                            <th class="text-center" style="color: #ffc107">
                                            @elseif(round((($programaActividades->where('programa_anual_id',$programaDetalleVium->programa_anual_id)->sum('tramo_km_total'))/ $programaDetalleVium->programaAnualVium->plan)*100) < 50)
                                            <th class="text-center" style="color: #dc3545">
                                            @endif
                                                
                                                {{round((($programaActividades->where('programa_anual_id',$programaDetalleVium->programa_anual_id)->sum('tramo_km_total'))/ $programaDetalleVium->programaAnualVium->plan)*100) }}%

                                            </td>
                                            
                                            <td class="text-center">{{ $programaDetalleVium->nro_orden }}</td>
                                            <td class="text-center">{{ $programaDetalleVium->nota }}</td>
                                            <td class="text-center">{{ $programaDetalleVium->usuario_crea }}</td>
                                            <td class="text-center">{{ $programaDetalleVium->usuario_actualiza }}</td>

                                            <td class="td-actions">
                                                <form action="{{ route('programaviasdetalle.destroy',$programaDetalleVium->id) }}" method="POST">
                                                    <a class="btn btn-link btn-success" href="{{ route('programaviasdetalle.edit',$programaDetalleVium->id) }}"><i class="fa fa-fw fa-edit"></i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="text-center"><b>TOTAL</b></td>
                                <td class="text-center">{{ $programaDetalleVia->sum('plan') }}</td>

                                <td class="text-center">{{$programaActividades->sum('tramo_km_total')}}
                                </td>
                                @if($programaDetalleVia->sum('plan') != 0)

                                @if(round($programaActividades->sum('tramo_km_total') /$programaDetalleVia->sum('plan') *100) >= 85)

                                 <th class="text-center" style="color: #28a745">
                                 @elseif(round($programaActividades->sum('tramo_km_total') /$programaDetalleVia->sum('plan') *100) >= 50)
                                 
                                 <th class="text-center" style="color: #ffc107">
                                 @elseif(round($programaActividades->sum('tramo_km_total') /$programaDetalleVia->sum('plan') *100) < 50)
                                            
                                 <th class="text-center" style="color: #dc3545">
                                 @endif
                                                
                                   <b>{{round($programaActividades->sum('tramo_km_total') /$programaDetalleVia->sum('plan') *100) }}%</b>

                                @else
                                <td class="text-center" style="color: red;">0%</td>
                                @endif

                                </td>
                                
                            </table>
                        </div>

                    </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
