<div class="box box-info padding-1">
    <div class="box-body">
        

        <table class="table">
            <thead>
                <tr>
                    <th class="text-center col-1">{{ Form::label('Semana #') }}</th>
                    <th class="text-center col-2">{{ Form::label('fecha_inicio') }}</th>
                    <th class="text-center col-2">{{ Form::label('fecha_fin') }}</th>
                    @if(!empty($programaVium->id))
                    <th class="text-center col-2">{{ Form::label('estatus') }}</th>
                    @endif
                    <th class="text-center">{{ Form::label('Nota') }}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center">
                        {{ Form::number('programa', $programaVium->programa, ['class' => 'form-control text-center' . ($errors->has('programa') ? ' is-invalid' : ''), 'min' => '1','max' => '53','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('programa', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    <td class="text-center">
                        {{ Form::date('fecha_inicio', $programaVium->fecha_inicio, ['class' => 'form-control text-center' . ($errors->has('fecha_inicio') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Inicio']) }}
                        {!! $errors->first('fecha_inicio', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    <td class="text-center">
                        {{ Form::date('fecha_fin', $programaVium->fecha_fin, ['class' => 'form-control text-center' . ($errors->has('fecha_fin') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Fin']) }}
                        {!! $errors->first('fecha_fin', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    @if(!empty($programaVium->id))
                    <td class="text-center">
                         <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }} text-center"
                            name="estatus" id="input-estatus" required="true"
                          >
                          <option value="">SELECCIONE</option>
                          @foreach($programaVium->estatus() as $status)
                            <option value="{{$status}}" {{$programaVium->estatus == $status ? 'selected' : '' }}>{{$status}}</option>
                          @endforeach
                        </select>

                        @if ($errors->has('estatus'))
                          <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
                        @endif
                    </td>
                    @endif
                    <td>
                        {{ Form::text('nota', $programaVium->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'maxlength' => '500','placeholder' => 'Nota']) }}
                        {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                </tr>
            </tbody>
        </table>

        <table class="table">
            <thead>
                <tr>
                    <th class="text-center col-4">{{ Form::label('planificador') }}</th>
                    <th class="text-center col-4">{{ Form::label('Jefe Superintendecia') }}</th>
                    <th class="text-center col-4">{{ Form::label('Jefe Planificación') }}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                   
                    <td>
                        <div class="form-group{{ $errors->has('planificador') ? ' has-danger' : '' }}">
                        <select name="planificador" class="responsable col-md-6" style="width: 100%">
                          @if (!empty($programaVium->datosplanificador->nombre))
                            <option value="{{$programaVium->planificador}}">{{ $programaVium->datosplanificador->nombre}}</option>
                          @endif
                        </select>
                        @if ($errors->has('planificador'))
                          <span id="name-error" class="error text-danger" for="input-planificador">{{ $errors->first('planificador') }}</span>
                        @endif

                        </div>
                    </td>
                    <td>
                        <div class="form-group{{ $errors->has('jefesuperintendencia') ? ' has-danger' : '' }}">
                        <select name="jefesuperintendencia" class="responsable col-md-6" style="width: 100%">
                          @if (!empty($programaVium->datosjefeTurnoarea->nombre))
                            <option value="{{$programaVium->jefesuperintendencia}}">{{ $programaVium->datosjefeTurnoarea->nombre}}</option>
                          @endif
                        </select>
                        @if ($errors->has('jefesuperintendencia'))
                          <span id="name-error" class="error text-danger" for="input-jefesuperintendencia">{{ $errors->first('jefesuperintendencia') }}</span>
                        @endif

                        </div>
                    </td>
                    <td>
                        <div class="form-group{{ $errors->has('jefeplanificacion') ? ' has-danger' : '' }}">
                        <select name="jefeplanificacion" class="responsable col-md-6" style="width: 100%">
                          @if (!empty($programaVium->datosjefeplanificacion->nombre))
                            <option value="{{$programaVium->jefeplanificacion}}">{{ $programaVium->datosjefeplanificacion->nombre}}</option>
                          @endif
                        </select>
                        @if ($errors->has('jefeplanificacion'))
                          <span id="name-error" class="error text-danger" for="input-jefeplanificacion">{{ $errors->first('jefeplanificacion') }}</span>
                        @endif

                        </div>
                    </td>
                </tr>
            </tbody>
        </table>       
    </div>
</div>