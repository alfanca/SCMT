@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Programa de Vías')])
@section('content')

 <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">

                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Inspecciones y Mantenimiento de Vías </h4>
                        <p class="card-category">Registro y Administración de Mantenimiento de Vías (Histórico)</p>
                      </div> 
                      <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip" title="Regresar"  
                            href="{{ route('programavias.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>
                        </a>  
                      </div>
                    </div>


                    <div class="card-body">
                      <form method="get" autocomplete="off" action="{{route('historico_programa_vias')}}" class="form-horizontal" style="margin-left: 260px" role="form">
                         <div class="row col-md-8">
                           <label class="col-md-3 col-form-label">{{ __('FECHA INICIO') }}</label>
                           <div class="col-md-3">
                               <input type="date" class="form-control"  id="fecha_inicio" type="text" name="fecha_inicio" value="{{$fechas['fecha_inicio'] ?? ''}}"/>
                           </div>

                           <label class="col-md-2 col-form-label">{{ __('FECHA FIN') }}</label>
                           <div class="col-md-3">
                               <input type="date" class="form-control"  id="fecha_fin" type="text" name="fecha_fin" value="{{$fechas['fecha_fin']  ?? ''}}"/>
                           </div>
                           <div class="col-md-1">
                               <input type="submit" value="Buscar" class="btn btn-primary">
                           </div>
                        </div>
                       </form>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th class="text-center">Programa</th>
										<th class="text-center">Fecha Inicio</th>
										<th class="text-center">Fecha Fin</th>
										<th class="text-center">Estatus</th>
										<th class="text-center">Planificador</th>
										<th class="text-center">Jefe Superintendencia</th>
										<th class="text-center">Jefe Planificacion</th>
										<th class="text-center">Nota</th>
										<th class="text-center">Usuario Crea</th>
										<th class="text-center">Usuario Actualiza</th>

                                        <th class="text-center">Borrar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($programaVia as $programaVium)
                                        <tr>
                                            <td>{{ ++$i }}</td>
                                            
											<td><a class="btn btn-sm btn-primary " href="{{ route('programavias.show',$programaVium->id) }}">Sem #{{ $programaVium->programa }}</a></td>
											<td class="text-center">{{\Carbon\Carbon::parse( $programaVium->fecha_inicio )->format('d/m/Y')}}</td>
											<td class="text-center">{{\Carbon\Carbon::parse($programaVium->fecha_fin)->format('d/m/Y')}}</td>
											<td class="text-center">{{ $programaVium->estatus }}</td>
											<td class="text-center">{{$programaVium->datosplanificador->nombre}}</td>
											<td class="text-center">{{$programaVium->datosjefeTurnoarea->nombre}}</td>
											<td class="text-center">{{$programaVium->datosjefeplanificacion->nombre}}</td>
											<td class="text-center">{{ $programaVium->nota }}</td>
											<td class="text-center">{{ $programaVium->usuario_crea }}</td>
											<td class="text-center">{{ $programaVium->usuario_actualiza }}</td>

                                            <td class="text-center">
                                              @if((Gate::check('isplanificador') || Gate::check('isJefe')) and $programaVium->estatus == 'LIBERADA' )
                                                <form action="{{ route('programavias.destroy',$programaVium->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
@endsection
