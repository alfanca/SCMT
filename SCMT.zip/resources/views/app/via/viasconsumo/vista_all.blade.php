@extends('layouts.app', ['activePage' => 'consumovias', 'titlePage' => __('Historial de Consumo de Vía')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Historial de Consumo de Vía</h4>
                        <p class="card-category">Busqueda de Consumo de Vía</p>
                      </div>
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{route('viasconsumo.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i> Regresar
                        </a>  
                      </div>
                    </div>

            <div class="card-body">
             <div class="card-body">

           <form method="get" autocomplete="off" action="{{route('via_consumo.periodo')}}" class="form-horizontal" role="form">
            @include('app.comun.nav_calendario_busqueda_sinboton_consumo')
           </form>

          
           </div>
             <div class="card-body">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        
                                        <th class="text-center">Fecha</th>
                                        <th class="text-center">N°SAP</th>
                                        <th class="text-center">N° Parte</th>
                                        <th>Material</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Tramo</th>
                                        <th class="text-center">Km Inicial</th>
                                        <th class="text-center">Km Final</th>
                                        <th class="text-center">Turno</th>
                                        <th class="text-center">Razon</th>
                                        <th class="text-center">Responsable</th>
                                        <th class="text-center">Acciones</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($consumo_all as $viasConsumo)
                                        <tr>
                                            
                                          <td class="text-center">{{ \Carbon\Carbon::parse($viasConsumo->fecha)->format('d/m/Y') }}</td>
                                          <td class="text-center">{{ $viasConsumo->viasMateriale->sap }}</td>
                                          <td class="text-center">{{ $viasConsumo->viasMateriale->parte }}</td>
                                          <td>{{ $viasConsumo->viasMateriale->descripcion }}</td>
                                          <td class="text-center">{{ $viasConsumo->cantidad }}</td>
                                          <td class="text-center">{{ $viasConsumo::TRAMO[$viasConsumo->tramo]}}</td>
                                          <td class="text-center">{{ $viasConsumo->ubicacion_inicial }}</td>
                                          <td class="text-center">{{ $viasConsumo->ubicacion_final }}</td>
                                          <td class="text-center">{{ $viasConsumo::TURNO[$viasConsumo->turno] }}</td>
                                          <td>{{ $viasConsumo::RAZON[$viasConsumo->razon] }}</td>
                                          <td>{{ $viasConsumo->datos->nombre }}</td>

                                            <td class="td-actions">
                                                <form action="{{ route('viasconsumo.destroy',$viasConsumo->id) }}" method="POST" class="text-center">
                                                    <a class="btn btn-link btn-primary " rel="tooltip" title="Ver Detalle" href="{{ route('viasconsumo.show',$viasConsumo->id) }}"><i class="fa fa-fw fa-eye"></i></a>
                                                    <a class="btn btn-link btn-success" rel="tooltip" title="Editar" href="{{ route('viasconsumo.edit',$viasConsumo->id) }}"><i class="fa fa-fw fa-edit"></i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Componentes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


@endsection
