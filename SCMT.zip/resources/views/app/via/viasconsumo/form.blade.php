<div class="box box-info padding-1">
    <div class="box-body">
        

        <div class="card-group">
            {{ Form::label('Fecha: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha', $viasConsumo->fecha, ['class' => 'form-control text-center' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la Fecha']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Tramo: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('tramo', $tramo,$viasConsumo->tramo, ['class' => 'form-control col-1 text-center' . ($errors->has('tramo') ? ' is-invalid' : ''), 'placeholder' => 'Seleccionar']) }}
            {!! $errors->first('tramo', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('KM Inicial: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('ubicacion_inicial', $viasConsumo->ubicacion_inicial, ['class' => 'form-control text-center' . ($errors->has('ubicacion_inicial') ? ' is-invalid' : ''),'min' => '0.00', 'step' => '0.1','placeholder' => 'Km Inicial']) }}
            {!! $errors->first('ubicacion_inicial', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('KM Final: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('ubicacion_final', $viasConsumo->ubicacion_final, ['class' => 'form-control text-center' . ($errors->has('ubicacion_final') ? ' is-invalid' : ''), 'min' => '0.00', 'step' => '0.1','placeholder' => 'Km Final']) }}
            {!! $errors->first('ubicacion_final', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

         <div class="card-group mt-5 col-12 row">

            {{ Form::label('turno: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('turno', $turno,$viasConsumo->turno, ['class' => 'form-control col-1 text-center' . ($errors->has('turno') ? ' is-invalid' : ''), 'placeholder' => 'Seleccionar']) }}
            {!! $errors->first('turno', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('cantidad: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('cantidad', $viasConsumo->cantidad, ['class' => 'form-control text-center' . ($errors->has('cantidad') ? ' is-invalid' : ''), 'min' => '0.00', 'placeholder' => 'Ingrese Cantidad']) }}
            {!! $errors->first('cantidad', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp


            {{ Form::label('razon: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('razon', $razon,$viasConsumo->razon, ['class' => 'form-control col-2 text-center' . ($errors->has('razon') ? ' is-invalid' : ''), 'placeholder' => 'Seleccionar']) }}
            {!! $errors->first('razon', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            
            {{ Form::label('responsable:') }}
            <div class="col-md-2">
            <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
            <select name="responsable" class="responsable col-md-6" style="width: 100%">
              @if (!empty($viasConsumo->datos->nombre))
                <option value="{{$viasConsumo->responsable}}">{{ $viasConsumo->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
            @endif

            </div>
          </div>
        </div>

        <div class="form-group mt-5 col-md-12">
            {{ Form::label('descripcion') }}
            <br>
            {{ Form::text('descripcion', $viasConsumo->descripcion, ['class' => 'form-control' . ($errors->has('descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la Descripción']) }}
            {!! $errors->first('descripcion', '<div class="invalid-feedback">:message</div>') !!}
        </div>

        <div class="table-responsive mt-5">
                <table class="table" id="myTable">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center col-1">Seleccionar</th>
                        <th class="text-center col-1">N° SAP</th>
                        <th class="text-center col-1">N° Parte</th>
                        <th class="text-center col-6">Descripción</th>
                        <th class="text-center col-1">Unid</th>
                        <th class="text-center col-1">Precio Unitario $</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($materialesvias as $materiales)
                      <tr>
                      <td class="text-center"><input type="radio" name="material_vias_id" value="{{$materiales->id}}"></td>              
                      <td class="text-center">{{$materiales->sap}}</td>
                      <td class="text-center">{{$materiales->parte}}</td>
                      <td style="text-transform: uppercase;">{{$materiales->descripcion}}</td>
                      <td class="text-center">{{$materiales::UNIDAD[$materiales->unidad]}}</td>
                      <td class="text-center">{{$materiales->preciounitario}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7" class="text-center">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {


        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Materiales)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


    </div>
    <div class="card-footer justify-content-center mt-2">
       <a href="{{route('viasconsumo.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
         <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
     </div>
</div>