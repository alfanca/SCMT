@extends('layouts.app', ['activePage' => 'consumovias', 'titlePage' => __('Detalles del Consumo de Vías')])
@section('content')

 <section class="content container-fluid">
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Consumo de Vías</h4>
                        <p class="card-category">Detalles del Consumo de Vías</p>
                      </div>
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{route('viasconsumo.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i> Regresar
                        </a>  
                      </div>
                    </div>


                    <div class="card-body">
                        
                        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
                        <div class="card-group mt-4">
                        <div class="form-group mx-4">
                            <strong><b>Fecha:</b></strong>
                            {{ \Carbon\Carbon::parse($viasConsumo->fecha)->format('d/m/Y') }}
                        </div>
                        <div class="form-group mx-4">
                            <strong><b>Tramo:</b></strong>
                            {{ $viasConsumo::TRAMO[$viasConsumo->tramo]}}
                        </div>
                        <div class="form-group mx-4">
                            <strong><b>Ubicacion Inicial:</b></strong>
                            {{ $viasConsumo->ubicacion_inicial }} Km
                        </div>
                        <div class="form-group mx-4">
                            <strong><b>Ubicacion Final:</b></strong>
                            {{ $viasConsumo->ubicacion_final }} Km
                        </div>
                        <div class="form-group mx-4">
                            <strong><b>Turno:</b></strong>
                            {{ $viasConsumo::TURNO[$viasConsumo->turno] }}
                        </div>
                        <div class="form-group mx-4">
                            <strong><b>Razon:</b></strong>
                            {{ $viasConsumo::RAZON[$viasConsumo->razon] }}
                        </div>   
                        </div>
                        <div class="card-group mt-4">
                        <div class="form-group mx-4">
                            <strong><b>Descripción:</b></strong>
                            {{ $viasConsumo->descripcion }}
                        </div>  
                       </div>
                        <hr>
                        <h4 class="col-md-12 text-center">Componente</h4>
                        <div class="card-group mt-4">

                  
                            <table id="myTable" class="table table-bordered">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">N° SAP</th>
                                        <th class="text-center">N° Parte</th>
                                        <th class="text-center">Material</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Precio $</th>
                                        <th class="text-center">Total $</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <tr>
                                <td class="text-center">{{ $viasConsumo->viasMateriale->sap }}</td>
                                <td class="text-center">{{ $viasConsumo->viasMateriale->parte }}</td>
                                <td class="text-center">{{ $viasConsumo->viasMateriale->descripcion }}</td>
                                <td class="text-center">{{ $viasConsumo->cantidad }}</td>
                                <td class="text-center">{{ $viasConsumo->precio }}</td>
                                <td class="text-center">{{ ($viasConsumo->precio)*$viasConsumo->cantidad }}</td>
                                </tr>
                               </tbody>
                            </table>
                         
                        </div>

                        <hr>
                        <h4 class="col-md-12 text-center">Responsables</h4>
                        <div class="card-group mt-4">
                        <div class="form-group mx-4">
                            <strong><b>Responsable:</b></strong><span style="text-transform: uppercase;">
                            {{ $viasConsumo->datos->nombre }}</span>
                        </div>
                        <div class="form-group mx-4">
                            <strong><b>Usuario Crea:</b></strong><span style="text-transform: uppercase;">
                            {{ $viasConsumo->usuario_crea }}</span>
                        </div>
                        <div class="form-group mx-4">
                            <strong><b>Usuario Actualiza:</b></strong><span style="text-transform: uppercase;">
                            {{ $viasConsumo->usuario_actualiza }}</span>
                        </div>
                       </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
