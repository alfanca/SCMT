<div class="box box-info padding-1">
    <div class="box-body">
        

        <div class="card-group">
            {{ Form::label('Fecha: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha', $viasConsumo->fecha, ['class' => 'form-control text-center' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la Fecha']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Tramo: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('tramo', $tramo,$viasConsumo->tramo, ['class' => 'form-control col-1 text-center' . ($errors->has('tramo') ? ' is-invalid' : ''), 'placeholder' => 'Seleccionar']) }}
            {!! $errors->first('tramo', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('KM Inicial: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('ubicacion_inicial', $viasConsumo->ubicacion_inicial, ['class' => 'form-control text-center' . ($errors->has('ubicacion_inicial') ? ' is-invalid' : ''),'min' => '0.00', 'step' => '0.1','placeholder' => 'Km Inicial']) }}
            {!! $errors->first('ubicacion_inicial', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('KM Final: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('ubicacion_final', $viasConsumo->ubicacion_final, ['class' => 'form-control text-center' . ($errors->has('ubicacion_final') ? ' is-invalid' : ''), 'min' => '0.00', 'step' => '0.1','placeholder' => 'Km Final']) }}
            {!! $errors->first('ubicacion_final', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

         <div class="card-group mt-5 col-12 row">

            {{ Form::label('turno: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('turno', $turno,$viasConsumo->turno, ['class' => 'form-control col-1 text-center' . ($errors->has('turno') ? ' is-invalid' : ''), 'placeholder' => 'Seleccionar']) }}
            {!! $errors->first('turno', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('cantidad: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('cantidad', $viasConsumo->cantidad, ['class' => 'form-control text-center' . ($errors->has('cantidad') ? ' is-invalid' : ''), 'min' => '0.00', 'placeholder' => 'Ingrese Cantidad']) }}
            {!! $errors->first('cantidad', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp


            {{ Form::label('razon: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('razon', $razon,$viasConsumo->razon, ['class' => 'form-control col-2 text-center' . ($errors->has('razon') ? ' is-invalid' : ''), 'placeholder' => 'Seleccionar']) }}
            {!! $errors->first('razon', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            
            {{ Form::label('responsable:') }}
            <div class="col-md-2">
            <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
            <select name="responsable" class="responsable col-md-6" style="width: 100%">
              @if (!empty($viasConsumo->datos->nombre))
                <option value="{{$viasConsumo->responsable}}">{{ $viasConsumo->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
            @endif

            </div>
          </div>
        </div>

        <div class="form-group mt-5 col-md-12">
            {{ Form::label('descripcion') }}
            <br>
            {{ Form::text('descripcion', $viasConsumo->descripcion, ['class' => 'form-control' . ($errors->has('descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la Descripción']) }}
            {!! $errors->first('descripcion', '<div class="invalid-feedback">:message</div>') !!}
        </div>

        <input type="text" name="material_vias_id" value="{{$_GET['id_material']}}" hidden="yes">

    </div>
    <div class="card-footer justify-content-center mt-2">
       <a href="{{route('viasconsumo.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
         <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
     </div>
</div>