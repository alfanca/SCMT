@extends('layouts.app', ['activePage' => 'consumovias', 'titlePage' => __('Consumo de Vías')])
@section('content')

 <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Consumo de Vías</h4>
                        <p class="card-category">Administración del Consumo de Vías</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip" title="Crear Consumo"
                            href="{{route('viasconsumo.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Crear Consumo
                          <i class="material-icons">add</i>
                        </a>  
                      </div>
                      @endif
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">No</th>
                                        
										<th class="text-center">Fecha</th>
										<th class="text-center">N°SAP</th>
                                        <th class="text-center">N° Parte</th>
                                        <th>Material</th>
										<th class="text-center">Cantidad</th>
										<th class="text-center">Tramo</th>
										<th class="text-center">Km Inicial</th>
										<th class="text-center">Km Final</th>
										<th class="text-center">Turno</th>
										<th class="text-center">Razon</th>
										<th class="text-center">Responsable</th>
                                        <th class="text-center">Acciones</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($viasConsumos as $viasConsumo)
                                        <tr>
                                            <td class="text-center">{{ ++$i }}</td>
                                            
											<td class="text-center">{{ \Carbon\Carbon::parse($viasConsumo->fecha)->format('d/m/Y') }}</td>
                                            <td class="text-center">{{ $viasConsumo->viasMateriale->sap }}</td>
											<td class="text-center">{{ $viasConsumo->viasMateriale->parte }}</td>
                                            <td><a rel="tooltip" title="Ver Detalle" href="{{ route('viasconsumo.show',$viasConsumo->id) }}">{{ $viasConsumo->viasMateriale->descripcion }}</a></td>
											<td class="text-center">{{ $viasConsumo->cantidad }}</td>
											<td class="text-center">{{ $viasConsumo::TRAMO[$viasConsumo->tramo]}}</td>
											<td class="text-center">{{ $viasConsumo->ubicacion_inicial }}</td>
											<td class="text-center">{{ $viasConsumo->ubicacion_final }}</td>
											<td class="text-center">{{ $viasConsumo::TURNO[$viasConsumo->turno] }}</td>
											<td>{{ $viasConsumo::RAZON[$viasConsumo->razon] }}</td>
											<td>{{ $viasConsumo->datos->nombre }}</td>

                                            <td class="td-actions">
                                                <form action="{{ route('viasconsumo.destroy',$viasConsumo->id) }}" method="POST" class="text-center">
                                                    @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                                    <a class="btn btn-link btn-success" rel="tooltip" title="Editar" href="{{ route('viasconsumo.edit',[$viasConsumo->id, 'id_material'=>$viasConsumo->material_vias_id]) }}"><i class="fa fa-fw fa-edit"></i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash"></i></button>
                                                    @endif
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['100'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Componentes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

</section>
@endsection
