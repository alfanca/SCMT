@extends('layouts.app')

@section('template_title')
    {{ $programaAnualVium->name ?? "{{ __('Show') Programa Anual Vium" }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">{{ __('Show') }} Programa Anual Vium</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('programa-anual-via.index') }}"> {{ __('Back') }}</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Ip10:</strong>
                            {{ $programaAnualVium->ip10 }}
                        </div>
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            {{ $programaAnualVium->descripcion }}
                        </div>
                        <div class="form-group">
                            <strong>Fecha Actualizacion:</strong>
                            {{ $programaAnualVium->fecha_actualizacion }}
                        </div>
                        <div class="form-group">
                            <strong>Frecuencia:</strong>
                            {{ $programaAnualVium->frecuencia }}
                        </div>
                        <div class="form-group">
                            <strong>Unidad:</strong>
                            {{ $programaAnualVium->unidad }}
                        </div>
                        <div class="form-group">
                            <strong>Tramo:</strong>
                            {{ $programaAnualVium->tramo }}
                        </div>
                        <div class="form-group">
                            <strong>Tramo Km Inicio:</strong>
                            {{ $programaAnualVium->tramo_km_inicio }}
                        </div>
                        <div class="form-group">
                            <strong>Tramo Km Fin:</strong>
                            {{ $programaAnualVium->tramo_km_fin }}
                        </div>
                        <div class="form-group">
                            <strong>Plan:</strong>
                            {{ $programaAnualVium->plan }}
                        </div>
                        <div class="form-group">
                            <strong>Estatus:</strong>
                            {{ $programaAnualVium->estatus }}
                        </div>
                        <div class="form-group">
                            <strong>Nota:</strong>
                            {{ $programaAnualVium->nota }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Crea:</strong>
                            {{ $programaAnualVium->usuario_crea }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Actualiza:</strong>
                            {{ $programaAnualVium->usuario_actualiza }}
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
