@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Premisa de Vías')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                     <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Crear Premisa de Vías</h4>
                      </div>
                      </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('programaviasanual.store') }}"  role="form" enctype="multipart/form-data">
                            @csrf

                            @include('app.via.programa-anual-vium.form')

                            <div class="card-footer justify-content-center">
                             <a href="{{route('programaviasanual.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                             <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
                             </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
