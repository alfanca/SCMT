<div class="box box-info padding-1">
    <div class="box-body">

        <table class="table">
            <thead>
                <tr>
                    <th class="text-center col-1">{{ Form::label('IP10') }}</th>
                    <th class="text-center col-4">{{ Form::label('descripcion') }}</th>
                    <th class="text-center col-1">{{ Form::label('frecuencia') }}</th>
                    @if(!empty($programaAnualVium->id))
                    <th class="text-center col-1">{{ Form::label('fecha_actualizacion') }}</th>
                    <th class="text-center col-1">{{ Form::label('estatus') }}</th>
                    @endif
                    <th class="text-center col-1">{{ Form::label('unidad') }}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center">
                        {{ Form::number('ip10', $programaAnualVium->ip10, ['class' => 'form-control text-center' . ($errors->has('ip10') ? ' is-invalid' : ''), 'min' => '0','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('ip10', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    <td class="text-center">

                        <div class="form-group{{ $errors->has('cedescripcionco') ? ' has-danger' : '' }} text-center">
                        <select class="custom-select form-control{{ $errors->has('descripcion') ? ' is-invalid' : '' }}"
                            name="descripcion" id="input-descripcion" required="true"
                          >
                          <option value="">SELECCIONE</option>
                          @foreach($programaAnualVium->inspecciones() as $inspeccion)
                            <option value="{{$inspeccion}}" {{$programaAnualVium->descripcion == $inspeccion ? 'selected' : '' }}>{{$inspeccion}}</option>
                          @endforeach
                        </select>

                        @if ($errors->has('descripcion'))
                          <span id="name-error" class="error text-danger" for="input-descripcion">{{ $errors->first('descripcion') }}</span>
                        @endif
                      </div>
                    </td>
                    <td class="text-center">
                        {{ Form::number('frecuencia', $programaAnualVium->frecuencia, ['class' => 'form-control text-center' . ($errors->has('frecuencia') ? ' is-invalid' : ''), 'min' => '1','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('frecuencia', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    @if(!empty($programaAnualVium->id))
                    <td class="text-center">
                        {{ Form::date('fecha_actualizacion', $programaAnualVium->fecha_actualizacion, ['class' => 'form-control text-center' . ($errors->has('fecha_actualizacion') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese']) }}
                        {!! $errors->first('fecha_actualizacion', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    <td class="text-center">

                       
                        <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }} text-center"
                            name="estatus" id="input-estatus" required="true"
                          >
                          <option value="">SELECCIONE</option>
                          @foreach($programaAnualVium->estatus() as $status)
                            <option value="{{$status}}" {{$programaAnualVium->estatus == $status ? 'selected' : '' }}>{{$status}}</option>
                          @endforeach
                        </select>

                        @if ($errors->has('estatus'))
                          <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
                        @endif
                    
                    </td>
                    @endif
                    <td class="text-center">
                       
                        <select class="custom-select form-control{{ $errors->has('unidad') ? ' is-invalid' : '' }} text-center"
                            name="unidad" id="input-unidad" required="true"
                          >
                          <option value="">SELECCIONE</option>
                          @foreach($programaAnualVium->unidades() as $unidad)
                            <option value="{{$unidad}}" {{$programaAnualVium->unidad == $unidad ? 'selected' : '' }}>{{$unidad}}</option>
                          @endforeach
                        </select>

                        @if ($errors->has('unidad'))
                          <span id="name-error" class="error text-danger" for="input-unidad">{{ $errors->first('unidad') }}</span>
                        @endif
                     
                    </td>
                </tr>
            </tbody>
        </table>

        <hr>

        <table class="table">
            <thead>
                <tr>
                    <th class="text-center col-2">{{ Form::label('tramo') }}</th>
                    <th class="text-center col-1">{{ Form::label('km_inicio') }}</th>
                    <th class="text-center col-1">{{ Form::label('km_fin') }}</th>     
                    <th class="text-center col-1">{{ Form::label('plan') }}</th>
                    <th class="text-center col-7">{{ Form::label('nota') }}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center">
                        <select class="custom-select form-control{{ $errors->has('tramo') ? ' is-invalid' : '' }} text-center"
                            name="tramo" id="input-tramo" required="true"
                          >
                          <option value="">SELECCIONE</option>
                          @foreach($programaAnualVium->tramos() as $tramo)
                            <option value="{{$tramo}}" {{$programaAnualVium->tramo == $tramo ? 'selected' : '' }}>{{$tramo}}</option>
                          @endforeach
                        </select>

                        @if ($errors->has('tramo'))
                          <span id="name-error" class="error text-danger" for="input-tramo">{{ $errors->first('tramo') }}</span>
                        @endif

                    </td>
                    <td class="text-center">
                        {{ Form::number('tramo_km_inicio', $programaAnualVium->tramo_km_inicio, ['class' => 'form-control text-center' . ($errors->has('tramo_km_inicio') ? ' is-invalid' : ''),'min' => '0', 'max' => '76', 'step' => '0.2','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('tramo_km_inicio', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    <td class="text-center">
                        {{ Form::number('tramo_km_fin', $programaAnualVium->tramo_km_fin, ['class' => 'form-control text-center' . ($errors->has('tramo_km_fin') ? ' is-invalid' : ''), 'min' => '0', 'max' => '76', 'step' => '0.2','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('tramo_km_fin', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    <td class="text-center">
                        {{ Form::number('plan', $programaAnualVium->plan, ['class' => 'form-control text-center' . ($errors->has('plan') ? ' is-invalid' : ''), 'min' => '1', 'step' => '0.2', 'placeholder' => 'Ingrese']) }}
                        {!! $errors->first('plan', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                    <td class="text-center">
                        {{ Form::text('nota', $programaAnualVium->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'maxlength' => '500','placeholder' => 'Ingrese']) }}
                        {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}
                    </td>
                </tr>
            </tbody>
        </table>

    </div>
</div>