@extends('layouts.app', ['activePage' => 'programavias', 'titlePage' => __('Premisa de Vías')])
@section('content')

 <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Premisas vias Anual </h4>
                        <p class="card-category">Premisas para Programas Anuales de Vías</p>
                      </div>
                      <div class="col-md-6" style="text-align: right;">

                        <button class="btn btn-sm btn-rounded dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background: #9b945f; color: white;" rel="tooltip" title="Ir a:">
                          <i class="fas fa-location-arrow" style="font-size: 17px"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdownProfile" style="border: 3px solid; border-radius: 20px; border-color: white;">
                           <a class="dropdown-item" href="{{route('programavias.index')}}" style="border-radius: 20px;">{{ __('Programa Vías') }}</a>
                           <div class="dropdown-divider"></div>
                           <a class="dropdown-item" href="{{route('programaviasactividades.index')}}" style="border-radius: 20px;">{{ __('Actividades') }}</a>
                           
                        </div>

                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))   
                        <a rel="tooltip" title="Crear Premisa Anual"
                            href="{{ route('programaviasanual.create') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="fas fa-plus" style="font-size: 17px"></i>
                        </a>  
                      @endif
                      </div>
                    </div>

                    <div class="card-body">
                        <form id="form">
                          <div class="text-center">
                            <div class="form-group">
                                <div class="col-md-12">
                                  <span style="font-size: 15px">Estatus:&nbsp&nbsp</span> 

                                  <select class="custom-select form-control col-2 text-center" name="estatus" style="width:100%" onchange="this.form.submit()">
                                    <option value="">SELECCIONE</option>
                                  @foreach($programaestatus as $status)
                                    <option value="{{$status}}">{{$status}}</option>
                                  @endforeach
                                </select>
                                </div>
                            </div>
                          </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">No</th>
                                        
                      										<th class="text-center">Ip10</th>
                      										<th class="text-center col-9">Descripcion</th>
                      										<th class="text-center">Fecha Ult.Programa</th>
                      										<th class="text-center">Frecuencia</th>
                                          <th class="text-center">Fecha Actualizada</th>
                                          <th class="text-center">Semana</th>
                      										<th class="text-center">Unidad</th>
                      										<th class="text-center">Tramo</th>
                      										<th class="text-center">Km Inicio</th>
                      										<th class="text-center">Km Fin</th>
                      										<th class="text-center">Plan</th>
                      										<th class="text-center">Estatus</th>
                      										<th class="text-center">Nota</th>
                      										<th class="text-center">Usuario Crea</th>
                      										<th class="text-center">Usuario Actualiza</th>

                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($programaAnualVia as $programaAnualVium)
                                        <tr>
                                            <td class="text-center">{{ ++$i }}</td>
                                            
                      											<td class="text-center">{{ $programaAnualVium->ip10 }}</td>
                      											<td>{{ $programaAnualVium->descripcion }}</td>
                      											<td class="text-center">
                                            @if(!empty($programaAnualVium->fecha_actualizacion))
                                              {{\Carbon\Carbon::parse($programaAnualVium->fecha_actualizacion)->format('d/m/Y')}}
                                             @endif 
                                            </td>
                      											<td class="text-center">{{ $programaAnualVium->frecuencia }}</td>
                                            <td class="text-center" style="text-transform: uppercase;">
                                            @if(!empty($programaAnualVium->programa))
                                              {{\Carbon\Carbon::parse($programaAnualVium->programa)->isoformat('dddd D/MM/Y')}}
                                            @endif
                                            </td>

                                            @if(\Carbon\Carbon::parse($programaAnualVium->programa)->isoFormat('w') <= now()->isoFormat('w'))
                                            <td class="text-center" style="color: red">
                                            @elseif(now()->isoFormat('w') >= \Carbon\Carbon::parse($programaAnualVium->programa)->isoFormat('w')-1)
                                            <td class="text-center" style="color: #ffc107">
                                            @else
                                            <td class="text-center" style="color: #28a745">
                                            @endif
                                            @if(!empty($programaAnualVium->programa))
                                              Sem #{{\Carbon\Carbon::parse($programaAnualVium->programa)->isoFormat('w')}}
                                            @endif
                                            </td>

                      											<td class="text-center">{{ $programaAnualVium->unidad }}</td>
                      											<td class="text-center">{{ $programaAnualVium->tramo }}</td>
                      											<td class="text-center">{{ $programaAnualVium->tramo_km_inicio }}</td>
                      											<td class="text-center">{{ $programaAnualVium->tramo_km_fin }}</td>
                      											<td class="text-center">{{ $programaAnualVium->plan }}</td>
                      											<td class="text-center">{{ $programaAnualVium->estatus }}</td>
                      											<td class="text-center">{{ $programaAnualVium->nota }}</td>
                      											<td class="text-center">{{ $programaAnualVium->usuario_crea }}</td>
                      											<td class="text-center">{{ $programaAnualVium->usuario_actualiza }}</td>

                                            <td class="td-actions text-centers">
                                              @if((Gate::check('isplanificador') || Gate::check('isJefe')) and $programaAnualVium->estatus == 'ACTIVO' )
                                                <form action="{{ route('programaviasanual.destroy',$programaAnualVium->id) }}" method="POST">
                                                    <a class="btn btn-link btn-success" href="{{ route('programaviasanual.edit',$programaAnualVium->id) }}"><i class="fa fa-fw fa-edit"></i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
@endsection
