@extends('layouts.app', ['activePage' => 'materialesvias', 'titlePage' => __('Materiales de Vías')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Vias Materiale</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('viasmateriale.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Parte:</strong>
                            {{ $viasMateriale->parte }}
                        </div>
                        <div class="form-group">
                            <strong>Sap:</strong>
                            {{ $viasMateriale->sap }}
                        </div>
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            {{ $viasMateriale->descripcion }}
                        </div>
                        <div class="form-group">
                            <strong>Unidad:</strong>
                            {{ $viasMateriale->unidad }}
                        </div>
                        <div class="form-group">
                            <strong>Preciounitario:</strong>
                            {{ $viasMateriale->preciounitario }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
