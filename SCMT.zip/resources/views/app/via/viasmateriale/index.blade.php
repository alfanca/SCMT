@extends('layouts.app', ['activePage' => 'materialesvias', 'titlePage' => __('Materiales de Vías')])
@section('content')
    <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Materiales de Vías</h4>
                        <p class="card-category">Administración de Materiales de Vías</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip" title="Crear Material"
                            href="{{route('viasmateriale.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Crear Material
                          <i class="material-icons">add</i>
                        </a>  
                      </div>
                      @endif
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">No</th>
                                        
										<th class="text-center">N° Sap</th>
										<th class="text-center">N° Parte</th>
										<th class="text-center col-4">Descripcion</th>
										<th class="text-center">Unidad</th>
										<th class="text-center">Precio Unitario $</th>
                                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('ispasante'))
                                        <th class="text-center col-1">Acciones</th>
                                        @endif

                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($viasMateriales as $viasMateriale)
                                        <tr>
                                            <td class="text-center">{{ ++$i }}</td>
                                            
											<td class="text-center">{{ $viasMateriale->sap }}</td>
											<td class="text-center">{{ $viasMateriale->parte }}</td>
											<td>{{ $viasMateriale->descripcion }}</td>
											<td class="text-center">{{ $viasMateriale::UNIDAD[$viasMateriale->unidad] }}</td>
											<td class="text-center">{{ $viasMateriale->preciounitario }}</td>

                                            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('ispasante'))
                                            <td class="td-actions text-center">
                                                <form action="{{ route('viasmateriale.destroy',$viasMateriale->id) }}" method="POST">
                                                    <a class="btn btn-link btn-success" rel="tooltip" title="Editar" href="{{ route('viasmateriale.edit',$viasMateriale->id) }}"><i class="material-icons">edit</i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                            </td>
                                            @endif
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
</section>
@endsection
