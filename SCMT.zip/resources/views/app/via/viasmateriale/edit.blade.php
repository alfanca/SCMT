@extends('layouts.app', ['activePage' => 'materialesvias', 'titlePage' => __('Editar Material de Vías')])
@section('content')

    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header card-header-primary">
                    <h4 class="card-title">{{ __('Actualizar Material de Vías') }}</h4>
                  </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('viasmateriale.update',[$viasMateriale->id]) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('app.via.viasmateriale.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
