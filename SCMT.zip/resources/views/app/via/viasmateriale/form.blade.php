<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="card-group">
            {{ Form::label('N° SAP: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('sap', $viasMateriale->sap, ['class' => 'form-control' . ($errors->has('sap') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese N°Sap']) }}
            {!! $errors->first('sap', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('N° Parte: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('parte', $viasMateriale->parte, ['class' => 'form-control' . ($errors->has('parte') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese N°Parte']) }}
            {!! $errors->first('parte', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Unidad: ') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('unidad', $elegirunidad,$viasMateriale->unidad, ['class' => 'form-control col-1' . ($errors->has('unidad') ? ' is-invalid' : ''), 'placeholder' => 'Seleccionar']) }}
            {!! $errors->first('unidad', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Precio Unitario $:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('preciounitario', $viasMateriale->preciounitario, ['class' => 'form-control' . ($errors->has('preciounitario') ? ' is-invalid' : ''), 'min' => '0.00','step' => '0.01','placeholder' => 'Ingrese Precio']) }}
            {!! $errors->first('preciounitario', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <br>
        <div class="form-group">
            {{ Form::label('Descripción') }}
            <br>
            {{ Form::text('descripcion', $viasMateriale->descripcion, ['class' => 'form-control' . ($errors->has('descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la Descripción']) }}
            {!! $errors->first('descripcion', '<div class="invalid-feedback">:message</div>') !!}
        </div>

    </div>
    <div class="card-footer justify-content-center mt-2">
       <a href="{{route('viasmateriale.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
         <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
     </div>
</div>