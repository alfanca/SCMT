<div class="row">
  <label class="col-md-2 col-form-label">{{ __('FECHA') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('fecha') ? ' has-danger' : '' }}">
    <input type="date"  name="fecha" class="form-control" style="width:40%" 
      value="{{ old('fecha') ?? $actividad->fecha }}"/>
    @if ($errors->has('fecha'))
      <span id="name-error" class="error text-danger" for="input-fecha">{{ $errors->first('fecha') }}</span>
    @endif

    </div>
  </div>

  <label class="col-md-2 col-form-label">{{ __('TURNO') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('turno') ? ' has-danger' : '' }}">

      <select class="custom-select form-control{{ $errors->has('turno') ? ' is-invalid' : '' }}" name="turno" id="input-turno"
        placeholder="{{ __('Ingrese el turno') }}" required="true">
        <option value="">SELECCIONE</option>
        @foreach($turnos as $turno)
         <option value="{{$turno}}" {{$actividad->turno == $turno ? 'selected' : '' }}>{{$turno}}</option>
        @endforeach
      </select>
    @if ($errors->has('turno'))
      <span id="name-error" class="error text-danger" for="input-turno">{{ $errors->first('turno') }}</span>
    @endif

    </div>
  </div>
</div>

<div class="row">
  <label class="col-md-2 col-form-label">{{ __('ACTIVIDAD') }}</label>
  <div class="col-md-10">
    <div class="form-group{{ $errors->has('actividad') ? ' has-danger' : '' }}">
    <textarea class="form-control" name="actividad" id="actividad" col="80" rows="5">{{ old('actividad') ?? $actividad->actividad }}</textarea> 
    @if ($errors->has('actividad'))
      <span id="name-error" class="error text-danger" for="input-actividad">{{ $errors->first('actividad') }}</span>
    @endif

    </div>
  </div>
</div>

<div class="row">
  <label class="col-md-2 col-form-label">{{ __('RESPONSABLE') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
    <select name="responsable" class="responsable" style="width: 100%">
      @if (!empty($actividad->datos->nombre))
        <option value="{{$actividad->responsable}}">{{ $actividad->datos->nombre}}</option>
      @endif
    </select>
    @if ($errors->has('responsable'))
      <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
    @endif

    </div>
  </div>
</div>
