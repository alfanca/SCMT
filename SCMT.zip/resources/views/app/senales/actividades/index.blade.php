@extends('layouts.app', ['activePage' => 'actividadsenales', 'titlePage' => __('Actividades de Señales')])
@section('content')
<div class="content">
	<div class="container-fluid">
		@include('app.comun.nav_dias', 	['url'=> 'senales/actividades/'])
		<div class="row">
			@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issenale'))
			<div class="col-md-12" style="text-align: center;">
				<a href="{{route('senales_actividades.create')}}" class="btn btn-sm btn-primary btn-rounded">Agregar</a>
				<a href="{{route('sen_actividades.vista_all')}}" class="btn btn-sm btn-danger btn-rounded" style="">Cambiar Vista</a>
			</div>
			@endif 
		</div>
      	@foreach($listadoActividades as $turno => $actividades)
    	<div class="row  justify-content-center">
      		<div class="col-md-12">
	 			<div class="card">
		            <div class="card-header card-header-primary">
		              <h4 class="card-title text-center">TURNO {{$turno}}</h4>
		            </div>
		            <div class="card-body">
		            	<?php $actividadPorTurno = $actividades->where('turno', $turno); ?>
		            	<div class="row justify-content-center">
		            		<table class="table table-hover table-bordered table-responsive table-small">
		            			<thead>
		            				<tr>
		            					<th class="col-7 text-center">Descripción del Servicio</th>
		            					<th class="col-2 text-center">Tramo</th>
		            					<th class="col-2 text-center">Orden</th>
		            					<th class="col-2 text-center">Responsable</th>
		            					@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issenale'))
		            					<th class="col-2 text-center">Opciones</th>
		            					@endif 
		            					@if(Gate::check('isplanificador') || Gate::check('isJefe'))
										<th class="text-center">Analista</th>
		            					@endif				            					
		            				</tr>
		            			</thead>
		            	@forelse($actividadPorTurno as $actividad)
		            		<tbody>
			            		<tr>
				                	<td class="text-justify" style="text-transform: uppercase;">{{$actividad->actividad}}</td>
				                	<td class="text-center">{{$actividad->tramo}}</td>
				                	<td class="text-center" style="text-transform: uppercase;">{{$actividad->orden}}</td>
				                	<td class="text-center">{{$actividad->datos->nombre}}</td>
				                	@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issenale'))
				                    <td class="td-actions" style="text-align: center;">
									        <a rel="tooltip" class="btn btn-success btn-link" href="{{route('senales_actividades.edit', [$actividad->id])}}" data-original-title="" title="Editar">
					                          <i class="material-icons">edit</i>
					                        </a>

					                        <form method="post" id="formDeleteActividades-{{$actividad->id}}" action="{{route('senales_actividades.destroy', [$actividad->id] ) }}">
					                          @csrf
					                          @method('delete')

					                          <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
					                          onclick="eliminarRegistro('formDeleteActividades-{{$actividad->id}}')" 
					                          ><i class="material-icons">delete</i></a>
					                        </form>
			                      	</td>
			                      	@endif
	            					@if(Gate::check('isplanificador') || Gate::check('isJefe'))
										<td class="text-center">
											{{$actividad->usuario_crea}} / 
											{{\Carbon\Carbon::parse($actividad->created_at)->format('d-m H:i')}}
										</td>
	            					@endif		
			              		</tr>
			              	</tbody>		            	
		            	@empty
		            	@endforelse
		            	</table>
		            </div>
		        </div>
      		</div>
    	</div>
  </div>
      	@endforeach
</div>
</div>
@endsection