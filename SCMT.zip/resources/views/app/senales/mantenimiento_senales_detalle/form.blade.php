<div class="box box-info padding-1">
    <div class="box-body">

        <input type="text" name="programa_id" value="{{$_GET['id']}}" style="visibility: hidden;">
    
        <div class="card-group" style="margin-left: 83%">
        <label>Buscador:</label><br>
        <input type="text" class="form-control pull-right" id="search" placeholder="Escriba su Busqueda">
        </div>

       <div class="table-responsive col-12">
                <table class="table" id="mytable" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center">Selec</th>
                        <th class="text-center">N° Equipo</th>
                        <th class="text-center">Conjunto</th>
                        <th class="text-center col-5">Descripción</th>
                        <th class="text-center col-1">Nro Sem</th>
                        <th class="text-center col-1">Día</th>
                        <th class="text-center">Fecha</th>
                        <th class="text-center col-1">% Cumpli</th>
                        <th class="text-center col-3">Nota</th>
                        <th class="text-center col-2">Nro Orden</th>
                        <th class="text-center">Tipo Mantt</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($equipos as $id => $equipo)
                      <tr>
                      <td class="text-center"> <input type="checkbox" name="equipo_id[{{$id}}]" value="{{$equipo->id}}"></td>          
                      <td class="text-center">{{$equipo->equipo}}</td>
                      <td class="text-center">{{$equipo->conjunto}}</td>
                      <td style="text-transform: uppercase;">{{$equipo->descripcion}}</td>
                      @if(\Carbon\Carbon::parse($equipo->programa)->isoFormat('w') <= now()->isoFormat('w'))
                      <td class="text-center" style="color: red">
                      @elseif(now()->isoFormat('w') >= \Carbon\Carbon::parse($equipo->programa)->isoFormat('w')-1)
                      <td class="text-center" style="color: #ffc107">
                      @else
                      <td class="text-center" style="color: #28a745">
                      @endif
                      
                        @if(!empty($equipo->programa))
                        Sem #{{\Carbon\Carbon::parse($equipo->programa)->isoFormat('w')}}
                        @endif

                      </td>
                      <td class="text-center" style="text-transform: uppercase;">{{\Carbon\Carbon::parse($equipo->programa)->isoformat('dddd')}}</td>
                      <td><input class="form-control text-center" type="date" name="fecha[{{$id}}]" value="{{$equipo->programa}}"></td>
                      <td><input class="form-control text-center" min="0" max="100" value="0" step="0.2" placeholder="Ingrese" type="number" name="cumplimiento[{{$id}}]"></td>
                      <td><input class="form-control" placeholder="Ingrese Nota" type="text" name="nota[{{$id}}]"></td>
                      <td><input class="form-control text-center" min="0" placeholder="Ingrese" type="number" name="n_orden[{{$id}}]"></td>
                      
                      <td class="text-center">{{$equipo->tipo_mant}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>

            </div>
          </div>


             <script src="{{ asset('js') }}/jQueryv310.js"></script>

<script>
 // Write on keyup event of keyword input element
 $(document).ready(function(){
 $("#search").keyup(function(){
 _this = this;
 // Show only matching TR, hide rest of them
 $.each($("#mytable tbody tr"), function() {
 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
 $(this).hide();
 else
 $(this).show();
 });
 });
});
</script>