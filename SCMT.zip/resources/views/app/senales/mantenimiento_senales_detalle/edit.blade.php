@extends('layouts.app', ['activePage' => 'programassenales', 'titlePage' => __('Actualizar Programa de Equipos de Señales')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header card-header-primary">
              <h4 class="card-title">{{ __('Actualizar Programa de Equipos de Señales') }}</h4>
            </div>
            <form method="post" action="{{route('programasdetalles.update', [$programadetalle->id])}}" autocomplete="off" class="form-horizontal">
              @csrf
              @method('patch')
              @include('app.senales.mantenimiento_senales_detalle.formedit')
            <div class="col-md-12 mt-4" align="center">
            <div class="card-footer justify-content-center">
            <a href="{{route('programas.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
              <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
            </div>
          </div>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

