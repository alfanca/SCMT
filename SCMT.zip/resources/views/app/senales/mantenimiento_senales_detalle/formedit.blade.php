<div class="box box-info padding-1">
    <div class="box-body">
    
            <input class="col-2" type="number" name="equipo_id" value="{{$programadetalle->equipo_id}}" style="visibility: hidden">
            <input class="col-2" type="number" name="programa_id" value="{{$programadetalle->programa_id}}" style="visibility: hidden">

        <div class="card-group mt-2">


            <h4 class="col-3">Nro Equipo: <label>{{$programadetalle->equiposenales->equipo}}</label></h4>
            <h4 class="col-2">Conjunto: <label>{{$programadetalle->equiposenales->conjunto}}</label></h4>
            <h4 class="col-6">Descripción: <label>{{$programadetalle->equiposenales->descripcion}}</label></h4>

          <div class="card-group col-12 mt-4">
            

            {{ Form::label('Fecha') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha', $programadetalle->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('% Cumplimiento') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('cumplimiento', $programadetalle->cumplimiento, ['class' => 'form-control text-center' . ($errors->has('cumplimiento') ? ' is-invalid' : ''), 'min' => '0', 'max' => '100' , 'step' => '0.2', 'placeholder' => 'Ingrese']) }}
            {!! $errors->first('cumplimiento', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Nota') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('nota', $programadetalle->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese Nota']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Nro Orden') }}&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('n_orden', $programadetalle->n_orden, ['class' => 'form-control text-center' . ($errors->has('n_orden') ? ' is-invalid' : ''), 'min' => '0', 'placeholder' => 'Ingrese']) }}
            {!! $errors->first('n_orden', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

          </div>

        </div>

       

            </div>
          </div>

