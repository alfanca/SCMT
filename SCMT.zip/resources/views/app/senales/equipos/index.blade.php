@extends('layouts.app', ['activePage' => 'equipossenales', 'titlePage' => __('Señales')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

              <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Equipos de Señales</h4>
                <p class="card-category">Registro y Administración de Equipos de Señales</p>
              </div>
              @if(Gate::check('isplanificador') || Gate::check('isJefe'))   
              <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Crear Equipo"
                    href="equipos/create" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Crear Equipo
                  <i class="material-icons">add</i>
                </a>  
              </div>
              @endif
            </div>

            <div class="card-body">

               <div class="card-group mx-8" align="center">

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #28a745; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-check text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Disponible</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$disponible}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #ffc107; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-info text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Parcialmente</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$parcialmente}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-times text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Mantenimiento</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$mantenimiento}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-equals text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Total</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$total}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
  
              <div class="table-responsive">
                <table class="table" id="myTable">
                  <thead class=" text-primary">
                    <tr>
                      <th>IP10</th>
                    	<th>N. Equipo</th>
                    	<th>Conjunto</th>
                    	<th class="text-center">Lugar</th>
                      <th>Ubicación</th>
                      <th class="text-center">Descripción</th>
                      <th class="text-center">Frecuencia de Mantenimiento (Días)</th>
                      <th class="text-center">Programas</th>
                      <th class="text-center col-1">Sem #</th>
                      <th class="text-center">Tipo Mantt</th>
                      <th class="text-center">Estatus</th>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe')) 
                    	<th class="text-center">Acciones</th>
                      @endif
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($equipos as $equipo)
										<tr>
                      <td class="text-center">{{$equipo->sap_ipdiez}}</td>
                      <td class="text-center">{{$equipo->equipo}}</td>
                      <td class="text-center">{{$equipo->conjunto}}</td>
                      <td class="text-center">{{$equipo->lugar}}</td>
                      <td class="text-center">{{$equipo->ubicacion}}</td>
                      <td>{{$equipo->descripcion}}</td>
                      <td class="text-center">{{$equipo->mantenimiento}}</td>
                      <td class="text-center" style="text-transform: uppercase;">
                      @if(!empty($equipo->programa))

                      {{\Carbon\Carbon::parse($equipo->programa)->isoFormat('dddd DD/MM/YY')}}
                      
                      @endif
                      </td>
                      @if(\Carbon\Carbon::parse($equipo->programa)->isoFormat('w') <= now()->isoFormat('w'))
                      <td class="text-center" style="color: red">
                      @elseif(now()->isoFormat('w') >= \Carbon\Carbon::parse($equipo->programa)->isoFormat('w')-1)
                      <td class="text-center" style="color: #ffc107">
                      @else
                      <td class="text-center" style="color: #28a745">
                      @endif
                      
                        @if(!empty($equipo->programa))
                        Sem #{{\Carbon\Carbon::parse($equipo->programa)->isoFormat('w')}}
                        @endif

                      </td>
                      <td class="text-center">{{$equipo->tipo_mant}}</td>
                      <td class="text-center">{{$equipo->estatus}}</td>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe')) 
                      <td class="td-actions">
                        <form method="post" id="formDeleteLocomotora-{{$equipo->id}}" action="{{route('equipos.destroy', [$equipo->id] ) }}" class="">
                          @csrf
                          @method('delete')
				                <a rel="tooltip" class="btn btn-success btn-link" href="{{route('equipos.edit', [$equipo->id])}}" data-original-title="" title="Editar">
                          <i class="material-icons">edit</i>
                          <div class="ripple-container"></div>
                        </a>
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteLocomotora-{{$equipo->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      </td>
                      @endif
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

@endsection
