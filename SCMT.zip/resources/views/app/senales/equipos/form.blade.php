  <div class="card-body ">
    <div class="card-group my-4">

      <label class="col-form-label col-1">{{ __('N. Equipo:') }}</label>
        <div class="form-group{{ $errors->has('equipo') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="equipo" id="input-name" type="text" placeholder="{{ __('Ingrese el Equipo') }}"
            value="{{ old('equipo') ?? $equipo->equipo }}" required="true"/>
          @if ($errors->has('equipo'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('equipo') }}</span>
          @endif
        </div> 

         &nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp


        <label class="col-1 col-form-label">{{ __('Conjunto') }}</label>

          <div class="form-group{{ $errors->has('conjunto') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('conjunto') ? ' is-invalid' : '' }} text-center"
                name="conjunto" id="input-conjunto"placeholder="{{ __('Seleccione el Conjunto') }}"
              >
              <option value="">SELECCIONE</option>
              @foreach($equipo->conjunto() as $conjuntos)
                <option value="{{$conjuntos}}" {{$equipo->conjuntos == $conjuntos ? 'selected' : '' }}>{{$conjuntos}}</option>
              @endforeach
            </select>


            @if ($errors->has('conjunto'))
              <span id="name-error" class="error text-danger" for="input-conjunto">{{ $errors->first('conjunto') }}</span>
            @endif
          </div>

           &nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp

        <label class="col-1 col-form-label">{{ __('Lugar') }}</label>

          <div class="form-group{{ $errors->has('lugar') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('lugar') ? ' is-invalid' : '' }} text-center"
                name="lugar" id="input-lugar"placeholder="{{ __('Seleccione el Lugar') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($equipo->lugares() as $lugar)
                <option value="{{$lugar}}" {{$equipo->lugar == $lugar ? 'selected' : '' }}>{{$lugar}}</option>
              @endforeach
            </select>


            @if ($errors->has('lugar'))
              <span id="name-error" class="error text-danger" for="input-lugar">{{ $errors->first('lugar') }}</span>
            @endif
          </div>

    </div>

    <div class="card-group my-4">
        <label class="col-1 col-form-label">{{ __('Ubicación') }}</label>

          <div class="form-group{{ $errors->has('ubicacion') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('ubicacion') ? ' is-invalid' : '' }}"
              name="ubicacion" id="input-ubicacion" type="text" placeholder="{{ __('Ingrese la Ubicación del Equipo') }}"
              value="{{ old('ubicacion') ?? $equipo->ubicacion }}" required="true"/>
            @if ($errors->has('ubicacion'))
              <span id="name-error" class="error text-danger" for="input-ubicacion">{{ $errors->first('ubicacion') }}</span>
            @endif
          </div>

        &nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp

        <label class="col-2 col-form-label">{{ __('Descripción del Equipo') }}</label>

          <div class="form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }} col-4">
            <input class="form-control{{ $errors->has('descripcion') ? ' is-invalid' : '' }}"
              name="descripcion" id="input-descripcion" type="text" placeholder="{{ __('Ingrese la Descripción del Equipo') }}"
              value="{{ old('descripcion') ?? $equipo->descripcion}}" required="true"/>
            @if ($errors->has('descripcion'))
              <span id="name-error" class="error text-danger" for="input-descripcion">{{ $errors->first('descripcion') }}</span>
            @endif
          </div>

    </div>

    <div class="card-group my-4">
        <label class="col-1 col-form-label">{{ __('Estatus') }}</label>

          <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }} text-center col-12" name="estatus" id="input-estatus"placeholder="{{ __('Seleccione el Estatus') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($equipo->estatusdelequipo() as $estatus)
                <option value="{{$estatus}}" {{$equipo->estatus == $estatus ? 'selected' : '' }}>{{$estatus}}</option>
              @endforeach
            </select>


            @if ($errors->has('estatus'))
              <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
            @endif
          </div>

          &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp

        <label class="col-2 col-form-label">{{ __('Frecuencia de Mantenimiento (Días)') }}</label>

          <div class="form-group{{ $errors->has('mantenimiento') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('mantenimiento') ? ' is-invalid' : '' }} col-6 text-center"
              name="mantenimiento" id="input-mantenimiento" min="0" type="number" placeholder="{{('Ingrese')}}"
              value="{{ old('mantenimiento') ?? $equipo->mantenimiento }}"/>
            @if ($errors->has('mantenimiento'))
              <span id="name-error" class="error text-danger" for="input-mantenimiento">{{ $errors->first('mantenimiento') }}</span>
            @endif
          </div>


          <label class="col-2 col-form-label">{{ __('Tipo de Mantenimiento') }}</label>

          <div class="form-group{{ $errors->has('tipo_mant') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('tipo_mant') ? ' is-invalid' : '' }} text-center"
                name="tipo_mant" id="input-tipo_mant"placeholder="{{ __('Seleccione') }}"
              >
              <option value="">SELECCIONE</option>
              @foreach($equipo->tipo() as $tipo)
                <option value="{{$tipo}}" {{$equipo->tipo_mant == $tipo ? 'selected' : '' }}>{{$tipo}}</option>
              @endforeach
            </select>


            @if ($errors->has('tipo_mant'))
              <span id="name-error" class="error text-danger" for="input-tipo_mant">{{ $errors->first('tipo_mant') }}</span>
            @endif
          </div>

          <div class="col-4 row card-group mt-4">

          <label class="col-3 col-form-label">{{ ('IP10') }}</label>

          <div class="{{ $errors->has('sap_ipdiez') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('sap_ipdiez') ? ' is-invalid' : '' }} col-6 text-center"
              name="sap_ipdiez" id="input-sap_ipdiez" min="0" type="number" placeholder="{{('Ingrese')}}"
              value="{{ old('sap_ipdiez') ?? $equipo->sap_ipdiez }}"/>
            @if ($errors->has('sap_ipdiez'))
              <span id="name-error" class="error text-danger" for="input-sap_ipdiez">{{ $errors->first('sap_ipdiez') }}</span>
            @endif
          </div>
          </div>

    </div>

  </div>
