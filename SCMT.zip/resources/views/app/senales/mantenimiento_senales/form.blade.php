<div class="box box-info padding-1">
    <div class="box-body">
      
        <div class="card-group col-12 my-4">

            {{ Form::label('Programa N°:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::number('programa', $programa->programa, ['class' => 'form-control text-center' . ($errors->has('programa') ? ' is-invalid' : ''), 'min' => '0', 'max' => '100', 'placeholder' => 'Ingrese']) }}
            {!! $errors->first('programa', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Fecha Inicio:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha', $programa->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Fecha Fin:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_fin', $programa->fecha_fin, ['class' => 'form-control ' . ($errors->has('fecha_fin') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
            {!! $errors->first('fecha_fin', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Nota:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('nota', $programa->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la nota']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp&nbsp


            @if(!empty($programa->estatus))



            {{ Form::label('Estatus:') }}&nbsp&nbsp&nbsp&nbsp

            <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }} text-center"
                name="estatus" id="input-estatus"placeholder="{{ __('Seleccione') }}"
              >
              <option value="">SELECCIONE</option>
              @foreach($programa->estatusPrograma() as $Estatus)
                <option value="{{$Estatus}}" {{$programa->estatus == $Estatus ? 'selected' : '' }}>{{$Estatus}}</option>
              @endforeach
            </select>


            @if ($errors->has('estatus'))
              <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
            @endif
          </div>
           @endif


        </div>

        

        <table class="table-responsive col-12"> 
              
              <thead>
                
                <tr>
                  
                  <th class="text-center col-4">{{ Form::label('Planificador:') }}</th>
                  <th></th>
                  <th class="text-center col-4">{{ Form::label('Superintendente de Señales:') }}</th>
                  <th></th>
                  <th class="text-center col-4">{{ Form::label('Jefe de Planificación:') }}</th>

                </tr>

              </thead>
              <tbody>
                <tr>

                  <td>
                    
                  <div class="form-group{{ $errors->has('planificador') ? ' has-danger' : '' }}">
                  <select name="planificador" class="responsable col-md-12">
                    @if (!empty($programa->datosplanificador->nombre))
                      <option value="{{$programa->planificador}}">{{ $programa->datosplanificador->nombre}}</option>
                    @endif
                  </select>
                  @if ($errors->has('planificador'))
                    <span id="name-error" class="error text-danger" for="input-planificador">{{ $errors->first('planificador') }}</span>
                  @endif

                  </div>

                  </td>

                  <td></td>


                  <td>
                    
                  <div class="form-group{{ $errors->has('superintendente') ? ' has-danger' : '' }}">
                  <select name="superintendente" class="responsable col-md-12">
                    @if (!empty($programa->datossuperintendente->nombre))
                      <option value="{{$programa->superintendente}}">{{ $programa->datossuperintendente->nombre}}</option>
                    @endif
                  </select>
                  @if ($errors->has('superintendente'))
                    <span id="name-error" class="error text-danger" for="input-superintendente">{{ $errors->first('superintendente') }}</span>
                  @endif

                  </div>

                  </td>

                  <td></td>


                  <td>
                    
                  <div class="form-group{{ $errors->has('jefeplanificacion') ? ' has-danger' : '' }}">
                  <select name="jefeplanificacion" class="responsable col-md-12">
                    @if (!empty($programa->datosjefeplanificacion->nombre))
                      <option value="{{$programa->jefeplanificacion}}">{{ $programa->datosjefeplanificacion->nombre}}</option>
                    @endif
                  </select>
                  @if ($errors->has('jefeplanificacion'))
                    <span id="name-error" class="error text-danger" for="input-jefeplanificacion">{{ $errors->first('jefeplanificacion') }}</span>
                  @endif

                  </div>

                  </td>


                </tr>
              </tbody>

            </table>

