@extends('layouts.app', ['activePage' => 'programassenales', 'titlePage' => __('Programas de Mantenimiento Preventivo de Señales')])
@section('content')

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Programa de Señales Sem N°{{$programa->programa}}</h4>
                        <p class="card-category">Programas de Mantenimiento Semanal Cumplimiento 


                        </p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">

                        <a rel="tooltip"
                            href="{{ route('programas.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>Regresar
                        </a> 
                        <a rel="tooltip"
                            href="{{ route('ferroprogramasenales',$programa->id) }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-file-alt"></i>
                        </a> 
                        
                      </div>
                      
                    </div>
                    <br>
                    <br>
                    <br>
                    <div class="card-body">

                        <div class="col-md-12">
                        
                        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
                        <div class="text-right">
                        @if((Gate::check('isplanificador') || Gate::check('isJefe')) and $programa->estatus == 'LIBERADA') 

                        <a class="btn btn-sm btn" style="background-color: #9B945F;" href="{{ route('programas.edit',[$programa->id]) }}"><i class="fa fa-fw fa-edit"></i> Editar</a>
 
                        @endif
                        </div>
                        <br>
              
                        <div class="card-group mt-4">
                        <div class="form-group col-2">
                            <strong><b>Programa Sem N° {{$programa->programa}}</b></strong>
                            
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Inicio:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse($programa->fecha)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Fin:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse($programa->fecha_fin)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Estatus:</b>&nbsp&nbsp </strong>
                            {{$programa->estatus}}
                        </div>
                        </div>
                        <hr>
                        <h4 class="col-md-12 text-center mt-3">Responsables</h4>
                        <br>
                        <div class="card-group mt-4">
                        <div class="form-group col-4">
                            <strong><b>Planificador:</b></strong>
                            {{$programa->datosplanificador->nombre}}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Superintendente:</b></strong>
                            {{$programa->datossuperintendente->nombre}}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Jefe de Planificación:</b></strong>
                            {{$programa->datosjefeplanificacion->nombre}}
                        </div>
                        </div>

                        <hr>

                        <div class="text-right">
                        @if((Gate::check('isplanificador') || Gate::check('isJefe')) and $programa->estatus == 'LIBERADA') 
                        <a class="btn btn-sm btn" style="background-color: #9B945F;" href="{{ route('programasdetalles.create',['id'=>$programa->id]) }}"><i class="fa fa-fw fa-upload"></i> Agregar Programa</a>
                        @endif
                        </div>

                        <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">IP10</th>
                                        <th class="text-center">N° Equipo</th>
                                        <th class="text-center">Conjunto</th>
                                        <th class="text-center">Tipo Mantt</th>
                                        <th class="text-center">Descripción</th>
                                        <th class="text-center">Fecha</th>
                                        <th class="text-center">Nota</th>
                                        <th class="text-center">Nro Orden</th>
                                        <th class="text-center">Usuario Crea</th>
                                        <th class="text-center">Usuario Actualiza</th>
                                        <th class="text-center">Cump. %</th>

                                        <th class="col-1 text-center">Acciones</th>



                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($detallesprogramasenales as $detalles)
                                        <tr>
                                            <td class="text-center">{{ $detalles->equiposenales->sap_ipdiez }}</td>
                                            <td class="text-center">{{ $detalles->equiposenales->equipo }}</td>
                                            <td class="text-center">{{ $detalles->equiposenales->conjunto }}</td>
                                            <td class="text-center">{{ $detalles->equiposenales->tipo_mant }}</td>
                                            <td>{{ $detalles->equiposenales->descripcion }}</td>
                                            <td class="text-center" style="text-transform: uppercase;">{{\Carbon\Carbon::parse($detalles->fecha)->isoformat('dddd DD/MM/Y')}}</td>
                                            <td class="text-center">
                                            @if(!empty($detalles->nota))
                                            <a href="" style="" data-toggle="modal" data-target="#nota_programaSenalesDetalle" data-observacion="{{$detalles->nota}}"><i class="material-icons">book</i></a>
                                            @endif
                                          </td>
                                            <td class="text-center">{{ $detalles->n_orden }}</td>
                                            <td class="text-center" style="text-transform: uppercase;">{{ $detalles->usuario_crea }}</td>
                                            <td class="text-center" style="text-transform: uppercase;">{{ $detalles->usuario_actualiza }}</td>

                                            @if($detalles->cumplimiento >= 85)
                                            <td class="text-center" style="color: #28a745">
                                            @elseif($detalles->cumplimiento >= 50)
                                            <td class="text-center" style="color: #ffc107">
                                            @elseif($detalles->cumplimiento < 50)
                                            <td class="text-center" style="color: #dc3545">
                                            @endif

                                            {{ $detalles->cumplimiento }}%</td>



                                            <td class="td-actions">
                                            @if((Gate::check('isplanificador') || Gate::check('isJefe')) and $programa->estatus == 'LIBERADA') 
                                                <form action="{{ route('programasdetalles.destroy',$detalles->id) }}" method="POST">
                                                    <a rel="tooltip" title="Actualizar Programa" class="btn btn-link btn-success" href="{{ route('programasdetalles.edit',$detalles->id) }}"><i class="material-icons">edit</i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                            @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <td></td>
                                    <td></td>
                                        <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                            <th class="text-center"><b>Total (%):</b></th>

                                            @if($cumplimientoTotal >= 85)
                                            <th class="text-center" style="color: #28a745">
                                            @elseif($cumplimientoTotal >= 50)
                                            <th class="text-center" style="color: #ffc107">
                                            @elseif($cumplimientoTotal < 50)
                                            <th class="text-center" style="color: #dc3545">
                                            @endif

                                            <b>{{round($cumplimientoTotal)}} %</b></th>


                            </table>
                        </div>
                    </div>

                    </div>

                    


                    </div>
                </div>
            </div>
        </div>

        <!-- Modal -->

  <div class="modal" id="nota_programaSenalesDetalle" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Notas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <p id="nota-modal"></p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </form>
    </div>
  </div>

  <!-- End Modal -->

    </section>



    <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
@endsection
