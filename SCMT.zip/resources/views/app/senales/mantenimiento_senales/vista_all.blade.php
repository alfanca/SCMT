@extends('layouts.app', ['activePage' => 'programassenales', 'titlePage' => __('Histórico de Programa de Señales')])
@section('content')
<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

              <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Inspecciones y Mantenimiento de Señales (Histórico)</h4>
                <p class="card-category">Registro y Administración de Equipos de Señales</p>
              </div>
                <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Regresar"
                    href="{{route('programas.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="material-icons">reply</i> Regresar
                  
                </a>  
              </div>
            </div>

            <form class="my-4" method="get" autocomplete="off" action="{{route('sen_programas.vista_all')}}" class="form-horizontal">
            @include('app.comun.nav_semana_busqueda_sinboton')
            </form>  

            <div class="card-body">

               <div class="card-group">

              <div class="col-xl-4 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-fw fa-clipboard text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Cantidad de Programas</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$cantidadDeProgramas}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-4 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-fw fa-file text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Inpecciones y Preventivos</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$cantidadDetallesprogramasenales}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-4 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        @if ($porcentajeCumplimiento < 50)
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
                        @elseif ($porcentajeCumplimiento < 80)
                        <div class="col-md-3 text-center" style="background-color: #ffc107; color: white;border-top-left-radius: 10px;">
                        @elseif ($porcentajeCumplimiento >= 80)
                        <div class="col-md-3 text-center" style="background-color: #28a745; color: white;border-top-left-radius: 10px;">
                        @endif
                          <i class="fa fa-percent text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-2 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>% Cumplimiento Anual</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{round($porcentajeCumplimiento)}} %</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>
  
              <div class="table-responsive">
                <table class="table" id="myTable">
                  <thead class=" text-primary">
                    <tr>
                    	<th class="text-center">Programa</th>
                    	<th class="text-center">Fecha Inicio</th>
                    	<th class="text-center">Fecha Fin</th>
                      <th class="text-center">Estatus</th>
                      <th class="text-center">Cant. Insp</th>
                      <th class="text-center">Planificador</th>
                      <th class="text-center">Superintendente</th>
                      <th class="text-center">Jefe de Planificación</th>
                      <th class="text-center">Nota</th>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe')) 
                    	<th class="text-center">Acciones</th>
                      @endif
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($programasBusqueda as $programasenales)
										<tr>
                      <td class="text-center"><a rel="tooltip" title="Ver Programa" class="btn btn-link btn-primary" href="{{ route('programas.show',$programasenales->id) }}">Sem N°{{$programasenales->programa}}</a></td>
                      <td class="text-center">{{\Carbon\Carbon::parse($programasenales->fecha)->format('d/m/Y')}}</td>
                      <td class="text-center">{{\Carbon\Carbon::parse($programasenales->fecha_fin)->format('d/m/Y')}}</td>
                      <td class="text-center">{{$programasenales->estatus}}</td>
                      <td class="text-center">{{$detallesprogramasenales->where('programa_id', $programasenales->id)->count()}}</td>
                      <td class="text-center">{{$programasenales->datosplanificador->nombre}}</td>
                      <td class="text-center">{{$programasenales->datossuperintendente->nombre}}</td>
                      <td class="text-center">{{$programasenales->datosjefeplanificacion->nombre}}</td>
                      <td class="text-center">
                        @if(!empty($programasenales->nota))
                        <a href="" style="" data-toggle="modal" data-target="#nota_programaSenales" data-observacion="{{$programasenales->nota}}"><i class="material-icons">book</i></a>
                        @endif
                      </td>
                      <td class="td-actions text-center">
                      @if((Gate::check('isplanificador') || Gate::check('isJefe')) and $programasenales->estatus == 'LIBERADA') 
                        <form method="post" id="formDeleteLocomotora-{{$programasenales->id}}" action="{{route('programas.destroy', [$programasenales->id] ) }}" class="">
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteLocomotora-{{$programasenales->id}}')" 
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      @endif
                      </td>
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>

 <!-- Modal -->

  <div class="modal" id="nota_programaSenales" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Notas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <p id="nota-modal"></p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </form>
    </div>
  </div>

  <!-- End Modal -->

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

@endsection
