@extends('layouts.app', ['activePage' => 'equipossenales', 'titlePage' => __('Formato de Programa de Señales')])
@section('content')
<section class="content container-fluid">
	    <div class="container-fluid">
        	 	<div class="card" align="center">
        	 		<div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title text-left">Programa de Señales</h4>
                        <p class="card-category text-left">Ferro de inspección y mantenimiento preventivo</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="col-md-6" style="text-align: right;">
                    	 <a rel="tooltip"
                            href="{{ route('programas.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>Regresar
                        </a> 
                        <a rel="tooltip" title="Imprimir"
                            href="" onclick="javascript:imprim1r(imprimir);" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="material-icons">print</i>
                        </a>  
                      </div>
                      @endif
                    </div>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<meta name="generator" content="LibreOffice 6.0.7.3 (Linux)"/>
	<meta name="created" content="2023-01-16T09:25:37.492319976"/>
	<meta name="changed" content="2023-01-16T09:41:33.737193425"/>
	<style type="text/css">
		@page { margin: 2cm }
		p { margin-bottom: 0.25cm; line-height: 115% }
		td p { margin-bottom: 0cm }
		a:link { so-language: zxx }
	</style>
		<script type="text/javascript">
		function imprim1r (imprimir){
			var printContents = document.getElementById('imprimir').innerHTML;
				w = window.open();
				w.document.write(printContents);
		w.print();
		w.close();
		return true;
		}
	</script>
</head>
<body lang="es-VE" dir="ltr">
	<div id="imprimir">	
<div title="header">
	<p align="center" style="margin-bottom: 0.5cm; line-height: 100%"><br/>

	</p>
</div>
<table width="665" cellpadding="4" cellspacing="0">
	<col width="113">
	<col width="423">
	<col width="105">
	<tr>
		<td width="113" valign="top" style="border: none; padding: 0cm">
			<p><img src="{{asset('/images/logosenales.png')}}" align="left" width="99" height="82"/>
<br/>

			</p>
		</td>
		<td width="423" style="border: none; padding: 0cm">
			<p align="center" style="margin-bottom: 0cm"><font size="2" style="font-size: 11pt">C.V.G
			FERROMINERA ORINOCO C.A.</font></p>
			<p align="center" style="margin-bottom: 0cm"><font size="2" style="font-size: 11pt">GERENCIA
			DE FERROCARRIL</font></p>
			<p align="center" style="margin-bottom: 0cm"><font size="2" style="font-size: 11pt">SUPERINTENDENCIA
			MANTENIMIENTO DE SEÑALES</font></p>
			<p align="center"><font size="2" style="font-size: 11pt">ACTIVIDADES
			POR EJECUTAR <b>SEM #{{$programa->programa}}</b></font></p>
			<p align="center"><font size="2" style="font-size: 11pt"><b>DESDE:</b> {{\Carbon\Carbon::parse($programa->fecha)->format('d/m/Y')}} <b>HASTA:</b> {{\Carbon\Carbon::parse($programa->fecha_fin)->format('d/m/Y')}}</font></p>
		</td>

		<td width="105" valign="top" style="border: none; padding: 0cm">
			<p><img src="{{asset('/images/fmologo.gif')}}" align="left" width="94" height="83"/>
<br/>

			</p>
		</td>
	</tr>
</table>
<p><br/>
<br/>

</p>
<p><br/>
<br/>

</p>
<table width="665" cellpadding="4" cellspacing="0">
	<col width="56">
	<col width="113">
	<col width="241">
	<col width="120">
	<col width="93">
	<tr>
		<td width="56" bgcolor="#d2091d" style="background: #d2091d" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font color="#ffffff"><b>TIPO</b></font></p>
		</td>
		<td width="113" bgcolor="#d2091d" style="background: #d2091d" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font color="#ffffff"><b>Nro EQUIPO</b></font></p>
		</td>
		<td width="241" bgcolor="#d2091d" style="background: #d2091d" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font color="#ffffff"><b>DESCRIPCIÓN</b></font></p>
		</td>
		<td width="120" bgcolor="#d2091d" style="background: #d2091d" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font color="#ffffff"><b>FECHA</b></font></p>
		</td>
		<td width="93" bgcolor="#d2091d" style="background: #d2091d" style="border: 1px solid #000000; padding: 0.1cm">
			<p align="center"><font color="#ffffff"><b>Nro SAP</b></font></p>
		</td>
	</tr>

	@foreach ($detallesprogramasenales->where('tipo_mant', 'ZPMI') as $detalles)
	<tr valign="top">
		<td width="56" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p style="text-align: center;">
				@if($detalles->equiposenales->tipo_mant == 'ZPMI')
				INSPECCIÓN
				@else
				MANTENIMIENTO
				@endif
			</p>
		</td>
		<td width="113" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p style="text-align: center;">
				{{ $detalles->equiposenales->equipo }}
			</p>
		</td>
		<td width="241" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p>
				{{ $detalles->equiposenales->descripcion }}
			</p>
		</td>
		<td width="120" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p style="text-transform: uppercase; text-align: center;">
				{{\Carbon\Carbon::parse($detalles->fecha)->isoformat('dddd DD/MM/Y')}}
			</p>
		</td>
		<td width="93" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
			<p style="text-align: center;">
				{{ $detalles->n_orden }}
			</p>
		</td>
	</tr>
	@endforeach
	<tr><th colspan="5" class="text-center" bgcolor="#d2091d" style="color: white; background: #d2091d" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">MANTENIMIENTO</th></tr>
	@foreach ($detallesprogramasenales->where('tipo_mant', 'ZPM2') as $detalles)
	<tr valign="top">
		<td width="56" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p style="text-align: center;">
				@if($detalles->equiposenales->tipo_mant == 'ZPMI')
				INSPECCIÓN
				@else
				MANTENIMIENTO
				@endif
			</p>
		</td>
		<td width="113" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p style="text-align: center;">
				{{ $detalles->equiposenales->equipo }}
			</p>
		</td>
		<td width="241" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p>
				{{ $detalles->equiposenales->descripcion }}
			</p>
		</td>
		<td width="120" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p style="text-transform: uppercase; text-align: center;">
				{{\Carbon\Carbon::parse($detalles->fecha)->isoformat('dddd DD/MM/Y')}}
			</p>
		</td>
		<td width="93" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
			<p style="text-align: center;">
				{{ $detalles->n_orden }}
			</p>
		</td>
	</tr>
	@endforeach
</table>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<table width="665" cellpadding="4" cellspacing="0">
	<col width="302">
	<col width="56">
	<col width="283">
	<tr valign="top">
		<td width="302" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center"><br/>
				{{$programa->datosplanificador->nombre}}
			</p>
		</td>
		<td width="56" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="283" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center"><br/>
				{{$programa->datosjefeplanificacion->nombre}}
			</p>
		</td>
	</tr>
	<tr valign="top">
		<td width="302" style="border: none; padding: 0cm">
			<p align="center">PLANIFICADOR</p>
			<p align="center"><br/>

			</p>
			<p align="center"><br/>

			</p>
			<p align="center"><br/>

			</p>
		</td>
		<td width="56" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="283" style="border: none; padding: 0cm">
			<p align="center">JEFE DE AREA DE PLANIFICACIÓN</p>
			<p align="center"><br/>

			</p>
			<p align="center"><br/>

			</p>
		</td>
	</tr>
	<tr>
		<td colspan="3" width="657" valign="top" style="border: none; padding: 0cm">
			<p align="center"><u>{{$programa->datossuperintendente->nombre}}</u></p>
			<p align="center">SUPERINTENDENTE</p>
		</td>
	</tr>
</table>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
</div>
</body>
</html>
</div>
</div>
</div>
</section>
@endsection