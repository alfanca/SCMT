@extends('layouts.app', ['activePage' => 'comunicacion', 'titlePage' => __('Gestión Comunicaciones FFCC')])
@section('content')

  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
          <div class="card-header card-header-primary">
            <h4 class="card-title">{{ __('Modificación de comunicación') }}</h4>
          </div>
          <form method="post" action="{{ route('gestion.comunicacion.update', [$comunicacion->id]) }}" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
          @csrf
          @method('patch')            
            @include('app.gestion.comunicaciones.form')
            <div class="card-footer justify-content-center">
              <a href="{{route('gestion.comunicacion.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>


@endsection