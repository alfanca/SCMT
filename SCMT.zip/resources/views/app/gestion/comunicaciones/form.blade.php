  <div class="card-body ">
    <div class="row">
        <label class="col-sm-2 col-form-label">Asunto</label>
        <div class="col-sm-9">
          <div class="form-group{{ $errors->has('nombre') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('nombre') ? ' is-invalid' : '' }}"
              name="nombre" id="input-nombre" type="text" placeholder="{{ __('Nombre o asunto de la comunicación') }}"
              value="{{ old('nombre') ?? $comunicacion->nombre }}" required="true"/>
            @if ($errors->has('nombre'))
              <span id="name-error" class="error text-danger" for="input-nombre">{{ $errors->first('nombre') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">Descripción</label>
        <div class="col-sm-10">
          <div class="form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }}">
            
            <textarea class="form-control" placeholder="Contenido principal de la comunicación" name="descripcion" id="descripcion" col="120" rows="5" required>{{ old('descripcion') ?? $comunicacion->descripcion }}</textarea> 

            @if ($errors->has('descripcion'))
              <span id="name-error" class="error text-danger" for="input-descripcion">{{ $errors->first('descripcion') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-md-2 col-form-label">Fecha enviada</label>
        <div class="col-md-4">
          <div class="form-group{{ $errors->has('fecha_enviada') ? ' has-danger' : '' }}">
          <input type="date" name="fecha_enviada" class="form-control" style="width:40%" value="{{ old('fecha_enviada') ?? $comunicacion->fecha_enviada }}"/>
          @if ($errors->has('fecha_enviada'))
            <span id="name-error" class="error text-danger" for="input-fecha_enviada">{{ $errors->first('fecha_enviada') }}</span>
          @endif
          </div>
        </div>

        <label class="col-md-2 col-form-label">Fecha recibida</label>
        <div class="col-md-4">
          <div class="form-group{{ $errors->has('fecha_recibida') ? ' has-danger' : '' }}">
          <input type="date" name="fecha_recibida" class="form-control" style="width:40%" value="{{old('fecha_recibida') ?? $comunicacion->fecha_recibida}}"/>
          @if ($errors->has('fecha_recibida'))
            <span id="name-error" class="error text-danger" for="input-fecha_recibida">{{ $errors->first('fecha_recibida') }}</span>
          @endif
          </div>
        </div>
    </div>


    <div class="row">
        <label class="col-md-2 col-form-label">Referencia gerencia</label>
        <div class="col-md-4">
          <div class="form-group{{ $errors->has('ref_gerencia') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('ref_gerencia') ? ' is-invalid' : '' }}"
              name="ref_gerencia" id="input-ref_gerencia" type="text" placeholder="Referencia gerencia comunicación"
              value="{{ old('ref_gerencia') ?? $comunicacion->ref_gerencia }}"/>

          @if ($errors->has('ref_gerencia'))
            <span id="name-error" class="error text-danger" for="input-ref_gerencia">{{ $errors->first('ref_gerencia') }}</span>
          @endif
          </div>
        </div>

        <label class="col-md-2 col-form-label">Referencia secundaria</label>
        <div class="col-md-4">
          <div class="form-group{{ $errors->has('ref_departamento') ? ' has-danger' : '' }}">

          <input class="form-control{{ $errors->has('ref_departamento') ? ' is-invalid' : '' }}"
              name="ref_departamento" id="input-ref_departamento" type="text" placeholder="Referencia secundaria comunicación"
              value="{{ old('ref_departamento') ?? $comunicacion->ref_departamento }}" required="true"/>

          @if ($errors->has('ref_departamento'))
            <span id="name-error" class="error text-danger" for="input-ref_departamento">{{ $errors->first('ref_departamento') }}</span>
          @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-md-2 col-form-label">Superintendencia solicitante</label>
        <div class="col-md-4">
          <div class="form-group{{ $errors->has('solicitante') ? ' has-danger' : '' }}">
         
            <select class="custom-select form-control{{ $errors->has('tipo') ? ' is-invalid' : '' }}"
                name="solicitante" id="input-solicitante"placeholder="Solicitante" required>
              <option value="">SELECCIONE</option>
              @foreach($comunicacion->departamentos() as $departamento)
                <option value="{{$departamento}}" {{$comunicacion->solicitante == $departamento ? 'selected' : '' }}>{{$departamento}}</option>
              @endforeach
            </select>

          @if ($errors->has('solicitante'))
            <span id="name-error" class="error text-danger" for="input-solicitante">{{ $errors->first('solicitante') }}</span>
          @endif
          </div>
        </div>

        <label class="col-md-2 col-form-label">Archivo comunicación</label>
        <div class="col-md-4">
           <input type="file" name="archivo" id="archivo" class="form-control">
          </div>
        </div>
    </div>    


  </div>
