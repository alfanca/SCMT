@extends('layouts.app', ['activePage' => 'comunicacion', 'titlePage' => __('Gestión Comunicaciones FFCC')])
@section('content')

<div class="content">
	<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

               <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Comunicaciones</h4>
                <p class="card-category">Administración de comunicaciones</p>
              </div>
              @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('issecretaria'))
              <div class="col-md-6" style="text-align: right;">
                <a rel="tooltip" title="Agregar Comunicación"
                    href="{{route('gestion.comunicacion.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Agregar
                  <i class="material-icons">add</i>
                </a>
              </div>
               @endif
            </div>
            <div class="card-body">
             <div align="center" >@include('app.comun.nav_anho')</div>
              <div class="table-responsive">
                <table id="myTable" class="table">
                  <thead class=" text-primary">
                    <tr>
                    	<th class="col-3 text-center">Nombre</th>
                    	<th class="col-6 text-center">Descripción</th>
                    	<th>Fecha solicitud</th>
                        <th>Ref. Ger.</th>
                        <th>Solicitante</th>
                        <th>Ref. Depto</th>
                        <th>Archivo</th>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('issecretaria'))
                    	<th class="text-center">Acciones</th>
                      @endif
                  	</tr>
                  </thead>
                  <tbody>
                  	@forelse($comunicaciones as $comunicacion)
					<tr>
                      <td>{{$comunicacion->nombre}}</td>
                      <td>{{$comunicacion->descripcion}}</td>
                      <td>{{$comunicacion->fecha_enviada}}</td>
                      <td>{{$comunicacion->ref_gerencia}}</td>
                      <td>{{$comunicacion->solicitante}}</td>
                      <td>{{$comunicacion->ref_departamento}}</td>
                      <td>
                            @if (is_file(public_path('storage/').$comunicacion->id))
                                <a href="{{route('gestion.comunicacion.download', [$comunicacion->id])}}"> <i class="material-icons">description</i> </a> </td>
                            @else
                                Sin archivo
                            @endif

                      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('issecretaria'))
                      <td class="td-actions text-center">
				                <a rel="tooltip" class="btn btn-success btn-link" href="{{route('gestion.comunicacion.edit', [$comunicacion->id])}}" data-original-title="" title="Editar">
                          <i class="material-icons">edit</i>
                          <div class="ripple-container"></div>
                        </a>
                        <form method="post" id="formDeletecomunicacion-{{$comunicacion->id}}" action="{{route('gestion.comunicacion.destroy', [$comunicacion->id] ) }}" class="">
                          @csrf
                          @method('delete')
                           <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeletecomunicacion-{{$comunicacion->id}}')"
                                    ><i class="material-icons">delete</i></a>
                        </form>
                      </td>
                      @endif
                    </tr>
                    @empty
                   	<tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

        lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"  />' );

        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );

    var table = $('#myTable').DataTable();
} );
</script>

@endsection

