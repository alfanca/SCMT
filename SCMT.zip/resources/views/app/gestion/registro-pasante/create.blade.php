@extends('layouts.app', ['activePage' => 'registro_pasante', 'titlePage' => __('Registrar Pasante')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">{{ __('Registro de Pasante') }}</h4>
                      </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('registrodepasantes.store') }}"  role="form" enctype="multipart/form-data">
                            @csrf

                            @include('app.gestion.registro-pasante.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
