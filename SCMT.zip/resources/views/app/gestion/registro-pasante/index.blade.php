@extends('layouts.app', ['activePage' => 'registro_pasante', 'titlePage' => __('Registro de Pasantes')])
@section('content')
<section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Registro de Pasantes</h4>
                        <p class="card-category">Administración de los Pasantes Ingresados</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip" title="Registrar Pasante"
                            href="{{ route('registrodepasantes.create') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="fas fa-address-card" style="font-size: 20px;"></i>
                        </a>  
                      </div>
                      @endif
                    </div>


                    <div class="card-body">
                        <div align="center" >@include('app.comun.nav_anho')</div>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable2">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">No</th>
                                        
										<th class="col-2 text-center">Fecha Ingreso</th>
										<th class="col-2 text-center">Fecha Salida</th>
										<th class="col-6 text-center">Pasante</th>
										<th class="col-3 text-center">C.I Pasante</th>
										<th class="col-4 text-center">Especialidad</th>
										<th class="col-4 text-center">Universidad</th>
										<th class="col-2 text-center">Tipo de Pasantia</th>
                                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                        <th class="col-1 text-center">Acciones</th>
                                        @endif

                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($registrodepasantes as $registroPasante)
                                        <tr>
                                            <td class="text-center">{{ ++$i }}</td>
                                            
											<td class="text-center">{{\Carbon\Carbon::parse($registroPasante->fecha_ingreso)->format('d/m/Y')}}</td>
											<td class="text-center">{{\Carbon\Carbon::parse($registroPasante->fecha_salida)->format('d/m/Y')}}</td>
			
											<td style="text-transform: uppercase;"><a rel="tooltip" title="Ver Expediente" class="btn btn-link btn-primary " href="{{ route('registrodepasantes.show',$registroPasante->id) }}">{{ $registroPasante->pasante }}</a></td>
											<td class="text-center">V-{{number_format($registroPasante->pasante_cedula,0,',','.')}}</td>

											<td class="text-center">{{ $registroPasante::ESPECIALIDAD[$registroPasante->especialidad] }}</td>
											
											<td class="text-center">{{ $registroPasante::UNIVERSIDAD[$registroPasante->universidad] }}</td>
											@if($registroPasante->pasantia_regular == '0' and $registroPasante->pasantia_tesista == '0')
											<td class="text-center">REGULAR Y TESISTA</td>
                                            @elseif($registroPasante->pasantia_tesista == '0')
                                            <td class="text-center">TESISTA</td>
                                            @elseif($registroPasante->pasantia_regular == '0')
                                            <td class="text-center">REGULAR</td>
                                            @else
                                            <td class="text-center">NO SE SELECCIONO</td>
                                            @endif
										
                                            @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                            <td class="td-actions">
                                                <form class="text-center" action="{{ route('registrodepasantes.destroy',$registroPasante->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" rel="tooltip" title="Borrar" class="btn btn-danger btn-link"><i class="fa fa-fw fa-trash" onclick="return confirm('¿Seguro que deseas Eliminar?')"></i></button>
                                                </form>
                                            </td>
                                            @endif
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['20'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Pasantes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>
@endsection

