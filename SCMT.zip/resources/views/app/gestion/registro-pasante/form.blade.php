<div class="box box-info padding-1">
    <div class="box-body">
        <h4 class="col-md-12 text-center">Datos Generales</h4>
        <div class="card-group mt-4">
            {{ Form::label('fecha_ingreso:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_ingreso', $registroPasante->fecha_ingreso, ['class' => 'form-control' . ($errors->has('fecha_ingreso') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Ingreso']) }}
            {!! $errors->first('fecha_ingreso', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('fecha_salida:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_salida', $registroPasante->fecha_salida, ['class' => 'form-control' . ($errors->has('fecha_salida') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Salida']) }}
            {!! $errors->first('fecha_salida', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp
        </div>
        <div class="card-group mt-5">

            {{ Form::label('gerencia:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('gerencia', $gerencia ,$registroPasante->gerencia, ['class' => 'form-control col-2 text-center' . ($errors->has('gerencia') ? ' is-invalid' : ''), 'placeholder' => 'SELECCIONE']) }}
            {!! $errors->first('gerencia', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('unidad:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('unidad', $unidad ,$registroPasante->unidad, ['class' => 'form-control col-4 text-center' . ($errors->has('unidad') ? ' is-invalid' : ''), 'placeholder' => 'SELECCIONE']) }}
            {!! $errors->first('unidad', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('division:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('division', $division ,$registroPasante->division, ['class' => 'form-control col-2 text-center' . ($errors->has('division') ? ' is-invalid' : ''), 'placeholder' => 'SELECCIONE']) }}
            {!! $errors->first('division', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp
        </div>
        <br>
        <hr>
        <h4 class="col-md-12 text-center mt-4">Datos del Tutor</h4>
        <div class="card-group mt-5">
            {{ Form::label('Nombres y Apellidos:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('tutor', $registroPasante->tutor, ['class' => 'form-control' . ($errors->has('tutor') ? ' is-invalid' : ''), 'placeholder' => '']) }}
            {!! $errors->first('tutor', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('N° Ficha:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('tutor_ficha', $registroPasante->tutor_ficha, ['class' => 'form-control col-5' . ($errors->has('tutor_ficha') ? ' is-invalid' : ''), 'placeholder' => 'Ficha']) }}
            {!! $errors->first('tutor_ficha', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('N° cedula:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('tutor_cedula', $registroPasante->tutor_cedula, ['class' => 'form-control col-6' . ($errors->has('tutor_cedula') ? ' is-invalid' : ''), 'placeholder' => 'Cedula']) }}
            {!! $errors->first('tutor_cedula', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

         <div class="card-group mt-4 col-6 row">

            {{ Form::label('cargo:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('cargo_tutor', $cargo ,$registroPasante->cargo_tutor, ['class' => 'form-control col-6 text-center' . ($errors->has('cargo_tutor') ? ' is-invalid' : ''), 'placeholder' => 'SELECCIONE']) }}
            {!! $errors->first('cargo_tutor', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp
        </div>
    </div>
        <br>
        <hr>
        <h4 class="col-md-12 text-center mt-4">Datos del Pasante</h4>
        <div class="card-group mt-5">
            {{ Form::label('Nombres y Apellidos:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('pasante', $registroPasante->pasante, ['class' => 'form-control col-12' . ($errors->has('pasante') ? ' is-invalid' : ''), 'placeholder' => '']) }}
            {!! $errors->first('pasante', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('N°_cedula:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('pasante_cedula', $registroPasante->pasante_cedula, ['class' => 'form-control col-6' . ($errors->has('pasante_cedula') ? ' is-invalid' : ''), 'placeholder' => 'Cedula']) }}
            {!! $errors->first('pasante_cedula', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('n° Ficha:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('pasante_ficha', $registroPasante->pasante_ficha, ['class' => 'form-control col-6' . ($errors->has('pasante_ficha') ? ' is-invalid' : ''), 'placeholder' => 'Ficha']) }}
            {!! $errors->first('pasante_ficha', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

        </div>

         <div class="card-group mt-5">

            {{ Form::label('universidad:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('universidad', $universidad ,$registroPasante->universidad, ['class' => 'form-control col-3 text-center' . ($errors->has('universidad') ? ' is-invalid' : ''), 'placeholder' => 'SELECCIONE']) }}
            {!! $errors->first('universidad', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('especialidad:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('especialidad', $especialidad,$registroPasante->especialidad, ['class' => 'form-control col-3 text-center' . ($errors->has('especialidad') ? ' is-invalid' : ''), 'placeholder' => 'SELECCIONE']) }}
            {!! $errors->first('especialidad', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('semestre:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('semestre', $registroPasante->semestre, ['class' => 'form-control col-3' . ($errors->has('semestre') ? ' is-invalid' : ''), 'placeholder' => '']) }}
            {!! $errors->first('semestre', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

        </div>

         <div class="col-12 mt-5 text-center">

            <label >Pasantia Regular:&nbsp&nbsp&nbsp&nbsp<input type="checkbox" name="pasantia_regular" value="0"></label>
            <label class="mx-5">Pasantia Tesista:&nbsp&nbsp&nbsp&nbsp<input type="checkbox" name="pasantia_tesista" value="0"></label>

        </div>

    </div>
    <br>
    <div class="box-footer mt20 mt-4 text-center">
        <a href="{{ route('registrodepasantes.index') }}" class="btn btn-danger">{{ __('Cancelar') }}</a>
        <button type="submit" class="btn btn-primary">Crear</button>
    </div>
</div>