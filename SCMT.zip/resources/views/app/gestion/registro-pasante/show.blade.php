@extends('layouts.app', ['activePage' => 'registro_pasante', 'titlePage' => __('Visualizar Expediente de Pasante')])
@section('content')

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                     <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">

                          Expediente de Pasante

                         </h4>
                        <p class="card-category">

                          Expediente de Pasante: <b style="text-transform: uppercase;">{{$registroPasante->pasante}}</b>

                          </p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                        <a rel="tooltip" title="Editar Expediente" class="btn btn-sm btn-rounded" href="{{ route('registrodepasantes.edit',$registroPasante->id) }}" style="background-color: #9B945F;"><i class="fa fa-fw fa-edit"></i>Editar</a>
                        @endif
                        <a rel="tooltip"
                            href="{{ route('registrodepasantes.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>Regresar
                        </a> 
                        
                        
                      </div>
                      
                    </div>


                    <div class="card-body">
                      
                        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
              
                        <div class="card-group mt-4">
                        <div class="form-group col-3">
                            <strong><b>Fecha Ingreso:</b></strong>
                            {{\Carbon\Carbon::parse($registroPasante->fecha_ingreso)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Salida:</b></strong>
                            {{\Carbon\Carbon::parse($registroPasante->fecha_salida)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Gerencia:</b></strong>
                            {{ $registroPasante::GERENCIA[$registroPasante->gerencia] }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Unidad:</b></strong>
                            @if($registroPasante->unidad == '0')
                            JEF PLANIFICACION MTTO
                            @endif
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Division:</b></strong>
                            {{ $registroPasante::DIVISION[$registroPasante->division] }}
                        </div>
                      </div>

                      <hr>
                       <h4 class="col-md-12 text-center mt-3">Datos del Tutor</h4>
              
                        <div class="card-group mt-4">

                        <div class="form-group col-4">
                            <strong><b style="text-transform: uppercase;">Nombre y Apellido:</b></strong>
                            <strong style="text-transform: uppercase;">{{ $registroPasante->tutor }}</strong>
                        </div>
                        <div class="form-group col-2">
                            <strong><b>N° Ficha:</b></strong>
                            {{ $registroPasante->tutor_ficha }}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>N° Cedula:</b></strong>
                            V-{{number_format($registroPasante->tutor_cedula,0,',','.') }}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Cargo:</b></strong>
                            {{ $registroPasante::CARGO[$registroPasante->cargo_tutor] }}
                        </div>
                    </div>

                    <hr>
                       <h4 class="col-md-12 text-center mt-3">Datos del Pasante</h4>
              
                        <div class="card-group mt-4">
                        <div class="form-group col-4">
                            <strong><b>Nombre y Apellido:</b></strong>
                            <strong style="text-transform: uppercase;">{{ $registroPasante->pasante }}</strong>
                        </div>
                        <div class="form-group col-2">
                            <strong><b>N° Ficha:</b></strong>
                            {{ $registroPasante->pasante_ficha }}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>N° Cedula:</b></strong>
                            V-{{number_format($registroPasante->pasante_cedula,0,',','.')}}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Especialidad:</b></strong>
                            {{ $registroPasante::ESPECIALIDAD[$registroPasante->especialidad] }}
                        </div>
                    </div>
                        <div class="card-group mt-4">
                        
                        <div class="form-group col-4">
                            <strong><b>Universidad:</b></strong>
                            {{ $registroPasante::UNIVERSIDAD[$registroPasante->universidad] }}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>Semestre:</b></strong>
                            {{ $registroPasante->semestre }}
                        </div>

                        <div class="form-group col-3">
                            <strong><b>Tipo de Pasantia:</b></strong>
                        @if($registroPasante->pasantia_regular == '0' and $registroPasante->pasantia_tesista == '0')
                        REGULAR Y TESISTA
                        @elseif($registroPasante->pasantia_tesista == '0')
                        TESISTA
                        @elseif($registroPasante->pasantia_regular == '0')
                        REGULAR
                        @else
                        NO SE SELECCIONO
                        @endif
                        </div>
                    </div>

                    <div class="card-group mt-4">

                        @if($registroPasante->pasantia_regular == '0' and $registroPasante->pasantia_tesista == '0')

                        <div class="form-group col-6">
                            <strong><b>Tema de Pasantia Regular:</b></strong>
                            <span style="text-transform: uppercase;">{{ $registroPasante->tema_regular }}</span>
                        </div>
                        <div class="form-group col-6">
                            <strong><b>Tema de Pasantia Tesista:</b></strong>
                            <span style="text-transform: uppercase;">{{ $registroPasante->tema_tesis }}</span>
                        </div>

                        @elseif($registroPasante->pasantia_tesista == '0')

                        <div class="form-group col-6">
                            <strong><b>Tema de Pasantia Tesista:</b></strong>
                            <span style="text-transform: uppercase;">{{ $registroPasante->tema_tesis }}</span>
                        </div>

                        @elseif($registroPasante->pasantia_regular == '0')

                        <div class="form-group col-6">
                            <strong><b>Tema de Pasantia Regular:</b></strong>
                            <span style="text-transform: uppercase;">{{ $registroPasante->tema_regular }}</span>
                        </div>

                        @endif

                    </div>
                        

                    <hr>
                       <h4 class="col-md-12 text-center mt-3">Evaluación y Datos Complementarios</h4>
              
                        <div class="card-group mt-4">
                        <div class="form-group col-4">
                            <strong><b>Evaluacion:</b></strong>
                            @if(empty($registroPasante->evaluacion))
                            NO SE HA EVALUADO AL PASANTE
                            @else
                            {{ $registroPasante::EVALUACION[$registroPasante->evaluacion] }}
                            @endif
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Usuario Crea:</b></strong>
                            <strong style="text-transform: uppercase;">{{ $registroPasante->usuario_crea }}</strong>
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Usuario Actualiza:</b></strong>
                            <strong style="text-transform: uppercase;">{{ $registroPasante->usuario_actualiza }}</strong>
                        </div>

                    </div>
                    <hr>
                       <h4 class="col-md-12 text-center mt-3">Ferros (Notificación de Riesgo y Evaluación)</h4>
              
                        <div class="card-group mt-4">
                            <div class="col-md-12" style="text-align: center;">
                            <a rel="tooltip" title="Notificación de riesgo F-5841" class="btn btn-sm btn-rounded" href="{{ route('ferronotificacionriesgo',$registroPasante->id) }}" target="_blank" style="background-color: #9B945F;"><i class="fas fa-user-shield" style="font-size: 20px;"></i>
                        </a> 
                        @if(!empty($registroPasante->evaluacion) and $registroPasante->evaluacion == '0')
                        <a rel="tooltip" title="Evaluación del Pasante F-5477" class="btn btn-sm btn-rounded" href="{{ route('ferroevaluacionpasantedeficiente',$registroPasante->id) }}" target="_blank" style="background-color: #9B945F;"><i class="fas fa-clipboard-check" style="font-size: 20px;"></i>
                        </a> 
                        @elseif(!empty($registroPasante->evaluacion) and $registroPasante->evaluacion == '1')
                        <a rel="tooltip" title="Evaluación del Pasante F-5477" class="btn btn-sm btn-rounded" href="{{ route('ferroevaluacionpasanteregular',$registroPasante->id) }}" target="_blank" style="background-color: #9B945F;"><i class="fas fa-clipboard-check" style="font-size: 20px;"></i>
                        </a> 
                        @elseif(!empty($registroPasante->evaluacion) and $registroPasante->evaluacion == '2')
                        <a rel="tooltip" title="Evaluación del Pasante F-5477" class="btn btn-sm btn-rounded" href="{{ route('ferroevaluacionpasantebueno',$registroPasante->id) }}" target="_blank" style="background-color: #9B945F;"><i class="fas fa-clipboard-check" style="font-size: 20px;"></i>
                        </a> 
                        @elseif(!empty($registroPasante->evaluacion) and $registroPasante->evaluacion == '3')
                        <a rel="tooltip" title="Evaluación del Pasante F-5477" class="btn btn-sm btn-rounded" href="{{ route('ferroevaluacionpasantemuybueno',$registroPasante->id) }}" target="_blank" style="background-color: #9B945F;"><i class="fas fa-clipboard-check" style="font-size: 20px;"></i>
                        </a> 
                        @elseif(!empty($registroPasante->evaluacion) and $registroPasante->evaluacion == '4')
                        <a rel="tooltip" title="Evaluación del Pasante F-5477" class="btn btn-sm btn-rounded" href="{{ route('ferronotificacionriesgoexcelente',$registroPasante->id) }}" target="_blank" style="background-color: #9B945F;"><i class="fas fa-clipboard-check" style="font-size: 20px;"></i>
                        </a>
                        @endif
                    </div>
                        </div>
                </div>
            </div>
        </div>
    </section>
@endsection
