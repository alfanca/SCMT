<div class="card-body mb-4">
    <div class="row">
        <div class="col-md-6">
            <label class="label-control col-md-6">FECHA</label>
            <div class="col-sm-6">
                <input type="date" name="fecha" class="form-control" value="{{$nota->fecha ?? $fecha}}" readonly="true" />
            </div>
        </div>
        <div class="form-group col-md-6">
            <label class="label-control">TURNO {{$nota->turno ?? $turno}}</label>
            <input type="hidden" name="turno" class="form-control" value="{{$nota->turno ?? $turno}}" readonly="true" />
        </div>
    </div>

    <div class="row">
        <div class="form-group col-md-6">
            <label class="label-control col-md-6">OBSERVACIÓN</label>
            <div class="col-sm-6">
                <textarea class="form-group" cols="120" rows="5" id="nota" name="nota">{{$nota->nota ?? ''}}</textarea>
            </div>
        </div>      
    </div>
</div>