<div class="box box-info padding-1">
    <div class="box-body">

        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
        <br>
        <div class="card-group mt-2 col-12">
            {{ Form::label('N° Loc:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('locomotora_id', $locomotoras,$maestropreventivolocomotora->locomotora_id, ['class' => 'form-control col-1' . ($errors->has('locomotora_id') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('locomotora_id', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('fecha_inicio:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_inicio', $maestropreventivolocomotora->fecha_inicio, ['class' => 'form-control text-center' . ($errors->has('fecha_inicio') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Inicio']) }}
            {!! $errors->first('fecha_inicio', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('fecha_fin:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_fin', $maestropreventivolocomotora->fecha_fin, ['class' => 'form-control text-center' . ($errors->has('fecha_fin') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Fin']) }}
            {!! $errors->first('fecha_fin', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        </div>

        <hr>
        <h4 class="col-md-12 text-center mt-3">Responsables</h4>
        <br>

            <div class="card-group mt-4">
            <div class="col-md-6">
            {{ Form::label('Planificador:') }}
            <div class="form-group{{ $errors->has('responsableplanificador') ? ' has-danger' : '' }}">
            <select name="responsableplanificador" class="responsable col-md-4">
              @if (!empty($reportedelocomotora->datos->nombre))
                <option value="{{$reportedelocomotora->responsableplanificador}}">{{ $reportedelocomotora->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsableplanificador">{{ $errors->first('responsableplanificador') }}</span>
            @endif

            </div>
          </div>

            <div class="col-md-6">
          {{ Form::label('Jefe de Planificación:') }}
            <div class="form-group{{ $errors->has('responsablejefeplanifiacion') ? ' has-danger' : '' }}">
            <select name="responsablejefeplanifiacion" class="responsable col-md-4">
              @if (!empty($reportedelocomotora->datos->nombre))
                <option value="{{$reportedelocomotora->responsablejefeplanifiacion}}">{{ $reportedelocomotora->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsablejefeplanifiacion">{{ $errors->first('responsablejefeplanifiacion') }}</span>
            @endif

            </div>
          </div>

            <div class="col-md-6">
          {{ Form::label('Jefe Taller de Locomotora:') }}
            <div class="form-group{{ $errors->has('responsablejefetallerloc') ? ' has-danger' : '' }}">
            <select name="responsablejefetallerloc" class="responsable col-md-4">
              @if (!empty($reportedelocomotora->datos->nombre))
                <option value="{{$reportedelocomotora->responsablejefetallerloc}}">{{ $reportedelocomotora->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsablejefetallerloc">{{ $errors->first('responsablejefetallerloc') }}</span>
            @endif

            </div>
          </div>

            <div class="col-md-6">
          {{ Form::label('Jefe Taller de Vagones:') }}
            <div class="form-group{{ $errors->has('responsablejefetallervag') ? ' has-danger' : '' }}">
            <select name="responsablejefetallervag" class="responsable col-md-4">
              @if (!empty($reportedelocomotora->datos->nombre))
                <option value="{{$reportedelocomotora->responsablejefetallervag}}">{{ $reportedelocomotora->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsablejefetallervag">{{ $errors->first('responsablejefetallervag') }}</span>
            @endif

            </div>
          </div>
        </div>


        <hr>
        <h4 class="col-md-12 text-center mt-3">Notas</h4>
        <br>

        <div class="form-group mt-4 col-12">
            {{ Form::label('nota') }}
            <br>
            {{ Form::text('nota', $maestropreventivolocomotora->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Agregar Nota']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}
        </div>

    </div>
    <div class="card-footer justify-content-center mt-2">
       <a href="{{route('maestropreventivolocomotora.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
         <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
     </div>
</div>