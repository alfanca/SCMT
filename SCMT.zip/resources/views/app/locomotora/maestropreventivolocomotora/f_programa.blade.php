@extends('layouts.app', ['activePage' => 'preventivolocomotora', 'titlePage' => __('Formato de Programa de Locomotora')])
@section('content')
<section class="content container-fluid">
	    <div class="container-fluid">
        	 	<div class="card" align="center">
        	 		<div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title text-left">Programa de Locomotoras</h4>
                        <p class="card-category text-left">Administración de Programas del Taller de Locomotoras</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="col-md-6" style="text-align: right;">
                    	<a rel="tooltip" title="Volver"
                            href="{{route('maestropreventivolocomotora.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="material-icons">reply</i>
                        </a> 
                        <a rel="tooltip" title="Imprimir"
                            href="" onclick="javascript:imprim1r(imprimir);" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="material-icons">print</i>
                        </a>  
                      </div>
                      @endif
                    </div>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<meta name="generator" content="LibreOffice 6.0.7.3 (Linux)"/>
	<meta name="created" content="2022-02-04T09:01:40.808261940"/>
	<meta name="changed" content="2022-02-04T09:19:41.979715203"/>
	<style type="text/css">
		@page { margin: 2cm }
		p { margin-bottom: 0.25cm; line-height: 115% }
		td p { margin-bottom: 0cm }
		a:link { so-language: zxx }
	</style>
	<script type="text/javascript">
		function imprim1r (imprimir){
			var printContents = document.getElementById('imprimir').innerHTML;
				w = window.open();
				w.document.write(printContents);
		w.print();
		w.close();
		return true;
		}
	</script>
</head>
<body lang="es-VE" dir="ltr">
	<div id="imprimir">	
<table width="665" cellpadding="4" cellspacing="0" class="mt-4">
	<col width="135">
	<col width="512">
	<tr>
		<td width="135" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><img src="{{asset('/images/logofmo.png')}}" align="center" width="90" height="90" />
<br/>

			</p>
		</td>
		<td width="512" valign="top" style="border: 1px solid #000000; padding: 0.1cm">
			<p align="center" style="margin-bottom: 0cm; font-weight: normal"><br/>

			</p>
			<p align="center" style="margin-bottom: 0cm; font-weight: normal"><font face="DejaVu Sans, sans-serif"><font size="3" style="font-size: 12pt"><font color="#000000"><span style="text-decoration: none"><span style="font-style: normal"><u>C.V.G
			FERROMINERA ORINOCO C.A.</u></span></span></font></font></font></p>
			<p align="center" style="margin-bottom: 0cm; font-weight: normal"><font face="DejaVu Sans, sans-serif"><font size="3" style="font-size: 12pt"><font color="#000000"><span style="text-decoration: none"><span style="font-style: normal"><u>GERENCIA
			DE FERROCARRIL</u></span></span></font></font></font></p>
			<p align="center" style="margin-bottom: 0cm; font-weight: normal"><font face="DejaVu Sans, sans-serif"><font size="3" style="font-size: 12pt"><font color="#000000"><span style="text-decoration: none"><span style="font-style: normal"><u>SUPERINTENDENCIA
			TALLERES DE LOCOMOTORA</u></span></span></font></font></font></p>
			<p align="center" style="margin-bottom: 0cm; font-weight: normal"><font face="DejaVu Sans, sans-serif"><font size="3" style="font-size: 12pt"><font color="#000000"><span style="text-decoration: none"><span style="font-style: normal"><u>ACTIVIDADES
			POR EJECUTAR <b>SEM #{{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_inicio)->isoFormat('w')}}</b></u></span></span></font></font></font>
			</p>
			<p align="center"><br/>

			</p>
		</td>
	</tr>
</table>
<p align="center" style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>

<table width="665" cellpadding="4" cellspacing="0">
	<colgroup>
		<col width="125">
		<col width="218">
	</colgroup>
	<colgroup>
		<col width="87">
	</colgroup>
	<colgroup>
		<col width="86">
	</colgroup>
	<colgroup>
		<col width="109">
	</colgroup>
	<tr valign="top">
		<td width="125" style="background: #ce181e; border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font color="#ffffff"><b>N.º LOC</b></font></p>
		</td>
		<td width="218" style="background: #ce181e; border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font color="#ffffff"><b>DESCRIPCION</b></font></p>
		</td>
		<td width="87" style="background: #ce181e; border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font color="#ffffff"><b>FECHA</b></font></p>
		</td>
		<td width="86" style="background: #ce181e; border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><font color="#ffffff"><b>% CUMP.</b></font></p>
		</td>
		<td width="109" style="background: #ce181e; border: 1px solid #000000; padding: 0.1cm">
			<p align="center"><font color="#ffffff"><b>ORDEN SAP</b></font></p>
		</td>
	</tr>
	@foreach ($detallespreventivos as $detallepreventivolocomotora)
	<tr valign="top">
		<td width="125" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center">

				@if ($detallepreventivolocomotora->locomotora == '0002')
				DF8BVEN-{{ $detallepreventivolocomotora->locomotora }}
				@else
				019-{{ $detallepreventivolocomotora->locomotora }}
				@endif
				<br/>

			</p>
		</td>
		<td width="218" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center">{{ $detallepreventivolocomotora->reportedelocomotora->descripcion_falla }}<br/>

			</p>
		</td>
		<td width="87" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center" style="text-transform: uppercase;">{{\Carbon\Carbon::parse($detallepreventivolocomotora->fecha_inicio)->isoFormat('dddd DD/MM/YYYY')}}<br/>

			</p>
		</td>
		<td width="86" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center">{{ $detallepreventivolocomotora->cumplimiento }}%<br/>

			</p>
		</td>
		<td width="109" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
			<p align="center">{{$detallepreventivolocomotora->reportedelocomotora->n_orden }}<br/>

			</p>
		</td>
	</tr>
	@endforeach
	<tr valign="top">
		<td width="125" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="218" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="87" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center">TOTAL %</p>
		</td>
		<td width="86" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
			
			@if ($conteocumplimiento == 0)

			<p align="center"><b>0 %</b><br/>

			</p>
            @else
            <p align="center"><b>{{round($sumadecumplimiento/$conteocumplimiento)}} %</b><br/>

			</p>
            @endif
		</td>
		<td width="109" style="border-top: none; border-bottom: none; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.1cm; padding-right: 0cm">
			<p align="center"><br/>

			</p>
		</td>
	</tr>
</table>


<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>


<table width="665" cellpadding="4" cellspacing="0">
	<col width="320">
	<col width="37">
	<col width="284">
	<tr valign="top">
		<td width="320" height="40" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center">{{$maestropreventivolocomotora->datosPlanificador->nombre}}   &nbsp&nbspF-{{$maestropreventivolocomotora->datosPlanificador->ficha}}

			</p>
		</td>
		<td width="37" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="284" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center">{{ $maestropreventivolocomotora->datosTallerLoc->nombre }}&nbsp&nbspF-{{$maestropreventivolocomotora->datosTallerLoc->ficha}}<br/>

			</p>
		</td>
	</tr>
	<tr valign="top">
		<td width="320" height="71" style="border: none; padding: 0cm">
			<p align="center">PLANIFICADOR	</p>
		</td>
		<td width="37" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="284" style="border: none; padding: 0cm">
			<p align="center">JEFE DE TURNO DE MANTENIMIENTO MECANICO /
			ELECTRICO DE LOCOMOTORA</p>
		</td>
	</tr>
	<tr valign="top">
		<td width="320" height="52" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center">{{ $maestropreventivolocomotora->datosTallerVag->nombre }}&nbsp&nbspF-{{$maestropreventivolocomotora->datosTallerVag->ficha}}<br/>

			</p>
		</td>
		<td width="37" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="284" style="border-top: none; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
			<p align="center">{{ $maestropreventivolocomotora->datosjefePlanificador->nombre }} &nbsp&nbspF-{{$maestropreventivolocomotora->datosjefePlanificador->ficha}}

			</p>
		</td>
	</tr>
	<tr valign="top">
		<td width="320" style="border: none; padding: 0cm">
			<p align="center">JEFE DE TURNO DE MANTENIMIENTO DE VAGONES /
			SERVICIO</p>
		</td>
		<td width="37" style="border: none; padding: 0cm">
			<p align="center"><br/>

			</p>
		</td>
		<td width="284" style="border: none; padding: 0cm">
			<p align="center">JEFE DE AREA DE PLANIFICACION DE MANTENIMIENTO	</p>
		</td>
	</tr>
</table>
<p style="margin-bottom: 0cm; line-height: 100%"><br/>

</p>
</body>
</html>
</div>
</div>
</div>
</section>
@endsection