<div class="box box-info padding-1">
    <div class="box-body">

        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
        <br>
        <div class="card-group mt-2 col-12">
            {{ Form::label('N° Loc:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('locomotora_id', $locomotoras,$maestropreventivolocomotora->locomotora_id, ['class' => 'form-control col-1' . ($errors->has('locomotora_id') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('locomotora_id', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('fecha_inicio:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_inicio', $maestropreventivolocomotora->fecha_inicio, ['class' => 'form-control text-center' . ($errors->has('fecha_inicio') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Inicio']) }}
            {!! $errors->first('fecha_inicio', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('fecha_fin:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_fin', $maestropreventivolocomotora->fecha_fin, ['class' => 'form-control text-center' . ($errors->has('fecha_fin') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Fin']) }}
            {!! $errors->first('fecha_fin', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Estatus:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('estatus', $estatus,$maestropreventivolocomotora->estatus, ['class' => 'form-control col-1 text-center' . ($errors->has('estatus') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('estatus', '<div class="invalid-feedback">:message</div>') !!}
        </div>

        <hr>
        <h4 class="col-md-12 text-center mt-3">Responsables</h4>
        <br>

            <div class="card-group mt-4">
            <div class="col-md-6">
            {{ Form::label('Planificador:') }}
            <div class="form-group{{ $errors->has('responsableplanificador') ? ' has-danger' : '' }}">
            <select name="responsableplanificador" class="responsable col-md-4">
              @if (!empty($maestropreventivolocomotora->datosPlanificador->nombre))
                <option value="{{$maestropreventivolocomotora->responsableplanificador}}">{{ $maestropreventivolocomotora->datosPlanificador->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsableplanificador">{{ $errors->first('responsableplanificador') }}</span>
            @endif

            </div>
          </div>

            <div class="col-md-6">
          {{ Form::label('Jefe de Planificación:') }}
            <div class="form-group{{ $errors->has('responsablejefeplanifiacion') ? ' has-danger' : '' }}">
            <select name="responsablejefeplanifiacion" class="responsable col-md-4">
              @if (!empty($maestropreventivolocomotora->datosjefePlanificador->nombre))z
                <option value="{{$maestropreventivolocomotora->responsablejefeplanifiacion}}">{{ $maestropreventivolocomotora->datosjefePlanificador->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsablejefeplanifiacion">{{ $errors->first('responsablejefeplanifiacion') }}</span>
            @endif

            </div>
          </div>

            <div class="col-md-6">
          {{ Form::label('Jefe Taller de Locomotora:') }}
            <div class="form-group{{ $errors->has('responsablejefetallerloc') ? ' has-danger' : '' }}">
            <select name="responsablejefetallerloc" class="responsable col-md-4">
              @if (!empty($maestropreventivolocomotora->datosTallerLoc->nombre))
                <option value="{{$maestropreventivolocomotora->responsablejefetallerloc}}">{{ $maestropreventivolocomotora->datosTallerLoc->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsablejefetallerloc">{{ $errors->first('responsablejefetallerloc') }}</span>
            @endif

            </div>
          </div>

            <div class="col-md-6">
          {{ Form::label('Jefe Taller de Vagones:') }}
            <div class="form-group{{ $errors->has('responsablejefetallervag') ? ' has-danger' : '' }}">
            <select name="responsablejefetallervag" class="responsable col-md-4">
              @if (!empty($maestropreventivolocomotora->datosTallerVag->nombre))
                <option value="{{$maestropreventivolocomotora->responsablejefetallervag}}">{{ $maestropreventivolocomotora->datosTallerVag->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsablejefetallervag">{{ $errors->first('responsablejefetallervag') }}</span>
            @endif

            </div>
          </div>
        </div>


        <hr>
        <h4 class="col-md-12 text-center mt-3">Notas</h4>
        <br>

        <div class="form-group mt-4 col-12">
            {{ Form::label('nota') }}
            <br>
            {{ Form::text('nota', $maestropreventivolocomotora->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Agregar Nota']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}
        </div>

        <script type="text/javascript">
  
          function muestra_oculta(id){
        if (document.getElementById){ //se obtiene el id
        var el = document.getElementById(id); //se define la variable "el" igual a nuestro div
        el.style.display = (el.style.display == 'none') ? 'block' : 'none'; //damos un atributo display:none que oculta el div
        }
        }
        window.onload = function(){/*hace que se cargue la función lo que predetermina que div estará oculto hasta llamar a la función nuevamente*/
        muestra_oculta('contenido');/* "contenido_a_mostrar" es el nombre que le dimos al DIV */
        }
          
        </script>

        <div class="col-md-12 text-center mt-4">
        <a onClick="muestra_oculta('contenido')" title="Reprogramar" class="btn btn-sm btn-rounded btn-primary" style="color: white; font-size: 12px;"><i class="fas fa-history" style="font-size: 18px;"></i> Reprogramar
        </a>
       </div>


        
        <div id="contenido">
        <hr>
        <h4 class="col-md-12 text-center mt-3">Reprogramación</h4>


        <div class="card-group mt-4">

            {{ Form::label('fecha_reprogramacion:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_reprogramacion', $maestropreventivolocomotora->fecha_reprogramacion, ['class' => 'form-control text-center' . ($errors->has('fecha_reprogramacion') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la Fecha']) }}
            {!! $errors->first('fecha_reprogramacion', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

        </div>

        <br>

        <div class="form-group mt-4 panel_error">

            {{ Form::label('causa_reprogramacion:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <br>
            {{ Form::textarea('causa_reprogramacion', $maestropreventivolocomotora->causa_reprogramacion, ['class' => 'form-control' . ($errors->has('causa_reprogramacion') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese la Causa']) }}
            {!! $errors->first('causa_reprogramacion', '<div class="invalid-feedback">:message</div>') !!}
        </div>

        </div>

    </div>
    <div class="card-footer justify-content-center mt-2">
       <a href="/locomotoras/maestropreventivolocomotora/{{$_GET['id_m']}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
         <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
     </div>
</div>