@extends('layouts.app', ['activePage' => 'preventivolocomotora', 'titlePage' => __('Mantenimiento Preventivo e Inspección de Locomotoras')])
@section('content')
    <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Programas de Mantenimiento de Locomotoras</h4>
                        <p class="card-category">Programas de Mantenimiento Preventivo e Inspección de Locomotoras</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip" title="Crear Programa"
                            href="{{route('maestropreventivolocomotora.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="far fa-calendar-plus" style="font-size: 19px;"></i>
                        </a>  
                      </div>
                      @endif
                    </div>


                    <div class="card-group" align="center">


              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-fw fa-clipboard-list text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Programas Anuales</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $maestropreventivolocomotorasconteo }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>


              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #a9afbb; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-fw fa-file-alt text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Inspecciones Anuales</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $detallespreventivosportada->count('cumplimiento') }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #ff8000; color: white;border-top-left-radius: 10px;">
           
                          <i class="fas fa-history text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Repr. Anuales</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$maestropreventivolocomotorasconteoreprogramado}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              
              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">

                        @if(!empty($detallespreventivosportada->count('cumplimiento')))

                        @if (round(($detallespreventivosportada->sum('cumplimiento'))/$detallespreventivosportada->count('cumplimiento')) < 50)
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
                          <i class="fa fa-percent text-center mt-4" style="font-size: 25px;"></i>
                        </div>
                        @elseif (round(($detallespreventivosportada->sum('cumplimiento'))/$detallespreventivosportada->count('cumplimiento')) < 80)
                        <div class="col-md-3 text-center" style="background-color: #ffc107; color: white;border-top-left-radius: 10px;">
                          <i class="fa fa-percent text-center mt-4" style="font-size: 25px;"></i>
                        </div>
                        @elseif (round(($detallespreventivosportada->sum('cumplimiento'))/$detallespreventivosportada->count('cumplimiento')) >= 80)
                        <div class="col-md-3 text-center" style="background-color: #28a745; color: white;border-top-left-radius: 10px;">
                          <i class="fa fa-percent text-center mt-4" style="font-size: 25px;"></i>
                        </div>
                        @endif
                    
                        @else
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
                          <i class="fa fa-percent text-center mt-4" style="font-size: 25px;"></i>
                        </div>
                        @endif 
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Cumplimiento Anual%</strong></div>
                          @if ($detallespreventivosportada->count('cumplimiento') == 0)
                          <p class="text-center" style="font-size: 18px;">0%</p>
                          @else
                          <p class="text-center" style="font-size: 18px;">
                              
                            {{round(($detallespreventivosportada->sum('cumplimiento'))/$detallespreventivosportada->count('cumplimiento'))}} %

                          </p>
                          @endif
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>


                    <div class="card-body">


                      <div class="mt-4">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class=" nav-link active" href="#tab-programas" data-toggle="tab">
                        <i class="fa fa-fw fa-clipboard-list" style="font-size: 15px;"></i> Programas
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-programar" data-toggle="tab">
                        <i class="fa fa-fw fa-stopwatch" style="font-size: 15px;"></i> Fecha de Programas
                        <div class="ripple-container"></div>
                      </a>
                    </li>

                  </ul>
                </div>
              </div>
            </div>

              <div class="tab-content">

                <div class="tab-pane active" id="tab-programas">

               <div class="table-responsive">

                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">No</th>
                                        
                                        <th class="text-center">N° Loc</th>
                                        <th class="text-center">Fecha Inicio</th>
                                        <th class="text-center">Fecha Fin</th>
                                        <th class="text-center">Semana</th>
                                        <th class="text-center">Estatus</th>
                                        <th class="text-center">Cant.Insp</th>
                                        <th class="text-center">Cump. %</th>
                                        <th class="text-center">CECO</th>
                                        <th class="text-center">N° Plan</th>
                                        @if ($conteonota > 0)
                                        <th class="text-center">Nota</th>
                                        @endif
                                        @if ($conteoreprogramacion > 0)
                                        <th class="text-center">Reprogramado</th>
                                        @endif
                                        @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isinvitado'))

                                        <th class="text-center col-1">Acciones</th>
                                        @endif



                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($maestropreventivolocomotorasfiltro as $maestropreventivolocomotora)
                                        <tr>
                                            <td class="text-center">{{ ++$i }}</td>
                                            
                                            <td class="text-center"><a rel="tooltip" title="Ver Programa" class="btn btn-link btn-primary" href="{{ route('maestropreventivolocomotora.show',$maestropreventivolocomotora->id) }}">{{ $maestropreventivolocomotora->locomotora->numero }}</a></td>

                                            <td class="text-center">{{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_inicio)->format('d/m/Y')}}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_fin)->format('d/m/Y')}}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_inicio)->isoFormat('w')}}</td>
                                            <td class="text-center">{{$maestropreventivolocomotora::ESTATUS[$maestropreventivolocomotora->estatus]}}</td>
                                            <td class="text-center">{{ $detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->count('cumplimiento') }}</td>

                                            @if ($detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->count('cumplimiento') == 0)

                                            <td class="text-center" style="color: #dc3545">0 %</td>
                                            @else

                                            @if(($detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->sum('cumplimiento'))/$detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->count('cumplimiento') >= 85)
                                            <td class="text-center" style="color: #28a745">
                                            @elseif(($detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->sum('cumplimiento'))/$detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->count('cumplimiento') >= 50)
                                            <td class="text-center" style="color: #ffc107">
                                            @elseif(($detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->sum('cumplimiento'))/$detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->count('cumplimiento') < 50)
                                            <td class="text-center" style="color: #dc3545">
                                            @endif


                                            {{round(($detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->sum('cumplimiento'))/$detallespreventivos->where('maestropreventivo_id', $maestropreventivolocomotora->id)->count('cumplimiento'))}} %</td>

                                            @endif

                                            <td class="text-center">{{ $maestropreventivolocomotora->locomotora->ceco }}</td>
                                            <td class="text-center">{{ $maestropreventivolocomotora->locomotora->n_plan }}</td>
                                            @if ($conteonota > 0)
                                            <td class="text-center" style="text-transform: uppercase;">

                                              @if(!empty($maestropreventivolocomotora->nota))
                                              <a href="" style="" data-toggle="modal" data-target="#notaPrograma" data-observacion="{{$maestropreventivolocomotora->nota}}"><i class="material-icons">book</i></a>
                                              @endif

                                            </td>
                                            @endif
                                            @if ($conteoreprogramacion > 0)
                                            <td class="text-center">

                                              @if(!empty($maestropreventivolocomotora->fecha_reprogramacion))
                                              {{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_reprogramacion)->format('d/m/Y')}}
                                              @endif

                                            </td>
                                            @endif

                                            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isinvitado'))
                                            
                                            <td class="td-actions">
                                                <form action="{{ route('maestropreventivolocomotora.destroy',$maestropreventivolocomotora->id) }}" method="POST">
                                                    @if (empty($maestropreventivolocomotora->fecha_reprogramacion))
                                                    <a rel="tooltip" title="Ver Formato de Inspección" class="btn btn-link btn-primary" href="{{ route('f_programa',$maestropreventivolocomotora->id) }}"><i class="fa fa-fw fa-file-download"></i></a>
                                                    @endif
                                                    @if (!empty($maestropreventivolocomotora->fecha_reprogramacion))
                                                    <a rel="tooltip" title="Ver Ferro de Reprogramacion" class="btn btn-link btn-primary" href="{{ route('f_reprogramacion', $maestropreventivolocomotora->id) }}"><i class="fa fa-fw fa-file-download"></i></a>
                                                    @endif
                                                    @csrf
                                                    @method('DELETE')
                                                    @endif
                                                    @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                                    @if($maestropreventivolocomotora->estatus != 'CERRADA')
                                                    <button rel="tooltip" title="Borrar" type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                    @endif
                                                    @endif
                                                </form>
                                            </td>

                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                <div class="tab-pane" id="tab-programar">

              <div class="card-group">
              @foreach ($programasfechatope as $programas)
              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">

                      @if (empty($programas[0]->fecha_reprogramacion))

                      <div class="media align-items-stretch">
                        @if(\Carbon\Carbon::parse($programas[0]->programa)->isoFormat('w') <= now()->format('W'))
                        <div class="col-md-3 text-center" style="background-color: red; color: white; border-top-left-radius: 10px;">
                          <br>
                          <i class="fa fa-times text-center mt-2" style="font-size: 30px;"></i>
                        
                      </div>
                      @elseif (\Carbon\Carbon::parse($programas[0]->programa)->isoFormat('w') - 1 == now()->format('W'))
                      <div class="col-md-3 text-center" style="background-color: #ffc107; color: white; border-top-left-radius: 10px;">
                          <br>
                          <i class="fas fa-bell text-center mt-2" style="font-size: 30px;"></i>
                        
                      </div>
                      @else
                      <div class="col-md-3 text-center" style="background-color: #28a745; color: white; border-top-left-radius: 10px;">
                          <br>
                          <i class="fa fa-check text-center mt-2" style="font-size: 30px;"></i>
                        
                      </div>
                      @endif
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 18px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>{{$programas[0]->locomotora->numero}}</strong></div>
                          
                          <p class="text-center" style="font-size: 12px;">
                            

                            {{\Carbon\Carbon::parse($programas[0]->programa)->format('d/m/Y')}}
                            Sem #{{\Carbon\Carbon::parse($programas[0]->programa)->isoFormat('w')}}

                            <br> N° Plan: {{$programas[0]->locomotora->n_plan}} 

                          </p>

                        </div>
                      </div>
                      @endif
                  </div>
                </div>
              </div>
@endforeach

              </div>
              <hr>
                      <h4 class="text-center">Reprogramados</h4>

                      <div class="card-group">
              @foreach ($programasfechatope as $programas)
              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">

                      @if (!empty($programas[0]->fecha_reprogramacion))

                      <div class="media align-items-stretch">
                        @if(\Carbon\Carbon::parse($programas[0]->fecha_reprogramacion)->isoFormat('w') <= now()->format('W'))
                        <div class="col-md-3 text-center" style="background-color: red; color: white; border-top-left-radius: 10px;">
                          <br>
                          <i class="fa fa-times text-center mt-2" style="font-size: 30px;"></i>
                        
                      </div>
                      @elseif (\Carbon\Carbon::parse($programas[0]->fecha_reprogramacion)->isoFormat('w') - 1 == now()->format('W'))
                      <div class="col-md-3 text-center" style="background-color: #ffc107; color: white; border-top-left-radius: 10px;">
                          <br>
                          <i class="fas fa-bell text-center mt-2" style="font-size: 30px;"></i>
                        
                      </div>
                      @else
                      <div class="col-md-3 text-center" style="background-color: #28a745; color: white; border-top-left-radius: 10px;">
                          <br>
                          <i class="fa fa-check text-center mt-2" style="font-size: 30px;"></i>
                        
                      </div>
                      @endif
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 18px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>{{$programas[0]->locomotora->numero}}</strong></div>
                          
                          <p class="text-center" style="font-size: 12px;">
                            

                            R- {{\Carbon\Carbon::parse($programas[0]->fecha_reprogramacion)->format('d/m/Y')}}
                            Sem #{{\Carbon\Carbon::parse($programas[0]->fecha_reprogramacion)->isoFormat('w')}} 

                            <br> N° Plan: {{$programas[0]->locomotora->n_plan}} 

                          </p>

                        </div>
                      </div>
                      @endif
                  </div>
                </div>
              </div>
@endforeach

              </div>




                  
                    </div>
                  
                </div>
            </div>


                        
                    </div>
                </div>

            </div>
        </div>
    </div>

<!-- Modal -->

  <div class="modal" id="notaPrograma" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Notas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <p id="nota-programa"></p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </form>
    </div>
  </div>


</section>
<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
@endsection
