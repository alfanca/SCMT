@extends('layouts.app', ['activePage' => 'preventivolocomotora', 'titlePage' => __('Formato de Reprogramación de Locomotora')])
@section('content')
<section class="content container-fluid">
        <div class="container-fluid">
                <div class="card" align="center">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title text-left">Reprogramación de Locomotoras</h4>
                        <p class="card-category text-left">Ferro de Reprogramación del Taller de Locomotoras</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip" title="Volver"
                            href="{{URL::previous()}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="material-icons">reply</i>
                        </a> 
                        <a rel="tooltip" title="Imprimir"
                            href="" onclick="javascript:imprim1r(imprimir);" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="material-icons">print</i>
                        </a>  
                      </div>
                      @endif
                    </div>

                    <script type="text/javascript">
        function imprim1r (imprimir){
            var printContents = document.getElementById('imprimir').innerHTML;
                w = window.open();
                w.document.write(printContents);
        w.print();
        w.close();
        return true;
        }
    </script>


<body lang="es-VE" dir="ltr">
    <div id="imprimir"> 
<table class="mt-4 col-9" cellpadding="0" cellspacing="0" style="margin-left:10.45pt; border-collapse:collapse;">
    <tbody>
        <tr style="height:12pt;">
            <td colspan="5" style="width:99.3pt; border-top-style:double; border-top-width:4.5pt; border-left-style:double; border-left-width:4.5pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:6pt; margin-bottom:0pt; text-align:center; font-size:6pt;"><span style="font-family:Arial;">FERRO-5331</span><span style="font-family:Arial;">&nbsp;&nbsp;</span><span style="font-family:Arial;">REV. 20/02/09</span></p>
            </td>
            <td colspan="9" style="width:414.25pt; border-top-style:double; border-top-width:4.5pt; border-right-style:double; border-right-width:4.5pt; border-left-style:solid; border-left-width:0.75pt; padding-right:1.25pt; padding-left:3.12pt; vertical-align:top;">
                <p style="margin-top:6pt; margin-bottom:0pt; text-align:center; font-size:7pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:69.8pt;">
            <td colspan="5" style="width:99.3pt; border-top-style:solid; border-top-width:0.75pt; border-left-style:double; border-left-width:4.5pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; text-align:center; font-size:13pt;"><img src="{{asset('/images/logofmo.png')}}" alt="" width="63" height="61"></p>
            </td>
            <td colspan="9" style="width:414.25pt; border-right-style:double; border-right-width:4.5pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:1.25pt; padding-left:3.12pt; vertical-align:top;">
                <p style="margin-top:22pt; margin-bottom:0pt; text-align:center; font-size:13pt;"><strong><span style="font-family:Arial;">REPROGRAMACI&Oacute;N DEL MANTENIMIENTO</span></strong></p>
            </td>
        </tr>
        <tr style="height:15.95pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:24pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="3" style="width:49.7pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:24pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">No. DE FMO:</span></p>
            </td>
            <td colspan="5" style="width:141.85pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:24pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span>019-{{$maestropreventivolocomotora->locomotora->numero}}</p>
            </td>
            <td colspan="3" style="width:156pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:24pt; margin-bottom:0pt; text-align:right; font-size:8pt;"><span style="font-family:Arial;">FECHA DE PROGRAMACIÓN:</span></p>
            </td>
            <td style="width:106.4pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:24pt; margin-bottom:0pt; font-size:8pt; text-transform: uppercase;"><span style="font-family:Arial;">&nbsp;</span>{{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_inicio)->isoformat('MMMM Y')}}</p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:24pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="5" style="width:141.85pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">CAUSA DE LA REPROGRAMACIÓN:</span></p>
            </td>
            <td colspan="7" style="width:326.1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt; text-transform: uppercase;"><span style="font-family:Arial;">&nbsp;</span>La Loc {{$maestropreventivolocomotora->locomotora->numero}} no se le realizara las inspecciones por que,</p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style=" margin-bottom:0pt; font-size:8pt; text-transform: uppercase; line-height: 300%; position: absolute; width: 600px;"><span style="font-family:Arial;">&nbsp;</span>{{$maestropreventivolocomotora->causa_reprogramacion}}</p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td style="width:14.25pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="12" style="width:474.95pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:14.65pt;">
            <td colspan="3" style="width:63.85pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td colspan="5" style="width:106.4pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">FECHA REPROGRAMADA:</span></p>
            </td>
            <td colspan="2" style="width:71pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt; text-transform: uppercase;"><span style="font-family:Arial;">&nbsp;</span>{{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_reprogramacion)->isoformat('MMMM Y')}}</p>
            </td>
            <td colspan="3" style="width:233.95pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
            <td style="width:17.35pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:1.85pt;">
            <td colspan="14" style="width:520.55pt; border-right-style:double; border-right-width:4.5pt; border-left-style:double; border-left-width:4.5pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:1.25pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:23.05pt;">
            <td colspan="14" style="width:520.55pt; border-right-style:double; border-right-width:4.5pt; border-left-style:double; border-left-width:4.5pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:1.25pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:6pt; margin-bottom:0pt; text-align:center; font-size:8pt;"><span style="font-family:Arial;">ELABORADO POR</span></p>
            </td>
        </tr>
        <tr style="height:13.15pt;">
            <td colspan="10" style="width:255.25pt; border-left-style:double; border-left-width:4.5pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:6pt; margin-bottom:6pt; text-align:center; font-size:8pt;"><span style="font-family:Arial;">JEFE ÁREA PLANIFICACIÓN</span></p>
            </td>
            <td colspan="4" style="width:258.3pt; border-right-style:double; border-right-width:4.5pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:1.25pt; padding-left:3.12pt; vertical-align:top;">
                <p style="margin-top:6pt; margin-bottom:6pt; text-align:center; font-size:8pt;"><span style="font-family:Arial;">JEFE ÁREA MANTENIMIENTO</span></p>
            </td>
        </tr>
        <tr style="height:13.15pt;">
            <td colspan="2" style="width:56.8pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:5.65pt; margin-bottom:0pt; text-align:right; font-size:8pt;"><span style="font-family:Arial;">NOMBRE:</span></p>
            </td>
            <td colspan="8" style="width:191.45pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:5.65pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span>{{ $maestropreventivolocomotora->datosjefePlanificador->nombre }}</p>
            </td>
            <td style="width:56.8pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:5.65pt; margin-bottom:0pt; text-align:right; font-size:8pt;"><span style="font-family:Arial;">NOMBRE:</span></p>
            </td>
            <td colspan="3" style="width:194.5pt; border-right-style:double; border-right-width:4.5pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:5.65pt; margin-bottom:0pt; text-align:center; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span>{{ $maestropreventivolocomotora->datosTallerLoc->nombre }}</p>
            </td>
        </tr>
        <tr style="height:13.15pt;">
            <td colspan="2" style="width:56.8pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:19.85pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">FICHA:</span></p>
            </td>
            <td colspan="8" style="width:191.45pt; border-top-style:solid; border-top-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:5.65pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span>{{ $maestropreventivolocomotora->datosjefePlanificador->ficha }}</p>
            </td>
            <td style="width:56.8pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:19.85pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">FICHA:</span></p>
            </td>
            <td colspan="3" style="width:194.5pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:5.65pt; margin-bottom:0pt; text-align:center; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span>{{ $maestropreventivolocomotora->datosTallerLoc->ficha }}</p>
            </td>
        </tr>
        <tr style="height:13.15pt;">
            <td colspan="2" style="width:56.8pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:19.85pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">FIRMA:</span></p>
            </td>
            <td colspan="8" style="width:191.45pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:6pt; margin-left:5.65pt; margin-bottom:6pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span>{{ $maestropreventivolocomotora->datosjefePlanificador->nombre }}</p>
            </td>
            <td style="width:56.8pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-left:19.85pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">FIRMA:</span></p>
            </td>
            <td colspan="3" style="width:194.5pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:double; border-right-width:4.5pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:6pt; margin-left:5.65pt; margin-bottom:6pt; text-align:center; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span>{{ $maestropreventivolocomotora->datosTallerLoc->nombre }}</p>
            </td>
        </tr>
        <tr style="height:23.05pt;">
            <td colspan="7" style="width:167.8pt; border-left-style:double; border-left-width:4.5pt; padding-right:3.5pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-right:5.65pt; margin-bottom:0pt; text-align:right; font-size:8pt;"><span style="font-family:Arial;">FECHA:</span></p>
            </td>
            <td colspan="3" style="width:80.45pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:3.5pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span>{{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_r_realizada)->format('d/m/Y')}}</p>
            </td>
            <td colspan="4" style="width:258.3pt; border-right-style:double; border-right-width:4.5pt; padding-right:1.25pt; padding-left:3.5pt; vertical-align:top;">
                <p style="margin-top:12pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:23.05pt;">
            <td colspan="14" style="width:520.55pt; border-right-style:double; border-right-width:4.5pt; border-left-style:double; border-left-width:4.5pt; border-bottom-style:double; border-bottom-width:4.5pt; padding-right:1.25pt; padding-left:1.25pt; vertical-align:top;">
                <p style="margin-top:0pt; margin-bottom:0pt; font-size:8pt;"><span style="font-family:Arial;">&nbsp;</span></p>
            </td>
        </tr>
        <tr style="height:0pt;">
            <td style="width:21.25pt;"><br></td>
            <td style="width:42.55pt;"><br></td>
            <td style="width:7.05pt;"><br></td>
            <td style="width:7.1pt;"><br></td>
            <td style="width:28.35pt;"><br></td>
            <td style="width:63.8pt;"><br></td>
            <td style="width:4.7pt;"><br></td>
            <td style="width:9.45pt;"><br></td>
            <td style="width:42.55pt;"><br></td>
            <td style="width:35.45pt;"><br></td>
            <td style="width:63.8pt;"><br></td>
            <td style="width:63.75pt;"><br></td>
            <td style="width:113.4pt;"><br></td>
            <td style="width:24.35pt;"><br></td>
        </tr>
    </tbody>
</table>
<p style="margin-top:0pt; margin-bottom:0pt;"><span style="font-family:Arial;">&nbsp;</span></p>
<p style="margin-top:0pt; margin-bottom:0pt;"><span style="font-family:Arial;">&nbsp;</span></p>
<p style="margin-top:0pt; margin-bottom:0pt;"><span style="font-family:Arial;">&nbsp;</span></p>

</div>
</body>
</div>
</div>
</section>
@endsection