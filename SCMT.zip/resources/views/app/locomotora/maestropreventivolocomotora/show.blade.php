@extends('layouts.app', ['activePage' => 'preventivolocomotora', 'titlePage' => __('Programas de Mantenimiento Preventivo e Inspección de Locomotoras')])
@section('content')

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Programa de Locomotora  019-{{$maestropreventivolocomotora->locomotora->numero}}</h4>
                        <p class="card-category">Programas de Mantenimiento Semanal Cumplimiento 

                            @if ($conteocumplimiento == 0)
                                <span>0 %</span>
                                @else
                                <span><b>{{round($sumadecumplimiento/$conteocumplimiento)}} %</b></span>
                                @endif

                        </p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{ route('maestropreventivolocomotora.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>Regresar
                        </a> 
                        
                        
                      </div>
                      
                    </div>
                    <br>
                    <br>
                    <br>
                    <div class="card-body">

                        <div class="col-md-12">
                        
                        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
                        <div class="text-right">
                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                        @if($maestropreventivolocomotora->estatus != '1')
                        <a class="btn btn-sm btn" style="background-color: #9B945F;" href="{{ route('maestropreventivolocomotora.edit',[$maestropreventivolocomotora->id, 'id_m'=>$maestropreventivolocomotora->id]) }}"><i class="fa fa-fw fa-edit"></i> Editar / Reprogramar</a>
                        @endif  
                        @endif
                        </div>
                        <br>
              
                        <div class="card-group mt-4">
                        <div class="form-group col-2">
                            <strong><b>N° Loc: </b></strong>
                            {{ $maestropreventivolocomotora->locomotora->numero }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Inicio:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_inicio)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Fin:</b>&nbsp&nbsp </strong>
                            {{\Carbon\Carbon::parse($maestropreventivolocomotora->fecha_fin)->format('d/m/Y')}}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>CECO: </b>&nbsp&nbsp</strong>
                            {{ $maestropreventivolocomotora->locomotora->ceco }}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>N° Plan: </b>&nbsp&nbsp</strong>
                            {{ $maestropreventivolocomotora->locomotora->n_plan }}
                        </div>
                        </div>
                        <hr>
                        <h4 class="col-md-12 text-center mt-3">Responsables</h4>
                        <br>
                        <div class="card-group mt-4">
                        <div class="form-group col-3">
                            <strong><b>Planificador:</b></strong>
                            {{ $maestropreventivolocomotora->datosPlanificador->nombre }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Jefe de Planificación:</b></strong>
                            {{ $maestropreventivolocomotora->datosjefePlanificador->nombre }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Jefe Taller de Locomotora:</b></strong>
                            {{ $maestropreventivolocomotora->datosTallerLoc->nombre }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Jefe Taller de Vagones:</b></strong>
                            {{ $maestropreventivolocomotora->datosTallerVag->nombre }}
                        </div>
                        </div>

                        <hr>
                        <h4 class="col-md-12 text-center mt-3">Notas y Responsables</h4>
                        <br>
                        <div class="card-group mt-4">
                        <div class="form-group col-6">
                            <strong><b>Nota:</b></strong>
                            {{ $maestropreventivolocomotora->nota }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Usuario Crea:</b></strong>
                            {{ $maestropreventivolocomotora->usuario_crea }}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Usuario Actualiza:</b></strong>
                            {{ $maestropreventivolocomotora->usuario_actualiza }}
                        </div>
                    </div>

                    @if(!empty($maestropreventivolocomotora->fecha_reprogramacion))
                    <hr>
                        <h4 class="col-md-12 text-center mt-3">Reprogramación</h4>
                        <br>
                    <div class="card-group mt-4">
                        <div class="form-group col-4">
                            <strong><b>Fecha de Reprogramación:</b></strong>
                            {{ $maestropreventivolocomotora->fecha_reprogramacion }}
                        </div>
                        <div class="form-group col-6">
                            <strong><b>Causa Reprogramación:</b></strong><span style="text-transform: uppercase;">
                            {{ $maestropreventivolocomotora->causa_reprogramacion }}</span>
                        </div>
                    </div>
                    @endif
                    </div>

                    <hr>
                    <h4 class="col-md-12 text-center mt-3">Programas de la Semana</h4>
                    <br>
                    <div class="text-right">
                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                        @if($maestropreventivolocomotora->estatus != '1')
                        <a class="btn btn-sm btn" style="background-color: #9B945F;" href="{{ route('detallepreventivolocomotora.create',['id_m'=>$maestropreventivolocomotora->id, 'loc'=>$maestropreventivolocomotora->locomotora->numero,'filtro'=>$maestropreventivolocomotora->locomotora_id]) }}"><i class="fa fa-fw fa-upload"></i> Agregar Programa</a>
                        @endif
                        @endif
                              </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        
                                        <th class="text-center">N° Orden</th>
                                        <th class="text-center">Descripción</th>
                                        <th class="text-center">Fecha Inicio</th>
                                        <th class="text-center">Fecha Fin</th>
                                        <th class="text-center">Nota</th>
                                        <th class="text-center">Responsable</th>
                                        <th class="text-center">Usuario Crea</th>
                                        <th class="text-center">Usuario Actualiza</th>
                                        <th class="text-center">Cump. %</th>
                                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                        @if($maestropreventivolocomotora->estatus != '1')
                                        <th class="col-1 text-center">Acciones</th>
                                        @endif
                                        @endif

                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($detallespreventivos as $detallepreventivolocomotora)
                                        <tr>
                                            
                                            <td class="text-center"><a href="/locomotoras/reportedelocomotoras/{{$detallepreventivolocomotora->reportelocomotora_id}}">{{ $detallepreventivolocomotora->reportedelocomotora->n_orden }}</a></td>
                                            <td style="text-transform: uppercase;">{{ $detallepreventivolocomotora->reportedelocomotora->descripcion_falla }}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($detallepreventivolocomotora->fecha_inicio)->format('d/m/Y')}}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($detallepreventivolocomotora->fecha_fin)->format('d/m/Y')}}</td>
                                            <td style="text-transform: uppercase;">{{ $detallepreventivolocomotora->nota }}</td>
                                            <td class="text-center">{{ $detallepreventivolocomotora->datos->nombre }}</td>
                                            <td class="text-center" style="text-transform: uppercase;">{{ $detallepreventivolocomotora->usuario_crea }}</td>
                                            <td class="text-center" style="text-transform: uppercase;">{{ $detallepreventivolocomotora->usuario_actualiza }}</td>

                                            @if($detallepreventivolocomotora->cumplimiento >= 85)
                                            <td class="text-center" style="color: #28a745">
                                            @elseif($detallepreventivolocomotora->cumplimiento >= 50)
                                            <td class="text-center" style="color: #ffc107">
                                            @elseif($detallepreventivolocomotora->cumplimiento < 50)
                                            <td class="text-center" style="color: #dc3545">
                                            @endif

                                            {{ $detallepreventivolocomotora->cumplimiento }}%</td>

                                            @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                            @if($maestropreventivolocomotora->estatus != '1')
                                            <td class="td-actions">
                                                <form action="{{ route('detallepreventivolocomotora.destroy',$detallepreventivolocomotora->id) }}" method="POST">
                                                    <a rel="tooltip" title="Actualizar Programa" class="btn btn-link btn-success" href="{{ route('detallepreventivolocomotora.edit',[$detallepreventivolocomotora->id, 'id_m'=>$maestropreventivolocomotora->id, 'loc'=>$maestropreventivolocomotora->locomotora->numero,'filtro'=>$maestropreventivolocomotora->locomotora_id, 'idreporte'=>$detallepreventivolocomotora->reportelocomotora_id]) }}"><i class="material-icons">edit</i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                </form>
                                            </td>
                                                    @endif
                                                    @endif
                                        </tr>
                                    @endforeach
                                </tbody>
                                <td></td>
                                    <td></td>
                                        <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <th class="text-center">Total Cumplimiento:</th>
                                @if ($conteocumplimiento == 0)

                                <td class="text-center" style="color: #dc3545"><b>0 %</b></td>
                                @else
                                @if($sumadecumplimiento/$conteocumplimiento >= 85)
                                <th class="text-center" style="color: #28a745">
                                @elseif($sumadecumplimiento/$conteocumplimiento >= 50)
                                <th class="text-center" style="color: #ffc107">
                                @elseif($sumadecumplimiento/$conteocumplimiento < 50)
                                <th class="text-center" style="color: #dc3545">
                                @endif

                                <b>{{round($sumadecumplimiento/$conteocumplimiento)}} %</b></th>

                                @endif

                            </table>
                        </div>
                    </div>

                    


                    </div>
                </div>
            </div>
        </div>
    </section>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ vagones)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
@endsection
