@extends('layouts.app', ['activePage' => 'disponibilidad', 'titlePage' => __('Periodos')])
@section('content')
<div class="content">
  <div class="container-fluid">
   
  <div class="row">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title text-center">Horas de Operatividad de Locomotoras</h4>
      </div>


      <div class="row justify-content-center h-100">
        <form method="get" autocomplete="off" action="{{route('disponibilidadXPeriodo.index')}}" class="form-horizontal">
            @include('app.comun.nav_calendario_busqueda')
        </form>            
      </div>


      <div class="card-group" align="center">


              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-8 text-center" style="background-color: #585858; color: white; width: 20px; border-top-left-radius: 10px;">
           
                          <i class="" style="font-size: 20px;">2000 HP <br> (1029 - 1051)</i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <p class="text-center mt-3" style="min-height: 27px; max-height: 27px; font-size: 18px;">{{ $locomotora2000hp }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-8 text-center" style="background-color: #585858; color: white; border-top-left-radius: 10px;">
           
                          <i class="mt-4" style="font-size: 20px;">4000 HP <br> (1052 - 1057)</i>
                        
                      </div>
                        <div class="media-body col-sm-10">

                          <p class="text-center mt-3" style="font-size: 18px;">{{ $locomotora4000hp }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-8 text-center" style="background-color: #585858; color: white; border-top-left-radius: 10px;">
           
                          <i class="mt-4" style="font-size: 20px;">4300 HP <br> (1060 - 1070)</i>
                        
                      </div>
                        <div class="media-body col-sm-10">

                          <p class="text-center mt-3" style="font-size: 18px;">{{ $locomotora4300hp }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-8 text-center" style="background-color: #585858; color: white; border-top-left-radius: 10px;">
           
                          <i class="mt-4" style="font-size: 20px;">4400 HP <br> (1058 - 1059)</i>
                        
                      </div>
                        <div class="media-body col-sm-10">

                          <p class="text-center mt-3" style="font-size: 18px;">{{ $locomotora4400hp }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-8 text-center" style="background-color: #585858; color: white; border-top-left-radius: 10px;">
           
                          <i class="mt-3" style="font-size: 20px;">DF8BVEN <br> (0001 - 0012)</i>
                        
                      </div>
                        <div class="media-body col-sm-10">

                          <p class="text-center mt-3" style="font-size: 18px;">{{ $locomotoraDF8 }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">


                        
                        @if($porcentajedecumplimiento < 50)

                        <div class="col-md-6 text-center" style="background-color: #dc3545; color: white; border-top-left-radius: 10px;">
                        

                        @elseif($porcentajedecumplimiento > 84)

                        <div class="col-md-6 text-center" style="background-color: #28a745; color: white; border-top-left-radius: 10px;">

                        @elseif($porcentajedecumplimiento > 50 | $porcentajedecumplimiento < 85)

                        <div class="col-md-6 text-center" style="background-color: #ffc107; color: white; border-top-left-radius: 10px;">

                        @endif

                          <p class="mt-3"> <i class="" style="font-size: 20px;">Total</i></p>
                          
                        
                      </div>
                        <div class="media-body col-sm-10">

                          <p class="text-center mt-3" style="font-size: 18px;">{{ $totalconteo }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
      </div>

        <div class="card-body">

          <div class="row">
        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-detalle" data-toggle="tab">
                        <i class="fas fa-table" style="font-size: 15px;"></i>  Detalle
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-confiabilidad" data-toggle="tab">
                        <i class="far fa-handshake" style="font-size: 15px;"></i>  Confiabilidad
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-mantenibilidad" data-toggle="tab">
                        <i class="fas fa-hard-hat" style="font-size: 15px;"></i>  Mantenibilidad
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-graficas" data-toggle="tab">
                        <i class="fas fa-chart-bar" style="font-size: 15px;"></i> Gráficas
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div class="tab-content">

                <div class="tab-pane active" id="tab-detalle">
                <div class="card-body my-4">

          <div class="card-group">

          @if(!empty ($acumuladoHoraXLocomotoraXUbicacion ['Puerto Ordaz']))
          <div class="col-md-4">
        <div class="card">
                <div class="card-header card-header-warning">
                    <h6 class="card-title text-center" style="font-weight: bold;">Puerto Ordaz</h6>
                </div>
                <div class="card-body">
                  <table class="table table-hover table-bordered table-responsive table-small">
                  <thead>
                <tr>
                  <th class="col-2 text-center"style="font-size: 13px; font-weight: bold;">N° Loc</th>
                  <th class="col-3 text-center"style="font-size: 13px; font-weight: bold;">Horas Operativa</th>
                </tr>
              </thead>
              @foreach($acumuladoHoraXLocomotoraXUbicacion ['Puerto Ordaz'] as $ubicacionhora)
              <thead>
                <tr>
                  <td style="text-align: center; font-size: 12px;">{{$ubicacionhora -> numero}}</td>
                  <td style="text-align: center; font-size: 12px;">{{$ubicacionhora -> horasdisponibles}}</td>
                </tr>
              </thead>
              @endforeach      
              <th class="col-2 text-center" style="font-weight: bold;">Promedio</th>
              <th class="col-3 text-center" style="font-weight: bold;">{{$promediohorastotalpuertoordaz}}</th>   
              </table>
          </div>
        </div>
      </div>
              @endif   


      @if(!empty ($acumuladoHoraXLocomotoraXUbicacion ['Ciudad Piar']))
          <div class="col-md-4">
        <div class="card">
                <div class="card-header card-header-warning">
                    <h6 class="card-title text-center" style="font-weight: bold;">Ciudad Piar</h6>
                </div>
                <div class="card-body">
                  <table class="table table-hover table-bordered table-responsive table-small">
                  <thead>
                <tr>
                  <th class="col-2 text-center" style="font-size: 13px; font-weight: bold;">N° Loc</th>
                  <th class="col-3 text-center" style="font-size: 13px; font-weight: bold;">Horas Operativa</th>
                </tr>
              </thead>
              @foreach($acumuladoHoraXLocomotoraXUbicacion ['Ciudad Piar'] as $ubicacionhora)
              <thead>
                <tr>
                  <td style="text-align: center; font-size: 12px;">{{$ubicacionhora -> numero}}</td>
                  <td style="text-align: center; font-size: 12px;">{{$ubicacionhora -> horasdisponibles}}</td>
                </tr>
              </thead>
              @endforeach      
              <th class="col-2 text-center" style="font-weight: bold;">Promedio</th>
              <th class="col-3 text-center" style="font-weight: bold;">{{$promediohorastotalciudadpiar}}</th>  
              </table>
          </div>
        </div>
      </div>
              @endif  

      @if(!empty ($acumuladoHoraXLocomotora))
          <div class="col-md-4">
        <div class="card">
                <div class="card-header card-header-warning">
                    <h6 class="card-title text-center" style="font-weight: bold;">Puerto Ordaz - Ciudad Piar ( {{$locomotorasDisponibilidaddd->count()}} )</h6>
                </div>
                <div class="card-body">
                  <table class="table table-hover table-bordered table-responsive table-small">
                  <thead>
                <tr>
                  <th class="col-2 text-center" style="font-size: 13px; font-weight: bold;">N° Loc</th>
                  <th class="col-3 text-center" style="font-size: 13px; font-weight: bold;">Horas Operativa</th>
                  <th class="col-3 text-center" style="font-size: 13px; font-weight: bold;">Horas Paradas</th>
                </tr>
              </thead>
              @foreach($locomotorasDisponibilidaddd as $locomotora)
              <thead>
                <tr>
                  <td style="text-align: center; font-size: 12px;">{{$locomotora->numero}}</td>
                  <td style="text-align: center; font-size: 12px;">{{$locomotora -> horasdisponibles}}</td>
                  <td style="text-align: center; font-size: 12px;">{{$locomotora -> fueradeservicio}}</td>
                </tr>
              </thead>
              @endforeach      
              @endif 
              @if ($promediohorastotal != 0)  
              <th class="col-2 text-center" style="font-weight: bold;">Promedio</th>
              <th class="col-3 text-center" style="font-weight: bold;">{{$promediohorastotal}}</th> 
              <th class="col-3 text-center" style="font-weight: bold;">{{$restarfechas - $promediohorastotal}}</th>   
              @endif
              </table>
          </div>
        </div>
      </div>

      </div>
    </div>
  </div>

  <div class="tab-pane" id="tab-confiabilidad">
    <div class="col-12 text-center">
        <img class="mt-3 text-center" src="{{asset('/images/Confiabilidad.png')}}" height="300" width="600" alt="" style="border: solid; border-width: 0.8px; border-color: #585858; text-align: center;">
      </div>
      <div class="card-group col-md-12">


            @foreach($locomotorasDisponibilidaddd as $locomotora)

            <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-8 text-center" style="background-color: #585858; color: white; border-top-left-radius: 10px;">
                          <br>
                          <i class="mt-3" style="font-size: 20px;">{{$locomotora->numero}}</i>
                          <p class=""></p>

                      </div>
                        <div class="media-body col-sm-10">

                          <p class="text-center mt-3" style="font-size: 18px;">

                            @if(count($conteoReportes->where('locomotora_id', $locomotora->numero)) > 0)

                            {{round(pow(2.71828,-((($locomotora -> horasdisponibles + $locomotora -> fueradeservicio)/24)/(abs(($locomotora -> horasdisponibles -$locomotora -> fueradeservicio))/count($conteoReportes->where('locomotora_id', $locomotora->numero)))))*100,2)}}%

                            @else

                            N/A

                            @endif

                          </p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              @endforeach 

      </div>

    </div>


    <div class="tab-pane" id="tab-mantenibilidad">
    <div class="col-12 text-center">
        <img class="mt-3 text-center" src="{{asset('/images/Mantenibilidad.png')}}" height="300" width="600" alt="" style="border: solid; border-width: 0.8px; border-color: #585858; text-align: center;">
      </div>
      <div class="card-group col-md-12">


            @foreach($locomotorasDisponibilidaddd as $locomotora)

            <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-8 text-center" style="background-color: #585858; color: white; border-top-left-radius: 10px;">
                          <br>
                          <i class="mt-3" style="font-size: 20px;">{{$locomotora->numero}}</i>
                          <p class=""></p>

                      </div>
                        <div class="media-body col-sm-10">

                          <p class="text-center mt-3" style="font-size: 18px;">

                            @if(count($conteoReportes->where('locomotora_id', $locomotora->numero)) > 0)

                            {{round((1-pow(2.71828,-((($locomotora -> horasdisponibles + $locomotora -> fueradeservicio)/24)/($locomotora -> fueradeservicio/count($conteoReportes->where('locomotora_id', $locomotora->numero))))))*100,2)}}%

                            @else

                            N/A

                            @endif

                          </p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              @endforeach 

      </div>

    </div>



  <div class="tab-pane" id="tab-graficas">
      <div class="card-group col-md-12">

            

      <div id="container" class="container my-4" style="border: solid; border-width: 0.8px; border-color: black;">
  </div>


  <div id="containerdos" class="container my-4" style="border: solid; border-width: 0.8px; border-color: black;">
  </div>

      </div>

    </div>
  </div>
</div>



        </div>
  </div>

   <script src="{{ asset('highchart') }}/code/highcharts.js"></script>
   <script src="{{ asset('highchart') }}/code/highcharts-3d.js"></script>
   <script src="{{ asset('highchart') }}/code/highcharts-3d.src.js"></script>
    <script src="{{ asset('highchart') }}/code/modules/data.js"></script>
    <script src="{{ asset('highchart') }}/code/modules/exporting.js"></script>
     <script src="{{ asset('highchart') }}/code/modules/offline-exporting.js"></script>

    <table id="datatable" hidden="true">
        <thead>
            <tr>
                <th></th>
                <th class="col-3 text-center">Horas Operativa</th>
                <th class="col-3 text-center">Horas Paradas</th>
            </tr>
        </thead>
        <tbody>
           @foreach($locomotorasDisponibilidaddd as $locomotora)
            <tr>
                <td>{{$locomotora->numero}}</td>
                <td>{{$locomotora -> horasdisponibles}}</td>
                <td>{{$locomotora -> fueradeservicio}}</td>
            </tr>
            @endforeach 

        </tbody>
    </table>


    <table id="cp" hidden="true">
        <thead>
            <tr>
                <th></th>
                <th>Horas Operativa</th>

            </tr>
        </thead>
        <tbody>
          @if(!empty ($acumuladoHoraXLocomotoraXUbicacion ['Ciudad Piar']))
           @foreach($acumuladoHoraXLocomotoraXUbicacion ['Ciudad Piar'] as $ubicacionhora)
            <tr>
                <td>{{$ubicacionhora -> numero}}</td>
                <td>{{$ubicacionhora -> horasdisponibles}}</td>

            </tr>
            @endforeach 
            @endif
        </tbody>
    </table>



    <script type="text/javascript">
Highcharts.chart('container', {
    data: {
        table: 'datatable'
    },
    chart: {
        type: 'column'
    },

    credits:{
      enabled: false
    },

    title: {
        text: '<strong style = "color: black;">DISPONIBILIDAD POR LOCOMOTORA (HORAS)</strong>'
    },

    xAxis: {
        type: 'category',
        min: 0,
    },

    yAxis: {
        allowDecimals: false,
        title: {
            text: '<strong style = "color: black;">HORAS</strong>'
        }
    },

    colors:['#9B945F', '#d2091d'],


    plotOptions: {

        series: {
            colorByPoint: false,
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y: f}'
            }

        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                '<p>Loc </p>'+this.point.name.toLowerCase() + ' tiene' + ' ' +this.point.y +'<p> Horas</p>';
        }
    }
});
    </script>

        <script type="text/javascript">
Highcharts.chart('containerdos', {
    data: {
        table: 'cp'
    },
    chart: {
        type: 'column'
    },

    credits:{
      enabled: false
    },

    title: {
        text: '<strong style = "color: black;">DISPONIBILIDAD POR LOCOMOTORA (HORAS)</strong>'
    },

    xAxis: {
        type: 'category',
        min: 0,
    },

    yAxis: {
        allowDecimals: false,
        title: {
            text: '<strong style = "color: black;">HORAS</strong>'
        }
    },

    colors:['#9B945F', '#d2091d'],


    plotOptions: {

        series: {
            colorByPoint: false,
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y: f}'
            }

        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                '<p>Loc </p>'+this.point.name.toLowerCase() + ' tiene' + ' ' +this.point.y +'<p> Horas</p>';
        }
    }
});
    </script>


  </div>
  </div>
  </div>




@endsection
