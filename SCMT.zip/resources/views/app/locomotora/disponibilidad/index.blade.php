@extends('layouts.app', ['activePage' => 'disponibilidad', 'titlePage' => __('Disponibilidad de Locomotora')])

@section('content')
<div class="content">
	<div class="container-fluid">
		@include('app.comun.nav_dias', 	['url'=> 'locomotoras/disponibilidad/'])

	<br>
    <div class="row">
      	@foreach($turnos as $turno)
      	<?php $disponibilidadTurno = $locomotorasDisponibilidad->where('turno', $turno)->sortByDesc('ubicacion'); 
      		$notasTurno = $locomotorasDisponibilidadNotas->where('turno', $turno); 
      	?>

      		<div class="col-md-4">
	 			<div class="card">
		            <div class="card-header card-header-primary">
	              		<h4 class="card-title text-center">TURNO {{$turno}}
	              			&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                          @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))	
	              			<a rel="tooltip" title="Agregar"
			              	href="{{route('disponibilidad.create',['turno'=>$turno])}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
	        		      		<i class="material-icons">add</i>
		            	 	</a>
		            	  @endif
	              		</h4>
		            </div>
		            <div class="card-body">
	            		<div class="table-responsive">
                  			  <table id="myTable4"  class="cell-border compact stripe hover" style="width:100%">
                  				<thead class=" text-primary">
                    				<tr class="text-center">
					                    <th>N° Loc</th>
					                    <th>Tipo</th>
					                    <th>Ubicación</th>
					                    @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
					                    <th>Acción</th>
					                    @endif
                    				</tr>
                               </thead>
                               <tbody>

	            			@forelse($disponibilidadTurno as $disponible)
		            		<tr class="text-center">
		            	    <td><a href="{{route('consumo.show', $disponible->locomotora_id)}}" style="text-decoration:none">{{$disponible->locomotora->numero}}</a></td>
		            	    <td>{{$disponible->locomotora->tipo}}</td>
		            	    <td>{{$disponible->ubicacion}}</td>
		            	    @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
		            	    <td><form method="post" id="formDeleteDisponibilidad-{{$disponible->id}}" action="{{route('disponibilidad.destroy', [$disponible->id] ) }}">
	            	            @csrf
	            	            @method('delete')
	                          <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
                                    onclick="eliminarRegistro('formDeleteDisponibilidad-{{$disponible->id}}')" 
                                    ><i class="material-icons">delete</i></a>
		                        </form>
		                    </td>
		                    @endif
		                    </tr>    
		              	@empty
		              	@endforelse
		              	</tbody>
                       </table>
                           </div>
		              	<hr>
		              	<div class="row">
		              		<div class="col-md-8">Puerto Ordaz: </div>
		              		<div class="col-md-4">{{$disponibilidadTurno->where('ubicacion', 'Puerto Ordaz')->count()}}</div>
		           		</div>
		              	
		              	<div class="row">
		              		<div class="col-md-8">Ciudad Piar: </div>
		              		<div class="col-md-4">{{$disponibilidadTurno->where('ubicacion', 'Ciudad Piar')->count()}}</div>
		           		</div>

		           		<div class="row">
		              		<div class="col-md-8">Total: </div>
		              		<div class="col-md-4">{{$disponibilidadTurno->count()}}</div>
		           		</div>
		              	<hr>
		              	<div class="row col-12">

		              		<table>
		              			<tbody>
		              				
		              				<tr>
		              					
		              					<td style="font-weight: bold;">Notas:</td>
		              					@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
		              					<td><a rel="tooltip" class="btn btn-success btn-link" data-original-title="" title="Agregar Nota"
                      					href="{{route('nota.create')}}?area=locomotoras&turno={{$turno}}&fecha={{$fechas['fechaAListar']}}">
                    					<i class="material-icons">add</i>
                    					</a></td>
                    					@endif
		              				</tr>

		              			</tbody>

		              		</table>

			             </div>
			            <div class="row col-12">
				            @forelse ($notasTurno as $nota)
				            	<div class="col-md-7" style="text-transform: uppercase;"><li>{{$nota->nota}}</li></div>
				            	@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
				            	<div class="col-md-2">
									<a rel="tooltip" class="btn btn-success btn-link" href="{{route('nota.edit', [$nota->id])}}" data-original-title="" title="Editar"><i class="material-icons">edit</i></a>
				            	</div>
				            	@endif
				            	@if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
				            	<div class="col-md-2 text-center">
									<form method="post" id="formDeleteConsumo-{{$nota->id}}" 
										action="{{route('nota.destroy', [$nota->id] ) }}">
				                      @csrf
				                      @method('delete')
				                      <a rel="tooltip" class="btn btn-danger btn-link" title="Borrar"
				                        onclick="eliminarRegistro('formDeleteConsumo-{{$nota->id}}')" 
				                      ><i class="material-icons">delete</i></a>
				                    </form>

				            	</div>
				            	@endif
				            	<hr>
			              	@empty
			              	@endforelse
		              	</div>
		            </div>
		        </div>
      		</div>
      	@endforeach
    </div>
 

</div>
</div>

@endsection
