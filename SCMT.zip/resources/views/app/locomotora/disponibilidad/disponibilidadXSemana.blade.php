@extends('layouts.app', ['activePage' => 'disponibilidad', 'titlePage' => __('Disponibilidad de Locomotora')])
@section('content')

<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">

               <div class="card-header card-header-primary d-flex justify-content-between">
              <div class="col-md-6">
                <h4 class="card-title ">Disponibilidad de Locomotora</h4>
                <p class="card-category">Busqueda de Disponibilidad por rango de Fechas</p>
              </div>
            </div>
            <div class="card-body">
             <div class="row justify-content-center h-100">
           <form method="get" autocomplete="off" action="{{route('disponibilidadPorSemana')}}" class="form-horizontal">
            @include('app.comun.nav_calendario_busqueda')
           </form>            
           </div>



           <div class="card-header card-header-tabs card-header-warning mt-4">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-detalle" data-toggle="tab">
                        <i class="fas fa-bars" style="font-size: 15px;"></i> Detalle
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-promediosemana" data-toggle="tab">
                        <i class="fas fa-calendar-alt" style="font-size: 15px;"></i> Promedio Semana
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-promediodias" data-toggle="tab">
                        <i class="fas fa-calendar-minus" style="font-size: 15px;"></i> Promedio Días
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

          <div class="tab-content">

                <div class="tab-pane active" id="tab-detalle">

           @forelse($disponibilidadXSemana as $semanaNumero => $semana)
           <div class="card-header card-header-primary d-flex justify-content-between mt-3">
              <div class="col-md-12">
                <h4 class="card-title text-center ">SEMANA {{$semanaNumero}}</h4>
              </div>
            </div>



           @php $semanaActual = $semana->groupBy('day'); @endphp

           @forelse($semanaActual as $diasemana)

           <div class="card-group">

            <div class="card-header card-header-primary d-flex justify-content-between col-1 mt-2">
              <div class="card-title text-center col-md-16">
                <h4 style="rotate: -90deg; left: -15px; top: 230px; position: relative; text-transform: uppercase;">
                  {{\Carbon\Carbon::parse($diasemana[0]['fecha'])->isoFormat('dddd DD/MM/YY')}}
                </h4>
              </div>
            </div>


        <div class="card">
                
                <div class="card-header card-header-warning">
                    <h4 class="card-title text-center">TURNO I 
                    </h4>

                </div>
                <div class="card-body">

                    <div class="table-responsive">
                          <table id="myTable4"  class="cell-border compact stripe hover" style="width:100%">
                          <thead class=" text-primary">
                            <tr class="text-center">
                               <th class="text-center">N°Loc</th>
                               <th class="text-center">Tipo</th>
                               <th class="text-center">Modelo</th>
                               <th class="text-center">Ubic.</th>
                            </tr>
                               </thead>
                    
                    @forelse($diasemana->where('turno', '=', 'I') as $disponibilidad)
                    <tbody>
                    <tr class="text-center">
                      <td class="text-center">{{$disponibilidad->locomotora->numero}}</td>
                      <td class="text-center">{{$disponibilidad->locomotora->tipo}}</td>
                      <td class="text-center">{{$disponibilidad->locomotora->modelo}}</td>
                      <td class="text-center">{{$disponibilidad->ubicacion}}</td>
                    </tr> 
                    </tbody>
                    @empty
                    @endforelse
                       </table>
                           </div>
                    <hr>
                    <div class="row">
        
             
                      <div class="col-md-8">Puerto Ordaz: </div>

                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'I')->where('ubicacion', '=', 'Puerto Ordaz')->count()}}</div>
                  </div>
                    
                    <div class="row">
                      <div class="col-md-8">Ciudad Piar: </div>
                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'I')->where('ubicacion', '=', 'Ciudad Piar')->count()}}</div>
                  </div>

                  <div class="row">
                      <div class="col-md-8">Total: </div>
                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'I')->count()}}</div>
                  </div>
                    <hr>
                   
                </div>
            </div>

            <div class="card">
                
                <div class="card-header card-header-warning">
                    <h4 class="card-title text-center">TURNO II 
                    </h4>

                </div>
                <div class="card-body">

                    <div class="table-responsive">
                          <table id="myTable4"  class="cell-border compact stripe hover" style="width:100%">
                          <thead class=" text-primary">
                            <tr class="text-center">
                               <th class="text-center">N°Loc</th>
                               <th class="text-center">Tipo</th>
                               <th class="text-center">Modelo</th>
                               <th class="text-center">Ubic.</th>
                            </tr>
                               </thead>
                    
                    @forelse($diasemana->where('turno', '=', 'II') as $disponibilidad)
                    <tbody>
                    <tr class="text-center">
                      <td class="text-center">{{$disponibilidad->locomotora->numero}}</td>
                      <td class="text-center">{{$disponibilidad->locomotora->tipo}}</td>
                      <td class="text-center">{{$disponibilidad->locomotora->modelo}}</td>
                      <td class="text-center">{{$disponibilidad->ubicacion}}</td>
                    </tr> 
                    </tbody>
                    @empty
                    @endforelse
                       </table>
                           </div>
                    <hr>
                    <div class="row">
                      <div class="col-md-8">Puerto Ordaz: </div>

                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'II')->where('ubicacion', '=', 'Puerto Ordaz')->count()}}</div>
                  </div>
                    
                    <div class="row">
                      <div class="col-md-8">Ciudad Piar: </div>
                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'II')->where('ubicacion', '=', 'Ciudad Piar')->count()}}</div>
                  </div>

                  <div class="row">
                      <div class="col-md-8">Total: </div>
                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'II')->count()}}</div>
                  </div>
                    <hr>
                   
                </div>
            </div>


             <div class="card">
                
                <div class="card-header card-header-warning">
                    <h4 class="card-title text-center">TURNO III 
                    </h4>

                </div>
                <div class="card-body">

                    <div class="table-responsive">
                          <table id="myTable4"  class="cell-border compact stripe hover" style="width:100%">
                          <thead class=" text-primary">
                            <tr class="text-center">
                               <th class="text-center">N°Loc</th>
                               <th class="text-center">Tipo</th>
                               <th class="text-center">Modelo</th>
                               <th class="text-center">Ubic.</th>
                            </tr>
                               </thead>
                    
                    @forelse($diasemana->where('turno', '=', 'III') as $disponibilidad)
                    <tbody>
                    <tr class="text-center">
                      <td class="text-center">{{$disponibilidad->locomotora->numero}}</td>
                      <td class="text-center">{{$disponibilidad->locomotora->tipo}}</td>
                      <td class="text-center">{{$disponibilidad->locomotora->modelo}}</td>
                      <td class="text-center">{{$disponibilidad->ubicacion}}</td>
                    </tr> 
                    </tbody>
                    @empty
                    @endforelse
                       </table>
                           </div>
                    <hr>
                    <div class="row">
                      <div class="col-md-8">Puerto Ordaz: </div>

                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'III')->where('ubicacion', '=', 'Puerto Ordaz')->count()}}</div>
                  </div>
                    
                    <div class="row">
                      <div class="col-md-8">Ciudad Piar: </div>
                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'III')->where('ubicacion', '=', 'Ciudad Piar')->count()}}</div>
                  </div>

                  <div class="row">
                      <div class="col-md-8">Total: </div>
                      <div class="col-md-4">{{$diasemana->where('turno', '=', 'III')->count()}}</div>
                  </div>
                    <hr>
                   
                </div>
            </div>
          </div>

           

          @empty
          @endforelse





          @empty
          @endforelse

        </div>

        <div class="tab-pane" id="tab-promediosemana">

          <div class="card-group" align="center">

            @forelse($disponibilidadXSemana as $semanaNumero => $semana)
            @php $semanaActual = $semana->groupBy('day'); @endphp
              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-6" style="background-color: #585858; color: white; width: 20px;border-top-left-radius: 10px;">
                          <div class="mt-2">
                          <i class="" style="font-size: 18px;">SEM #{{$semanaNumero}}</i>
                        </div>
                      </div>
                        <div class="media-body col-sm-10">
                          <p class="text-center" style="min-height: 27px; max-height: 35px; font-size: 15px;">PZO: {{round((($semana->where('ubicacion', '=', 'Puerto Ordaz')->count())/3)/7)}}
                            <br>
                            CP: {{round((($semana->where('ubicacion', '=', 'Ciudad Piar')->count())/3)/7)}}

                          </p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

               @empty
               @endforelse
            </div>

        </div>

        <div class="tab-pane" id="tab-promediodias">


            @forelse($disponibilidadXSemana as $semanaNumero => $semana)

                <div class="card-header card-header-primary d-flex justify-content-between mt-3 row">
                <div class="col-md-6">
                <h5 class="card-title">DISPONIBILIDAD PROMEDIO DE LA SEMANA #{{$semanaNumero}}</h5>
                </div>
                <div class="col-md-2" style="text-align: right;">
                 <a class="badge badge-danger text-center" style="color: white;"><h4><strong>PZO: {{round((($semana->where('ubicacion', '=', 'Puerto Ordaz')->count())/3)/7)}}</strong></h4></a>
                 <a class="badge badge-danger text-center" style="color: white;"><h4><strong>CP: {{round((($semana->where('ubicacion', '=', 'Ciudad Piar')->count())/3)/7)}}</strong></h4></a>
                 </div>
                 </div>
            


            @php $semanaActual = $semana->groupBy('day'); @endphp
          <div class="card-group" align="center">
             @forelse($semanaActual as $diasemana)
              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-6" style="background-color: #585858; color: white; width: 20px; border-top-left-radius: 10px;">
                          <div class="mt-1">
                          <i class="" style="font-size: 13px; text-transform: uppercase;">{{\Carbon\Carbon::parse($diasemana[0]['fecha'])->isoFormat('dddd DD/MM/YY')}}</i>
                           
                        </div>
                      </div>
                        <div class="media-body col-sm-10">
                          <p class="text-center" style="min-height: 27px; max-height: 40px; font-size: 15px;">PZO: {{round($diasemana->where('ubicacion', '=', 'Puerto Ordaz')->count()/3)}} <br> CP: {{round($diasemana->where('ubicacion', '=', 'Ciudad Piar')->count()/3)}}

                          </p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
              @empty
                  @endforelse
            </div>

               @empty
               @endforelse

        </div>

      </div>



            </div>
          </div>
      </div>
    </div>
  </div>
</div>

@endsection

