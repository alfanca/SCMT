@extends('layouts.app', ['activePage' => 'disponibilidad', 'titlePage' => __('Registrar disponibilidad de locomotoras')])

@section('content')

<style type="text/css">
  
   /* The switch - the box around the slider */
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-image: linear-gradient(-5deg, #6a1816, #d2091d);
}

input:focus + .slider {
  box-shadow: 0 0 1px black;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
} 

</style>

  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header card-header-primary text-center">
                <h4 class="card-title">{{ __('Disponibilidad de Locomotora (Puerto Ordaz - Ciudad Piar)') }}</h4>
              </div>
        <form method="post" action="{{ route('disponibilidad.store') }}" autocomplete="off" class="form-horizontal">
            @csrf
            <div class="card-body mb-4">
                <div class="row" align="center">
                    <div class="col-md-6" align="center">
                        <label class="label-control">FECHA</label>
                        <div class="col-sm-4">
                          @if(Gate::check('isplanificador') || Gate::check('isJefe'))  
                            <input type="date" name="fecha" class="form-control" 
                            value="<?php echo date("Y-m-d");?>" required="true"/ style="text-align: center;">
                            @endif
                            @can('isanalistam')
                            <input type="date" name="fecha" class="form-control" 
                            min = "<?php echo date("Y-m-d",strtotime(date("Y-m-d")."- 1 days"));?>" 
                            max = "<?php echo date("Y-m-d",strtotime(date("Y-m-d")."+ 0 days"));?>" 
                            value="<?php echo date("Y-m-d");?>" required="true"/ style="text-align: center;">
                            @endcan
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="label-control">TURNO</label>
                        <br>
                        <input class="col-md-1 text-center form-control{{ $errors->has('turno') ? ' is-invalid' : '' }}" type="text" name="turno" value="{{$_GET['turno']}}" readonly="" required="true">
                    </div>

                </div>
            </div>

          <div class="col-md-12">
              


                <table class="table table-striped col-md-12" id="myTable">
                  <thead class="">
                    <th class="text-center col-md-4" style="font-size: 20px; background-color: #9B945F; color: white;">N° Locomotora</th>
                    <th class="text-center col-md-3" style="font-size: 20px; background-color: #9B945F; color: white;">Puerto Ordaz</th>
                    <th class="text-center col-md-3" style="font-size: 20px; background-color: #9B945F; color: white;">Ciudad Piar</th>
                    </thead>
                  @foreach ($locomotoras as $locomotora)
                  <tr>
                    <td class="text-center col-md-4"><a class="badge badge-primary text-center" style="color: white; font-size: 25px;"><strong>{{$locomotora->numero}}</strong></a></td>
                    <td class="text-center col-md-3">
                      <label class="switch">
                      <input type="checkbox" type="checkbox" id="pzo{{$locomotora->numero}}" name="pzo[]" value="{{$locomotora->id}}">
                      <span class="slider round"></span>
                      </label></td>  


                      <td class="text-center col-md-3">
                      <label class="switch">
                      <input type="checkbox" id="pc{{$locomotora->numero}}" name="cp[]" value="{{$locomotora->id}}">
                      <span class="slider round"></span>
                      </label></td>            
                  </tr>
                  @endforeach
                  </table>

            </div>  

        
            <div class="card-footer justify-content-center">
              <a href="{{route('disponibilidad.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

    <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: '',

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Locomotoras)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>
@endsection

