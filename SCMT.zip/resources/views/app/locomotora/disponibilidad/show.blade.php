@extends('layouts.app', ['activePage' => 'disponibilidad', 'titlePage' => __('Disponibilidad')])

@section('content')
<div class="content">
	<div class="container-fluid">
		@include('app.comun.nav_dias', 	['url'=> 'locomotoras/disponibilidad/'])
		
	    <div class="card-body">
   	    <div class="row">
		<div class="col-md-3" style="font-weight: normal;">Promedio Puerto Ordaz: </div>
		<div class="row" style="font-weight: normal;">{{round($locomotorasDisponibilidad->where('ubicacion', 'Puerto Ordaz')->count()/3)}}</div>
		</div>

    	<div class="row">
		<div class="col-md-3" style="font-weight: normal;">Promedio Ciudad Piar: </div>
		<div class="row" style="font-weight: normal;">{{round($locomotorasDisponibilidad->where('ubicacion', 'Ciudad Piar')->count()/3)}}</div>
		</div>
		</div>

    <div class="row">
      	@foreach($turnos as $turno)
      	<?php $disponibilidadTurno = $locomotorasDisponibilidad->where('turno', $turno)->sortByDesc('ubicacion'); 
     		$notasTurno = $locomotorasDisponibilidadNotas->where('turno', $turno); 
      	?>

      		<div class="col-md-4">
	 			<div class="card">
		            <div class="card-header card-header-primary">
	              		<h4 class="card-title text-center">TURNO {{$turno}}</h4>
		            </div>
		            <div class="card-body">

		            	<div class="table-responsive">
                  			  <table id="myTable4"  class="cell-border compact stripe hover" style="width:100%">
                  				<thead class=" text-primary">
                    				<tr class="text-center">
					                    <th>N° Loc</th>
					                    <th>Tipo</th>
					                    <th>Ubicación</th>
                    				</tr>
                               </thead>
                               <tbody>

	            			@forelse($disponibilidadTurno as $disponible)
		            		<tr class="text-center">
		            	    <td>{{$disponible->locomotora->numero}}</td>
		            	    <td>{{$disponible->locomotora->tipo}}</td>
		            	    <td>{{$disponible->ubicacion}}</td>
		                    </tr>    
		              	@empty
		              	@endforelse
		              	</tbody>
                       </table>
                           </div>
		              	<hr>
		              	<div class="row">
		              		<div class="col-md-8">Puerto Ordaz: </div>
		              		<div class="col-md-4">{{$disponibilidadTurno->where('ubicacion', 'Puerto Ordaz')->count()}}</div>
		           		</div>
		              	
		              	<div class="row">
		              		<div class="col-md-8">Ciudad Piar: </div>
		              		<div class="col-md-4">{{$disponibilidadTurno->where('ubicacion', 'Ciudad Piar')->count()}}</div>
		           		</div>

		           			<div class="row">
		              		<div class="col-md-8">Total: </div>
		              		<div class="col-md-4">{{$disponibilidadTurno->count()}}</div>
		           		</div>
		              	<hr>
			            <div class="row col-12">
				            @forelse ($notasTurno as $nota)
				            	<div class="col-md-12" style="text-transform: uppercase;"><li>{{$nota->nota}}</li></div>
				            	<hr>
			              	@empty
			              	@endforelse
		              	</div>
		            </div>
		        </div>
      		</div>
      	@endforeach
    </div>
  </div>
</div>

@endsection
