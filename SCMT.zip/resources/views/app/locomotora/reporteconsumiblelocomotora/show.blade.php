@extends('layouts.app', ['activePage' => 'locomotoras', 'titlePage' => __('Locomotoras')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Reporteconsumiblelocomotora</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('reporteconsumiblelocomotoras.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Reportelocomotora Id:</strong>
                            {{ $reporteconsumiblelocomotora->reportelocomotora_id }}
                        </div>
                        <div class="form-group">
                            <strong>Materiales Id:</strong>
                            {{ $reporteconsumiblelocomotora->materiales_id }}
                        </div>
                        <div class="form-group">
                            <strong>Fecha:</strong>
                            {{ $reporteconsumiblelocomotora->fecha }}
                        </div>
                        <div class="form-group">
                            <strong>Locomotora:</strong>
                            {{ $reporteconsumiblelocomotora->locomotora }}
                        </div>
                        <div class="form-group">
                            <strong>Cantidad:</strong>
                            {{ $reporteconsumiblelocomotora->cantidad }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Crea:</strong>
                            {{ $reporteconsumiblelocomotora->usuario_crea }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Actualiza:</strong>
                            {{ $reporteconsumiblelocomotora->usuario_actualiza }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
