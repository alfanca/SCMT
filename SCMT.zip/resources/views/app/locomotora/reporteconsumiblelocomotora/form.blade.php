<div class="box box-info padding-1">
    <div class="box-body">
        

            <input type="text" name="reportelocomotora_id" value="{{$_GET['id']}}" style="visibility: hidden;">

            @if ($_GET['loc'] === 'S/N')
            <div class="card-group">
            {{ Form::label('N° Locomotora:')}}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('locomotora', $locomotoras,$reporteconsumiblelocomotora->locomotora, ['class' => 'form-control col-1 text-center' . ($errors->has('locomotora') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp
           </div>
            @else

            <input type="text" name="locomotora" value="{{$_GET['loc']}}" style="visibility: hidden;">

            @endif


             <div class="card-group mt-4">
            {{ Form::label('Fecha:') }} &nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha', $reporteconsumiblelocomotora->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}

            &nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Cantidad:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('cantidad', $reporteconsumiblelocomotora->cantidad, ['class' => 'form-control col-5' . ($errors->has('cantidad') ? ' is-invalid' : ''), 'min'=>'1','placeholder' => 'Ingrese']) }}
            {!! $errors->first('cantidad', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <br>
        <br>

       <div class="table-responsive">
                <table class="table" id="myTable" style="width:100%">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center col-1">Seleccionar</th>
                        <th hidden="yes"></th>
                        <th class="text-center col-1">N° Parte</th>
                        <th class="text-center col-1">N° SAP</th>
                        <th class="text-center col-1">Modelo</th>
                        <th class="text-center col-6">Descripción</th>
                        <th class="text-center col-1">Unid</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($materialeslocomotoras as $materiales)
                                        <tr>
                      <td class="text-center"> <input type="radio" name="materiales_id" value="{{$materiales->id}}"></td>
                      <td hidden="yes"></td>                 
                      <td class="text-center">{{$materiales->parte}}</td>
                      <td class="text-center">{{$materiales->sap}}</td>
                      <td class="text-center">{{$materiales->modelo}}</td>
                      <td style="text-transform: uppercase;">{{$materiales->descripcion}}</td>
                      <td class="text-center">{{$materiales->unidad}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>


               <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {


        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Materiales)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>

       

    </div>
   <div class="box-footer mt20 mt-4 text-center">
        <a href="/locomotoras/reportedelocomotoras/{{$_GET['id']}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
        <button type="submit" class="btn btn-primary">Crear</button>
    </div>
</div>