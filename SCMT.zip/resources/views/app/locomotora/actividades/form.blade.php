<div class="row">
  <label class="col-md-2 col-form-label">{{ __('LOCOMOTORA') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('locomotora') ? ' has-danger' : '' }}">
      <select class="custom-select form-control{{ $errors->has('locomotora') ? ' is-invalid' : '' }}" name="locomotora_id" id="input-locomotora_id" placeholder="{{ __('Ingrese locomotora') }}" required="true">
        <option value="">SELECCIONE</option>
        @foreach ($locomotoras as $locomotora)
          <option value="{{$locomotora->id}}" {{$actividad->locomotora_id == $locomotora->id ? 'selected' : '' }}>{{$locomotora->numero}}</option>
        @endforeach
      </select>
      @if ($errors->has('locomotora'))
        <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('locomotora') }}</span>
      @endif
    </div>
  </div>

  <label class="col-md-2 col-form-label">{{ __('DISPONBLE?') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">
      <select class="custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }}" name="estatus" id="input-estatus" placeholder="{{ __('Locomotora esta disponible?') }}" required="true">
          <option value="">SELECCIONE</option>
          <option value="true"  {{$actividad->estatus == 'Disponible' ? 'selected' : ''  }}>Disponible</option>
          <option value="false" {{$actividad->estatus == 'No disponible' ? 'selected' : '' }}>No Disponible</option>
      </select>
      @if ($errors->has('estatus'))
        <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
      @endif
    </div>
  </div>
</div>

<div class="row">
  <label class="col-md-2 col-form-label">{{ __('FECHA') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('fecha') ? ' has-danger' : '' }}">
    <input type="date" name="fecha" class="form-control" style="width:30%" value="{{ old('fecha') ?? $actividad->fecha }}"/>
    @if ($errors->has('fecha'))
      <span id="name-error" class="error text-danger" for="input-fecha">{{ $errors->first('fecha') }}</span>
    @endif

    </div>
  </div>

  <label class="col-md-2 col-form-label">{{ __('TURNO') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('turno') ? ' has-danger' : '' }}">

      <select class="custom-select form-control{{ $errors->has('turno') ? ' is-invalid' : '' }}" name="turno" id="input-turno"
        placeholder="{{ __('Ingrese el turno') }}" required="true">
        <option value="">SELECCIONE</option>
        @foreach($turnos as $turno)
         <option value="{{$turno}}" {{$actividad->turno == $turno ? 'selected' : '' }}>{{$turno}}</option>
        @endforeach
      </select>
    @if ($errors->has('turno'))
      <span id="name-error" class="error text-danger" for="input-turno">{{ $errors->first('turno') }}</span>
    @endif

    </div>
  </div>
</div>

<div class="row">
  <label class="col-md-2 col-form-label">{{ __('ACTIVIDAD') }}</label>
  <div class="col-md-10">
    <div class="form-group{{ $errors->has('actividad') ? ' has-danger' : '' }}">
    <textarea class="form-control" name="actividad" id="actividad" col="80" rows="5">{{ old('actividad') ?? $actividad->actividad }}</textarea> 
    @if ($errors->has('actividad'))
      <span id="name-error" class="error text-danger" for="input-actividad">{{ $errors->first('actividad') }}</span>
    @endif
    </div>
  </div>
</div>

<div class="row">
  <label class="col-md-2 col-form-label">{{ __('RESPONSABLE') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
    <select name="responsable" class="responsable" style="width: 100%">
      @if (!empty($actividad->datos->nombre))
        <option value="{{$actividad->responsable}}">{{ $actividad->datos->nombre}}</option>
      @endif
    </select>
    @if ($errors->has('responsable'))
      <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
    @endif

    </div>
  </div>

  <label class="col-md-2 col-form-label">{{ __('DURACIÓN') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('tiempo') ? ' has-danger' : '' }}">
      <input type="number" max="8" min="0" name="tiempo" id="tiempo" value="{{ old('tiempo') ?? $actividad->tiempo }}">

    @if ($errors->has('tiempo'))
      <span id="name-error" class="error text-danger" for="input-tiempo">{{ $errors->first('tiempo') }}</span>
    @endif

    </div>
  </div>
    <label class="col-md-2 col-form-label">{{ __('ORDEN') }}</label>
      <div class="col-md-4 form-group{{ $errors->has('orden') ? ' has-danger' : '' }}">
    <input type="number" name="orden"
      value="{{ old('orden') ?? $actividad->orden }}"/>
    @if ($errors->has('orden'))
      <span id="name-error" class="error text-danger" for="input-orden">{{ $errors->first('orden') }}</span>
    @endif

    </div>
</div>
  <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
  <script src="{{ asset('material') }}/js/plugins/moment.min.js"></script>
  <script src="{{ asset('material') }}/js/plugins/bootstrap-datetimepicker.min.js"></script>

  <script type="text/javascript">
$('.datetimepicker').datetimepicker({
    icons: {
        time: "fa fa-clock-o",
        date: "fa fa-calendar",
        up: "fa fa-chevron-up",
        down: "fa fa-chevron-down",
        previous: 'fa fa-chevron-left',
        next: 'fa fa-chevron-right',
        today: 'fa fa-screenshot',
        clear: 'fa fa-trash',
        close: 'fa fa-remove'
    },
    format: 'DD-MM-YYYY',
    maxDate : 'now',
    defaultDate: new Date(),
    useCurrent: true 
});
  </script>
