@extends('layouts.app', ['activePage' => 'actividades', 'titlePage' => __('Actividades')])

@section('content')
<div class="content">
	<div class="container-fluid">
		@include('app.comun.nav_dias', 	['url'=> 'locomotoras/actividades/'])
			
      	@foreach($listadoActividades as $turno => $actividades)
    	<div class="row">
      		<div class="col-md-12">
	 			<div class="card">
		            <div class="card-header card-header-primary">
		              <h4 class="card-title text-center">TURNO {{$turno}}</h4>
		            </div>
		            <div class="card-body">
		            	<?php $actividadPorTurno = $actividades->where('turno', $turno)->sortBy('locomotora_id'); ?>
		            	<div class="row">
		            		<table class="table table-hover table-bordered table-responsive table-small">
		            			<thead>
		            				<tr>
		            					<th class="col-1 text-center">Locomotora</th>
		            					<th class="col-5 text-center">Descripción del Servicio</th>
		            					<th class="col-1 text-center">Orden</th>
		            					<th class="text-center">Responsable</th>
		            					<th class="text-center">Tiempo de ejecución</th>
		            					<th class="text-center">Estatus</th>
		            					@if(Gate::check('isplanificador') || Gate::check('isJefe'))
										<th class="text-center">Analista</th>
		            					@endif			            					
		            				</tr>
		            			</thead>
		            	@forelse($actividadPorTurno as $actividad)
		            		<tbody>
			            		<tr>
				                	<td class="text-center">{{$actividad->locomotora->numero}}</td>
				                	<td class="text-justify"style="text-transform: uppercase;">{{$actividad->actividad}}</td>
				                	<td class="text-center">{{$actividad->orden}}</td>
				                	<td class="text-center">{{$actividad->datos->nombre}}</td>
				                	<td class="text-center">{{$actividad->tiempo}} horas</td>
				                	<td class="text-center">{{$actividad->estatus}}</td>
	            					@if(Gate::check('isplanificador') || Gate::check('isJefe'))
										<td class="text-center">
											{{$actividad->usuario_crea}} / 
											{{\Carbon\Carbon::parse($actividad->created_at)->format('d-m H:i')}}
										</td>
	            					@endif					                	
				              		</tr>
			              	</tbody>		            	
		            	@empty
		            	@endforelse
		            	</table>
		            </div>
		        </div>
      		</div>
    	</div>
  </div>
      	@endforeach
</div>
</div>
@endsection