@extends('layouts.app', ['activePage' => 'locomotoras', 'titlePage' => __('Locomotoras')])
@section('content')

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Reporteactividadlocomotora</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('reporteactividadlocomotora.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Reportelocomotora Id:</strong>
                            {{ $reporteactividadlocomotora->reportelocomotora_id }}
                        </div>
                        <div class="form-group">
                            <strong>Locomotora:</strong>
                            {{ $reporteactividadlocomotora->locomotora }}
                        </div>
                        <div class="form-group">
                            <strong>Fecha:</strong>
                            {{ $reporteactividadlocomotora->fecha }}
                        </div>
                        <div class="form-group">
                            <strong>Turno:</strong>
                            {{ $reporteactividadlocomotora->turno }}
                        </div>
                        <div class="form-group">
                            <strong>Area:</strong>
                            {{ $reporteactividadlocomotora->area }}
                        </div>
                        <div class="form-group">
                            <strong>Falla:</strong>
                            {{ $reporteactividadlocomotora->falla }}
                        </div>
                        <div class="form-group">
                            <strong>Fallamotivo:</strong>
                            {{ $reporteactividadlocomotora->fallamotivo }}
                        </div>
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            {{ $reporteactividadlocomotora->descripcion }}
                        </div>
                        <div class="form-group">
                            <strong>Estatus:</strong>
                            {{ $reporteactividadlocomotora->estatus }}
                        </div>
                        <div class="form-group">
                            <strong>Responsable:</strong>
                            {{ $reporteactividadlocomotora->responsable }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Crea:</strong>
                            {{ $reporteactividadlocomotora->usuario_crea }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Actualiza:</strong>
                            {{ $reporteactividadlocomotora->usuario_actualiza }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
