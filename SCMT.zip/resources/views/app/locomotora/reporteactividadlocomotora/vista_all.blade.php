@extends('layouts.app', ['activePage' => 'reportelocomotora', 'titlePage' => __('Historial de Actividades de Locomotora')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Historial de Actividades de Locomotoras</h4>
                        <p class="card-category">Busqueda de Actividades de Locomotora</p>
                      </div>
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{route('reportedelocomotoras.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i> Regresar
                        </a>  
                      </div>
                    </div>

            <div class="card-body">
             <div class="card-body">

           <form method="get" autocomplete="off" action="{{route('periodo.reporte.actividad')}}" class="form-horizontal" role="form">
            @include('app.comun.nav_calendario_busqueda_sinboton_reporte')
           </form>

          
           </div>
             <div class="card-body">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-striped table-hover">
                                <thead class="thead">    
                                        <th class="text-center col-1">N° Orden ó Aviso</th>
                                        <th class="text-center col-1">N° Loc</th>
                                        <th class="text-center col-1">Fecha</th>
                                        <th class="text-center col-1">Turno</th>
                                        <th class="text-center col-1">Area</th>
                                        <th class="text-center col-1">Falla</th>
                                        <th class="text-center col-1">Motivo</th>
                                        <th class="text-center col-6">Descripcion</th>
                                        <th class="text-center col-1">¿Disponible?</th>
                                        <th class="text-center col-1">Responsable</th>
                                        @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                        <th class="col-md-1 text-center">Usuario Crea</th>
                                        <th class="col-md-1 text-center">Usuario Actualiza</th>
                                        @endif
                                </tr>
                                </thead>
                                <tbody>
                                    @foreach ($reporte_all as $reporteactividadlocomotora)
                                        <tr>           
                                            <td class="text-center">{{ $reporteactividadlocomotora->reportedelocomotora->n_orden }}</td>
                                            <td class="text-center">{{ $reporteactividadlocomotora->locomotora }}</td>
                                            <td class="text-center">{{ $reporteactividadlocomotora->fecha }}</td>
                                            <td class="text-center">{{ $reporteactividadlocomotora::TURNO[$reporteactividadlocomotora->turno]}}</td>
                                            <td class="text-center">{{ $reporteactividadlocomotora::AREA[$reporteactividadlocomotora->area] }}</td>
                                            <td class="text-center">{{ $reporteactividadlocomotora::FALLA[$reporteactividadlocomotora->falla] }}</td>
                                            <td class="text-center">{{ $reporteactividadlocomotora::FALLAMOTIVO[$reporteactividadlocomotora->fallamotivo] }}</td>
                                            <td style="text-transform: uppercase;">{{ $reporteactividadlocomotora->descripcion }}</td>
                                            <td class="text-center">{{ $reporteactividadlocomotora::ESTATUS[$reporteactividadlocomotora->estatus] }}</td>
                                            <td class="text-center">{{ $reporteactividadlocomotora->datos->nombre }}</td>
                                            @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                            <td class="text-center" style="text-transform: uppercase;">{{$reporteactividadlocomotora->usuario_crea}}</td>
                                            <td class="text-center" style="text-transform: uppercase;">{{$reporteactividadlocomotora->usuario_actualiza}}</td>
                                            @endif
                                 </tr>
                                  @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Componentes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


@endsection
