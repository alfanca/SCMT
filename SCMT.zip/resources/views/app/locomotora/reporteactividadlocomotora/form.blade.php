<div class="box box-info padding-1">
    <div class="box-body">
        


        <div class="card-group col-12">

        
        


            @if ($_GET['loc'] === 'S/N')
            <div class="row">
            {{ Form::label('N° Locomotora:')}}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('locomotora', $locomotoras,$reporteactividadlocomotora->locomotora, ['class' => 'form-control col-5 text-center' . ($errors->has('locomotora') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp
            </div>
        @else
        <input type="text" name="locomotora" value="{{$_GET['loc']}}" style="visibility: hidden;">
        @endif

        <input type="text" name="reportelocomotora_id" value="{{$_GET['id_r']}}" style="visibility: hidden;">
        </div>


        <div class="card-group">

            {{ Form::label('Fecha/Hora') }}&nbsp&nbsp&nbsp&nbsp
            <input type="datetime" name="fecha" value="{{old('fecha') ?? \Carbon\Carbon::parse($reporteactividadlocomotora->fecha)->format('d/m/Y H:i') ?? \Carbon\Carbon::now()->format('d/m/Y H:i')}}" class="form-control col-8 ($errors->has('fecha') ? ' is-invalid' : '')">
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</div>') !!}

            {{ Form::label('Turno:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('turno', $turno,$reporteactividadlocomotora->turno, ['class' => 'form-control col-1 text-center' . ($errors->has('turno') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('turno', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Area:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('area', $area,$reporteactividadlocomotora->area, ['class' => 'form-control col-2 text-center' . ($errors->has('area') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('area', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Falla:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('falla', $falla,$reporteactividadlocomotora->falla, ['class' => 'form-control col-2 text-center' . ($errors->has('falla') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('falla', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp

        </div>
        <div class="card-group mt-4">
            {{ Form::label('Motivo:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::select('fallamotivo', $fallamotivo,$reporteactividadlocomotora->fallamotivo, ['class' => 'form-control col-2 text-center' . ($errors->has('fallamotivo') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('fallamotivo', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp
        </div>
        <br>
        <br>
        <div class="form-group">
            <br>
            {{ Form::label('descripcion') }}
            {{ Form::textarea('descripcion', $reporteactividadlocomotora->descripcion, ['class' => 'form-control' . ($errors->has('descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese texto']) }}
            {!! $errors->first('descripcion', '<div class="invalid-feedback">:message</p>') !!}
        </div>
        <br>
        <br>
        <div class="card-group">
            {{ Form::label('¿Disponible?') }}
            {{ Form::select('estatus', $estatus,$reporteactividadlocomotora->estatus, ['class' => 'form-control col-1 text-center' . ($errors->has('estatus') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('estatus', '<div class="invalid-feedback">:message</p>') !!}&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('Horas:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('horas', $reporteactividadlocomotora->horas, ['class' => 'form-control col-8 text-center' . ($errors->has('horas') ? ' is-invalid' : ''), 'min' => '0', 'max' => '8','placeholder' => 'N° horas']) }}
            {!! $errors->first('horas', '<div class="invalid-feedback">:message</div>') !!}

            {{ Form::label('Responsable:') }}
            <div class="col-md-4">
            <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
            <select name="responsable" class="responsable col-md-6" style="width: 100%">
              @if (!empty($reporteactividadlocomotora->datos->nombre))
                <option value="{{$reporteactividadlocomotora->responsable}}">{{ $reporteactividadlocomotora->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
            @endif

            </div>
          </div>
        </div>

    </div>
    <div class="box-footer mt20 mt-4 text-center">
        <a href="/locomotoras/reportedelocomotoras/{{$_GET['id_r']}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
        <button type="submit" class="btn btn-primary">Crear</button>
    </div>
</div>