@extends('layouts.app', ['activePage' => 'materialeslocomotora', 'titlePage' => __('Actualizar Materiales de Locomotoras')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header card-header-primary">
              <h4 class="card-title">{{ __('Actualizar Locomotora') }}</h4>
            </div>
            <form method="post" action="{{route('materialeslocomotora.update', [$materialeslocomotora->id])}}" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
              @csrf
              @method('patch')
              @include('app.locomotora.materiales.form')
            <div class="col-md-12" align="center">
            <div class="card-footer justify-content-center">
            <a href="{{route('materialeslocomotora.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
              <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
            </div>
          </div>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

