@can('isanalistam')
<div class="row">
  <label class="col-md-2 col-form-label">{{ __('FECHA') }}</label>
   <div class="col-md-4">
          <input type="date" class="form-control"  id="fecha" type="text" name="fecha" 
          min = "<?php echo date("Y-m-d",strtotime(date("Y-m-d")."- 1 days"));?>" 
          max = "<?php echo date("Y-m-d",strtotime(date("Y-m-d")."+ 0 days"));?>" 
          value="{{$hoy ?? \Carbon\Carbon::parse($locomotoraConsumo->fecha)->format('Y-m-d')}}"/> 
    </div>
</div>
@endcan
@if(Gate::check('isplanificador') || Gate::check('isJefe'))
<div class="row">
  <label class="col-md-2 col-form-label">{{ __('FECHA') }}</label>
   <div class="col-md-4">
          <input type="date" class="form-control"  id="fecha" type="text" name="fecha" 
          value="{{$hoy ?? \Carbon\Carbon::parse($locomotoraConsumo->fecha)->format('Y-m-d')}}"/> 
    </div>
</div>
@endif
<div class="row mt-4">
  <label class="col-md-2 col-form-label">{{ __('LOCOMOTORA') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('locomotora') ? ' has-danger' : '' }}">
      <select class="custom-select form-control{{ $errors->has('locomotora') ? ' is-invalid' : '' }}" name="locomotora_id" id="input-locomotora_id" placeholder="{{ __('Ingrese locomotora') }}" required="true">
        <option value="">SELECCIONE</option>
        @foreach ($locomotoras as $locomotora)
          <option value="{{$locomotora->id}}" {{$locomotoraConsumo->locomotora_id == $locomotora->id ? 'selected' : '' }}>{{$locomotora->numero}}</option>
        @endforeach
      </select>
      @if ($errors->has('locomotora'))
        <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('locomotora') }}</span>
      @endif
    </div>
  </div>
  <label class="col-md-2 col-form-label">{{ __('TURNO') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('turno') ? ' has-danger' : '' }}">
      <select class="custom-select form-control{{ $errors->has('turno') ? ' is-invalid' : '' }}" name="turno" id="input-turno"
        placeholder="{{ __('Ingrese el turno') }}" required="true">
        <option value="">SELECCIONE</option>
        @foreach($turnos as $turno)
         <option value="{{$turno}}" {{$locomotoraConsumo->turno == $turno ? 'selected' : '' }}>{{$turno}}</option>
        @endforeach
      </select>
    @if ($errors->has('turno'))
      <span id="name-error" class="error text-danger" for="input-turno">{{ $errors->first('turno') }}</span>
    @endif
    </div>
  </div>
</div>

<div class="row mt-3">
 <label class="col-md-2 col-form-label">{{ __('CANTIDAD') }}</label>
  <div class="col-md-4">
    <input type="number" class="form-control"  id="cantidad" type="text" name="cantidad" max="50000" min="0" 
      value="{{old('cantidad') ?? $locomotoraConsumo->cantidad}}" />
  </div>       
  <label class="col-md-2 col-form-label">{{ __('TIPO CONSUMIBLE') }}</label>
  <div class="col-md-4">
      <select class="custom-select form-control{{ $errors->has('tipo') ? ' is-invalid' : '' }}" name="tipo" id="input-tipo"
        placeholder="{{ __('Ingrese el tipo de consumible') }}" required="true">
        <option value="">SELECCIONE</option>
        @foreach($locomotoraConsumo::listadoConsumibles() as $tipo)
         <option value="{{$tipo}}" {{$locomotoraConsumo->tipo == $tipo ? 'selected' : '' }}>{{$tipo}}</option>
        @endforeach
      </select>
      @if ($errors->has('tipo'))
        <span id="name-error" class="error text-danger" for="input-tipo">{{ $errors->first('tipo') }}</span>
      @endif      
</div>   

            <label class="col-md-2 col-form-label mt-4">{{ __('NOTA') }}</label>
            <div class="col-md-4 mt-4">
            {{ Form::text('nota', $locomotoraConsumo->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese texto']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}
            </div>