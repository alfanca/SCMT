@extends('layouts.app', ['activePage' => 'consumible', 'titlePage' => __('Consumibles de Locomotoras')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
    <div class="card">
    <div class="card-header card-header-primary d-flex justify-content-between">
    <div class="col-md-6">
    <h4 class="card-title">Consumibles del Taller de Locomotoras</h4>
    </div>
     @if(Gate::check('isplanificador') || Gate::check('isanalistam') || Gate::check('isJefe'))
     <div class="col-md-2" style="text-align: right;">
     <a rel="tooltip" title="Crear Consumo"
        href="{{route('crear')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Administrar
     </a>  
     </div>
     @endif
     </div>
    
     

      <form method="get" autocomplete="off" action="{{route('consumo.index')}}" class="form-horizontal">
            @include('app.comun.nav_calendario_busqueda_sinboton_locomotora')
        </form>  

            <div class="card-body">
              <div class="col-sm-12 text-center" align="center">
                

              <div class="card-group" align="center">
            <?php $acumulados = $listadoRegistroDeConsumo->groupBy('tipo');?>
            @foreach ($acumulados as $tipo => $datos)
              <div class="col-xl-3 col-md-4 mt-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                       <div class="media align-items-stretch">
                        @if ($tipo === 'GASOIL')
                        <div class="col-md-3 text-center" style="background-color: orange; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-gas-pump text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         @elseif ($tipo === 'ENGRALUB')
                         <div class="col-md-3 text-center" style="background-color: #ffc107; color: white;border-top-left-radius: 10px;">
           
                          <i class="fas fa-prescription-bottle text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         @elseif ($tipo === 'GRASA NEGRA')
                         <div class="col-md-3 text-center" style="background-color: black; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-fill-drip text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         @elseif ($tipo === 'MAXITREN DIESEL')
                         <div class="col-md-3 text-center" style="background-color: #db932c; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-oil-can text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         @elseif ($tipo === 'ZAPATAS')
                         <div class="col-md-3 text-center" style="background-color: #a9afbb; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-compact-disc text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         @elseif ($tipo === 'ACEITE 15W40')
                         <div class="col-md-3 text-center" style="background-color: #d7c955; color: white;border-top-left-radius: 10px;">
           
                          <i class="fas fa-tint text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         @elseif ($tipo === 'COMPRESOR')
                         <div class="col-md-3 text-center" style="background-color: #8b957d; color: white;border-top-left-radius: 10px;">
           
                          <i class="fas fa-fan text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         @elseif ($tipo === 'GOBERNADOR')
                         <div class="col-md-3 text-center" style="background-color: #b9ad80; color: white;border-top-left-radius: 10px;">
           
                          <i class="fab fa-cloudsmith text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         @else
                         <div class="col-md-3 text-center" style="background-color: red; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-exclamation text-center mt-4" style="font-size: 25px;"></i>
                        
                         </div>
                         
                         @endif
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>{{$tipo}}</strong></div>
                          @if ($tipo === 'ZAPATAS')
                          <p class="text-center" style="font-size: 18px;">{{number_format($datos->sum('cantidad'),0, ',','.')}} <span style="font-size: 10px">UND</span></p>
                          @elseif ($tipo === 'GRASA NEGRA')
                          <p class="text-center" style="font-size: 18px;">{{number_format($datos->sum('cantidad'),0, ',','.')}} <span style="font-size: 10px">UND</span></p>
                          @else
                          <p class="text-center" style="font-size: 18px;">{{number_format($datos->sum('cantidad'),0, ',','.')}} <span style="font-size: 10px">LTS</span></p>
                          @endif
                        </div>
                      </div>
                  </div>
                </div>
              </div>
              @endforeach
                </div>
              </div>



        <br>
        <div class="row">
        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning" >
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#tab-detalle" data-toggle="tab">
                        <i class="fas fa-table" style="font-size: 15px;"></i>  Consumo Detalle
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    @if(empty($_GET['locomotora_id']))
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-resumen" data-toggle="tab">
                        <i class="fas fa-bars" style="font-size: 15px;"></i> Resumen
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    @endif
                    @if(empty($_GET['locomotora_id']) and (Gate::check('isplanificador') ||  Gate::check('isJefe')))
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-graficas" data-toggle="tab">
                        <i class="fas fa-chart-bar" style="font-size: 15px;"></i> Graficas
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    @endif
                  </ul>
                </div>
              </div>
            </div>

          <div class="tab-content">

                <div class="tab-pane active" id="tab-detalle">
                   <div class="card-body table-responsive">
                    <table id="example"  class="cell-border compact stripe hover" style="width:100%">
                  <thead class=" text-primary">
                    <tr class="text-center">
                      <th class="col-2 text-center">Locomotora</th>
                      <th class="col-3 text-center">Consumible</th>
                      <th style="text-align: center;">Fecha</th>
                      <th style="text-align: center;">Semana</th>
                      <th style="text-align: center;">Cantidad</th>
                      <th style="text-align: center;">Unid</th>
                      <th style="text-align: center;">Turno</th>
                      <th style="text-align: center;">Nota</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($listadoRegistroDeConsumo as $consumo)
                     <tr>
                  <td style="text-align: center; color: black; font-size: 14px">{{$consumo->locomotora->numero}}</td>
                  <td style="text-align: center; color: black; font-size: 14px">{{$consumo->tipo}}</td>
                  <td style="text-align: center; color: black; font-size: 14px">{{$consumo->fecha}}</td>
                  <td style="text-align: center; color: black; font-size: 14px">{{\Carbon\Carbon::parse($consumo->fecha)->isoFormat('w')}}</td>
                  <td style="text-align: center; color: black; font-size: 14px">{{$consumo->cantidad}}</td>
                  @if ($consumo->tipo === 'ZAPATAS')
                  <th style="text-align: center; color: black; font-size: 14px; font-weight: normal;">Unid</th>
                  @else
                  <th style="text-align: center; color: black; font-size: 14px; font-weight: normal;">Lts</th>
                  @endif
                  <td style="text-align: center; color: black; font-size: 14px">{{$consumo->turno}}</td>
                  <td style="text-align: justify; color: black; font-size: 14px">{{$consumo->nota}}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
                  </div>
                </div>

                





                <div class="tab-pane" id="tab-resumen">
                   <div class="card-group col-md-12">
                <div class="card col-md-3">
                  <div class="card-header" style="background-color: #ffc107; color:white">
                    <h6 class="card-header text-center">ENGRALUB (Lts)</h6>
                    </div>
                    <div class="card-body">
                      @if (!empty($listadoConsumoPorLocomotora ['ENGRALUB']))
                      @foreach($listadoConsumoPorLocomotora ['ENGRALUB'] as $consumo)
                      <table class="cell-border compact stripe hover">
                      <tbody>
                        <tr>
                        <td class="col-md-2 text-left">{{$consumo->locomotora}}</td>
                        <td class="col-md-2 text-right">{{$consumo->cantidad}}</td>
                        </tr>
                      </tbody>
                    </table>
                      @endforeach
                      @endif
                    </div>
                  
                </div>
               

                <div class="card col-md-3">
                  <div class="card-header" style="background-color: orange; color:white">
                    <h6 class="card-header text-center">GASOIL (Lts)</h6>
                      </div>
                    <div class="card-body">
                    @if (!empty($listadoConsumoPorLocomotora ['GASOIL']))
                    @foreach($listadoConsumoPorLocomotora ['GASOIL'] as $consumo)
                    <table class="cell-border compact stripe hover">
                    <tbody>
                      <tr>
                      <td class="col-md-2 text-left">{{$consumo->locomotora}}</td>
                      <td class="col-md-2 text-right">{{$consumo->cantidad}}</td>
                      </tr>
                    </tbody>
                  </table>
                    @endforeach
                    @endif
                    </div>
                  
                </div>

                <div class="card col-md-3">
                  <div class="card-header" style="background-color: #db932c; color:white">
                    <h6 class="card-header text-center">MAXITREN DIESEL (Lts)</h6>
                    </div>
                    <div class="card-body">
                    @if (!empty($listadoConsumoPorLocomotora ['MAXITREN DIESEL']))
                    @foreach($listadoConsumoPorLocomotora ['MAXITREN DIESEL'] as $consumo)
                    <table class="cell-border compact stripe hover">
                    <tbody>
                      <tr>
                      <td class="col-md-2 text-left">{{$consumo->locomotora}}</td>
                      <td class="col-md-2 text-right">{{$consumo->cantidad}}</td>
                      </tr>
                    </tbody>
                  </table>
                    @endforeach
                    @endif
                    </div>
                  
                </div>
                <div class="card col-md-3">
                  <div class="card-header" style="background-color: #a9afbb; color:white">
                    <h6 class="card-header text-center">ZAPATAS (Unid)</h6>
                    </div>
                    <div class="card-body">
                    @if (!empty($listadoConsumoPorLocomotora ['ZAPATAS']))
                    @foreach($listadoConsumoPorLocomotora ['ZAPATAS'] as $consumo)
                    <table class="cell-border compact stripe hover">
                    <tbody>
                      <tr>
                      <td class="col-md-2 text-left">{{$consumo->locomotora}}</td>
                      <td class="col-md-2 text-right">{{$consumo->cantidad}}</td>
                      </tr>
                    </tbody>
                  </table>
                    @endforeach
                    @endif
                    </div>
                  
                </div>
              </div>

                <div class="card-group col-md-12">

                <div class="card col-md-3">
                  <div class="card-header" style="background-color: black; color:white">
                    <h6 class="card-header text-center">GRASA NEGRA (Unid)</h6>
                    </div>
                    <div class="card-body">
                    @if (!empty($listadoConsumoPorLocomotora ['GRASA NEGRA']))
                    @foreach($listadoConsumoPorLocomotora ['GRASA NEGRA'] as $consumo)
                    <table class="cell-border compact stripe hover">
                    <tbody>
                      <tr>
                      <td class="col-md-2 text-left">{{$consumo->locomotora}}</td>
                      <td class="col-md-2 text-right">{{$consumo->cantidad}}</td>
                      </tr>
                    </tbody>
                  </table>
                    @endforeach
                    @endif
                    </div>
                  
                </div>

                <div class="card col-md-3">
                  <div class="card-header" style="background-color: #d7c955; color:white">
                    <h6 class="card-header text-center">ACEITE 15W40 (Lts)</h6>
                    </div>
                    <div class="card-body">
                    @if (!empty($listadoConsumoPorLocomotora ['ACEITE 15W40']))
                    @foreach($listadoConsumoPorLocomotora ['ACEITE 15W40'] as $consumo)
                    <table class="cell-border compact stripe hover">
                    <tbody>
                      <tr>
                      <td class="col-md-2 text-center">{{$consumo->locomotora}}</td>
                      <td class="col-md-2 text-right">{{$consumo->cantidad}}</td>
                      </tr>
                    </tbody>
                  </table>
                    @endforeach
                    @endif
                    </div>
                  
                </div>

                <div class="card col-md-3">
                  <div class="card-header" style="background-color: #8b957d; color:white">
                    <h6 class="card-header text-center">ACEITE COMPRESOR (Lts)</h6>
                    </div>
                    <div class="card-body">
                    @if (!empty($listadoConsumoPorLocomotora ['COMPRESOR']))
                    @foreach($listadoConsumoPorLocomotora ['COMPRESOR'] as $consumo)
                    <table class="cell-border compact stripe hover">
                    <tbody>
                      <tr>
                      <td class="col-md-2 text-center">{{$consumo->locomotora}}</td>
                      <td class="col-md-2 text-right">{{$consumo->cantidad}}</td>
                      </tr>
                    </tbody>
                  </table>
                    @endforeach
                    @endif
                    </div>
                  
                </div>

                <div class="card col-md-3">
                  <div class="card-header" style="background-color: #b9ad80; color:white">
                    <h6 class="card-header text-center">ACEITE GOBERNADOR (Lts)</h6>
                    </div>
                    <div class="card-body">
                    @if (!empty($listadoConsumoPorLocomotora ['GOBERNADOR']))
                    @foreach($listadoConsumoPorLocomotora ['GOBERNADOR'] as $consumo)
                    <table class="cell-border compact stripe hover">
                    <tbody>
                      <tr>
                      <td class="col-md-2 text-center">{{$consumo->locomotora}}</td>
                      <td class="col-md-2 text-right">{{$consumo->cantidad}}</td>
                      </tr>
                    </tbody>
                  </table>
                    @endforeach
                    @endif
                    </div>
                  </div>
                </div>

        </div>


        <div class="tab-pane" id="tab-graficas">
        <div class="card-group col-md-12">


          <div id="container" class="container my-4" style="border: solid; border-width: 0.8px; border-color: black;">
          </div>

          <div id="containerdos" class="container my-4" style="border: solid; border-width: 0.8px; border-color: black;">
          </div>
       

       </div>

        </div>
      </div>

      </div>
    </div>
    </div>

  </div>
  </div>
</div>
</div>

   <script src="{{ asset('highchart') }}/code/highcharts.js"></script>
   <script src="{{ asset('highchart') }}/code/highcharts-3d.js"></script>
   <script src="{{ asset('highchart') }}/code/highcharts-3d.src.js"></script>
    <script src="{{ asset('highchart') }}/code/modules/data.js"></script>
    <script src="{{ asset('highchart') }}/code/modules/exporting.js"></script>
     <script src="{{ asset('highchart') }}/code/modules/offline-exporting.js"></script>

    <table id="gasoil" hidden="true">
        <thead>
            <tr>
                <th></th>
                <th>Gasoil</th>
            </tr>
        </thead>

        <tbody>
           @if (!empty($listadoConsumoPorLocomotora ['GASOIL']))
           @foreach($listadoConsumoPorLocomotora ['GASOIL'] as $consumo)
            <tr>
                <td>{{$consumo->locomotora}}</td>
                <td>{{$consumo->cantidad}}</td>
            </tr>
            @endforeach
            @endif 

        </tbody>
    </table>


    <table id="maxitren" hidden="true">
        <thead>
            <tr>
                <th></th>
                <th>Aceite Maxitren</th>
            </tr>
        </thead>

        <tbody>
           @if (!empty($listadoConsumoPorLocomotora ['MAXITREN DIESEL']))
           @foreach($listadoConsumoPorLocomotora ['MAXITREN DIESEL'] as $consumo)
            <tr>
                <td>{{$consumo->locomotora}}</td>
                <td>{{$consumo->cantidad}}</td>
            </tr>
            @endforeach
            @endif 

        </tbody>
    </table>





    <script type="text/javascript">
Highcharts.chart('container', {
    data: {
        table: 'gasoil'
    },
    chart: {
        type: 'column'
    },

    credits:{
      enabled: false
    },

    title: {
        text: '<strong style = "color: black;">CONSUMO DE GASOIL POR LOCOMOTORA</strong>'
    },

    xAxis: {
        type: 'category',
        min: 0,
    },

    yAxis: {
        allowDecimals: false,
        title: {
            text: '<strong style = "color: black;">LTS</strong>'
        }
    },


    plotOptions: {

        series: {
            color: '#d2091d',
            colorByPoint: false,
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y: f}'
            }

        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                '<p>Loc </p>'+this.point.name.toLowerCase() + ' tiene un consumo de' + ' ' +this.point.y +'<p> Litros</p>';
        }
    }
});
    </script>


        <script type="text/javascript">
Highcharts.chart('containerdos', {
    data: {
        table: 'maxitren'
    },
    chart: {
        type: 'column'
    },

    credits:{
      enabled: false
    },
    
    title: {
        text: '<strong style = "color: black;">CONSUMO DE ACEITE MAXITREN POR LOCOMOTORA</strong>'
    },

    xAxis: {
        type: 'category',
        min: 0,
    },

    yAxis: {
        allowDecimals: false,
        title: {
            text: '<strong style = "color: black;">LTS<strong>'
        }
    },


    plotOptions: {

        series: {
            color: '#d2091d',
            colorByPoint: false,
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y: f}'
            }

        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                '<p>Loc </p>'+this.point.name.toLowerCase() + ' consumió' + ' ' +this.point.y +'<p> Litros</p>'+ ' ó ' +((this.point.y)/208).toFixed(1) + ' Tr';
        }
    }
});
    </script>


@endsection
            <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
            <script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>
            <script type="text/javascript">
              
            $(document).ready(function() {
            $('#example').DataTable( {
               ordering: false,
               dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

            "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ consumibles)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
              },
                         }
                    } );
                } );
             
          </script>

