@if(!empty($datosAGraficar))
<?php 
    $ordenados = $datosAGraficar->sortBy('cantidad');
	$label = $ordenados->pluck('locomotora'); 
	$datos = $ordenados->pluck('cantidad'); 
    $max = $datos->max() + 2000;
    
?>
<br>

 <div class="ct-chart" id="{{$tipo}}"></div>

@push('js')
  <script>

    //rgb(106 24 22)
    //#6a1816
      var data = {
        labels: {!! json_encode($label) !!},
        series: [{!! json_encode($datos) !!}]
      };
      var options = {
        axisX: {
          showGrid: true,
        },
        legend: {
            display: true,
            labels: {
                fontColor: 'black',
                padding: 20

            }
        },
        low: 0,
        high: {{$max}},
        chartPadding: {
          top: 0,
          right: 30,
          bottom: 0,
          left: 30
        }
      };
      var responsiveOptions = [
        ['screen and (max-width: 720px)', {
          seriesBarDistance: 5,
          axisX: {
            labelInterpolationFnc: function(value) {
                console.log(value[0]);
              return value[0];

            }
          }
        }]
      ];
      var grafico = Chartist.Bar('#{{$tipo}}', data, options, responsiveOptions);
  </script>
@endpush

@endif