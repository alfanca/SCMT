@extends('layouts.app', ['activePage' => 'consumible', 'titlePage' => __('Editar consumo de locomotoras')])

@section('content')

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header card-header-primary">
              <h4 class="card-title">{{ __('Actualizar consumo') }}</h4>
            </div>
            <form method="post" action="{{route('consumo.update', [$locomotoraConsumo->id])}}" autocomplete="off" class="form-horizontal col-md-12">
              @csrf
              @method('patch')
              @include('app.locomotora.consumibles.form')
              <div class="col-md-12" align="center">
              <div class="card-footer justify-content-center">
              <a href="{{route('crear')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
            </div>
          </div>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
