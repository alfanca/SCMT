@extends('layouts.app', ['activePage' => 'reportelocomotora', 'titlePage' => __('Reportes del Taller de Locomotoras')])
@section('content')
<section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Reportes del Taller de Locomotoras</h4>
                        <p class="card-category">Administración de Reportes del Taller de Locomotoras</p>
                      </div>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                    <div class="col-md-6" style="text-align: right;">
                      <a rel="tooltip" class="btn btn-sm btn-rounded" href="" data-toggle="modal" data-target="#staticBackdropayuda" title="Ayuda" style="background-color: #868686;">
                          <i class="material-icons" style="font-size: 23px;">help</i>
                        </a>
                        <a rel="tooltip" title="Crear Reporte"
                            href="{{route('reportedelocomotoras.create')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">Crear Reporte
                          <i class="material-icons">add</i>
                        </a>  
                      </div>
                      @endif
                    </div>

                    <div class="modal bd-example-modal-lg" id="staticBackdropayuda" tabindex="-1" role="dialog">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="titulo">Instructivo</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body text-center">
                                
                                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                      <div class="carousel-inner">
                        <div class="carousel-item active">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/1.png" alt="First slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/2.png" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/3.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/4.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/5.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/6.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/7.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/8.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/9.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="{{ asset('ayudareporte') }}/10.png" alt="Third slide">
                        </div>
                      </div>
                      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Anterior</span>
                      </a>
                      <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Siguiente</span>
                      </a>
                    </div>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                          </div>
                        </div>
                      </div>
                      </div>


                    <div class="card-body">


        <div class="col-md-12 mt-4">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class=" nav-link active" href="#tab-correctivo" data-toggle="tab">
                        <i class="fa fa-fw fa-times" style="font-size: 15px;"></i> Correctivos
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class=" nav-link" href="#tab-correctivoNoti" data-toggle="tab">
                        <i class="fa fa-fw fa-check" style="font-size: 15px;"></i> Correctivos Notificados
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class=" nav-link" href="#tab-servicio" data-toggle="tab">
                        <i class="fas fa-gas-pump" style="font-size: 15px;"></i> Servicio
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-preventivo" data-toggle="tab">
                        <i class="fa fa-fw fa-stopwatch" style="font-size: 15px;"></i> Preventivos
                        <div class="ripple-container"></div>
                      </a>
                    </li>

                  </ul>
                </div>
              </div>
            </div>

              <div class="tab-content">

                <div class="tab-pane active" id="tab-correctivo">

                    <div class="card-group" align="center">


              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-fw fa-flag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Abiertas/Liberadas</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $reportedelocomotoranocerradascorrectivo->whereNotIn('locomotora_id', 25)->count() }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>


               <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fas fa-exclamation-triangle text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Sin Orden</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $reportedelocomotoranocerradascorrectivo->whereNotIn('locomotora_id', 25)->where('n_orden', '')->count() }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
          </div>

               <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">No</th>
                                        
                                        <th class="text-center col-1">N° Loc</th>
                                        <th class="text-center">Fecha Entrada</th>
                                        <th class="text-center">Descripción</th>
                                        <th class="text-center">Estatus</th>
                                        <th class="text-center">¿Notificada?</th>
                                        <th class="text-center">¿Planeado?</th>
                                        <th class="text-center">Motivo</th>
                                        <th class="text-center">Responsable</th>
                                        <th class="text-center col-1">N° Orden ó Aviso</th>
                                        <th class="text-center col-1">Acciones</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($reportedelocomotoranocerradascorrectivo as $reportedelocomotora)
                                        <tr>
                                            <td class="text-center">{{ ++$i }}</td>
                                            
                                            <td class="text-center">

                                            @if($reportedelocomotora->locomotora->numero == 'S/N')
                                            SERVICIO TALLER
                                            @else
                                            {{ $reportedelocomotora->locomotora->numero }}
                                            @endif

                                            </td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('d/m/Y H:i')}}</td>
                                            <td style="text-transform: uppercase;"><a rel="tooltip" title="Ver Reporte" class="" href="{{ route('reportedelocomotoras.show',$reportedelocomotora->id) }}">{{ $reportedelocomotora->descripcion_falla }}</a></td>
                                            <td class="text-center">{{ $reportedelocomotora->estatus }}</td>

                                            <style type="text/css">
                                              
                                              .btnActions {

                                                display: none;
                                              }

                                            </style>

                                            <td class="text-center" onmouseover="$(this).children().show();">




                                        @if(!empty($reportedelocomotora->fecha_salida))
                                            <div onmouseover="$(this).children().hide();">
                                            <i class="fa fa-check text-center"> SI</i>
                                            </div>
                                        @else
                                            <div onmouseover="$(this).children().hide();">
                                            <i class="fa fa-times text-center text-primary"> NO</i>
                                            </div>
                                        @endif
                                              @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                                                     @if($reportedelocomotora->estatus != 'CERRADA')
                                                     @if (empty($reportedelocomotora->fecha_salida) | $reportedelocomotora->locomotora->numero === 'S/N')
                                                     <a rel="tooltip" title="Crear Actividad" class="btn btn-sm btn-rounded btn-danger btnActions" href="{{ route('reporteactividadlocomotora.create',['id_r'=>$reportedelocomotora->id, 'loc'=>$reportedelocomotora->locomotora->numero]) }}"><i class="material-icons">assignment</i></a>
                                                      @endif
                                                      @endif
                                                      @endif


                                            </td>

                                            <td class="text-center">{{ $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] }}</td>
                                            <td class="text-center">{{ $reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado] }}</td>
                                            <td class="text-center">{{ $reportedelocomotora->datos->nombre }}</td>
                                            <td class="text-center">


                                              @if(!empty($reportedelocomotora->n_orden))
                                              <a rel="tooltip" title="F-4237" href="{{ route('ferroreporte',$reportedelocomotora->id) }}">{{ $reportedelocomotora->n_orden }}</a>
                                              @else
                                              <a rel="tooltip" title="F-4237" href="{{ route('ferroreporte',$reportedelocomotora->id) }}" style="font-size: 18px;"><i class="fa fa-fw fa-file-alt"></i></a>

                                              @endif
                                            </td>

                                            <td class="text-center">
                                                <form action="{{ route('reportedelocomotoras.destroy',$reportedelocomotora->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                                    @if ($reportedelocomotora->estatus == 'CERRADA') 
                                                    @else  
                                                    <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                    @endif
                                                    @endif
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>



                      <div class="tab-pane" id="tab-correctivoNoti">

                    <div class="card-group" align="center">


              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-fw fa-flag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Pendientes Por Cerrar</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $reportedelocomotoranocerradascorrectivoNotificado->whereNotIn('locomotora_id', 25)->count() }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>


               <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fas fa-exclamation-triangle text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Sin Orden</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $reportedelocomotoranocerradascorrectivoNotificado->whereNotIn('locomotora_id', 25)->where('n_orden', '')->count() }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
          </div>

               <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable3">
                                <thead class="thead">
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th class="text-center col-1">N° Loc</th>
                                        <th class="text-center">Fecha Entrada</th>
                                        <th class="text-center">Fecha Salida</th>
                                        <th class="text-center col-4">Descripción</th>
                                        <th class="text-center">Estatus</th>
                                        <th class="text-center">¿Notificada?</th>
                                        <th class="text-center">¿Planeado?</th>
                                        <th class="text-center">Motivo</th>
                                        <th class="text-center">Responsable</th>
                                        <th class="text-center col-1">N° Orden ó Aviso</th>
                                        <th class="text-center col-1">Acciones</th>



                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($reportedelocomotoranocerradascorrectivoNotificado as $reportedelocomotora)
                                        <tr>
                                            <td class="text-center">{{ ++$i }}</td>
                                            
                                            <td class="text-center">

                                            @if($reportedelocomotora->locomotora->numero == 'S/N')
                                            SERVICIO TALLER
                                            @else
                                            {{ $reportedelocomotora->locomotora->numero }}
                                            @endif

                                            </td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('d/m/Y H:i')}}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($reportedelocomotora->fecha_salida)->format('d/m/Y H:i')}}
                                            </td>
                                            <td style="text-transform: uppercase;"><a rel="tooltip" title="Ver Reporte" href="{{ route('reportedelocomotoras.show',$reportedelocomotora->id) }}">{{ $reportedelocomotora->descripcion_falla }}</a></td>
                                            <td class="text-center">{{ $reportedelocomotora->estatus }}</td>

                                            <td class="text-center">


                                        @if(!empty($reportedelocomotora->fecha_salida))

                                                 <i class="fa fa-check text-center"> SI</i>
                                        @else

                                             <i class="fa fa-times text-center text-primary"> NO</i>

                                        @endif


                                            </td>

                                            <td class="text-center">{{ $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] }}</td>
                                            <td class="text-center">{{ $reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado] }}</td>
                                            <td class="text-center">{{ $reportedelocomotora->datos->nombre }}</td>
                                            <td class="text-center">

                                              @if(!empty($reportedelocomotora->n_orden))
                                              <a rel="tooltip" title="F-4237" href="{{ route('ferroreporte',$reportedelocomotora->id) }}">{{ $reportedelocomotora->n_orden }}</a></td>
                                              @else
                                              <a rel="tooltip" title="F-4237" href="{{ route('ferroreporte',$reportedelocomotora->id) }}" style="font-size: 18px;"><i class="fa fa-fw fa-file-alt"></i></a></td>
                                              @endif

                                            </td>

                                            <td class="text-center">
                                                <form action="{{ route('reportedelocomotoras.destroy',$reportedelocomotora->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                                    @if ($reportedelocomotora->estatus == 'CERRADA') 
                                                    @else  
                                                    <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                    @endif
                                                    @endif
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <div class="tab-pane" id="tab-servicio">

                   <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>

                                        
                                        <th class="text-center col-1">Servicio</th>
                                        <th class="text-center">Fecha Entrada</th>
                                        <th class="text-center">Semana</th>
                                        <th class="text-center">Descripción</th>
                                        <th class="text-center">Crear Actividad</th>
                                        <th class="text-center">¿Planeado?</th>
                                        <th class="text-center">Motivo</th>
                                        <th class="text-center">Responsable</th>
                                        <th class="text-center col-1">Acciones</th>



                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($reportedelocomotoranocerradaslineaservicio as $reportedelocomotora)

                                        <tr>

                                            
                                            <td class="text-center">

                                            @if($reportedelocomotora->locomotora->numero == 'S/N')
                                            SERVICIO TALLER
                                            @else
                                            {{ $reportedelocomotora->locomotora->numero }}
                                            @endif

                                            </td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('d/m/Y H:i')}}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->isoFormat('w')}}</td>
                                            <td class="col-4" style="text-transform: uppercase;"><a rel="tooltip" title="Ver Reporte" href="{{ route('reportedelocomotoras.show',$reportedelocomotora->id) }}">{{ $reportedelocomotora->descripcion_falla }}</a></td>
                                            <td class="text-center">

                                              @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                                              @if($reportedelocomotora->estatus != 'CERRADA')
                                                <div class="col-12 text-center">
                                                <a rel="tooltip" title="Crear Actividad" class="btn btn-sm btn-rounded" style="background-color: #9B945F;" href="{{ route('reporteactividadlocomotora.create',['id_r'=>$reportedelocomotora->id, 'loc'=>$reportedelocomotora->locomotora->numero]) }}"><i class="material-icons" style="font-size: 17px;">assignment</i></a> 
                                                </div>
                                                @endif
                                                @endif

                                            </td>

                                            <td class="text-center">{{ $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] }}</td>
                                            <td class="text-center">{{ $reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado] }}</td>
                                            <td class="text-center">{{ $reportedelocomotora->datos->nombre }}</td>

                                            <td class="text-center">
                                                <form action="{{ route('reportedelocomotoras.destroy',$reportedelocomotora->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                                    @if ($reportedelocomotora->estatus == 'CERRADA') 
                                                    @else  
                                                    <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                    @endif
                                                    @endif
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                <div class="tab-pane" id="tab-preventivo">

                    <div class="card-group" align="center">


              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #585858; color: white;border-top-left-radius: 10px;">
           
                          <i class="fa fa-fw fa-flag text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Abiertas/Liberadas</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $reportedelocomotoranocerradaspreventivo->whereNotIn('locomotora_id', 25)->count() }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>


               <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
           
                          <i class="fas fa-exclamation-triangle text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Sin Orden</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $reportedelocomotoranocerradaspreventivo->whereNotIn('locomotora_id', 25)->where('n_orden', '')->count() }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
          </div>

                   <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable2">
                                <thead class="thead">
                                    <tr>
                                        
                                        <th class="text-center col-2">N° Loc</th>
                                        <th class="text-center">Fecha Entrada</th>
                                        <th class="text-center">Fecha Salida</th>
                                        <th class="text-center">Descripción</th>
                                        <th class="text-center">Estatus</th>
                                        <th class="text-center">¿Notificada?</th>
                                        <th class="text-center">¿Planeado?</th>
                                        <th class="text-center">Motivo</th>
                                        <th class="text-center">Responsable</th>
                                        <th class="text-center col-1">N° Orden</th>
                                        <th class="text-center col-1">Acciones</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($reportedelocomotoranocerradaspreventivo as $reportedelocomotora)

                                        <tr>
                                            
                                            <td class="text-center">{{ $reportedelocomotora->locomotora->numero }}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('d/m/Y H:i')}}</td>

                                            <td class="text-center">

                                              @if(!empty($reportedelocomotora->fecha_salida))
                                                {{ \Carbon\Carbon::parse($reportedelocomotora->fecha_salida)->format('d/m/Y H:i') }}
                                                @else
                                                @endif
                                              
                                            </td>
                                            <td class="col-4" style="text-transform: uppercase;"><a rel="tooltip" title="Ver Reporte" href="{{ route('reportedelocomotoras.show',$reportedelocomotora->id) }}">{{ $reportedelocomotora->descripcion_falla }}</a></td>
                                            <td class="text-center">{{ $reportedelocomotora->estatus }}</td>
                                            <td class="text-center">


                                             @if($reportedelocomotora->notificado == true)

                                             <i class="fa fa-check text-center"> SI</i>
                                             
                                              @else

                                             <i class="fa fa-times text-center text-primary"> NO</i>

                                              @endif


                                            </td>
                                            <td class="text-center">{{ $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] }}</td>
                                            <td class="text-center">{{ $reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado] }}</td>
                                            <td class="text-center">{{ $reportedelocomotora->datos->nombre }}</td>
                                            <td class="text-center">

                                              @if(!empty($reportedelocomotora->n_orden))
                                              <a rel="tooltip" title="F-4237" href="{{ route('ferroreporte',$reportedelocomotora->id) }}">{{ $reportedelocomotora->n_orden }}</a></td>
                                              @else
                                              <a rel="tooltip" title="F-4237" href="{{ route('ferroreporte',$reportedelocomotora->id) }}" style="font-size: 18px;"><i class="fa fa-fw fa-file-alt"></i></a></td>
                                              @endif

                                            </td>

                                            <td class="text-center">
                                                <form action="{{ route('reportedelocomotoras.destroy',$reportedelocomotora->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                                    @if ($reportedelocomotora->estatus == 'CERRADA') 
                                                    @else  
                                                    <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                                    @endif
                                                    @endif
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                  
                </div>
            </div>


                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['200'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable2').DataTable( {

    lengthMenu: ['50'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable2 thead tr').clone(true).appendTo( '#myTable2 thead' );
    $('#myTable2 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable2').DataTable();
} );
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable3').DataTable( {

    lengthMenu: ['10'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Reportes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable3 thead tr').clone(true).appendTo( '#myTable3 thead' );
    $('#myTable3 thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable3').DataTable();
} );
</script>


@endsection
