@extends('layouts.app', ['activePage' => 'reportelocomotora', 'titlePage' => __('Historial de Reporte de Locomotora')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Historial de Reporte de Locomotora</h4>
                        <p class="card-category">Busqueda de Reporte de Locomotora</p>
                      </div>
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{route('reportedelocomotoras.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i> Regresar
                        </a>  
                      </div>
                    </div>

            <div class="card-body">
             <div class="card-body">

           <form method="get" autocomplete="off" action="{{route('periodo.reporte.locomotora')}}" class="form-horizontal" role="form">
            @include('app.comun.nav_calendario_busqueda_sinboton_reporte')
           </form>

          
           </div>


        <div class="col-md-12 mt-4">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class=" nav-link active" href="#tab-indicadores" data-toggle="tab">
                        <i class="fas fa-balance-scale" style="font-size: 15px;"></i> Indicadores
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class=" nav-link" href="#tab-detalle" data-toggle="tab">
                        <i class="fa fa-fw fa-file-alt" style="font-size: 15px;"></i> Detalle
                        <div class="ripple-container"></div>
                      </a>
                    </li>

                  </ul>
                </div>
              </div>
            </div>
          </div>

              <div class="tab-content">

                <div class="tab-pane active" id="tab-indicadores">

                    <div class="card-group mt-4" align="center">

              <div class="col-lg-4 col-md-6 col-sm-6">
          <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between">

                <p class="card-title col-12" style="font-size: 16px;">Abiertas/Liberadas</p>

                </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-flag text-center mt-1" style="font-size: 14px; color: #585858; font-weight: bold;"></i> Creadas</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->count() }}</h5></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-flag-checkered mt-1" style="font-size: 14px; color: #28a745; font-weight: bold;"></i> Cerradas</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('estatus', 'CERRADA')->count() }}</h5></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-clock text-center mt-1" style="font-size: 14px; color: #ffc107; font-weight: bold;"></i> Sin Notificar</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('estatus', '!=','CERRADA')->count() }}</h5></div>
                </div>

                <div class="row">
                <div class="col-md-8 text-left"><i class="fas fa-exclamation-triangle text-center mt-1" style="font-size: 14px; color: #dc3545; font-weight: bold;"></i> Sin Orden</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('n_orden', '')->count() }}</h5></div>
              </div>
              </div>
            </div>            
           </div>




            <div class="col-lg-4 col-md-6 col-sm-6">
          <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between">

                <p class="card-title col-12" style="font-size: 16px;">Abier/Lib (ZPM1)</p>

                </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-flag text-center mt-1" style="font-size: 14px; color: #585858; font-weight: bold;"></i> Creadas</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('planeado', '1')->count() }}</h5></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-flag-checkered mt-1" style="font-size: 14px; color: #28a745; font-weight: bold;"></i> Cerradas</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('estatus', 'CERRADA')->where('planeado', '1')->count() }}</h5></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-clock text-center mt-1" style="font-size: 14px; color: #ffc107; font-weight: bold;"></i> Sin Notificar</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('estatus', '!=','CERRADA')->where('planeado', '1')->count() }}</h5></div>
                </div>

                <div class="row">
                <div class="col-md-8 text-left"><i class="fas fa-exclamation-triangle text-center mt-1" style="font-size: 14px; color: #dc3545; font-weight: bold;"></i> Sin Orden</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('n_orden', '')->where('planeado', '1')->count() }}</h5></div>
              </div>
              </div>
            </div>            
           </div>



           <div class="col-lg-4 col-md-6 col-sm-6">
          <div class="card card-stats" style="background-color: #f9f9f9; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <div class="card-header card-header-warning d-flex justify-content-between">

                <p class="card-title col-12" style="font-size: 16px;">Abier/Lib (ZPM2/ZPMI)</p>

                </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-flag text-center mt-1" style="font-size: 14px; color: #585858; font-weight: bold;"></i> Creadas</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('planeado', '0')->count() }}</h5></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-flag-checkered mt-1" style="font-size: 14px; color: #28a745; font-weight: bold;"></i> Cerradas</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('estatus', 'CERRADA')->where('planeado', '0')->count() }}</h5></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left"><i class="fa fa-fw fa-clock text-center mt-1" style="font-size: 14px; color: #ffc107; font-weight: bold;"></i> Sin Notificar</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('estatus', '!=','CERRADA')->where('planeado', '0')->count() }}</h5></div>
                </div>

                <div class="row">
                <div class="col-md-8 text-left"><i class="fas fa-exclamation-triangle text-center mt-1" style="font-size: 14px; color: #dc3545; font-weight: bold;"></i> Sin Orden</div>
                <div class="col-md-4 text-text-righ"><h5 class="card-title">{{ $reporte_all->whereNotIn('locomotora_id', 'S/N')->where('n_orden', '')->where('planeado', '0')->count() }}</h5></div>
              </div>
              </div>
            </div>            
           </div>


              

            </div>


                  </div>


                    <div class="tab-pane" id="tab-detalle">


                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-striped table-hover">
                                <thead class="thead">    
                                <th class="text-center col-1">N° Loc</th>
                                <th class="text-center">Fecha Entrada</th>
                                <th class="text-center">Fecha Salida</th>
                                <th class="text-center col-4">Descripción</th>
                                <th class="text-center">Estatus</th>
                                <th class="text-center">¿Notificada?</th>
                                <th class="text-center">Planeado</th>
                                <th class="text-center">Motivo</th>
                                <th class="text-center">Responsable</th>
                                <th class="text-center col-1">N° Orden ó Aviso</th>
                                
                                <th class="text-center col-1">Acciones</th>

                                </tr>
                                </thead>
                                <tbody>
                                    @foreach ($reporte_all as $reportedelocomotora)
                                        <tr>           
                                 <td class="text-center">

                                  @if($reportedelocomotora->locomotora_id == 'S/N')
                                            SERVICIO TALLER
                                            @else
                                            {{ $reportedelocomotora->locomotora_id }}
                                            @endif

                                  </td>
                                 <td class="text-center">{{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('d/m/Y H:i')}}</td>
                                 <td class="text-center">


                                    @if(!empty($reportedelocomotora->fecha_salida))
                                    {{\Carbon\Carbon::parse($reportedelocomotora->fecha_salida)->format('d/m/Y H:i')}}
                                    @endif


                                 </td>
                                 <td style="text-transform: uppercase;"><a rel="tooltip" title="Ver Reporte" href="{{ route('reportedelocomotoras.show',$reportedelocomotora->id) }}">{{ $reportedelocomotora->descripcion_falla }}</a></td>
                                 <td class="text-center">{{ $reportedelocomotora->estatus }}</td>
                                 <td class="text-center">

                                  @if($reportedelocomotora->planeado == '1')

                                        @if($reportedelocomotora->estatus == 'CERRADA' || !empty($reportedelocomotora->fecha_salida))

                                        <i class="fa fa-check text-center"> SI</i>

                                        @else

                                          <i class="fa fa-times text-center text-primary"> NO</i>

                                        @endif

                                  @endif

                                  @if($reportedelocomotora->planeado == '0')

                                        @if($reportedelocomotora->estatus == 'CERRADA' || $reportedelocomotora->notificado == true)

                                        <i class="fa fa-check text-center"> SI</i>

                                        @else

                                        <i class="fa fa-times text-center text-primary"> NO</i>

                                        @endif

                                  @endif



                                 </td>
                                 <td class="text-center">{{ $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] }}</td>
                                 <td class="text-center">{{ $reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado] }}</td>
                                 <td class="text-center">{{ $reportedelocomotora->datos->nombre }}</td>
                                 <td class="text-center">

                                  @if(!empty($reportedelocomotora->n_orden))
                                  <a rel="tooltip" title="F-4237" href="{{ route('ferroreporte',$reportedelocomotora->id) }}">{{ $reportedelocomotora->n_orden }}</a></td>
                                  @else
                                  <a rel="tooltip" title="F-4237" href="{{ route('ferroreporte',$reportedelocomotora->id) }}" style="font-size: 18px;"><i class="fa fa-fw fa-file-alt"></i></a></td>
                                  @endif

                                 </td>

                                 <td class="text-center">
                                 <form action="{{ route('reportedelocomotoras.destroy',$reportedelocomotora->id) }}" method="POST">
                                 @csrf
                                 @method('DELETE')
                                 @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                                 @if ($reportedelocomotora->estatus == 'CERRADA') 
                                 @else  
                                 <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                                 @endif
                                 @endif
                                 </form>
                                 </td>
                                 </tr>
                                  @endforeach
                            </table>
                        </div>
                      </div>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
                    


<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Componentes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


@endsection
