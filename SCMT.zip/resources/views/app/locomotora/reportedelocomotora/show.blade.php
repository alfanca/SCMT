@extends('layouts.app', ['activePage' => 'reportelocomotora', 'titlePage' => __('Reportes del Taller de Locomotoras')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">

                          @if($reportedelocomotora->locomotora->numero == 'S/N')
                                            SERVICIO TALLER
                                            @else
                                            Reporte de Locomotora  019-{{$reportedelocomotora->locomotora->numero}}
                                            @endif

                         </h4>
                        <p class="card-category">

                          @if($reportedelocomotora->locomotora->numero == 'S/N')
                                           
                           @else
                           N° Orden ó Aviso: {{ $reportedelocomotora->n_orden }}
                           @endif

                          </p>
                      </div>
                      
                    <div class="col-md-6" style="text-align: right;">
                      <a rel="tooltip" title="F-4237" class="btn btn-sm btn-rounded " href="{{ route('ferroreporte',$reportedelocomotora->id) }}" style="background-color: #9B945F;"><i class="fa fa-fw fa-file-alt"></i></a>
                        <a rel="tooltip"
                            href="{{URL::previous()}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i>Regresar
                        </a> 

                        <a rel="tooltip"
                            href="{{ route('reportedelocomotoras.index') }}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-home"></i>
                        </a> 
                        
                        
                      </div>
                      
                    </div>
                    <br>
                    <br>
                    <br>
                    <div class="card-body mt-4">


        <div class="col-md-12">

            <div class="card-header card-header-tabs card-header-warning">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <span class="nav-tabs-title">TABLAS:</span>
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class=" nav-link active" href="#tab-encabezado" data-toggle="tab">
                        <i class="fa fa-fw fa-edit" style="font-size: 15px;"></i> Encabezado
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-obra" data-toggle="tab">
                        <i class="fa fa-fw fa-stopwatch" style="font-size: 15px;"></i> Mano de Obra
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-actividad" data-toggle="tab">
                        <i class="material-icons" style="font-size: 17px;">assignment</i> Actividades
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-componentes" data-toggle="tab">
                        <i class="fas fa-toolbox" style="font-size: 15px;"></i> Componentes
                        <div class="ripple-container"></div>
                      </a>
                    </li>

                  </ul>
                </div>
              </div>
            </div>

              <div class="tab-content">

                <div class="tab-pane active" id="tab-encabezado">

                @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                @if($reportedelocomotora->estatus != 'CERRADA')
                <div class="col-12 text-right mt-4">
                 <a class="btn btn-sm btn-rounded" style="background-color: #9B945F;" href="{{ route('reportedelocomotoras.edit',$reportedelocomotora->id) }}"><i class="fa fa-fw fa-edit"></i> Editar</a> 
                  @csrf
                </div>
                @endif
                @endif

                   <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
              
                        <div class="card-group mt-4">
                        <div class="form-group col-2">
                            @if($reportedelocomotora->locomotora->numero == 'S/N')
                            <strong><b>Servicio Taller</b></strong>
                            @else
                            <strong><b>N° Loc:</b></strong>
                            {{ $reportedelocomotora->locomotora->numero }}
                            @endif
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Entrada:</b></strong>
                            {{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('d/m/Y H:i')}}
                        </div>
                        <div class="form-group col-3">
                            <strong><b>Fecha Salida:</b></strong>
                            @if(!empty($reportedelocomotora->fecha_salida))
                            {{ \Carbon\Carbon::parse($reportedelocomotora->fecha_salida)->format('d/m/Y H:i') }}
                            @endif
                        </div>
                        <div class="form-group col-2">
                            <strong><b>Estatus:</b></strong>
                            {{ $reportedelocomotora->estatus }}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>Ceco:</b></strong>
                            {{ $reportedelocomotora::CECO[$reportedelocomotora->ceco] }}
                        </div>
                        </div>
                        <hr>
                        <h4 class="col-md-12 text-center">Mantenimiento</h4>
                        <div class="card-group" align="center">
                        <div class="form-group col-6">
                            <strong><b>Planeado:</b></strong>
                            {{ $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] }}
                        </div>
                        <div class="form-group mt-4 col-4">
                            <strong><b>Motivo:</b></strong>
                            {{ $reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado] }}
                        </div>
                        </div>
                        <div class="form-group col-12 mt-4">
                            <strong><b>Descripcion Falla:</b></strong>
                            <strong style="text-transform: uppercase;">{{ $reportedelocomotora->descripcion_falla }}</strong>
                        </div>
                        <hr>
                        <h4 class="col-md-12 text-center">Razon de la Falla / Razon de Demora</h4>
                        <div class="card-group mt-4">
                        <div class="form-group col-4">
                            <strong><b>Razon Falla:</b></strong>
                            {{ $reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] }}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Razon Demora:</b></strong>
                            {{ $reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] }}
                        </div>
                        <div class="form-group col-2">
                            <strong><b>Otro Motivo:</b></strong>
                            {{ $reportedelocomotora->otro_motivo }}
                        </div>
                        </div>
                        <hr>
                        <h4 class="col-md-12 text-center">Responsables</h4>
                        <div class="card-group mt-4">
                        <div class="form-group col-4">
                            <strong><b>Responsable:</b></strong>
                            {{ $reportedelocomotora->datos->nombre }}
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Reporte Creado Por:</b></strong>
                            <strong style="text-transform: uppercase;">{{ $reportedelocomotora->usuario_crea }}</strong>
                        </div>
                        <div class="form-group col-4">
                            <strong><b>Reporte Actualizado por:</b></strong>
                            <strong style="text-transform: uppercase;">{{ $reportedelocomotora->usuario_actualiza }}</strong>
                        </div>
                    </div>
                </div>


                <div class="tab-pane" id="tab-obra">

                  <div class="card-group" align="center">


              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #3e77b6; color: white; border-top-left-radius: 10px;">
           
                          <i class="fas fa-user text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>N° Personas</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$agruparPersonal}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #3e77b6; color: white; border-top-left-radius: 10px;">
           
                          <i class="fas fa-user-cog text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Horas Taller</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$horasTaller}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #3e77b6; color: white; border-top-left-radius: 10px;">
           
                          <i class="fas fa-user-clock text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px; border-radius: 10px;"><strong>Horas Hombre</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{$horasTaller * $agruparPersonal}}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

            </div>

                    @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                    @if($reportedelocomotora->estatus != 'CERRADA')
                    <div class="col-12 text-right mt-4">
                    <a class="btn btn-sm btn-rounded" style="background-color: #9B945F;" href="{{ route('reportetiempolocomotoras.create',['id'=>$reportedelocomotora->id]) }}"><i class="fa fa-fw fa-stopwatch"></i> Añadir Mano de Obra</a> 
                    </div>
                    @endif
                    @endif

                    <div class="table-responsive">
                <table class="table">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center">Ficha</th>
                        <th class="text-center">Nombre</th>
                        <th class="text-center">Fecha</th>
                        <th class="text-center">Horas</th>
                        @if ($reportedelocomotora->estatus == 'CERRADA')
                        @else
                        <th class="text-center col-1">Acciones</th>
                        @endif
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($reportetiempo as $tiempolocomotora)
                      <tr>
                      <td class="text-center">{{$tiempolocomotora->responsable}}</td>
                      <td class="text-center">{{$tiempolocomotora->datos->nombre}}</td>
                      <td class="text-center">{{\Carbon\Carbon::parse($tiempolocomotora->fecha)->format('d/m/Y')}}</td>
                      <td class="text-center">{{$tiempolocomotora->horas}}</td>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                      @if ($reportedelocomotora->estatus == 'CERRADA')
                      @else
                      <td class="text-center">
                       <form class="text-center" action="{{ route('reportetiempolocomotoras.destroy',$tiempolocomotora->id) }}" method="POST">
                       @csrf
                       @method('DELETE')
                       <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                       </form>
                      </td>
                      @endif
                      @endif
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
                  
                </div>
                
                <div class="tab-pane" id="tab-actividad">
                  <?php $verifiacion = $reporteactividad->sortByDesc('fecha')->pluck('estatus')->first(); 
                  ?>
                  @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                  @if($reportedelocomotora->estatus != 'CERRADA')
                  @if ($verifiacion != 0 | $conteoactividades == 0 | $reportedelocomotora->locomotora->numero === 'S/N')
                    <div class="col-12 text-right mt-4">
                    <a class="btn btn-sm btn-rounded" style="background-color: #9B945F;" href="{{ route('reporteactividadlocomotora.create',['id_r'=>$reportedelocomotora->id, 'loc'=>$reportedelocomotora->locomotora->numero]) }}"><i class="material-icons" style="font-size: 17px;">assignment</i> Añadir Actividad</a> 
                    </div>
                    @endif
                    @endif
                    @endif


                <div class="table-responsive">
                  <table class="table">
                  <thead class=" text-primary">
                    <tr>
                        <th class="col-md-1 text-center">Fecha</th>
                        @if ($reportedelocomotora->locomotora->numero === 'S/N')
                        <th class="col-md-1 text-center">N° Locomotora</th>
                        @endif
                        <th class="col-md-1 text-center">Turno</th>
                        <th class="col-md-1 text-center">Area</th>
                        <th class="col-md-1 text-center">Falla</th>
                        <th class="col-md-1 text-center">Motivo</th>
                        <th>Descripción</th>
                        <th class="col-md-1 text-center">¿Disponible?</th>
                        <th class="col-md-1 text-center">Responsable</th>
                        @if(Gate::check('isplanificador') || Gate::check('isJefe') )
                        <th class="col-md-1 text-center">Usuario Crea</th>
                        <th class="col-md-1 text-center">Usuario Actualiza</th>
                        @endif
                        @if ($verifiacion >= 0 | $reportedelocomotora->locomotora->numero === 'S/N')
                        @if ($reportedelocomotora->estatus == 'CERRADA')
                        @else
                        <th class="text-center col-1">Acciones</th>
                        @endif
                        @endif
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($reporteactividad as $actividad)
                      <tr>
                      <td class="text-center">{{\Carbon\Carbon::parse($actividad->fecha)->format('d/m/Y')}}</td>
                      @if ($reportedelocomotora->locomotora->numero === 'S/N')
                      <td class="text-center">{{$actividad->locomotora}}</td>
                      @endif
                      <td class="text-center">{{$actividad::TURNO[$actividad->turno]}}</td>
                      <td class="text-center">{{$actividad::AREA[$actividad->area]}}</td>
                      <td class="text-center">{{$actividad::FALLA[$actividad->falla]}}</td>
                      <td class="text-center">{{$actividad::FALLAMOTIVO[$actividad->fallamotivo]}}</td>
                      <td class="col-6" style="text-transform: uppercase;">{{$actividad->descripcion}}</td>
                      <td class="text-center">{{$actividad::ESTATUS[$actividad->estatus]}}</td>
                      <td class="text-center">{{$actividad->datos->nombre}}</td>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                      <td class="text-center" style="text-transform: uppercase;">{{$actividad->usuario_crea}}</td>
                      <td class="text-center" style="text-transform: uppercase;">{{$actividad->usuario_actualiza}}</td>
                      @endif
                      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                      @if ($verifiacion >= 0 | $reportedelocomotora->locomotora->numero === 'S/N')
                      @if ($reportedelocomotora->estatus == 'CERRADA')
                      @else
                      <td class="td-actions">
                       <form class="text-center" action="{{ route('reporteactividadlocomotora.destroy',$actividad->id) }}" method="POST">
                       <a class="btn btn-link btn-success" rel="tooltip" title="Editar" href="{{ route('reporteactividadlocomotora.edit',[$actividad->id,'id_r'=>$reportedelocomotora->id, 'loc'=>$reportedelocomotora->locomotora->numero]) }}"><i class="material-icons">edit</i></a>
                       @csrf
                       @method('DELETE')
                       <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                       </form>
                      </td>
                      @endif
                      @endif
                      @endif
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>

                </div>

                <div class="tab-pane" id="tab-componentes">

                  @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                  @if($reportedelocomotora->estatus != 'CERRADA')
                    <div class="col-12 text-right mt-4">
                    <a class="btn btn-sm btn-rounded" style="background-color: #9B945F;" href="{{ route('reporteconsumiblelocomotoras.create',['id'=>$reportedelocomotora->id, 'loc'=>$reportedelocomotora->locomotora->numero]) }}"><i class="fa fa-fw fa-toolbox"></i> Añadir Componente</a> 
                    </div>
                    @endif
                    @endif

                    <div class="table-responsive">
                <table class="table">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center">N° SAP</th>
                        <th class="text-center">N° Parte</th>
                        @if($reportedelocomotora->locomotora->numero == 'S/N')
                        <th class="text-center">Locomotora</th>
                        @endif
                        <th class="text-center">Fecha</th>
                        <th class="text-center">Descripción</th>
                        <th class="text-center">Cantidad</th>
                        <th class="text-center">Precio Unit</th>
                        <th class="text-center">Precio Total</th>
                        @if ($reportedelocomotora->estatus == 'CERRADA')
                        @else
                        <th class="text-center col-1">Acciones</th>
                        @endif
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($reporteconsumible as $consumiblelocomotora)
                      <tr>
                      <td class="text-center">{{$consumiblelocomotora->materiales->sap}}</td>
                      <td class="text-center">{{$consumiblelocomotora->materiales->parte}}</td>
                      @if($reportedelocomotora->locomotora->numero == 'S/N')
                      <td class="text-center">{{$consumiblelocomotora->locomotora}}</td>
                      @endif
                      <td class="text-center">{{\Carbon\Carbon::parse($consumiblelocomotora->fecha)->format('d/m/Y')}}</td>
                      <td style="text-transform: uppercase;">{{$consumiblelocomotora->materiales->descripcion}}</td>
                      <td class="text-center">{{$consumiblelocomotora->cantidad}}</td>
                      @if(Gate::check('isplanificador') || Gate::check('isJefe'))
                      <td class="text-center">{{$consumiblelocomotora->preciounitario}}</td>
                      <td class="text-center">{{($consumiblelocomotora->preciounitario)*$consumiblelocomotora->cantidad}}</td>
                      @endif
                      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('issupervisorlocomotora'))
                      @if ($reportedelocomotora->estatus == 'CERRADA')
                      @else
                      <td class="text-center">
                       <form class="text-center" action="{{ route('reporteconsumiblelocomotoras.destroy',$consumiblelocomotora->id) }}" method="POST">
                       @csrf
                       @method('DELETE')
                       <button type="submit" class="btn btn-danger btn-link" onclick="return confirm('¿Seguro que deseas Eliminar?')"><i class="fa fa-fw fa-trash"></i></button>
                       </form>
                      </td>
                      @endif
                      @endif
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>
                   
                </div>

              </div>


        </div>






                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
