@extends('layouts.app', ['activePage' => 'reportelocomotora', 'titlePage' => __('Ferro 4237')])
@section('content')
<section class="content container-fluid">
	    <div class="container-fluid">
        	 	<div class="card" align="center">
        	 		<div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title text-left">Reportes del Taller de Locomotoras</h4>
                        <p class="card-category text-left">Administración de Reportes del Taller de Locomotoras</p>
                      </div>
                    <div class="col-md-6" style="text-align: right;">
                    	<a rel="tooltip" title="Volver"
                            href="{{route('reportedelocomotoras.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="material-icons">reply</i>
                        </a> 
                        <a rel="tooltip" title="Imprimir"
                            href="" onclick="javascript:imprim1r(imprimir);" class="btn btn-sm btn-rounded" style="background-color: #9B945F;">
                          <i class="material-icons">print</i>
                        </a>  
                      </div>

                    </div>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title>FERRO 4237</title>
	<meta name="generator" content="LibreOffice 6.0.7.3 (Linux)"/>
	<meta name="author" content="Gcia. de Sistemas"/>
	<meta name="created" content="2010-11-10T11:14:00"/>
	<meta name="changed" content="2022-01-21T09:00:04.499795151"/>
	<style type="text/css">
		@page { margin-left: 1.41cm; margin-right: 0.84cm; margin-top: 1.8cm; margin-bottom: 0.67cm }
		p { margin-bottom: 0cm; direction: ltr; color: #000000; orphans: 2; widows: 2 }
		p.western { font-family: "Arial", sans-serif; font-size: 10pt; so-language: es-MX }
		p.cjk { font-family: "Times New Roman", serif; font-size: 10pt }
		p.ctl { font-family: "Arial", sans-serif; font-size: 10pt; so-language: ar-SA }
		td p { margin-bottom: 0cm; direction: ltr; color: #000000; orphans: 2; widows: 2 }
		td p.western { font-family: "Times New Roman", serif; font-size: 10pt; so-language: es-ES-u-co-trad }
		td p.cjk { font-family: "Times New Roman", serif; font-size: 10pt }
		td p.ctl { font-family: "Times New Roman", serif; font-size: 10pt; so-language: ar-SA }
		a:link { so-language: zxx }
	</style>
	<script type="text/javascript">
		function imprim1r (imprimir){
			var printContents = document.getElementById('imprimir').innerHTML;
				w = window.open();
				w.document.write(printContents);
		w.print();
		w.close();
		return true;
		}
	</script>
</head>
<body lang="es-VE" text="#000000" bgcolor="#ffffff" dir="ltr">

<div id="imprimir">	

	<table width="695" cellpadding="5" cellspacing="2" style="background-color: white;" align="center" class="mt-4">
		<colgroup>
			<col width="5">
			<col width="111">
		</colgroup>
		<colgroup>
			<col width="16">
		</colgroup>
		<colgroup>
			<col width="139">
		</colgroup>
		<colgroup>
			<col width="355">
			<col width="4360">
		</colgroup>
		<tbody>
			<tr valign="top">
				<td colspan="2" width="128" style="border-top: 4.50pt double #000000; border-bottom: none; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="pt-BR" class="western" align="center" style="margin-top: 0.21cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 6pt">FERRO-4237
					REV. 16/03/2022</font></font></p>
				</td>
				<td colspan="4" width="537" style="border-top: 4.50pt double #000000; border-bottom: none; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="pt-BR" class="western" align="right" style="margin-top: 0.21cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">PÁG.:
					<u>_</u><u>1_</u>  DE: <font face="Arial, sans-serif"><u>_</u></font><font face="Arial, sans-serif"><u>2_</u></font></font></font></p>
				</td>
			</tr>
			<tr valign="top">
				<td colspan="2" width="128" height="81" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.42cm">
					<img src="{{asset('/images/logofmo.png')}}" name="Objeto1" align="bottom" width="63" height="61"/>
</p>
				</td>

		<td colspan="4" width="537" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.64cm">
					<font face="Spranq eco sans, sans-serif"><font size="3" style="font-size: 12pt"><b>REPORTE
					DE TRABAJOS EJECUTADOS POR EL TALLER</b></font></font></p>
				</td>
			</tr>
		</tbody>
		<tbody>

			<tr>
				<td colspan="6" width="677" height="3" valign="top" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<table width="100%" cellpadding="4" cellspacing="0">
						<col width="85*">
						<col width="85*">
						<col width="85*">
						<tr valign="top">
							<td width="33%" height="30" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" align="left">

								</p>
								<p lang="es-ES" class="western" align="left"><font face="Spranq eco sans, sans-serif">

								@if($reportedelocomotora->locomotora->numero == 'S/N')
								<font size="1" style="font-size: 7pt">N.º
								EQUIPO: <u>LINEA DE SERVICIO</u></font></font>
								@else
								<font size="1" style="font-size: 7pt">N.º
								EQUIPO: <u>
									
									@if ($reportedelocomotora->locomotora->numero == '0002')
									DF8BVEN-{{ $reportedelocomotora->locomotora->numero  }}
									@else
									019-{{ $reportedelocomotora->locomotora->numero }}
									@endif
									

								</u></font></font>
								</p>
								@endif


							</td>
							<td width="33%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" align="left">

								</p>
								<p lang="es-ES" class="western" align="left"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">FECHA
								ENTRADA: <u>{{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('d/m/Y')}}</u></font></font></p>
							</td>
							<td width="33%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" align="left">

								</p>
								<p lang="es-ES" class="western" align="left"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">FECHA
								SALIDA: <u>{{ \Carbon\Carbon::parse($reportedelocomotora->fecha_salida)->format('d/m/Y') }}</u></font></font></p>
							</td>
						</tr>
						<tr valign="top">
							<td width="33%" height="23" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" align="left">

								</p>
								<p lang="es-ES" class="western" align="left"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">CENTRO
								DE COSTO: <u>{{ $reportedelocomotora::CECO[$reportedelocomotora->ceco] }}</u></font></font></p>
							</td>
							<td width="33%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" align="left">

								</p>
								<p lang="es-ES" class="western" align="left"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">HORA
								ENTRADA: <u>{{\Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('H:i')}}</u></font></font></p>
							</td>
							<td width="33%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" align="left">

								</p>
								<p lang="es-ES" class="western" align="left"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">HORA
								SALIDA: <u>{{ \Carbon\Carbon::parse($reportedelocomotora->fecha_salida)->format('H:i') }}</u></font></font></p>
							</td>
						</tr>
					</table>
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">


					</p>
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr>
				<td colspan="6" width="677" height="3" valign="top" style="border-top: none; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><b>MANTENIMIENTO</b></font></font></p>
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr>
				<td colspan="6" width="677" height="9" valign="top" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES-u-co-trad" class="western" style="line-height: 100%">
					<br/>

					</p>
					<table width="541" cellpadding="4" cellspacing="0">
						<col width="22">
						<col width="94">
						<col width="79">
						<col width="26">
						<col width="26">
						<col width="22">
						<col width="83">
						<col width="90">
						<col width="27">
						<tr valign="top">
							<td width="22" height="15" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] === 'SI')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								  ) </font></font>
								</p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								  ) </font></font>
								</p>
								@endif
							</td>
							<td width="94" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">PLANEADO:
								 </font></font>
								</p>
							</td>
							<td width="79" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">A)
								INSPECCIÓN </font></font>
								</p>
							</td>
							<td width="26" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado] === 'INSPECCIÓN')
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
							    @endif
							</td>
							<td width="26" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western" style="margin-top: 0.11cm">
								<br/>

								</p>
							</td>
							<td width="22" style="border: none; padding: 0cm">
							@if ($reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] === 'NO')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								  ) </font></font>
								</p>
							@else
							<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								  ) </font></font>
								</p>
							@endif
							</td>
							<td width="83" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">NO
								PLANEADO:  </font></font>
								</p>
							</td>
							<td width="90" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">A)
								REPARACIÓN </font></font>
								</p>
							</td>
							<td width="27" style="border: none; padding: 0cm">
							@if ($reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado] === 'REPARACIÓN')
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								  ) </font></font>
								</p>
							@else
							<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								  ) </font></font>
								</p>
							@endif
							</td>
						</tr>
						<tr valign="top">
							<td width="22" height="11" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="94" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="79" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">B)
								CHEQUEO</font></font></p>
							</td>
							<td width="26" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado]  === 'CHEQUEO' and $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] === 'SI')
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								 @else
								 <p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								 @endif
							</td>
							<td width="26" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="22" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="83" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="90" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">B)
								AJUSTE </font></font>
								</p>
							</td>
							<td width="27" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado]  === 'AJUSTE' and $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] === 'NO')
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								  ) </font></font>
								</p>
								@else
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								  ) </font></font>
								</p>
								@endif
							</td>
						</tr>
						<tr valign="top">
							<td width="22" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="94" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="79" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">C)
								CAMBIO</font></font></p>
							</td>
							<td width="26" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado]  === 'CAMBIO' and $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] === 'SI')
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="26" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="22" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="83" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="90" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">C)
								CAMBIO </font></font>
								</p>
							</td>
							<td width="27" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado]  === 'CAMBIO' and $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] === 'NO')
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								  ) </font></font>
								@else
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								  ) </font></font>
								@endif
								</p>
							</td>
						</tr>
						<tr valign="top">
							<td width="22" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="94" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="79" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">D)
								AJUSTE</font></font></p>
							</td>
							<td width="26" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado]  === 'AJUSTE' and $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] === 'SI')
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								 @else
								 <p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								 @endif
							</td>
							<td width="26" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="22" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="83" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="90" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">D)
								CHEQUEO</font></font></p>
							</td>
							<td width="27" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::ESCOGERPLANEADO[$reportedelocomotora->escoger_planeado]  === 'CHEQUEO' and $reportedelocomotora::PLANEADO[$reportedelocomotora->planeado] === 'NO')
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								  )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								  )</font></font></p>
								@endif
							</td>
						</tr>
					</table>
					<p lang="es-ES-u-co-trad" class="western" style="margin-top: 0.11cm; margin-bottom: 0.11cm; line-height: 100%">


					</p>
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr valign="top">
				<td width="5" height="6" style="border-top: 1px solid #000000; border-bottom: none; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-ES" class="western" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<br/>
<br/>

					</p>
				</td>
				<td colspan="4" width="1000000" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: none; border-right: none; padding: 0cm">
					<p lang="es-ES" class="western" style="margin-top: 0.21cm; text-transform: uppercase;"><font face="Spranq eco sans, sans-serif" style="font-size: 7pt">DESCRIPCIÓN
					DE LA FALLA: <u>{{ $reportedelocomotora->descripcion_falla }}</u>
				</font>
					
				</td>
				<td width="4360" style="border-top: 1px solid #000000; border-bottom: none; border-left: none; border-right: 4.50pt double #000000; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr>
				<td colspan="6" width="677" height="6" valign="top" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><b>RAZÓN
					DE LA FALLA:</b></font></font></p>
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr>
				<td colspan="6" width="677" height="6" valign="top" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western">   
					</p>
					<table width="100%" cellpadding="4" cellspacing="0">
						<col width="48*">
						<col width="20*">
						<col width="55*">
						<col width="28*">
						<col width="65*">
						<col width="39*">
						<tr valign="top">
							<td width="19%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">A)
								MALA OPERACIÓN</font></font></p>
							</td>
							<td width="8%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'MALA OPERACIÓN')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="22%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">D)
								MAL INSTALADO</font></font></p>
							</td>
							<td width="11%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'MAL INSTALADO')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="25%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">G)
								RUTINA DE TRABAJO</font></font></p>
							</td>
							<td width="15%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'RUTINA DE TRABAJO')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
						</tr>
						<tr valign="top">
							<td width="19%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">B)
								MAL DISEÑO</font></font></p>
							</td>
							<td width="8%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'MAL DISEÑO')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="22%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">E)
								DESGASTE PREMATURO</font></font></p>
							</td>
							<td width="11%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'DESGASTE PREMATURO')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="25%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">H)
								SERVICIO DEFICIENTE</font></font></p>
							</td>
							<td width="15%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'SERVICIO DEFICIENTE')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
						</tr>
						<tr valign="top">
							<td width="19%" height="38" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">C)
								MAL ARMADO</font></font></p>
							</td>
							<td width="8%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'MAL ARMADO')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="22%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">F)
								SOBRECARGA</font></font></p>
							</td>
							<td width="11%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'SOBRECARGA')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="25%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">I)
								 OTRA</font></font></p>
							</td>
							<td width="15%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONFALLA[$reportedelocomotora->razon_falla] === 'OTRA')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
						</tr>
						<tr valign="top">
							<td colspan="3" width="48%" height="20" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">HORAS
								HOMBRE TOTALES USADAS EN EL TRABAJO</font></font></p>
							</td>
							<td width="11%" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="25%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">HORAS-HOMBRE
								                                                    </font></font>
								</p>
							</td>
							<td width="15%" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
						</tr>
						<tr valign="top">
							<td colspan="3" width="48%" style="border: none; padding: 0cm">
								@if (!empty($reportetiempoconteo))
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">N°
								DE PERSONAS: <u>__{{$reportetiempoconteo}}__</u> </font></font>
								</p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">N°
								DE PERSONAS:___<u face="Spranq eco sans, sans-serif" class="western">S/N</u>___ </font></font>
								</p>
								@endif
							</td>
							<td width="11%" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="25%" style="border: none; padding: 0cm">
								@if (!empty($reportetiempoconteo))
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"> <u>______{{$reportetiemposuma*$reportetiempoconteo}}_______</u></font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">_______<u face="Spranq eco sans, sans-serif" class="western">S/N</u>______</font></font></p>
								@endif
							</td>
							<td width="15%" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
						</tr>
						<tr valign="top">
							<td colspan="3" width="48%" style="border: none; padding: 0cm">
								@if (!empty($reportetiemposuma))
								<p lang="es-ES" class="western" style="margin-top: 0.42cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">HORAS
								DEL EQUIPO EN EL TALLER:   ____<u>{{$reportetiemposuma}}</u>____</font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.42cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">HORAS
								DEL EQUIPO EN EL TALLER:   ___<u face="Spranq eco sans, sans-serif" class="western">S/N</u>___</font></font></p>
								@endif
							</td>
							<td width="11%" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="25%" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
							<td width="15%" style="border: none; padding: 0cm">
								<p lang="es-ES-u-co-trad" class="western"><br/>

								</p>
							</td>
						</tr>
					</table>
					<p lang="es-ES" class="western" style="margin-top: 0.11cm; margin-bottom: 0.11cm">


					</p>
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr>
				<td colspan="6" width="677" height="6" valign="top" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><b>RAZÓN
					DE LA DEMORA</b></font></font></p>
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr>
				<td colspan="6" width="677" height="6" valign="top" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western"> 
					</p>
					<table width="100%" cellpadding="4" cellspacing="0">
						<col width="82*">
						<col width="27*">
						<col width="101*">
						<col width="46*">
						<tr valign="top">
							<td width="32%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">1)
								ESPERANDO POR MANO DE OBRA:</font></font></p>
							</td>
							<td width="10%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'ESPERANDO POR MANO DE OBRA')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="39%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">5)
								ESPERANDO POR EQUIPOS AUXILIARES:</font></font></p>
							</td>
							<td width="18%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'ESPERANDO POR EQUIPOS AUXILIARES')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
						</tr>
						<tr valign="top">
							<td width="32%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">2)
								DIAGNOSTICANDO FALLA:</font></font></p>
							</td>
							<td width="10%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'DIAGNOSTICANDO FALLA')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="39%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">6)
								MODIFICANDO O ADAPTANDO REPUESTOS:</font></font></p>
							</td>
							<td width="18%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'MODIFICANDO O ADAPTANDO REPUESTOS')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
						</tr>
						<tr valign="top">
							<td width="32%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">3)
								ESPERANDO REPUESTO:  </font></font>
								</p>
							</td>
							<td width="10%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'ESPERANDO REPUESTO')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="39%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">7)
								HORAS NO PROGRAMADAS: </font></font>
								</p>
							</td>
							<td width="18%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'HORAS NO PROGRAMADAS')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
						</tr>
						<tr valign="top">
							<td width="32%" style="border: none; padding: 0cm">
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">4)
								ESPERANDO POR HERRAMIENTAS:</font></font></p>
							</td>
							<td width="10%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'HORAS NO PROGRAMADAS')
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" align="left" style="margin-top: 0.11cm">
								<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
							<td width="39%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'OTROS MOTIVOS')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">8)
								OTROS MOTIVOS: <u>{{ $reportedelocomotora->otro_motivo }}</u></font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">8)
								OTROS MOTIVOS:  _________________________________</font></font></p>
								@endif
							</td>
							<td width="18%" style="border: none; padding: 0cm">
								@if ($reportedelocomotora::RAZONDEMORA[$reportedelocomotora->razon_demora] === 'OTROS MOTIVOS')
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">( X
								 )</font></font></p>
								@else
								<p lang="es-ES" class="western" style="margin-top: 0.11cm"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">(
								 )</font></font></p>
								@endif
							</td>
						</tr>
					</table>
					<p lang="es-ES" class="western" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					</p>
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr>
				<td colspan="6" width="677" height="6" valign="top" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><b>MATERIAL
					UTILIZADO</b></font></font></p>
				</td>
			</tr>
		</tbody>
		<tbody>
			<tr valign="top">
				<td colspan="3" width="156" height="6" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">CANTIDAD</font></font></p>
				</td>
				<td width="139" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">CÓDIGO</font></font></p>
				</td>
				<td colspan="2" width="358" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">DESCRIPCIÓN</font></font></p>
				</td>
			</tr>
		</tbody>
		<tbody>
			@forelse($reporteconsumible as $consumiblelocomotora)
			<tr valign="top">
				<td colspan="3" width="156" height="9" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-ES" class="western" style="margin-top: 0.11cm; margin-bottom: 0.11cm" align="center">
					<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">{{$consumiblelocomotora->cantidad}}</font>

					</p>
				</td>
				<td width="139" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-ES" class="western text-center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font size="1"  face="Spranq eco sans, sans-serif" style="font-size: 7pt">{{$consumiblelocomotora->materiales->sap}}</font>	

					</p>
				</td>
				<td colspan="2" width="358" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">{{$consumiblelocomotora->materiales->descripcion}}</font>

					</p>
				</td>
			</tr>
			@empty
            <tr valign="top">
				<td colspan="3" width="156" height="9" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-ES" class="western" style="margin-top: 0.11cm; margin-bottom: 0.11cm" align="center">
					<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">S/N</font>

					</p>
				</td>
				<td width="139" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-ES" class="western text-center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font size="1"  face="Spranq eco sans, sans-serif" style="font-size: 7pt">S/N</font>	

					</p>
				</td>
				<td colspan="2" width="358" style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding: 0cm 0.12cm">
					<p lang="es-ES" class="western" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">S/N</font>

					</p>
				</td>
			</tr>
            @endforelse
		</tbody>
		<tbody>
			<tr>
				<td colspan="4" width="1800" height="62" valign="bottom" style="border-top: 1px solid #000000; border-bottom: 4.50pt double #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.3cm; padding-right: 0cm">
					<p lang="es-ES-u-co-trad" class="western" style="margin-top: 0.42cm; margin-bottom: 0.11cm">
					<font face="Times New Roman, serif"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><span lang="es-ES">SUPERVISOR:
					</span></font></font><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><span lang="es-ES"><u>{{ $reportedelocomotora->datos->nombre }}</u></span></font></font></font></p>
					<p lang="es-ES-u-co-trad" class="western" style="margin-top: 0.42cm; margin-bottom: 0.11cm">
					<font face="Times New Roman, serif"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><span lang="es-ES">FICHA:
					</span></font></font><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><span lang="es-ES"><u>{{ $reportedelocomotora->responsable }}</u></span></font></font></font></p>
				</td>
				<td colspan="2" width="358" valign="top" style="border-top: 1px solid #000000; border-bottom: 4.50pt double #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.3cm; padding-right: 0.2cm">
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt"><b>ORDEN
					GENERADA (SAP): </b></font></font>
					</p>
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<br/>
<br/>

					</p>
					@if (!empty($reportedelocomotora->n_orden))
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">ORDEN
					Nº : <u>{{ $reportedelocomotora->n_orden }}</u></font></font></p>
					@else
					<p lang="es-ES" class="western" align="center" style="margin-top: 0.11cm; margin-bottom: 0.11cm">
					<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">ORDEN
					Nº :_____________________________</font></font></p>
					@endif
				</td>
			</tr>
		</tbody>
	</table>
</dl>
<p lang="es-ES-u-co-trad" class="western"><br/>

</p>
	
	<table width="689" cellpadding="4" cellspacing="3" style="page-break-before: always; background-color: white;" align="center"> 
		<colgroup>
			<col width="128">
			<col width="185">
		</colgroup>
		<colgroup>
			<col width="220">
			<col width="105">
		</colgroup>
		<tr valign="top">
			<td width="128" style="border-top: 4.50pt double #000000; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.42cm">
				<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 6pt">FERRO-4237A
				 REV. 05/06</font></font></p>
			</td>
			<td colspan="2" width="416" style="border-top: 4.50pt double #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font face="Spranq eco sans, sans-serif"><b>REPORTE DE TRABAJOS
				EJECUTADOS POR EL TALLER</b></font></p>
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 8pt"><b>(CONTINUACIÓN)</b></font></font></p>
			</td>
			<td width="105" style="border-top: 4.50pt double #000000; border-bottom: 1px solid #000000; border-left: none; border-right: 4.50pt double #000000; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0.1cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.42cm">
				<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 7pt">PÁG.:
				<u>__</u><u>2</u><u>__</u>  DE: <u>__</u><u>2</u><u>__</u></font></font></p>
			</td>
		</tr>
		<tr>
			<td colspan="4" width="671" valign="top" style="border-top: none; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: 4.50pt double #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
				<p lang="es-ES-u-co-trad" class="western" style="margin-top: 0.11cm">
				 <font face="Times New Roman, serif"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 8pt"><u>MANO
				DE OBRA</u></font></font></font></p>
			</td>
		</tr>
		<tr valign="top">
			<td width="128" style="border-top: none; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 8pt"><b>FICHA</b></font></font></p>
			</td>
			<td width="185" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 8pt"><b>NOMBRE</b></font></font></p>
			</td>
			<td width="220" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 8pt"><b>FECHA</b></font></font></p>
			</td>
			<td width="105" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
				<p lang="es-ES-u-co-trad" class="western" align="center"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 8pt"><b>TOTAL
				</b></font></font>
				</p>
				<p lang="es-ES-u-co-trad" class="western" align="center"><font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 8pt"><b>(HORAS)</b></font></font></p>
			</td>
		</tr>
		<tr valign="top">
			@forelse($reportetiempo as $tiempolocomotora)
			<td width="128" style="border-top: none; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">{{$tiempolocomotora->responsable}}</font>

				</p>
			</td>
			<td width="185" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">{{$tiempolocomotora->datos->nombre}}</font>

				</p>
			</td>
			<td width="220" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">{{\Carbon\Carbon::parse($tiempolocomotora->fecha)->format('d/m/Y')}}</font>

				</p>
			</td>
			<td width="105" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-right: 0.3cm; margin-top: 0.21cm; orphans: 2; widows: 2; background: transparent">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">{{$tiempolocomotora->horas}}</font>

				</p>
			</td>
		</tr>
		@empty
		<tr valign="top">
			<td width="128" style="border-top: none; border-bottom: 1px solid #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">S/N</font>

				</p>
			</td>
			<td width="185" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">S/N</font>

				</p>
			</td>
			<td width="220" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">S/N</font>

				</p>
			</td>
			<td width="105" style="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-right: 0.3cm; margin-top: 0.21cm; orphans: 2; widows: 2; background: transparent">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">S/N</font>

				</p>
			</td>
		</tr>
        @endforelse
		<tr valign="top">
			<td width="128" style="border-top: none; border-bottom: 4.50pt double #000000; border-left: 4.50pt double #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<br/>

				</p>
			</td>
			<td width="185" style="border-top: none; border-bottom: 4.50pt double #000000; border-left: none; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<br/>

				</p>
			</td>
			<td width="220" style="border-top: none; border-bottom: 4.50pt double #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.11cm">
				<font face="Spranq eco sans, sans-serif"><font size="1" style="font-size: 8pt"><b>TOTAL
				H-H</b></font></font></p>
			</td>
			@if (!empty ($tiempolocomotora))
			<td width="105" style="border-top: none; border-bottom: 4.50pt double #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">{{$reportetiemposuma*$reportetiempoconteo}}</font>

				</p>
			</td>
			@else
			<td width="105" style="border-top: none; border-bottom: 4.50pt double #000000; border-left: 1px solid #000000; border-right: 4.50pt double #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
				<p lang="es-ES-u-co-trad" class="western" align="center" style="margin-top: 0.21cm">
				<font size="1" face="Spranq eco sans, sans-serif" style="font-size: 7pt">S/N</font>

				</p>
			</td>
			@endif
		</tr>
	</table>
</dl>
<p lang="es-ES-u-co-trad" class="western"><br/>
</p>
</body>
</html>
</div>
</div>
</div>
</section>
@endsection