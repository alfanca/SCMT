<div class="box box-info padding-1">

    <script type="text/javascript">        

        function seleccion_otro(){

        var selector_motivo = document.getElementById('motivo').value;

        if (selector_motivo == '7') {
            document.getElementById("otro").style.display = '';
            
        }

        else {
            document.getElementById("otro").style.display = 'none';
        }

        }

    </script>

    <div class="box-body">
        
        <h4 class="col-md-12 text-center mt-3">Datos Generales</h4>
        <div class="mt-2 card-group col-md-12">
        <div class="row col-md-12 my-4">
        <div class="card-group col-md-2">
            {{ Form::label('N° Locomotora') }}
            {{ Form::select('locomotora_id',$locomotoras, $reportedelocomotora->locomotora_id, ['class' => 'form-control' . ($errors->has('locomotora_id') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('locomotora_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="card-group col-md-2">
            {{ Form::label('fecha_entrada') }}
            <input type="datetime" name="fecha_entrada" value="{{old('fecha_entrada') ?? \Carbon\Carbon::parse($reportedelocomotora->fecha_entrada)->format('d/m/Y H:i') ?? \Carbon\Carbon::now()->format('d/m/Y H:i')}}" class="form-control ($errors->has('fecha_entrada') ? ' is-invalid' : '')">
            {!! $errors->first('fecha_entrada', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        @if(!empty($reportedelocomotora->fecha_salida))
        <div class="card-group col-md-2">
            {{ Form::label('fecha_salida') }}
             <input type="datetime" name="fecha_salida" value="{{old('fecha_salida') ?? \Carbon\Carbon::parse($reportedelocomotora->fecha_salida)->format('d/m/Y H:i') ?? \Carbon\Carbon::now()->format('d/m/Y H:i')}}" class="form-control ($errors->has('fecha_entrada') ? ' is-invalid' : '')">
            {!! $errors->first('fecha_salida', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        @endif
        <div class="card-group col-md-2">
            {{ Form::label('Estatus') }}
            <select name="estatus" class="form-control">
            
            @if(!empty($reportedelocomotora->n_orden and !empty($reportedelocomotora->fecha_salida) or $reportedelocomotora->locomotora->numero =='S/N'))
            <option value="LIBERADA">LIBERAR</option>
            <option value="CERRADA">CERRAR</option>
            @endif

        </select>
        </div>
        <div class="card-group col-md-2">
            {{ Form::label('Centro de Costo') }}
            {{ Form::select('ceco', $ceco, $reportedelocomotora->ceco, ['class' => 'form-control' . ($errors->has('ceco') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('ceco', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        </div>
        </div>
        <hr>
        <div class="mt-4 card-group col-md-12">
        <h4 class="col-md-12 text-center">Mantenimiento</h4>
        <div class="mt-2 card-group col-md-12">
        <div class="row col-md-12 my-4">
        <div class="card-group col-md-2">

            {{ Form::label('¿Planeado?') }}

            @if(Gate::check('isplanificador') || Gate::check('isJefe'))

            {{ Form::select('planeado', $planeado, $reportedelocomotora->planeado, ['class' => 'form-control' . ($errors->has('planeado') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('planeado', '<div class="invalid-feedback">:message</div>') !!}

            @else

            {{ Form::select('planeado', $planeado->forget(0), $reportedelocomotora->planeado, ['class' => 'form-control' . ($errors->has('planeado') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('planeado', '<div class="invalid-feedback">:message</div>') !!}

            @endif
        </div>

        <div class="card-group col-md-4">
            {{ Form::label('Motivo') }}

            @if(Gate::check('isplanificador') || Gate::check('isJefe'))

            {{ Form::select('escoger_planeado',  $escogerplaneado ,$reportedelocomotora->escoger_planeado, ['class' => 'form-control' . ($errors->has('escoger_planeado') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('escoger_planeado', '<div class="invalid-feedback">:message</div>') !!}

            @else

            {{ Form::select('escoger_planeado',  $escogerplaneado->forget(1) ,$reportedelocomotora->escoger_planeado, ['class' => 'form-control' . ($errors->has('escoger_planeado') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('escoger_planeado', '<div class="invalid-feedback">:message</div>') !!}

            @endif
        </div>

        </div>
        <br>
        <div class="form-group col-md-12">
            {{ Form::label('Decripción') }}
            <br>
            {{ Form::textarea('descripcion_falla', $reportedelocomotora->descripcion_falla, ['class' => 'form-control' . ($errors->has('descripcion_falla') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese texto']) }}
            {!! $errors->first('descripcion_falla', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        </div>
        </div>

        <hr>
        <h4 class="col-md-12 text-center">Razon de la Falla / Razon de Demora</h4>
        <div class="mt-2 card-group col-md-12">
        <div class="row col-md-12 my-4">

        <div class="card-group col-md-4">
            {{ Form::label('Razon de la Falla') }}
            {{ Form::select('razon_falla', $razonfalla, $reportedelocomotora->razon_falla, ['class' => 'form-control' . ($errors->has('razon_falla') ? ' is-invalid' : ''), 'placeholder' => 'Seleccione']) }}
            {!! $errors->first('razon_falla', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="card-group col-md-4">
            {{ Form::label('Razon de la Demora') }}
            {{ Form::select('razon_demora', $razondemora,$reportedelocomotora->razon_demora, ['class' => 'form-control' . ($errors->has('razon_demora') ? ' is-invalid' : ''), 'onclick' => 'seleccion_otro()','id' => 'motivo','placeholder' => 'Seleccione']) }}
            {!! $errors->first('razon_demora', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div id="otro" style="display: none;" class="card-group col-md-3">
            {{ Form::label('Otro Motivo') }}
            {{ Form::text('otro_motivo', $reportedelocomotora->otro_motivo, ['class' => 'form-control' . ($errors->has('otro_motivo') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese texto']) }}
            {!! $errors->first('otro_motivo', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        </div>
        </div>
   
       
        <hr>
        <h4 class="col-md-12 text-center">Responsables</h4>
        <div class="mt-2 card-group col-md-12">
        <div class="row col-md-12 my-4">

        <div class="card-group col-md-4">
            {{ Form::label('N° Orden ó Aviso') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('n_orden', $reportedelocomotora->n_orden, ['class' => 'form-control' . ($errors->has('n_orden') ? ' is-invalid' : ''), 'min' => '0','placeholder' => 'Ingrese N° Orden ó Aviso']) }}
            {!! $errors->first('n_orden', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="card-group col-md-6">
            {{ Form::label('responsable:') }}
            <div class="col-md-6">
            <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
            <select name="responsable" class="responsable col-md-6" style="width: 100%">
              @if (!empty($reportedelocomotora->datos->nombre))
                <option value="{{$reportedelocomotora->responsable}}">{{ $reportedelocomotora->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
            @endif

            </div>
          </div>
        </div>
    </div>
    </div>

    </div>

    <hr>
    <div class="card-footer justify-content-center mt-2">
       <a href="{{route('reportedelocomotoras.index')}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
         <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
     </div>
</div>