@extends('layouts.app', ['activePage' => 'locomotoras', 'titlePage' => __('Locomotoras')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Reportetiempolocomotora</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('reportetiempolocomotoras.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Reportelocomotora Id:</strong>
                            {{ $reportetiempolocomotora->reportelocomotora_id }}
                        </div>
                        <div class="form-group">
                            <strong>Fecha:</strong>
                            {{ $reportetiempolocomotora->fecha }}
                        </div>
                        <div class="form-group">
                            <strong>Responsable:</strong>
                            {{ $reportetiempolocomotora->responsable }}
                        </div>
                        <div class="form-group">
                            <strong>Horas:</strong>
                            {{ $reportetiempolocomotora->horas }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Crea:</strong>
                            {{ $reportetiempolocomotora->usuario_crea }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Actualiza:</strong>
                            {{ $reportetiempolocomotora->usuario_actualiza }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
