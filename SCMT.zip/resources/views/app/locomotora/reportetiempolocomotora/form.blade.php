<div class="box box-info padding-1">
    <div class="box-body">
        


        <div class="form-group" style="visibility: hidden;">
            {{ Form::label('Reportes') }}
            <input type="text" name="reportelocomotora_id" value="{{$_GET['id']}}">
        </div>

        <div class="card-group">
            {{ Form::label('Fecha:') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha', $reportetiempolocomotora->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha']) }}
            {!! $errors->first('fecha', '<div class="invalid-feedback">:message</p>') !!}&nbsp&nbsp&nbsp&nbsp
       
            {{ Form::label('responsable') }}&nbsp&nbsp

            <div class="col-md-4">
            <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
            <select name="responsable" class="responsable col-md-6" style="width: 100%">
              @if (!empty($reportetiempolocomotora->datos->nombre))
                <option value="{{$reportetiempolocomotora->responsable}}">{{ $reportetiempolocomotora->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
            @endif

            </div>
          </div>&nbsp&nbsp&nbsp
           

            {{ Form::label('Ingrese las Horas') }}&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('horas', $reportetiempolocomotora->horas, ['class' => 'form-control' . ($errors->has('horas') ? ' is-invalid' : ''), 'step' => '0.1', 'min' => '0','placeholder' => 'Ingrese Horas']) }}
            {!! $errors->first('horas', '<div class="invalid-feedback">:message</p>') !!}
        </div>

    </div>
    <div class="box-footer mt20 mt-4 text-center">
        <a href="/locomotoras/reportedelocomotoras/{{$_GET['id']}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
        <button type="submit" class="btn btn-primary">Crear</button>
    </div>
</div>