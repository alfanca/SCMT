@extends('layouts.app', ['activePage' => 'reportelocomotora', 'titlePage' => __('Registrar Mano de Obra')])
@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">


                <div class="card card-default">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Registar Mano de Obra</h4>
                      </div>
                      
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('reportetiempolocomotoras.store') }}"  role="form" enctype="multipart/form-data">
                            @csrf

                            @include('app.locomotora.reportetiempolocomotora.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
