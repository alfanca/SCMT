  <div class="card-body ">
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Numero') }}</label>
      <div class="col-sm-7">
        <div class="form-group{{ $errors->has('numero') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="numero" id="input-name" type="text" placeholder="{{ __('Ingrese numero de locomotora') }}"
            value="{{ old('numero') ?? $locomotora->numero }}" required="true"/>
          @if ($errors->has('numero'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('numero') }}</span>
          @endif
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('Centro de Costo') }}</label>
      <div class="col-sm-7">
          <div class="form-group{{ $errors->has('ceco') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('ceco') ? ' is-invalid' : '' }}"
                name="ceco" id="input-ceco"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($locomotora->centrocosto() as $ceco)
                <option value="{{$ceco}}" {{$locomotora->ceco == $ceco ? 'selected' : '' }}>{{$ceco}}</option>
              @endforeach
            </select>


            @if ($errors->has('ceco'))
              <span id="name-error" class="error text-danger" for="input-ceco">{{ $errors->first('ceco') }}</span>
            @endif
          </div>
        </div>
      </div>
    <div class="row">
      <label class="col-sm-2 col-form-label">{{ __('N° Plan') }}</label>
      <div class="col-sm-2">
        <div class="form-group{{ $errors->has('n_plan') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="n_plan" id="input-name" type="number" placeholder="{{ __('Ingrese N° plan') }}"
            value="{{ old('n_plan') ?? $locomotora->n_plan }}">
          @if ($errors->has('n_plan'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('n_plan') }}</span>
          @endif
        </div>
      </div>
      <label class="col-sm-2 col-form-label">{{ __('Frecuencia de Mantenimiento') }}</label>
      <div class="col-sm-3">
        <div class="form-group{{ $errors->has('mant') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}"
            name="mant" id="input-name" type="number" placeholder="{{ __('Ingrese Frecuencia') }}"
            value="{{ old('mant') ?? $locomotora->mant }}">
          @if ($errors->has('mant'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('mant') }}</span>
          @endif
        </div>
      </div>
    </div>
    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Tipo') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('tipo') ? ' has-danger' : '' }}">

            <select class="custom-select form-control{{ $errors->has('tipo') ? ' is-invalid' : '' }}"
                name="tipo" id="input-tipo"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($locomotora->tipoLocomotoras() as $tipo)
                <option value="{{$tipo}}" {{$locomotora->tipo == $tipo ? 'selected' : '' }}>{{$tipo}}</option>
              @endforeach
            </select>


            @if ($errors->has('tipo'))
              <span id="name-error" class="error text-danger" for="input-tipo">{{ $errors->first('tipo') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Marca') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('marca') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('marca') ? ' is-invalid' : '' }}"
              name="marca" id="input-marca" type="text" placeholder="{{ __('Marca de locomotora') }}"
              value="{{ old('marca') ?? $locomotora->marca }}" required="true"/>
            @if ($errors->has('marca'))
              <span id="name-error" class="error text-danger" for="input-marca">{{ $errors->first('marca') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Modelo') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('modelo') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('modelo') ? ' is-invalid' : '' }}"
              name="modelo" id="input-modelo" type="text" placeholder="{{ __('Modelo de locomotora') }}"
              value="{{ old('modelo') ?? $locomotora->modelo }}" required="true"/>
            @if ($errors->has('modelo'))
              <span id="name-error" class="error text-danger" for="input-modelo">{{ $errors->first('modelo') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('Ubicacion') }}</label>
        <div class="col-sm-7">
          <div class="form-group{{ $errors->has('ubicacion') ? ' has-danger' : '' }}">
            <input class="form-control{{ $errors->has('ubicacion') ? ' is-invalid' : '' }}"
              name="ubicacion" id="input-ubicacion" type="text" placeholder="{{ __('Ubicación de locomotora') }}"
              value="{{ old('ubicacion') ?? $locomotora->ubicacion }}" required="true"/>
            @if ($errors->has('ubicacion'))
              <span id="name-error" class="error text-danger" for="input-ubicacion">{{ $errors->first('ubicacion') }}</span>
            @endif
          </div>
        </div>
    </div>

    <div class="row">
        <label class="col-sm-2 col-form-label">{{ __('¿Desincorporada?') }}</label>
        <div class="col-sm-2">
          <div class="form-group{{ $errors->has('estatus') ? ' has-danger' : '' }}">
            <select class="text-center custom-select form-control{{ $errors->has('estatus') ? ' is-invalid' : '' }}"
                name="estatus" id="input-estatus"placeholder="{{ __('Ingrese potencia de locomotora') }}" required="true"
              >
              <option value="">SELECCIONE</option>
              @foreach($locomotora->estatusLocomotoras() as $clave => $valor)
                <option value="{{$clave}}" {{$locomotora->estatus == $valor ? 'selected' : '' }}>{{$valor}}</option>
              @endforeach
            </select>
            @if ($errors->has('estatus'))
              <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('estatus') }}</span>
            @endif
          </div>
        </div>

      <label class="col-sm-2 col-form-label">{{ __('Fecha Desincorporación:') }}</label>
      <div class="col-sm-2">
        <div class="form-group{{ $errors->has('fecha_desincorporacion') ? ' has-danger' : '' }}">
          <input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} text-center"
            name="fecha_desincorporacion" id="input-name" type="date"
            value="{{ old('fecha_desincorporacion') ?? $locomotora->fecha_desincorporacion }}" />
          @if ($errors->has('fecha_desincorporacion'))
            <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('fecha_desincorporacion') }}</span>
          @endif
        </div>
      </div>


    </div>
  </div>
