@extends('layouts.app', ['activePage' => 'preventivolocomotora', 'titlePage' => __('Actualizar Actividades de Preventivo')])
@section('content')


    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Actualizar Actividades de Preventivo</h4>
                      </div>
                      
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('detallepreventivolocomotora.update', $detallepreventivolocomotora->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('app.locomotora.detallepreventivolocomotora.formedit')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
