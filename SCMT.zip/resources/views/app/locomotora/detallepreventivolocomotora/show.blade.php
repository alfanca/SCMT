@extends('layouts.app', ['activePage' => 'locomotoras', 'titlePage' => __('Locomotoras')])
@section('content')

    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Detallepreventivolocomotora</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('detallepreventivolocomotora.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Reportelocomotora Id:</strong>
                            {{ $detallepreventivolocomotora->reportelocomotora_id }}
                        </div>
                        <div class="form-group">
                            <strong>Maestropreventivo Id:</strong>
                            {{ $detallepreventivolocomotora->maestropreventivo_id }}
                        </div>
                        <div class="form-group">
                            <strong>Locomotora:</strong>
                            {{ $detallepreventivolocomotora->locomotora }}
                        </div>
                        <div class="form-group">
                            <strong>Fecha Inicio:</strong>
                            {{ $detallepreventivolocomotora->fecha_inicio }}
                        </div>
                        <div class="form-group">
                            <strong>Fecha Fin:</strong>
                            {{ $detallepreventivolocomotora->fecha_fin }}
                        </div>
                        <div class="form-group">
                            <strong>Cumplimiento:</strong>
                            {{ $detallepreventivolocomotora->cumplimiento }}
                        </div>
                        <div class="form-group">
                            <strong>Nota:</strong>
                            {{ $detallepreventivolocomotora->nota }}
                        </div>
                        <div class="form-group">
                            <strong>Responsable:</strong>
                            {{ $detallepreventivolocomotora->responsable }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Crea:</strong>
                            {{ $detallepreventivolocomotora->usuario_crea }}
                        </div>
                        <div class="form-group">
                            <strong>Usuario Actualiza:</strong>
                            {{ $detallepreventivolocomotora->usuario_actualiza }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
