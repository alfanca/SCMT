<div class="box box-info padding-1">
    <div class="box-body">
        
       <input type="number" name="maestropreventivo_id" value="{{$_GET['id_m']}}" hidden="yes">
       <input type="number" name="locomotora" value="{{$_GET['loc']}}" hidden="yes">
       <input type="number" name="reportelocomotora_id" value="{{$_GET['idreporte']}}" hidden="yes">



         <div class="card-group">
            {{ Form::label('fecha_inicio:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_inicio', $detallepreventivolocomotora->fecha_inicio, ['class' => 'form-control' . ($errors->has('fecha_inicio') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Inicio']) }}
            {!! $errors->first('fecha_inicio', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('fecha_fin:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_fin', $detallepreventivolocomotora->fecha_fin, ['class' => 'form-control' . ($errors->has('fecha_fin') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Fin']) }}
            {!! $errors->first('fecha_fin', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('cumplimiento') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('cumplimiento', $detallepreventivolocomotora->cumplimiento, ['class' => 'form-control text-center col-9' . ($errors->has('cumplimiento') ? ' is-invalid' : ''), 'step'=>'0.1', 'min'=>'0','max'=>'100','placeholder' => 'Cumplimiento %']) }}
            {!! $errors->first('cumplimiento', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        </div>
        <div class="card-group mt-5">
        
            {{ Form::label('nota') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('nota', $detallepreventivolocomotora->nota, ['class' => 'form-control col-12' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese nota']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp


            {{ Form::label('responsable:') }}
            <div class="col-md-4">
            <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
            <select name="responsable" class="responsable col-md-6" style="width: 100%">
              @if (!empty($detallepreventivolocomotora->datos->nombre))
                <option value="{{$detallepreventivolocomotora->responsable}}">{{ $detallepreventivolocomotora->datos->nombre}}</option>
              @endif
            </select>
            @if ($errors->has('responsable'))
              <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
            @endif

            </div>
          </div>
        </div>


    </div>
    <div class="card-footer justify-content-center mt-2">
       <a href="/locomotoras/maestropreventivolocomotora/{{$_GET['id_m']}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
         <button type="submit" class="btn btn-primary">{{ __('Actualizar') }}</button>
     </div>
</div>