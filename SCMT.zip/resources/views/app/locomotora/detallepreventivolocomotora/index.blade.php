@extends('layouts.app', ['activePage' => 'locomotoras', 'titlePage' => __('Locomotoras')])
@section('content')

    <section class="content container-fluid">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                {{ __('Detallepreventivolocomotora') }}
                            </span>

                             <div class="float-right">
                                <a href="{{ route('detallepreventivolocomotora.create') }}" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  {{ __('Create New') }}
                                </a>
                              </div>
                        </div>
                    </div>
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Reportelocomotora Id</th>
										<th>Maestropreventivo Id</th>
										<th>Locomotora</th>
										<th>Fecha Inicio</th>
										<th>Fecha Fin</th>
										<th>Cumplimiento</th>
										<th>Nota</th>
										<th>Responsable</th>
										<th>Usuario Crea</th>
										<th>Usuario Actualiza</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($detallepreventivolocomotoras as $detallepreventivolocomotora)
                                        <tr>
                                            <td>{{ ++$i }}</td>
                                            
											<td>{{ $detallepreventivolocomotora->reportelocomotora_id }}</td>
											<td>{{ $detallepreventivolocomotora->maestropreventivo_id }}</td>
											<td>{{ $detallepreventivolocomotora->locomotora }}</td>
											<td>{{ $detallepreventivolocomotora->fecha_inicio }}</td>
											<td>{{ $detallepreventivolocomotora->fecha_fin }}</td>
											<td>{{ $detallepreventivolocomotora->cumplimiento }}</td>
											<td>{{ $detallepreventivolocomotora->nota }}</td>
											<td>{{ $detallepreventivolocomotora->responsable }}</td>
											<td>{{ $detallepreventivolocomotora->usuario_crea }}</td>
											<td>{{ $detallepreventivolocomotora->usuario_actualiza }}</td>

                                            <td>
                                                <form action="{{ route('detallepreventivolocomotora.destroy',$detallepreventivolocomotora->id) }}" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="{{ route('detallepreventivolocomotora.show',$detallepreventivolocomotora->id) }}"><i class="fa fa-fw fa-eye"></i> Show</a>
                                                    <a class="btn btn-sm btn-success" href="{{ route('detallepreventivolocomotora.edit',$detallepreventivolocomotora->id) }}"><i class="fa fa-fw fa-edit"></i> Edit</a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                {!! $detallepreventivolocomotoras->links() !!}
            </div>
        </div>
    </div>
</section>
@endsection
