<div class="box box-info padding-1">
    <div class="box-body">
        
       <input type="number" name="maestropreventivo_id" value="{{$_GET['id_m']}}" hidden="yes">
       <input type="number" name="locomotora" value="{{$_GET['loc']}}" hidden="yes">



         <div class="card-group">
            {{ Form::label('fecha_inicio:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_inicio', $detallepreventivolocomotora->fecha_inicio, ['class' => 'form-control' . ($errors->has('fecha_inicio') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Inicio']) }}
            {!! $errors->first('fecha_inicio', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('fecha_fin:') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::date('fecha_fin', $detallepreventivolocomotora->fecha_fin, ['class' => 'form-control' . ($errors->has('fecha_fin') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Fin']) }}
            {!! $errors->first('fecha_fin', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

            {{ Form::label('cumplimiento') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::number('cumplimiento', $detallepreventivolocomotora->cumplimiento, ['class' => 'form-control text-center col-9' . ($errors->has('cumplimiento') ? ' is-invalid' : ''), 'step'=>'0.1', 'min'=>'0','max'=>'100','placeholder' => 'Cumplimiento %']) }}
            {!! $errors->first('cumplimiento', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        </div>
        <div class="card-group mt-5">
        
            {{ Form::label('nota') }}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            {{ Form::text('nota', $detallepreventivolocomotora->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese nota']) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

        </div>




        <div class="form-group" style="margin-left: 77%">
        <label style="font-weight: bold;">Buscador:</label>
        <br>
        <input type="text" class="form-control pull-right" id="search" placeholder="Escriba su Busqueda">
        </div>
       <div class="table-responsive mt-4">
                <table class="table" id="myTable" style="width: 100%;">
                  <thead class=" text-primary">
                    <tr>
                        <th class="text-center col-1">Seleccionar todo (<input type="checkbox" onclick="marcar(this);" />)</th>
                        <th class="text-center col-1">N° Orden</th>
                        <th class="text-center col-1">N° Loc</th>
                        <th class="text-center col-1">Descripción</th>
                        <th class="text-center col-1">Fecha Inicio</th>
                        <th class="text-center col-1">Fecha Fin</th>
                        <th class="text-center col-1">Responsable</th>
                        <th class="text-center col-1">¿Planeado?</th>
                        <th class="text-center col-6">Motivo</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($reportedelocomotoras->where('locomotora_id', $_GET['filtro']) as $reporte)
                                        <tr>
                      <td class="text-center"> <input type="checkbox" name="reportelocomotora_id[]" value="{{$reporte->id}}"></td>                  
                      <td class="text-center">{{$reporte->n_orden }}</td>
                      <td class="text-center">{{$reporte->locomotora->numero }}</td>
                      <td class="col-4">{{$reporte->descripcion_falla}}</td>
                      <td class="text-center">{{\Carbon\Carbon::parse($reporte->fecha_entrada)->format('d/m/Y')}}</td>
                      <td class="text-center">{{\Carbon\Carbon::parse($reporte->fecha_salida)->format('d/m/Y')}}</td>
                      <td class="text-center">
                        
                        <div class="form-group{{ $errors->has('responsable') ? ' has-danger' : '' }}">
                      <select name="responsable[]" class="responsable col-md-6" style="width: 100%">
                        @if (!empty($reporte->responsable))
                          <option value="{{$reporte->responsable}}">{{$reporte->datos->nombre}}</option>
                        @endif
                      </select>
                      @if ($errors->has('responsable'))
                        <span id="name-error" class="error text-danger" for="input-responsable">{{ $errors->first('responsable') }}</span>
                      @endif

                      </div>

                      </td>
                      <td class="text-center" style="text-transform: uppercase;">{{$reporte::PLANEADO[$reporte->planeado] }}</td>
                      <td class="text-center">{{$reporte::ESCOGERPLANEADO[$reporte->escoger_planeado] }}</td>
                    </tr>
                    @empty
                    <tr><td colspan="7">No hay registradas</td></tr>
                   @endforelse
                  </tbody>
                </table>
              </div>


<script src="{{ asset('js') }}/jQueryv310.js"></script>

<script>
 // Write on keyup event of keyword input element
 $(document).ready(function(){
 $("#search").keyup(function(){
 _this = this;
 // Show only matching TR, hide rest of them
 $.each($("#myTable tbody tr"), function() {
 if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase()) === -1)
 $(this).hide();
 else
 $(this).show();
 });
 });
});
</script>  

<script type="text/javascript">
  function marcar(source) 
  {
    checkboxes=document.getElementsByTagName('input'); //obtenemos todos los controles del tipo Input
    for(i=0;i<checkboxes.length;i++) //recoremos todos los controles
    {
      if(checkboxes[i].name == "reportelocomotora_id[]") //solo si es un checkbox entramos
      {
        checkboxes[i].checked=source.checked; //si es un checkbox le damos el valor del checkbox que lo llamó (Marcar/Desmarcar Todos)
      }
    }
  }
</script>  


    </div>
    <div class="card-footer justify-content-center mt-2">
       <a href="/locomotoras/maestropreventivolocomotora/{{$_GET['id_m']}}" class="btn btn-danger">{{ __('Cancelar') }}</a>
         <button type="submit" class="btn btn-primary">{{ __('Crear') }}</button>
     </div>
</div>