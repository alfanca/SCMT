@extends('layouts.app', ['activePage' => 'preventivolocomotora', 'titlePage' => __('Historial de Programas de Locomotora Detalles')])
@section('content')
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary d-flex justify-content-between">
                      <div class="col-md-6">
                        <h4 class="card-title ">Historial de Programas de Locomotora Detalles</h4>
                        <p class="card-category">Busqueda de Programas de Locomotora Detalles</p>
                      </div>
                    <div class="col-md-6" style="text-align: right;">
                        <a rel="tooltip"
                            href="{{route('maestropreventivolocomotora.index')}}" class="btn btn-sm btn-rounded" style="background-color: #9B945F;"><i class="fa fa-fw fa-reply"></i> Regresar
                        </a>  
                      </div>
                    </div>


             <div class="card-body">

           <form method="get" autocomplete="off" action="{{route('periodo.programa.locomotora.detalles')}}" class="form-horizontal" role="form">
            @include('app.comun.nav_calendario_busqueda_sinboton_reporte')
           </form>

          
           </div>

           <div class="card-group">
               
               <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        <div class="col-md-3 text-center" style="background-color: #28a745; color: white;border-top-left-radius: 10px;">
           
                          <i class="fas fa-sort-amount-up-alt text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Inspecciones</strong></div>
                          <p class="text-center" style="font-size: 18px;">{{ $programasdetalle_all->count('cumplimiento') }}</p>
                        </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-3 col-md-4 mt-1">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                  <div class="card-content">
                      <div class="media align-items-stretch">
                        @if ($programasdetalle_all->count('cumplimiento') != 0)
                        @if (round(($programasdetalle_all->sum('cumplimiento'))/$programasdetalle_all->count('cumplimiento')) < 50)
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
                        @elseif (round(($programasdetalle_all->sum('cumplimiento'))/$programasdetalle_all->count('cumplimiento')) >= 50)
                        <div class="col-md-3 text-center" style="background-color: #ffc107; color: white;border-top-left-radius: 10px;">
                        @elseif (round(($programasdetalle_all->sum('cumplimiento'))/$programasdetalle_all->count('cumplimiento')) >= 80)
                        <div class="col-md-3 text-center" style="background-color: #28a745; color: white;border-top-left-radius: 10px;">
                        @endif
                        @else
                        <div class="col-md-3 text-center" style="background-color: #dc3545; color: white;border-top-left-radius: 10px;">
                        @endif
                          <i class="fa fa-percent text-center mt-4" style="font-size: 25px;"></i>
                        
                      </div>
                        <div class="media-body col-sm-10">
                          <div class="card-text mt-1 text-center"  style="font-size: 12px; min-height: 27px; max-height: 27px;border-radius: 10px;"><strong>Cumplimiento %</strong></div>
                          @if ($programasdetalle_all->count('cumplimiento') == 0)
                          <p class="text-center" style="font-size: 18px;">0%</p>
                          @else
                          <p class="text-center" style="font-size: 18px;">
                              
                            {{round(($programasdetalle_all->sum('cumplimiento'))/$programasdetalle_all->count('cumplimiento'))}} %

                          </p>
                          @endif
                        </div>
                      </div>
                  </div>
                </div>
              </div>

           </div>


<div class="card-body">



                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="myTable">
                                <thead class="thead">
                                    <tr>

                                        

                                        <th class="text-center">N° Loc</th>
                                        <th class="text-center">Fecha Inicio</th>
                                        <th class="text-center">Fecha Fin</th>
                                        <th class="text-center">Cump. %</th>
                                        <th class="text-center">Nota</th>
                                        <th class="text-center">Responsable</th>
                                        <th class="text-center">Usuario Crea</th>
                                        <th class="text-center">Usuario Actualiza</th>



                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($programasdetalle_all as $detallepreventivolocomotora)
                                        <tr>


                                            <td class="text-center">{{ $detallepreventivolocomotora->locomotora }}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($detallepreventivolocomotora->fecha_inicio)->format('d/m/Y')}}</td>
                                            <td class="text-center">{{\Carbon\Carbon::parse($detallepreventivolocomotora->fecha_fin)->format('d/m/Y')}}</td>
                                            @if($detallepreventivolocomotora->cumplimiento >= 85)
                                            <td class="text-center" style="color: #28a745">
                                            @elseif($detallepreventivolocomotora->cumplimiento >= 50)
                                            <td class="text-center" style="color: #ffc107">
                                            @elseif($detallepreventivolocomotora->cumplimiento < 50)
                                            <td class="text-center" style="color: #dc3545">
                                            @endif
                                            {{ $detallepreventivolocomotora->cumplimiento }}</td>
                                            <td class="text-center">{{ $detallepreventivolocomotora->nota }}</td>
                                            <td class="text-center">{{ $detallepreventivolocomotora->datos->nombre }}</td>
                                            <td class="text-center" style="text-transform: uppercase;">{{ $detallepreventivolocomotora->usuario_crea }}</td>
                                            <td class="text-center" style="text-transform: uppercase;">{{ $detallepreventivolocomotora->usuario_actualiza }}</td>

                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable( {

    lengthMenu: ['4000'],
       dom: 'Bfrtip',
               buttons: [
            'copy','excel', 'pdf'
                        ],

        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Lo siento, no se encontraron registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Se encontro _END_ de un total de _MAX_ Componentes)",
            "search":"Busqueda General:",
             "paginate": {
             "first":      "First",
             "last":       "Last",
             "next":       "Siguiente",
             "previous":   "Anterior"
    },
        }
    } );
} );

$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myTable thead tr').clone(true).appendTo( '#myTable thead' );
    $('#myTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input style="width: 100%; text-align: center;" type="text"/>' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#myTable').DataTable();
} );
</script>


@endsection
