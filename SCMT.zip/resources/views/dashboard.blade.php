@extends('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Resumen')])

@section('content')

  <div class="content">
    <div class="container-fluid">
      <div class="row">

        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-warning card-header-icon">
              
              <div class="card-icon" style="border-radius: 20px;">
                 @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
                 <a style="color:white"; href="locomotoras/disponibilidad">
                 @endif
                 <img src="{{asset('/images/locoW.png')}}" height="55" width="55" alt="" /></a>
              </div>
              <p class="card-category">Disponibilidad 
                @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('isinvitado'))
                <a href="" class="badge badge-danger text-center" style="color: white;" data-toggle="modal" data-target="#staticBackdrop"><strong>Consumibles</strong></a>
                @endif
              </p>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-8 text-left">Locomotoras PZO</div>
                <div class="col-md-4 text-text-righ"><h4 class="card-title">{{$locomotoraDisponibilidad->where('ubicacion', 'Puerto Ordaz')->count()}}</h4></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left">Locomotoras CP</div>
                <div class="col-md-4 text-text-righ"><h4 class="card-title">{{$locomotoraDisponibilidad->where('ubicacion', 'Ciudad Piar')->count()}}</h4></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left">Total</div>
                <div class="col-md-4 text-text-righ"><h4 class="card-title">{{$locomotoraDisponibilidad->count()}}</h4></div>
              </div>
              <hr>
              <div class="row">
            <div class="card-footer">
              <div class="stats" style="font-size: 11px;">Ult. actualización
                <i class="material-icons" style="font-size: 15px;">date_range</i>
                {{\Carbon\Carbon::parse($ultimoTurnoLocomotoraDisponibilidad->fecha)->format('d-m')}}-Turno:{{$ultimoTurnoLocomotoraDisponibilidad->turno}}</div>
              </div>
              </div>
            </div>            
           </div>
          </div>


        <div id="carouselExampleSlidesOnly" class="col-lg-3 col-md-6 col-sm-6 carousel slide" data-ride="carousel">
          <div class="carousel-inner">
          <div class="card card-stats carousel-item active">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon" style="border-radius: 20px; background: #E2A274; box-shadow: outset;">
                 @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
                 <a style="color:white"; href="vagones/disponibilidad/operativa">
              
                 @endif
                 <img src="{{asset('/images/vagonW.png')}}" height="55" width="55" alt="" /></a>
              </div>
              <p class="card-category">Disponibilidad</p>
              
            </div>
            <div class="card-body mt-2">
              <br>
              <div class="row">
                <div class="col-md-8 text-left">Góndolas</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$conteoVagonesGondolas}}</h4></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left">Tolvas</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$conteoVagonesTolvas}}</h4></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left">Total</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$conteoVagonesGondolas+$conteoVagonesTolvas}}</h4></div>
              </div>
              <hr>
              <div class="row">
            <div class="card-footer">
              <div class="stats" style="font-size: 11px;">Ult. actualización
                <i class="material-icons" style="font-size: 15px;">date_range</i>
                {{\Carbon\Carbon::parse($ultimoTurnoVagonesDisponibilidadOperativa->fecha)->format('d-m')}}-Turno:{{$ultimoTurnoVagonesDisponibilidadOperativa->turno}}
              </div>
            </div>
            </div>
          </div>
        </div>


        <div class="card card-stats carousel-item">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon" style="border-radius: 20px; background: #585858; text-shadow: outset;">
                 @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam'))
                 <a style="color:white"; href="vagones/equipodeapoyo">
              
                 @endif
                 <img src="{{asset('/images/apoyo.png')}}" height="55" width="55" alt="" /></a>
              </div>
              <p class="card-category">Equipo Apoyo</p>
              
            </div>
            <div class="card-body mt-2">
              <br>
              <div class="row">
                <div class="col-md-8 text-left">Disponibles (UND)</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$dispEquipoApoyo}}</h4></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left">F / Servicio (UND)</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$fueradeServicio}}</h4></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left">Total (UND)</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$totalEquipoApoyo}}</h4></div>
              </div>
              <hr>
              <div class="row">
            <div class="card-footer">
              <div class="stats" style="font-size: 11px;">Ult. actualización
                <i class="material-icons" style="font-size: 15px;">date_range</i>
                {{\Carbon\Carbon::parse($ultimoregistroeqpoyoyo->updated_at)->format('d-m-y')}}
              </div>
            </div>
            </div>
          </div>
        </div>

      </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon" style="border-radius: 20px; background: #BA9D74; text-shadow: outset;">
                 
                 <a style="color:white"; ><img src="{{asset('/images/viasW.png')}}" height="55" width="55" alt="" /></a>
                 
              </div>
              <p class="card-category">Vías y Equipos</p>
              
            </div>
            <div class="card-body">

               <div class="row">
                <div class="col-md-8 text-left">Perfil de Vel (Km/h)</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$perfilvelocidadhome}}</h4></div>
              </div>

              <div class="row">
                <div class="col-md-8 text-left">Vía S/Reducción (%) </div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$reduccioneshome}}</h4></div>
              </div>

               <div class="row">
                <div class="col-md-8 text-left">Eq. Ferroviarios (%)</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$eqferroviarioshome}}</h4></div>
              </div>
            
              <hr>
              <div class="row">
            <div class="card-footer">
              <div class="stats" style="font-size: 11px;">Ult. actualización
                <i class="material-icons" style="font-size: 15px;">date_range</i>
                {{\Carbon\Carbon::parse($ultimoregistrovs->updated_at)->format('d-m-y')}}
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>


        <!-- Consumo locomotora -->
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-info card-header-icon">
              <div class="card-icon" style="border-radius: 20px; background: #F5C75F; text-shadow: outset;">
              
              <img src="{{asset('/images/signW.png')}}" height="55" width="55" alt="" />
              </div>
              <p class="card-category">Señales (Equipos)</p>
            </div>
              <div class="card-body">
                <div class="row">
                <div class="col-md-8 text-left">Disp. Física</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$señalesequiposhome}}</h4></div>
              </div>
               <div class="row">
                <div class="col-md-8 text-left">Disp. Operativa</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$disponibilidadoperativahome}}</h4></div>
              </div>
              <div class="row">
                <div class="col-md-8 text-left">Total Equipos</div>
                <div class="col-md-4 text-righ"><h4 class="card-title">{{$total}}</h4></div>
              </div>
              <hr>
              <div class="row text-center">
            <div class="card-footer text-center">
            <div class="stats" style="font-size: 11px;">Ult. actualización
                <i class="material-icons" style="font-size: 15px;">date_range</i>
                {{\Carbon\Carbon::parse($ultimoregistro->updated_at)->format('d-m-y')}}
              </div>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
<!--
      <div class="row">
        <div class="col-md-4">
          <div class="card card-chart">
            <div class="card-header card-header-success">
              <div class="ct-chart" id="dailySalesChart"></div>
            </div>
            <div class="card-body">
              <h4 class="card-title">Daily Sales</h4>
              <p class="card-category">
                <span class="text-success"><i class="fa fa-long-arrow-up"></i> 55% </span> increase in today sales.</p>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">access_time</i> updated 4 minutes ago
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-chart">
            <div class="card-header card-header-warning">
              <div class="ct-chart" id="websiteViewsChart"></div>
            </div>
            <div class="card-body">
              <h4 class="card-title">Email Subscriptions</h4>
              <p class="card-category">Last Campaign Performance</p>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">access_time</i> campaign sent 2 days ago
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-chart">
            <div class="card-header card-header-danger">
              <div class="ct-chart" id="completedTasksChart"></div>
            </div>
            <div class="card-body">
              <h4 class="card-title">Completed Tasks</h4>
              <p class="card-category">Last Campaign Performance</p>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">access_time</i> campaign sent 2 days ago
              </div>
            </div>
          </div>
        </div>
      </div>
    -->
    @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('isinvitado'))
      <div class="row">
        <div class="col-md-12">
          <div class="card">
             <div class="card-header card-header-tabs card-header-primary" style="background-image: linear-gradient(to right, #6a1816,#d2091d); border-radius: 10px;">
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#locomotoras" data-toggle="tab"  style="font-size: 14px;">
                        <img src="{{asset('/images/locoW.png')}}" height="40" width="40" alt="Locomotoras" />&nbsp&nbsp&nbspLocomotoras
                        <div class="ripple-container"></div>
                      </a>
                    </li>

                    <li class="nav-item">
                     <a class="nav-link" href="#tab-vagones" data-toggle="tab"  style="font-size: 14px;">
                        <img src="{{asset('/images/vagonW.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbspVagones
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-via" data-toggle="tab"  style="font-size: 14px;">
                        <img src="{{asset('/images/viasW.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbspVías
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#tab-señales" data-toggle="tab"  style="font-size: 14px;">
                        <img src="{{asset('/images/signW.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbspSeñales
                        <div class="ripple-container"></div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tab-content">
                <div class="tab-pane active" id="locomotoras">
                   <div class="card-body table-responsive">
                    <table class="table table-hover">
                      <thead class="text-warning">
                        <th class="text-center col-1" style="color: black;">N° Loc</th>
                        <th class="text-center" style="color: black;">Fecha Entrada</th>
                        <th class="text-center col-4" style="color: black;">Descripción</th>
                        <th class="text-center" style="color: black;">Estatus</th>
                        <th class="text-center" style="color: black;">¿Planeado?</th>
                        <th class="text-center" style="color: black;">Motivo</th>
                        <th class="text-center" style="color: black;">Responsable</th>
                        <th class="text-center col-2" style="color: black;">N° Orden</th>
                      </thead>
                      <tbody>
                        @forelse ($listadoActividadesLocomotora as $actividad)
                        <tr>
                          <td class="text-center">
                          @if($actividad->locomotora->numero == 'S/N')
                          SERVICIO TALLER
                          @else
                          {{ $actividad->locomotora->numero }}</td>
                          @endif
                          <td class="text-center">{{\Carbon\Carbon::parse($actividad->fecha_entrada)->format('d/m/Y H:i')}}</td>
                         <td style="text-transform: uppercase;">{{ $actividad->descripcion_falla }}</td>
                          <td class="text-center">{{ $actividad->estatus }}</td>
                          <td class="text-center">{{ $actividad::PLANEADO[$actividad->planeado] }}</td>
                          <td class="text-center">{{ $actividad::ESCOGERPLANEADO[$actividad->escoger_planeado] }}</td>
                          <td class="text-center">{{ $actividad->datos->nombre }}</td>
                          <td class="text-center">{{ $actividad->n_orden }}</td>
                        </tr>
                        @empty
                        <tr>
                          <td colspan="3" class="text-center" style="text-transform: uppercase;">Sin activadades registradas hoy</td>
                        </tr>
                        @endforelse
                      </tbody>
                    </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-vagones">
                   <div class="card-body table-responsive">
                    <table class="table table-hover">
                      <thead class="text-warning">
                        <th class="col-md-2 text-center" style="color: black;">Area</th>
                        <th class="text-center col-md-9" style="color: black;">Actividad</th>
                        <th class="text-center col-md-1" style="color: black;">Turno</th>                        
                      </thead>
                      <tbody>
                        @forelse ($listadoActividadesVagones as $actividad)
                        <tr>
                          <td style="text-transform: uppercase; text-align: center;">{{$actividad->area}}</td>
                          <td style="text-transform: uppercase; text-align: justify;">{{$actividad->actividad}}</td>
                          <td class="text-center" style="text-transform: uppercase;">{{$actividad->turno}}</td>                          
                        </tr>
                        @empty
                        <tr>
                          <td colspan="3" class="text-center" style="text-transform: uppercase;">Sin activadades registradas hoy</td>
                        </tr>
                        @endforelse
                      </tbody>
                    </table>
                  </div>
                </div>

                <div class="tab-pane" id="tab-via">
                   <div class="card-body table-responsive">
                    <table class="table table-hover">
                      <thead class="text-warning">
                        <th class="text-center col-md-11" style="color: black;">Actividad</th>
                        <th class="text-center col-md-1" style="color: black;">Turno</th></thead>
                        <tbody>
                        @forelse ($listadoActividadesVia as $actividad)
                        <tr>                        
                          <td style="text-transform: uppercase; text-align: justify;">{{$actividad->actividad}}</td>
                          <td class="text-center" style="text-transform: uppercase;">{{$actividad->turno}}</td>
                        </tr>
                        @empty
                        <tr>
                          <td colspan="2" class="text-center" style="text-transform: uppercase;">Sin activadades registradas hoy</td>
                        </tr>
                        @endforelse
                      </tbody>
                    </table>
                  </div>
                </div>


                <div class="tab-pane" id="tab-señales">
                   <div class="card-body table-responsive">
                    <table class="table table-hover">
                      <thead class="text-warning">
                        <th class="text-center col-md-11" style="color: black;">Actividad</th>
                        <th class="text-center col-md-1" style="color: black;">Turno</th>                        
                      </thead>
                      <tbody>
                        @forelse ($listadoActividadesSeñales as $actividad)
                        <tr>
                          <td style="text-transform: uppercase; text-align: justify;">{{$actividad->actividad}}</td>
                          <td class="text-center">{{$actividad->turno}}</td>                           
                        </tr>
                        @empty
                        <tr>
                          <td colspan="2" class="text-center" style="text-transform: uppercase;">Sin activadades registradas hoy</td>
                        </tr>
                        @endforelse
                      </tbody>
                    </table>
                  </div>
                </div>


              </div>
            </div>
          </div>
        </div>

      </div>
      @endif
    </div>
  </div>
            <!-- Modal -->

  <div class="modal" id="staticBackdrop" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Consumibles del Mes Locomotora</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-hover table-bordered table-small">
                  <thead class=" text-primary">
                    <tr>
                      <th>Consumible</th>
                      <th class="text-center">Cantidad (Unid-Lts)</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse ($locomotoraConsumoMensual as $consumo)
                    <tr>
                      <td>{{$consumo->tipo}}</td>
                      <td class="text-center">{{number_format($consumo->cantidad,0, ',','.')}}</td>
                    </tr>
                @empty
                @endforelse
                 </tbody>
            </table>
            <div class="text-center"><span class="text-center">Ultima actualización: {{\Carbon\Carbon::parse($ultimoregistroConsumo->fecha)->format('d-m')}}-Turno:{{$ultimoregistroConsumo->turno}}</span></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <a href="{{ route('consumo.index') }}"><button type="submit" class="btn btn-primary">Ver Historico</button></a>
      </div>
    </form>
    </div>
  </div>
</div>
           
@endsection

@push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();
    });
  </script>
@endpush
