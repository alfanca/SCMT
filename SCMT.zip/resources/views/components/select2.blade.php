<select id="locomotora" name="locomotora" style="width:100%">
    <option>Seleccione locomotoras para el tren</option>
    @foreach ($locomotoras as $locomotora)
      <option value="{{$locomotora->id}}">{{$locomotora->numero}}</option>
    @endforeach
</select>