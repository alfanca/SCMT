  <label class="col-md-2 col-form-label">{{ __('LOCOMOTORA') }}</label>
  <div class="col-md-4">
    <div class="form-group{{ $errors->has('locomotora') ? ' has-danger' : '' }}">
        <select class="custom-select form-control{{ $errors->has('locomotora') ? ' is-invalid' : '' }}" name="locomotora_id" id="input-locomotora_id" placeholder="{{ __('Ingrese locomotora') }}" required="true">
          <option value="">SELECCIONE</option>
          @foreach ($listadoLocomotoras as $locomotora)
            <option value="{{$locomotora->id}}"  {{ $isSelected($value) ? 'selected="selected"' : '' }} >{{$locomotora->numero}}</option>
          @endforeach
        </select>
      @if ($errors->has('locomotora'))
        <span id="name-error" class="error text-danger" for="input-estatus">{{ $errors->first('locomotora') }}</span>
      @endif
    </div>
  </div>