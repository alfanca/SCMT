<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ __('Sistema de Planificación de Mantenimiento y Control') }}</title>
    <link rel="apple-touch-icon" sizes="76x76" href="{{ asset('material') }}/img/apple-icon.png">
    <link rel="icon" type="image/png" href="{{ asset('material') }}/img/favicon.png">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="{{ asset('css') }}/fonts.css" rel="stylesheet" />

    <link href="{{ asset('vendor') }}/select2/css/select2.min.css" rel="stylesheet" />

    <link href="{{asset('css/bootstrap-datetimepicker.min.css')}}" rel="stylesheet">

    <!-- CSS Files -->
    <link href="{{ asset('material') }}/css/material-dashboard.css?v=2.1.1" rel="stylesheet" />
    
    <link href="{{asset('css/fmo.css')}}" rel="stylesheet">

    <link href="{{ asset('vendor') }}/fontawesome/css/all.min.css" rel="stylesheet" />

    <link href="{{ asset('vendor') }}/DataTables/datatables.min.css" rel="stylesheet" />

    <link href="{{ asset('vendor') }}/Chart/Chart.css" rel="stylesheet" />
    </head>
    
     <style type="text/css">
      
      #myBtn {
        position: fixed; /* Fixed/sticky position */
        bottom: 20px; /* Place the button at the bottom of the page */
        right: 30px; /* Place the button 30px from the right */
        z-index: 99; /* Make sure it does not overlap */
        border: none; /* Remove borders */
        outline: none; /* Remove outline */
        color: white; /* Text color */
        cursor: pointer; /* Add a mouse pointer on hover */
        padding: 15px; /* Some padding */
        border-radius: 10px; /* Rounded corners */
        font-size: 18px; /* Increase font size */
        box-shadow: initial;
      }

   </style>

    <style type="text/css">

    #barra_opciones {
      position: fixed;
      bottom: 20px;
      right: 30px;
      z-index: 99;
      height: 50px;
      border-radius: 25px;
      overflow: hidden;
      background: #9b945f;
      box-shadow: 0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(155, 148, 95, 0.4);
      transition: all 0.5s ease;
    }
    #barra_opciones > * {
      float: left;
    }

    #barra_opciones-toggle {
      display: block;
      cursor: pointer;
      opacity: 0;
      z-index: 999;
      margin: 0;
      width: 50px;
      height: 50px;
      position: absolute;
      top: 0;
      left: 0;
    }
    #barra_opciones-toggle:checked ~ #lista {
      width: 150px;
      background-position: 0px -50px;
    }

    #lista {
      list-style-type: none;
      margin: 0;
      padding: 0 0 0 50px;
      height: 50px;
      width: 0px;
      transition: 0.5s width ease;
      background-image: url("{{ asset('material') }}/img/menu.png");
      background-repeat: no-repeat;
      background-position: 0px 0px;
    }

    .lista_desplegable {
      display: inline-block;
      line-height: 50px;
      width: 50px;
      text-align: center;
      margin: 0;
    }
    .accesos {
      font-size: 1.25em;
      font-weight: bold;
      color: white;
      text-decoration: none;
    }

       </style>

    <script type="text/javascript">
  
        //Get the button:
        mybutton = document.getElementById("myBtn");

        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
          if (document.body.scrollTop > 8 || document.documentElement.scrollTop > 8) {
            mybutton.style.display = "block";
          } else {
            mybutton.style.display = "none";
          }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
          document.body.scrollTop = 0; // For Safari
          document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
        } 


    </script>


    </head>
    <body class="{{ $class ?? '' }}" style="background-image: url({{ asset('material') }}/img/imagen-2.png); background-repeat: no-repeat; background-attachment: fixed; background-size: 100% 100%;">


        @auth()
            <form id="logout-form" action="{{ route('logout') }}" method="POST">
                @csrf
            </form>
            @include('layouts.page_templates.auth')
        @endauth
        @guest()
            @include('layouts.page_templates.guest')
        @endguest
        <!--   Core JS Files   -->
        <script src="{{ asset('js') }}/app.js"></script>
        <script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
        <script src="{{ asset('material') }}/js/core/popper.min.js"></script>
        <script src="{{ asset('material') }}/js/core/bootstrap-material-design.min.js"></script>
        <script src="{{ asset('material') }}/js/plugins/perfect-scrollbar.jquery.min.js"></script>
        <!-- Plugin for the momentJs  -->
        <script src="{{ asset('material') }}/js/plugins/moment.min.js"></script>
        <!--  Plugin for Sweet Alert -->
        <script src="{{ asset('material') }}/js/plugins/sweetalert2.js"></script>
        <!-- Forms Validations Plugin -->
        <script src="{{ asset('material') }}/js/plugins/jquery.validate.min.js"></script>
        <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
        <script src="{{ asset('material') }}/js/plugins/jquery.bootstrap-wizard.js"></script>
        <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
        <script src="{{ asset('material') }}/js/plugins/bootstrap-selectpicker.js"></script>
        <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
        <script src="{{ asset('material') }}/js/plugins/bootstrap-datetimepicker.min.js"></script>
        <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
        <script src="{{ asset('material') }}/js/plugins/jquery.dataTables.min.js"></script>
        <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
        <script src="{{ asset('material') }}/js/plugins/bootstrap-tagsinput.js"></script>
        <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
        <script src="{{ asset('material') }}/js/plugins/jasny-bootstrap.min.js"></script>
        <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
        <script src="{{ asset('material') }}/js/plugins/fullcalendar.min.js"></script>
        <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
        <script src="{{ asset('material') }}/js/plugins/jquery-jvectormap.js"></script>
        <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
        <script src="{{ asset('material') }}/js/plugins/nouislider.min.js"></script>
        <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->

        <!-- Library for adding dinamically elements -->
        <script src="{{ asset('material') }}/js/plugins/arrive.min.js"></script>
        <!-- Chartist JS -->
        <script src="{{ asset('material') }}/js/plugins/chartist.min.js"></script>
        <!--  Notifications Plugin    -->
        <script src="{{ asset('material') }}/js/plugins/bootstrap-notify.js"></script>
        <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
        <script src="{{ asset('material') }}/js/material-dashboard.js?v=2.1.1" type="text/javascript"></script>
        <!-- Material Dashboard DEMO methods, don't include it in your project! -->
        <script src="{{ asset('material') }}/demo/demo.js"></script>
        <script src="{{ asset('vendor') }}/select2/js/select2.min.js"></script>

        <script src="{{ asset('vendor') }}/DataTables/datatables.min.js"></script>

        <script src="{{ asset('js') }}/fmo.js"></script>
        <script src="{{ asset('material') }}/js/settings.js"></script>
        @stack('js')
    </body>
</html>
