<div class="wrapper ">
  @include('layouts.navbars.sidebar')
  <div class="main-panel" id="main_panel" style="width: 100%">

    <script type="text/javascript">

  function OcultarMostrar() {
    var x = document.getElementById("sidebar");
    if (x.style.display === "none") {
        x.style.display = "block";
        document.getElementById("main_panel").style.width = "";
    } else {
        x.style.display = "none";
        document.getElementById("main_panel").style.width = "100%";

    }
  }
  </script>

    <script type="text/javascript">
        
     /* When the user scrolls down, hide the navbar. When the user scrolls up, show the navbar */
        var prevScrollpos = window.pageYOffset;
        window.onscroll = function() {
          var currentScrollPos = window.pageYOffset;
          if (prevScrollpos > currentScrollPos) {

            document.getElementById("barra_opciones").style.display = "none";

          } else {

            document.getElementById("barra_opciones").style.display = "";
          }
          prevScrollpos = currentScrollPos;
} 

    </script>
    @include('layouts.navbars.navs.auth')

        <div id="barra_opciones">
      <input type="checkbox" id="barra_opciones-toggle"/>
      <ul id="lista">
        <li class="lista_desplegable">
          <a class="accesos" href="#" data-toggle="tab" rel="tooltip" title="Ocultar / Mostrar Barra de Menu" onclick="OcultarMostrar()"><i class="material-icons" style="color: white; margin-bottom: 5px;">dashboard</i></a>
        </li><li class="lista_desplegable">
          <a class="accesos" href="#" data-toggle="tab" onclick="topFunction()" rel="tooltip" title="Subir"><i class="fas fa-chevron-circle-up" style="color: white;"></i></a>
        </li><li class="lista_desplegable">
          <a class="accesos" href="#">&#x2709;</a>
        </li>
      </ul>
    </div>
    @yield('content')
    @include('layouts.mensajes')
  </div>
</div>