<!-- Navbar -->

<script src="{{ asset('material') }}/js/core/jquery.min.js"></script>
<script src="{{ asset('material') }}/js/core/popper.min.js"></script>
<script src="{{ asset('material') }}/js/core/bootstrap-material-design.min.js"></script>

<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
  <div class="container-fluid">
    <div class="navbar-wrapper">
    <a href="#" rel="tooltip" title="Ocultar / Mostrar Barra de Menu" onclick="OcultarMostrar()" style="background-color: #9b945f; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
    <i class="material-icons" style="font-size: 18px; margin-left: 11px; margin-top: 10px; color: white;">dashboard</i>
    </a>
      <a class="navbar-brand" href="#">{{ $titlePage ?? '' }}</a>
    </div>

    <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
    <span class="sr-only">Toggle navigation</span>
    <span class="navbar-toggler-icon icon-bar"></span>
    <span class="navbar-toggler-icon icon-bar"></span>
    <span class="navbar-toggler-icon icon-bar"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end">
      <ul class="navbar-nav">
        @if ($activePage == 'dashboard')
        <div>
          <a rel="tooltip" class="btn btn-sm btn-rounded" href="" data-toggle="modal" data-target="#staticBackdropflayer" title="Ver Guia de Usuario" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
            <i class="far fa-lightbulb" style="font-size: 18px; margin-left: -6px; margin-top: 3px;"></i>
              </a>
         </div>&nbsp&nbsp&nbsp
        @endif
        @can ('isJefe')
        <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded" href="{{ route('asistenciaControl') }}" title="Asistencia" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
            <i class="far fa-address-book" style="font-size: 18px; margin-left: -7px; margin-top: 3px;"></i>
              </a>
          </li>&nbsp&nbsp&nbsp
          </li>
          @endcan

          @can ('isvagones')
        <li class="nav-item">
          <span>Creado Por: ING Carlos Ortiz F-16512</span>
          </li>&nbsp&nbsp&nbsp
          @endcan


        @if ($activePage == 'reportelocomotora')
        <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="" data-toggle="modal" data-target="#staticBackdropuno" title="Ver Historiales" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
                <i class="material-icons" style="font-size: 18px; margin-left: -9px; margin-top: -9px;">date_range</i>
              </a>
         </li>&nbsp&nbsp&nbsp
        @endif
        @if ($activePage == 'preventivolocomotora')
        <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="" data-toggle="modal" data-target="#staticBackdropdos" title="Ver Historiales" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
                <i class="material-icons" style="font-size: 18px; margin-left: -9px; margin-top: -9px;">date_range</i>
              </a>
         </li>&nbsp&nbsp&nbsp
        @endif
        @if ($activePage == 'consumovias')
        <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{ route('via_consumo.periodo') }}" title="Historial de Consumo" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
                <i class="material-icons" style="font-size: 18px; margin-left: -9px; margin-top: -9px;">date_range</i>
              </a>
         </li>&nbsp&nbsp&nbsp
        @endif
        @if ($activePage == 'disponibilidad')
        <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{ route('disponibilidadPorSemana') }}" title="Cambiar Vista" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
                <i class="material-icons" style="font-size: 18px; margin-left: -9px; margin-top: -9px;">date_range</i>
              </a>
         </li>&nbsp&nbsp
         @if(Gate::check('isplanificador') || Gate::check('isJefe'))
         <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="/locomotoras/periodo" title="Periodo" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
                 <i class="fas fa-stopwatch text-center" style="font-size: 18px; margin-left: -8px; margin-top: 3px;"></i>
              </a>
         </li>&nbsp&nbsp&nbsp
         @endif
         @endif

         @if ($activePage == 'adminvagones' and (Gate::check('isplanificador') || Gate::check('isJefe')))
         <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{route('vagonDescarrilamiento.index')}}" title="Ir a Módulo de Descarrilamiento y Desincorporaciones" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
                <i class="fas fa-trailer" style="font-size: 18px; margin-left: -10px; margin-top: 3px;"></i>
              </a>
         </li>&nbsp&nbsp
         @if(Gate::check('isplanificador') || Gate::check('isJefe'))
        <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{route('admin.create')}}" title="Agregar Vagon al Sistema" style="background-color: #9b945f; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
                <i class="material-icons" style="font-size: 25px; margin-left: -12px; margin-top: -15px;">add</i>
              </a>
         </li>
        @endif
        &nbsp&nbsp&nbsp
        @endif

        @if($activePage == 'vagon_taller')
        <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{ route('vagontaller') }}" title="Ir al Historial del Taller" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;">
                <i class="material-icons" style="font-size: 18px; margin-left: -9px; margin-top: -9px;">date_range</i>
              </a>
         </li>&nbsp&nbsp
         <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{ route('proyectoVagones.index') }}" title="Ir a Proyecto de Vagones" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;"><i class="fa fa-fw fa-folder-open" style="font-size: 17px; margin-left: -9px; margin-top: -10px;"></i>
              </a>
         </li>&nbsp&nbsp
         <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{ route('taller.index') }}" title="Ir al Taller" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;"><i class="fas fa-cog" style="font-size: 17px; margin-left: -9px; margin-top: 3px;"></i>
              </a>
         </li>&nbsp&nbsp
         <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{ route('vagonesRuedas.index') }}" title="Ir a Medición de Ruedas" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;"><i class="fas fa-drafting-compass" style="font-size: 17px; margin-left: -9px; margin-top: 3px;"></i>
              </a>
         </li>&nbsp&nbsp
        <li class="nav-item">
          <a rel="tooltip" class="btn btn-sm btn-rounded text-center" href="{{ route('consumoVagones.index') }}" title="Ir al Registro de Consumo de Vagones" style="background-color: #d2091d; border-radius: 20px; height: 40px; width: 40px; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px;"><i class="fas fa-cart-plus" style="font-size: 19px; margin-left: -12px; margin-top: 3px;"></i>
              </a>
         </li>&nbsp&nbsp&nbsp
        @endif

       <!-- <li class="nav-item dropdown">
          <a class="nav-link" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="material-icons">notifications</i>
            <span class="notification"></span>
            <p class="d-lg-none d-md-block">
              {{ __('Some Actions') }}
            </p>
          </a>
            
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="#">{{ __('Mike John responded to your email') }}</a>
            <a class="dropdown-item" href="#">{{ __('You have 5 new tasks') }}</a>
            <a class="dropdown-item" href="#">{{ __('You\'re now friend with Andrew') }}</a>
            <a class="dropdown-item" href="#">{{ __('Another Notification') }}</a>
            <a class="dropdown-item" href="#">{{ __('Another One') }}</a>
          </div>
         
        </li> -->
        <!-- <li class="nav-item dropdown">
          <a class="nav-link" href="#" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            <i class="material-icons">person</i>
            <p class="d-lg-none d-md-block">
              {{ __('Account') }}
            </p>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
            <a class="dropdown-item" href="{{ route('profile.edit') }}">{{ __('Perfil') }}</a>
           <a class="dropdown-item" href="#">{{ __('Ajustes') }}</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">{{ __('Salida') }}</a>
          </div>
        </li>-->
<li class="nav-item">

<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border: 1px solid; border-radius: 20px; background: #9b945f; border-color: #9b945f; color: white;">
    <img src="{{asset('/images/usuario 1.png')}}" height="20" width="20" alt="" />&nbsp&nbsp{{ auth()->user()->name }}
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile" style="border: 3px solid; border-radius: 20px; border-color: white;">
     <a class="dropdown-item" href="{{ route('profile.edit') }}" style="border-radius: 20px;">{{ __('Actualizar Contraseña') }}</a>
     <div class="dropdown-divider"></div>
     <a class="dropdown-item" href="{{ route('logout') }}" style="border-radius: 20px;" onclick="event.preventDefault();document.getElementById('logout-form').submit();">{{ __('Cerrar Sesión') }}</a>
  </div>
</div>

</li>


      </ul>
    </div>
  </div>
</nav>
<div class="modal" id="staticBackdropuno" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Busqueda</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
            <a rel="tooltip" class="btn btn-sm btn-rounded" href="{{ route('periodo.reporte.locomotora') }}" title="Ver Historial de Reportes" style="background-color: #9B945F;">
                <i class="fas fa-folder-open" style="font-size: 16px;"></i>
               &nbsp Ir al Historial de Reportes</a>
            <a rel="tooltip" class="btn btn-sm btn-rounded" href="{{ route('periodo.reporte.actividad') }}" title="Ver Historial de Actividades" style="background-color: #9B945F;">
                <i class="material-icons" style="font-size: 16px;">assignment</i>
               &nbsp Ir al Historial de Actividades</a>
             <a rel="tooltip" class="btn btn-sm btn-rounded" href="{{ route('periodo.reporte.consumibles') }}" title="Ver Historial de Consumibles" style="background-color: #9B945F;">
                <i class="fas fa-tasks fas fa-toolbox" style="font-size: 16px;"></i>
               &nbsp Ir al Historial de Consumibles</a>
             <a rel="tooltip" class="btn btn-sm btn-rounded" href="{{ route('loc_actividades.vista_alll') }}" title="Ver Historial de Actividades" style="background-color: #9B945F;">
                <i class="material-icons" style="font-size: 16px;">assignment</i>
               &nbsp Ir al Historial de Actividades Data Vieja</a>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
  </div>

  <div class="modal" id="staticBackdropdos" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="titulo">Busqueda</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
            <a rel="tooltip" class="btn btn-sm btn-rounded" href="{{ route('periodo.programa.locomotora') }}" title="Ver Historial de Programas" style="background-color: #9B945F;">
                <i class="fas fa-folder-open" style="font-size: 16px;"></i>
               &nbsp Ir al Historial de Programas</a>
            <a rel="tooltip" class="btn btn-sm btn-rounded" href="{{ route('periodo.programa.locomotora.detalles') }}" title="Ver Historial de Programas Detalle" style="background-color: #9B945F;">
                <i class="material-icons" style="font-size: 16px;">assignment</i>
               &nbsp Ir al Historial de Programas Detalle</a>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
  </div>


  <div class="modal bd-example-modal-lg" id="staticBackdropflayer" tabindex="-1" role="dialog">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="titulo">Guía de Atajos para el Usuarios</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body text-center">


                          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                          <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="8"></li>

                          </ol>
                          <div class="carousel-inner">
                            <div class="carousel-item active">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva1.JPG" alt="First slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva2.JPG" alt="Second slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva3.JPG" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva4.JPG" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva5.JPG" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva6.JPG" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva7.JPG" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva8.JPG" alt="Third slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="{{ asset('Flyer_SPMC') }}/Diapositiva9.JPG" alt="Third slide">
                            </div>
                          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Anterior</span>
                          </a>
                          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Siguiente</span>
                          </a>
                        </div>
                      </div>
                    </div>


                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                          </div>
                        </div>
                      </div>
                      </div>


