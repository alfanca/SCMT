
<div id="sidebar" class="sidebar" data-color="orange" data-background-color="white" data-image="{{ asset('material') }}/img/sidebar-1.jpg" style="display: none;">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="{{ route('home') }}" rel="tooltip" title="Sistema de Planificación de Mantenimiento y Control (S.P.M.C)" class="simple-text logo-normal" style="color: #d2091d; font-size: 25px;">
     <img src="{{asset('/images/FMOarea logo.png')}}" height="30" width="30" alt="logo" /> <strong> S.P.M.C </strong><img src="{{asset('/images/FMOarea logo.png')}}" height="30" width="30" alt="logo" />
    </a>  
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item{{ $activePage == 'dashboard' ? ' active' : '' }}">
        <a class="nav-link" href="{{ route('home') }}" style="border-radius: 10px;">
            <p style="font-size: 16px;">

              @if ($activePage == 'dashboard')
              <img src="{{asset('/images/menu-squared-2.png')}}" height="30" width="30" alt="logo" />
              @else
              <img src="{{asset('/images/resumen2.png')}}" height="31" width="31" alt="logo" />
              @endif
              &nbsp&nbsp{{ __('Resumen') }}</p>
        </a>
      </li>
      @can('isgestionoperaciones')
      <li class="nav-item{{ $activePage == 'vagon_inspeccion' ? ' active' : '' }}">
        <a class="nav-link" href="{{ route('inspeccion.index') }}">
          <i class="material-icons">book</i>
            <p>{{ __('Inspecciones de Trenes') }}</p>
        </a>
      </li>
      <li class="nav-item{{ $activePage == 'comunicacion' ? ' active' : '' }}">
        <a class="nav-link" href="{{ route('gestion.comunicacion.index')}}">
          <i class="material-icons">assignment</i>
            <p>{{ __('Comunicaciones') }}</p>
        </a>
      </li>
      @endcan

      <!-- CPTT Vagones -->

      @can('isvagones')
      <li class="nav-item{{ $activePage == 'vagon_inspeccion' ? ' active' : '' }}">
        <a class="nav-link" href="{{ route('admin.index') }}">
          <i class="fa fa-fw fa-file-alt"></i>
            <p>{{ __('Vagones') }}</p>
        </a>
      </li>
      @endcan

      <!-- END -->

      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('isinvitado') || Gate::check('islocomotoras'))
      <li class="nav-item {{ ($activePage == '') ? ' active' : '' }}">
        <a class="nav-link" data-toggle="collapse" href="#locomtoras" aria-expanded="false" style="font-size: 14px;">
          <img src="{{asset('/images/loco.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbsp{{ __('Locomotoras') }}
          <b class="caret"></b>
        </a>
        <div class="collapse" id="locomtoras">
          <ul class="nav">
             @if(Gate::check('isplanificador') || Gate::check('isJefe')) 
            <li class="nav-item{{ $activePage == 'locomotoras' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{route('administradorlocomotoras.index')}}" style="font-size: 14px;">
                <span class="sidebar-normal">{{ __('Administrar') }} </span>
              </a>
            </li>
            @endif
            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isinvitado') || Gate::check('isanalistam') || Gate::check('islocomotoras')) 
            <li class="nav-item{{ $activePage == 'preventivolocomotora' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('maestropreventivolocomotora.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Programas') }} </span>
              </a>
            </li>
            @endif
            <li class="nav-item{{ $activePage == 'reportelocomotora' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('reportedelocomotoras.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Reportes') }} </span>
              </a>
            </li>

            <!--<li class="nav-item{{ $activePage == 'actividades' ? ' active' : '' }}">
              <a class="nav-link" href="{{ route('actividades.index') }}">
                <span class="sidebar-normal"> {{ __('Actividades') }} </span>
              </a>
            </li>-->

            <li class="nav-item{{ $activePage == 'disponibilidad' ? ' active' : '' }} text-center">
                <a class="nav-link" href="{{ route('disponibilidad.index') }}" style="font-size: 14px;">
                  <span class="sidebar-normal"> {{ __('Disponibilidad') }} </span>
                </a>
            </li>
           
               <li class="nav-item{{ $activePage == 'consumible' ? ' active' : '' }} text-center">
                <a class="nav-link" href="{{ route('consumo.index') }}" style="font-size: 14px;">
                  <span class="sidebar-normal"> {{ __('Consumibles') }} </span>
                </a>
            </li>
          </ul>
        </div>
      </li>
      @endif
       @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('isinvitado'))
      <!-- vagones -->
      <li class="nav-item {{ ($activePage == '') ? ' active' : '' }}">
        <a class="nav-link" data-toggle="collapse" href="#vagones" aria-expanded="false" style="font-size: 14px;">
           <img src="{{asset('/images/vagon1.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbsp
          {{ __('Vagones / Serv.') }}
            <b class="caret"></b>
          
        </a>
        <div class="collapse" id="vagones">
          <ul class="nav">

             <li class="nav-item{{ $activePage == 'adminvagones' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('admin.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Vagones (Indicadores)') }} </span>
              </a>
            </li>

            <li class="nav-item{{ $activePage == 'vagon_inspeccion' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('inspeccion.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Inspección Trenes') }} </span>
              </a>
            </li>   

            <li class="nav-item{{ $activePage == 'vagon_taller' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('taller.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Taller (Vagones)') }} </span>
              </a>
            </li>     

            <li class="nav-item{{ $activePage == 'vagones_disponibilidad' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('vagones_disponibilidad_o.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Disponibilidad') }} </span>
              </a>
            </li>

            <li class="nav-item{{ $activePage == 'eq_apoyo' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('equipodeapoyo.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Equipo Apoyo') }} </span>
              </a>
            </li>  

            <li class="nav-item{{ $activePage == 'Actividades_Vagones' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('vagones_actividades.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Actividades') }} </span>
              </a>
            </li>
            <!--
            <li class="nav-item{{ $activePage == 'inventario_vagon' ? ' active' : '' }}">
              <a class="nav-link" href="{{ route('inventario.index') }}">
                <span class="sidebar-normal"> {{ __('Inventario') }} </span>
              </a>
            </li>   
            -->
          </ul>
        </div>
      </li>
      @endif
       @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('isinvitado'))
      <!-- via -->
      <li class="nav-item {{ ($activePage == '') ? ' active' : '' }}">
        <a class="nav-link" data-toggle="collapse" href="#via" aria-expanded="false" style="font-size: 14px;">
           <img src="{{asset('/images/via2.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbsp
          {{ __('Vias / Equipos') }} <b class="caret"></b>
          
        </a>
        <div class="collapse" id="via">
          <ul class="nav">
            <li class="nav-item{{ $activePage == 'indicadoresvias' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('perfilvelocidad.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Indicadores de Vías') }} </span>
              </a>
            </li>
            <li class="nav-item{{ $activePage == 'programavias' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('programavias.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Programa Vías') }} </span>
              </a>
            </li>
             <li class="nav-item{{ $activePage == 'eqferroviarios' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('eqferroviario.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Eq. Ferroviario') }} </span>
              </a>
            </li>
            <li class="nav-item{{ $activePage == 'via' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('via_actividades.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Actividades') }} </span>
              </a>
            </li>
            <li class="nav-item{{ $activePage == 'consumovias' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('viasconsumo.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Consumo') }} </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      @endif
      @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('isanalistam') || Gate::check('isinvitado'))
      <!-- señales -->
      <li class="nav-item {{ ($activePage == '') ? ' active' : '' }}">
        <a class="nav-link" data-toggle="collapse" href="#senales" aria-expanded="false" style="font-size: 14px;">
           <img src="{{asset('/images/sign3.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbsp
          {{ __('Señales') }}
            <b class="caret"></b>
          
        </a>
        <div class="collapse" id="senales">
          <ul class="nav">
            <li class="nav-item{{ $activePage == 'equipossenales' ? ' active' : '' }} text-center" >
              <a class="nav-link" href="{{route('equipos.index')}}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Equipos') }} </span>
              </a>
            </li>
            <li class="nav-item{{ $activePage == 'programassenales' ? ' active' : '' }} text-center" >
              <a class="nav-link" href="{{route('programas.index')}}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Programas') }} </span>
              </a>
            </li>
            <li class="nav-item{{ $activePage == 'actividadsenales' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('senales_actividades.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Actividades') }} </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      @endif

      @can('issenale')
      <li class="nav-item {{ ($activePage == '') ? ' active' : '' }}">
        <a class="nav-link" data-toggle="collapse" href="#senales" aria-expanded="false" style="font-size: 14px;">
           <img src="{{asset('/images/sign3.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbsp
          {{ __('Señales') }}
            <b class="caret"></b>
          
        </a>
        <div class="collapse" id="senales">
          <ul class="nav">
            <li class="nav-item{{ $activePage == 'equipossenales' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{route('equipos.index')}}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Equipos') }} </span>
              </a>
            </li>
            <li class="nav-item{{ $activePage == 'actividadsenales' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('senales_actividades.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Actividades') }} </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      @endcan



            @if(Gate::check('isplanificador') || Gate::check('isJefe') || Gate::check('issecretaria') || Gate::check('isinvitado') || Gate::check('ispasante') || Gate::check('isanalistam'))
      <!-- GESTION -->
      <li class="nav-item {{ ($activePage == '') ? ' active' : '' }}">
        <a class="nav-link" data-toggle="collapse" href="#gestion" aria-expanded="false" style="font-size: 14px;">
           <img src="{{asset('/images/gestion1.png')}}" height="40" width="40" alt="" />&nbsp&nbsp&nbsp
          {{ __('Control') }}
            <b class="caret"></b>
          
        </a>
        <div class="collapse" id="gestion">
          <ul class="nav">
            <li class="nav-item{{ $activePage == 'materialeslocomotora' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('materialeslocomotora.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Materiales de Locomotora') }} </span>
              </a>
            </li>
            <li class="nav-item{{ $activePage == 'materialvagon' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('materialesvagones.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Materiales de Vag. y Eq.') }} </span>
              </a>
            </li>
            <li class="nav-item{{ $activePage == 'materialesvias' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('viasmateriale.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Materiales de Vías') }} </span>
              </a>
            </li>
            @if(Gate::check('ispasante'))
            <li class="nav-item{{ $activePage == 'materialesvias' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('consumoVagones.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Consumo Vagones') }} </span>
              </a>
            </li>
            @endif
            @if(auth()->user()->id == 11  || Gate::check('isJefe'))
            <li class="nav-item{{ $activePage == 'usuarios' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('usuarioControl') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Control de Usuarios') }} </span>
              </a>
            </li>
            @endif
            @if(Gate::check('isplanificador') || Gate::check('isJefe'))
            <li class="nav-item{{ $activePage == 'registro_pasante' ? ' active' : '' }} text-center">
              <a class="nav-link" href="{{ route('registrodepasantes.index') }}" style="font-size: 14px;">
                <span class="sidebar-normal"> {{ __('Registro de Pasantes') }} </span>
              </a>
            </li>
            @endif
          </ul>
        </div>
      </li>
      @endif
    </ul>
  </div>
</div>
