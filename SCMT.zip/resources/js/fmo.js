$(".tripulacion").select2({
  minimumInputLength: 3,
  theme: "classic",
  multiple: true,
  minimumResultsForSearch: 10,
  ajax: {
    url: "/api/datosbasicos/",
    dataType: "json",
    type: "GET",
    data: function(params) {
      var queryParameters = {
        id: params.term
      };
      return queryParameters;
    },
    processResults: function(data) {
      return {
        results: $.map(data, function(item) {
          return { text: item.text, id: item.id };
        })
      };
    }
  }
});


function eliminarRegistro(formulario) {
  var r = confirm("Esta seguro desea eliminar este registro?");
  if (r == true) {
    console.log("false");
    return 1;
  } else {
    console.log("false");
    return 0;
  }
}