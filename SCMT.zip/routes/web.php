<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home')->middleware('auth');

Route::group(['middleware' => 'auth'], function () {

    Route::prefix('locomotoras')->group(function () {
        Route::get('consumo/crear', 'LocomotoraConsumoController@crear')->name('crear');
        Route::resource('/administradorlocomotoras', 'LocomotoraController',['except' => ['show']]);
        Route::resource('/actividades', 'LocomotoraActividadController');
        Route::resource('/disponibilidad', 'LocomotoraDisponibilidadController');
        Route::resource('/consumo', 'LocomotoraConsumoController');
        Route::resource('/nota', 'NotaController');
        Route::resource('/materialeslocomotora', 'MaterialeslocomotoraController',['except' => ['show']]);
        Route::resource('/reportedelocomotoras', 'ReportedelocomotoraController');
        Route::resource('/reportetiempolocomotoras', 'ReportetiempolocomotoraController');
        Route::resource('/reporteconsumiblelocomotoras', 'ReporteconsumiblelocomotoraController');
        Route::resource('/reporteactividadlocomotora', 'ReporteactividadlocomotoraController');
        Route::resource('/maestropreventivolocomotora', 'MaestropreventivolocomotoraController');
        Route::resource('/detallepreventivolocomotora', 'DetallepreventivolocomotoraController');
        Route::get('/periodo/', 'LocomotoraDisponibilidadController@disponibilidadXPeriodo')->name('disponibilidadXPeriodo.index');
        Route::get('/periodo_reporte', 'ReportedelocomotoraController@periodoreporte')->name('periodo.reporte.locomotora');
        Route::get('/periodo_programa', 'MaestropreventivolocomotoraController@periodoprograma')->name('periodo.programa.locomotora');
        Route::get('/periodo_programa_detalles', 'DetallepreventivolocomotoraController@periodoprogramasdetalle')->name('periodo.programa.locomotora.detalles');
        Route::get('/periodo_actividades', 'ReporteactividadlocomotoraController@periodoactividad')->name('periodo.reporte.actividad');
        Route::get('/periodo_consumibles', 'ReporteconsumiblelocomotoraController@periodoconsumibles')->name('periodo.reporte.consumibles');
        Route::get('locomotora/actividades/vista_alll','LocomotoraActividadController@listacompleta')->name('loc_actividades.vista_alll');
        Route::get('locomotora/disponibilidad/disponibilidadXSemana','LocomotoraDisponibilidadController@disponibilidadPorSemana')->name('disponibilidadPorSemana');
        Route::get('ferroprograma/{id}','MaestropreventivolocomotoraController@ferroprograma')->name('f_programa'); 
        Route::get('ferroreprogramacion/{id}','MaestropreventivolocomotoraController@ferroreprogramacion')->name('f_reprogramacion');    
        Route::get('ferroreporte/{id}','ReportedelocomotoraController@ferroreporte')->name('ferroreporte');  
    });

        Route::prefix('vagones')->group(function () {

        Route::resource('/admin', 'VagonesController');
        Route::resource('/inspeccion', 'VagonInspeccionController');
        Route::resource('/taller', 'VagonTallerController');
        Route::patch('taller/{taller}/retornar_estatus','VagonTallerController@retornar_estatus')->name('taller.devolver_patio');
        Route::resource('/inventario', 'VagonInventarioController');

        Route::resource('/materialesvagones', 'MaterialesvagonesController',['except' => ['show']]);

        Route::resource('/vagonDescarrilamiento', 'VagonDescarrilamientoController',['except' => ['show']]);

        Route::resource('/consumoVagones', 'ConsumoVagonesController',['except' => ['show']]);

        Route::resource('/vagonesRuedas', 'VagonesRuedasController',['except' => ['show']]);

        Route::resource('/equipodeapoyo', 'Equipo_apoyoController',['except' => ['show']]);

        Route::resource('/equipodeapoyo/programaEquipoApoyo', 'ProgramaEquipoApoyoController');
        
        Route::get('equipodeapoyo/vista_all','ProgramaEquipoApoyoController@programasBusqueda')->name('eqApoyo_programas.vista_all');

        Route::resource('/proyectoVagones', 'ProyectovagonesController');
        Route::resource('/proyectoVagonesConsumo', 'ProyectoVagonesComponentesController');

        Route::resource('/catalogo_fallas_tarjeta', 'CatalogoFallasTarjetaVagonController');

        Route::resource('/equipodeapoyo/programaEquipoApoyoDetalle', 'ProgramaEquipoApoyoDetalleController',['except' => ['show']]);

        Route::get('ferroprogramaApoyo/{id}','ProgramaEquipoApoyoController@ferroprogramaApoyo')->name('ferroprogramaApoyo');

        Route::get('/vagones/taller/tallerbusqueda','VagonTallerController@vagonestallerbusqueda')->name('vagontaller');

        Route::get('/actividades','ActividadesVagonesController@index')->name('vagones_actividades.index');
        Route::get('/actividades/create','ActividadesVagonesController@create')->name('vagones_actividades.create');
        Route::post('/actividades','ActividadesVagonesController@store')->name('vagones_actividades.store');
        Route::get('/actividades/edit/{actividad}','ActividadesVagonesController@edit')->name('vagones_actividades.edit');
        Route::get('/actividades/{fecha}','ActividadesVagonesController@show')->name('vagones_actividades.show');
        Route::patch('/actividades/{actividad}','ActividadesVagonesController@update')->name('vagones_actividades.update');
        Route::delete('/actividades/{actividad}','ActividadesVagonesController@destroy')->name('vagones_actividades.destroy');


        Route::get('/disponibilidad/operativa','VagonDisponibilidadOperativaController@index')->name('vagones_disponibilidad_o.index');
        Route::get('/disponibilidad/operativa/create','VagonDisponibilidadOperativaController@create')->name('vagones_disponibilidad_o.create');
        Route::post('/disponibilidad/operativa','VagonDisponibilidadOperativaController@store')->name('vagones_disponibilidad_o.store');
        Route::get('/disponibilidad/operativa/edit/{disponibilidad}','VagonDisponibilidadOperativaController@edit')->name('vagones_disponibilidad_o.edit');
        Route::get('/disponibilidad/operativa/{fecha}','VagonDisponibilidadOperativaController@show')->name('vagones_disponibilidad_o.show');
        Route::patch('/disponibilidad/operativa/{disponibilidad}','VagonDisponibilidadOperativaController@update')->name('vagones_disponibilidad_o.update');
        Route::delete('/disponibilidad/operativa/{disponibilidad}','VagonDisponibilidadOperativaController@destroy')->name('vagones_disponibilidad_o.destroy');


    });

    Route::get('via/actividades','ViaActividadesController@index')->name('via_actividades.index');
    Route::get('via/actividades/vista_all','ViaActividadesController@listacompleta')->name('via_actividades.vista_all');
    Route::get('viasconsumo/vista_all','ViasConsumoController@peridodoconsumo')->name('via_consumo.periodo');
    Route::get('via/actividades/create','ViaActividadesController@create')->name('via_actividades.create');
    Route::post('via/actividades','ViaActividadesController@store')->name('via_actividades.store');
    Route::get('via/actividades/edit/{actividad}','ViaActividadesController@edit')->name('via_actividades.edit');
    Route::get('via/actividades/{fecha}','ViaActividadesController@show')->name('via_actividades.show');
    Route::patch('via/actividades/{actividad}','ViaActividadesController@update')->name('via_actividades.update');
    Route::delete('via/actividades/{actividad}','ViaActividadesController@destroy')->name('via_actividades.destroy');
    Route::resource('via/eqferroviario', 'EquipoferroviariosController',['except' => ['show']]);
    Route::resource('via/perfilvelocidad', 'PerfilvelocidadController',['except' => ['show']]);
    Route::resource('viasmateriale', 'ViasMaterialeController');
    Route::resource('viasconsumo', 'ViasConsumoController');
    Route::resource('programavias', 'ProgramaViumController');
    Route::resource('programaviasdetalle', 'ProgramaDetalleViumController');
    Route::resource('programaviasanual', 'ProgramaAnualViumController');
    Route::resource('programaviasactividades', 'ProgramaActiviadesViumController');

    Route::get('ferroprogramavias/{id}','ProgramaViumController@ferroprograma')->name('f_programa_via');
    Route::get('Programa_Vias_historico','ProgramaViumController@ProgramaHistorico')->name('historico_programa_vias');  





    Route::get('senales/actividades','SenalesActividadesController@index')->name('senales_actividades.index');
    Route::get('senales/actividades/vista_all','SenalesActividadesController@listacompletasenales')->name('sen_actividades.vista_all');
    Route::get('senales/actividades/create','SenalesActividadesController@create')->name('senales_actividades.create');
    Route::post('senales/actividades','SenalesActividadesController@store')->name('senales_actividades.store');
    Route::get('senales/actividades/edit/{actividad}','SenalesActividadesController@edit')->name('senales_actividades.edit');
    Route::get('senales/actividades/{fecha}','SenalesActividadesController@show')->name('senales_actividades.show');
    Route::patch('senales/actividades/{actividad}','SenalesActividadesController@update')->name('senales_actividades.update');
    Route::delete('senales/actividades/{actividad}','SenalesActividadesController@destroy')->name('senales_actividades.destroy');

    Route::resource('senales/equipos', 'SenalesEquiposController',['except' => ['show']]);
    Route::resource('senales/programas', 'ProgramasSenalesController');
    Route::resource('senales/programasdetalles', 'ProgramasSenalesDetallesController', ['except' => ['show']]);

    Route::get('senales/vista_all','ProgramasSenalesController@programasBusqueda')->name('sen_programas.vista_all');

    Route::get('ferroprogramas/{id}','ProgramasSenalesController@ferroprogramasenales')->name('ferroprogramasenales');


    Route::resource('gestion/registrodepasantes', 'RegistroPasanteController');
    Route::get('gestion/registrodepasantes/ferronotificacionriesgo/{id}','RegistroPasanteController@ferronotificacionriesgo')->name('ferronotificacionriesgo');
    Route::get('gestion/registrodepasantes/ferronotificacionriesgoexcelente/{id}','RegistroPasanteController@ferronotificacionriesgoexcelente')->name('ferronotificacionriesgoexcelente');
    Route::get('gestion/registrodepasantes/ferroevaluacionpasantebueno/{id}','RegistroPasanteController@ferroevaluacionpasantebueno')->name('ferroevaluacionpasantebueno');
    Route::get('gestion/registrodepasantes/ferroevaluacionpasantemuybueno/{id}','RegistroPasanteController@ferroevaluacionpasantemuybueno')->name('ferroevaluacionpasantemuybueno');
    Route::get('gestion/registrodepasantes/ferroevaluacionpasanteregular/{id}','RegistroPasanteController@ferroevaluacionpasanteregular')->name('ferroevaluacionpasanteregular');
    Route::get('gestion/registrodepasantes/ferroevaluacionpasantedeficiente/{id}','RegistroPasanteController@ferroevaluacionpasantedeficiente')->name('ferroevaluacionpasantedeficiente');

    Route::get('asistencia','UserController@asistencia')->name('asistenciaControl');

    Route::get('usuarios','UserController@usuarios')->name('usuarioControl');

    // Registration Routes...

     Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');
     Route::post('register', 'Auth\RegisterController@register');


});

Route::group(['middleware' => 'auth'], function () {
	Route::resource('user', 'UserController', ['except' => ['show']]);
	Route::get('profile', ['as' => 'profile.edit', 'uses' => 'ProfileController@edit']);
	Route::put('profile', ['as' => 'profile.update', 'uses' => 'ProfileController@update']);
	Route::put('profile/password', ['as' => 'profile.password', 'uses' => 'ProfileController@password']);
});

